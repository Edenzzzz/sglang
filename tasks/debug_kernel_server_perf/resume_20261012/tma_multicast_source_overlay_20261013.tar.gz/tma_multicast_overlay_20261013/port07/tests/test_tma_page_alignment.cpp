#include <cassert>
#include <cstdio>
#include <vector>

#include <flashinfer/attention/fused_plan.cuh>

int main() {
  std::vector<flashinfer::FusedWorkItem> work = {
      {0, 0, 128, 0, 129, 0},
      {1, 0, 128, 128, 4097, 1},
      {2, 0, 128, 4096, 8193, 2},
  };
  assert(flashinfer::FusedTmaPageAlignedWork(work, 128));
  for (uint32_t page_size : {0u, 1u, 64u, 256u}) {
    assert(!flashinfer::FusedTmaPageAlignedWork(work, page_size));
  }
  for (int32_t start : {-128, -1, 1, 127, 129}) {
    work[0].kv_start = start;
    assert(!flashinfer::FusedTmaPageAlignedWork(work, 128));
  }
  work[0].kv_start = 0;
  for (int32_t end : {-1, 0}) {
    work[0].kv_end = end;
    assert(!flashinfer::FusedTmaPageAlignedWork(work, 128));
  }
  assert(flashinfer::FusedTmaPageAlignedWork({}, 128));
  std::puts("TMA page alignment and partial-tail bounds: 13 cases PASS");
}

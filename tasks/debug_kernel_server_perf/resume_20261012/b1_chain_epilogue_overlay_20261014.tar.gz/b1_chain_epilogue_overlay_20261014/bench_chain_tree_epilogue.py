import argparse
import json
from pathlib import Path

import torch
import triton

from sglang.srt.speculative.eagle_utils import TreeMaskMode, build_tree_kernel_efficient
from sglang.srt.speculative.fused_chain_tree import build_fused_chain_tree


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    results = []
    for batch_size in (1, 8, 32, 48):
        for length in (4096, 65536, 131072, 262144):
            width = 4
            bonus = torch.arange(batch_size, device="cuda", dtype=torch.int32)
            draft = torch.arange(batch_size * (width - 1), device="cuda").reshape(
                batch_size, width - 1
            )
            lengths = torch.full(
                (batch_size,), length, device="cuda", dtype=torch.int64
            )
            parents = (
                torch.arange(-1, width - 2, device="cuda")
                .expand(batch_size, -1)
                .contiguous()
            )
            selected = (
                torch.arange(width - 1, device="cuda")
                .expand(batch_size, -1)
                .contiguous()
            )
            for fill_prefix in (True, False):

                def baseline():
                    return build_tree_kernel_efficient(
                        bonus,
                        parents,
                        selected,
                        draft,
                        lengths,
                        batch_size * length,
                        1,
                        width - 1,
                        width,
                        TreeMaskMode.FULL_MASK,
                        fill_prefix_mask=fill_prefix,
                    )

                def candidate():
                    return build_fused_chain_tree(
                        bonus,
                        draft,
                        lengths,
                        batch_size * length,
                        fill_prefix_mask=fill_prefix,
                    )

                baseline()
                candidate()
                baseline_times = [
                    triton.testing.do_bench_cudagraph(baseline, rep=60) * 1000
                    for repeat in range(3)
                ]
                candidate_times = [
                    triton.testing.do_bench_cudagraph(candidate, rep=60) * 1000
                    for repeat in range(3)
                ]
                row = {
                    "batch": batch_size,
                    "context": length,
                    "width": width,
                    "fill_prefix": fill_prefix,
                    "baseline_us": baseline_times,
                    "candidate_us": candidate_times,
                }
                print(json.dumps(row), flush=True)
                results.append(row)
                args.output.write_text(json.dumps(results, indent=2) + "\n")
    print("CHAIN_EPILOGUE_BENCH_PASS", len(results), flush=True)


if __name__ == "__main__":
    main()

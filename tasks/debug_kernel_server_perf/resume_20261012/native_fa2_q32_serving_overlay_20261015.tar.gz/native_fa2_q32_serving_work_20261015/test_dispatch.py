import ast
import logging
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import torch


class TestStockDispatch(unittest.TestCase):
    def exercise(self, stock, phase, split_rows=False, kv_splits=1, query_tile=0, maximum_query=4):
        source = Path(__file__).resolve().parent / "candidate/flashinfer_backend.py"
        module = ast.parse(source.read_text())
        method = next(node for node in ast.walk(module) if isinstance(node, ast.FunctionDef) and node.name == "_native_pdl_dispatch")
        calls = []

        def primary(*arguments):
            calls.append("native_primary")
            arguments[4].copy_(arguments[0] * 2)

        def dependent(*arguments):
            calls.append(("fa2", arguments[-3], arguments[-2]))
            arguments[7].copy_(arguments[0] * 2)

        def stock_primary(*arguments):
            calls.append(("stock_primary", arguments[-2]))
            arguments[3].copy_(arguments[0] * 2)

        def query_tile_run(*arguments):
            calls.append(("query_tile", arguments[-2], arguments[-1], arguments[-5], arguments[-4]))
            arguments[7].copy_(arguments[0] * 2)

        native_ops = SimpleNamespace(fused_primary_compact=primary, native_fa2_run=dependent,
                                    fused_primary_finish=lambda *arguments: calls.append("native_finish"))
        fake_torch = SimpleNamespace(**{name: getattr(torch, name) for name in ("empty", "empty_like", "bfloat16")})
        fake_torch.ops = SimpleNamespace(test_native=native_ops, stock_fa3_pdl=SimpleNamespace(run=stock_primary),
                                        native_fa2_q32=SimpleNamespace(run=query_tile_run))
        scope = {"torch": fake_torch, "os": os, "STOCK_FA3_PHASE": phase, "STOCK_FA3_PDL": stock,
                 "FUSED_SPLIT_VERIFY": False, "logger": logging.getLogger(__name__), "NATIVE_FA2_QUERY_TILE": query_tile}
        exec(compile(ast.Module(body=[method], type_ignores=[]), str(source), "exec"), scope)
        query = torch.arange(6 * 28 * 128, dtype=torch.float32).reshape(6, 28, 128).to(torch.bfloat16)
        key = torch.zeros(32, 4, 128, dtype=torch.bfloat16)
        wrapper = SimpleNamespace(**{name: None for name in (
            "_qo_indptr_buf", "_paged_kv_indptr_buf", "_paged_kv_indices_buf", "_paged_kv_last_page_len_buf",
            "_float_workspace_buffer", "_int_workspace_buffer",
        )}, _plan_info=[0, 0, 0, 64])
        backend = SimpleNamespace(page_size=1, fused_fa2_wrapper=wrapper, fused_split_calls=1,
                                  token_to_kv_pool=SimpleNamespace(get_kv_buffer=lambda layer: (key, key)))
        layer = SimpleNamespace(layer_id=0, head_dim=128, v_head_dim=128,
                                tp_q_head_num=28, tp_k_head_num=4, tp_v_head_num=4, scaling=0.1)
        plan = {"fa3_span": None if split_rows else (0, 2), "fa2_span": None if split_rows else (2, 6),
                "fa3_tok": torch.tensor([0, 2]) if split_rows else torch.tensor([0, 1]),
                "fa2_tok": torch.tensor([1, 3, 4, 5]) if split_rows else torch.tensor([2, 3, 4, 5])}
        kernel = {name: None for name in ("empty_lse", "empty_timeline", "kv_indices", "pers_int", "pers_float",
                                         "kv_lens", "q_indptr", "kv_indptr", "stock_lse", "stock_pages",
                                         "stock_partial_o", "stock_partial_lse", "stock_splits", "stock_counter")}
        kernel.update(op_namespace="test_native", stock_selected=stock, stock_split_count=kv_splits, pers_plan=[], sm_split=112,
                      num_requests=1, max_pages=32, max_q=2, fa2_max_query=maximum_query)
        paged = SimpleNamespace(paged_kv_view=lambda value, *arguments: value)
        with patch.dict(sys.modules, {"sglang.srt.mem_cache.layout.paged_view": paged}):
            output = scope["_native_pdl_dispatch"](backend, query, layer, plan, kernel, True, 0, None, None)
        torch.testing.assert_close(output, query * 2, rtol=0, atol=0)
        independent = not stock or phase == 2
        dependent_call = ("fa2", independent, independent)
        if query_tile and 16 < maximum_query * 7 <= 32:
            dependent_call = ("query_tile", 32 if query_tile == 32 else 0, maximum_query, independent, independent)
        if stock:
            expected = [("stock_primary", phase), dependent_call]
            if kv_splits > 1:
                expected.append(("stock_primary", 3))
            self.assertEqual(calls, expected)
        else:
            self.assertEqual(calls, ["native_primary", dependent_call, "native_finish"])

    def test_stock_and_native_call_order(self):
        for phase in (0, 1, 2):
            for split_rows in (False, True):
                for kv_splits in (1, 4):
                    self.exercise(True, phase, split_rows, kv_splits)
        self.exercise(False, 2)

    def test_query_tile_selection_and_order(self):
        for query_tile in (32, 64):
            for maximum_query in (1, 3, 4, 8):
                for scattered in (False, True):
                    for phase in (0, 2):
                        with self.subTest(tile=query_tile, maximum=maximum_query, scattered=scattered, phase=phase):
                            self.exercise(True, phase, scattered, 4, query_tile, maximum_query)


if __name__ == "__main__":
    unittest.main(verbosity=2)

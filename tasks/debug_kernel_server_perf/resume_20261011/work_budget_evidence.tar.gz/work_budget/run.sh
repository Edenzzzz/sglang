set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi
export HEADS=28,4 SM_SPLIT=64 FUSED_REFERENCE_WORKSPACE_BYTES=16
for mode in fa2 fa3_1chunk fa3_split mixed_verify; do
 FUSED_WORK_BUDGET_SPLIT=1 MODE=$mode /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/work_budget/verify_$mode.log 2>&1
done
echo WORK_BUDGET_REFERENCE_PASS
for budget in 0 1 1 0; do
 run=${run:-0}; run=$((run+1))
 FUSED_WORK_BUDGET_SPLIT=$budget MODE=mixed_verify TIME_AB=1 TIME_ITERS=100 /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/work_budget/timing_${run}_budget$budget.log 2>&1
done
echo WORK_BUDGET_AB_DONE

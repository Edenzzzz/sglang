#include <cassert>
#include <cstdio>
#include <vector>

#include <flashinfer/attention/fused_plan.cuh>

int main() {
  assert((flashinfer::FusedRoleKvChunkLengths(65536, 4096, 0) ==
          std::vector<int32_t>{4096, 4096, 4096, 65536}));
  assert((flashinfer::FusedRoleKvChunkLengths(65536, 4096, 8192) ==
          std::vector<int32_t>{4096, 4096, 4096, 8192}));
  assert((flashinfer::FusedRoleKvChunkLengths(65536, 0, 256) ==
          std::vector<int32_t>{65536, 65536, 65536, 256}));
  assert((flashinfer::FusedRoleKvChunkLengths(65536, 0, 0) ==
          std::vector<int32_t>{65536, 65536, 65536, 65536}));
  assert((flashinfer::FusedRoleKvChunkLengths(0, 0, 0) ==
          std::vector<int32_t>{1, 1, 1, 1}));
  std::puts("Independent FA2/FA3 chunk metadata: PASS");
}

import importlib.util
import os
from pathlib import Path
import unittest
from unittest.mock import patch

import numpy as np


class TestDecodeGuard(unittest.TestCase):
    def module(self, guard):
        source = Path(__file__).parent / "candidate/mixed_dispatch.py"
        environment = {name: value for name, value in os.environ.items() if not name.startswith("SGLANG_FUSED_")}
        environment["SGLANG_FUSED_DECODE_GUARD"] = str(guard)
        with patch.dict(os.environ, environment, clear=True):
            specification = importlib.util.spec_from_file_location("dispatch_candidate", source)
            module = importlib.util.module_from_spec(specification)
            specification.loader.exec_module(module)
        return module

    def test_long_prefill_exclusion_is_guard_only(self):
        query_lengths = [512, *([4] * 46)]
        kv_lengths = [65536, *([49152] * 46)]
        for guard in (0, 1):
            with self.subTest(guard=guard):
                with patch.dict(os.environ, {"SGLANG_FUSED_DISPATCH": "", "SGLANG_FUSED_FORCE_MIXED": "0"}):
                    mask, query_tiles, kv_tiles = self.module(guard).split_classes(query_lengths, kv_lengths, 7)
                np.testing.assert_array_equal(mask, [not guard, *([False] * 46)])
                self.assertEqual(query_tiles[0], 28)
                self.assertEqual(kv_tiles[0], 512)

    def test_short_prefill_and_verify_selection_unchanged(self):
        query_lengths = [512, *([4] * 46)]
        kv_lengths = [512, *([49152] * 46)]
        for guard in (0, 1):
            with patch.dict(os.environ, {"SGLANG_FUSED_DISPATCH": "", "SGLANG_FUSED_FORCE_MIXED": "0"}):
                mask, _, _ = self.module(guard).split_classes(query_lengths, kv_lengths, 7)
            np.testing.assert_array_equal(mask, [True, *([False] * 46)])

    def test_verify_only_stays_fa2(self):
        for guard in (0, 1):
            with patch.dict(os.environ, {"SGLANG_FUSED_DISPATCH": "", "SGLANG_FUSED_FORCE_MIXED": "0"}):
                mask, _, _ = self.module(guard).split_classes([4] * 48, [131072] * 48, 7)
            self.assertFalse(mask.any())


if __name__ == "__main__":
    unittest.main(verbosity=2)

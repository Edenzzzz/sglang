// K1c2 gate: run FusedFourTaskPlan on a real batch and check the invariants the kernel relies
// on. Compiling the body proves nothing about what it produces.
#include <cuda_runtime.h>
#include <cstdio>
#include <algorithm>
#include <map>
#include <utility>
#include <vector>
#include <flashinfer/attention/fused_plan.cuh>

using namespace flashinfer;

static int failures = 0;
static void check(bool ok, const char* what) {
  printf("%-52s %s\n", what, ok ? "PASS" : "FAIL");
  if (!ok) ++failures;
}

int main() {
  // A mixed batch: two long rows routed to FA3 (so split-KV fires) and three short decode-ish
  // rows for the FA2 classes -- the shape the 4-mode step actually produces.
  const uint32_t B = 5, HQ = 28, HKV = 7, D = 128, PAGE = 1, SM = 132, SM_SPLIT = 16;
  std::vector<int32_t> qo{512, 384, 1, 1, 1};
  std::vector<int32_t> kvl{8192, 6144, 300, 512, 128};
  std::vector<char> mask{1, 1, 0, 0, 0};
  std::vector<int32_t> qo_indptr(B + 1, 0), kv_indptr(B + 1, 0);
  for (uint32_t i = 0; i < B; ++i) {
    qo_indptr[i + 1] = qo_indptr[i] + qo[i];
    kv_indptr[i + 1] = kv_indptr[i] + kvl[i];
  }

  const size_t IWS = 64u << 20, FWS = 512u << 20;
  void *d_int = nullptr, *d_float = nullptr, *h_pin = nullptr;
  cudaMalloc(&d_int, IWS);
  cudaMalloc(&d_float, FWS);
  cudaHostAlloc(&h_pin, IWS, cudaHostAllocDefault);

  FusedPlanInfo<4> plan;
  cudaError_t st = FusedFourTaskPlan<4, int32_t>(
      d_float, FWS, d_int, h_pin, IWS, plan, qo_indptr.data(), kv_indptr.data(), kvl.data(),
      reinterpret_cast<const bool*>(mask.data()), B, HQ, HKV, D, D, PAGE, SM_SPLIT, SM,
      /*causal=*/false, nullptr);
  cudaDeviceSynchronize();
  check(st == cudaSuccess, "FusedFourTaskPlan returns cudaSuccess");
  if (st != cudaSuccess) { printf("  %s\n", cudaGetErrorString(st)); return 1; }

  auto vec = plan.ToVector();
  check(vec.size() == 59, "plan serialises to 59 entries (15 shared + 4*11)");
  check(vec.back() == plan.num_fa3_clusters, "plan_info[-1] is num_fa3_clusters");
  check(plan.num_fa3_clusters == int64_t(SM_SPLIT),
        "num_fa3_clusters == sm_split (dispatcher checks this)");
  check(plan.num_fa3_requests == 2, "num_fa3_requests counts the masked rows");
  check(plan.max_splits_fa3 > 1, "split-KV actually fired for the long rows");
  check(plan.num_pers_clusters > 0, "FA2 queue is non-empty");

  // work_indptr must be monotonic and cover every item, per task. The FA3 task's array must have
  // exactly sm_split+1 entries: its scheduler indexes work_indptr[blockIdx.x].
  auto host_of = [&](int64_t off, size_t n) {
    std::vector<int32_t> v(n);
    cudaMemcpy(v.data(), reinterpret_cast<char*>(d_int) + off, n * sizeof(int32_t),
               cudaMemcpyDeviceToHost);
    return v;
  };
  bool mono = true, covers = true;
  for (int t = 0; t < 4; ++t) {
    const uint32_t ctas = (t == 3) ? SM_SPLIT : SM;
    auto wi = host_of(plan.tasks[t].work_indptr_offset, ctas + 1);
    if (wi.front() != 0) covers = false;
    for (uint32_t c = 0; c + 1 <= ctas; ++c)
      if (wi[c + 1] < wi[c]) mono = false;
  }
  check(mono, "work_indptr is monotonic for all four tasks");
  check(covers, "work_indptr starts at 0 for all four tasks");

  // len_kv_chunk: only task 3 is split, and the scheduler reads element [3].
  auto lkc = host_of(plan.len_kv_chunk_offset, 4);
  // NOT zero: persistent.cuh divides by len_kv_chunk unconditionally, so a 0 here is a device
  // divide-by-zero that sends unsplit FA2 rows down the split path and writes a 16 B vector at a
  // wild offset. The earlier version of this check asserted == 0 and so encoded the bug.
  check(lkc[0] > 0 && lkc[1] > 0 && lkc[2] > 0, "FA2 classes carry a non-zero span");
  check(lkc[0] >= kvl[0] && lkc[0] >= kvl[1], "FA2 span covers every row (=> 1 chunk)");
  check(lkc[3] > 0 && lkc[3] % 128 == 0, "task 3 chunk is a non-zero multiple of TILE_KV");

  // The cursor must start at zero or the drain loop skips that many FA2 clusters.
  auto cur = host_of(plan.cluster_cursor_offset, 1);
  check(cur[0] == 0, "cluster cursor starts at zero");

  // partial_indptr must agree with merge_indptr: every non-negative entry has to land inside the
  // partial slab the merge layout sized. A disagreement here is what left 511/512 rows unwritten.
  // The merge contract: merge_indptr is per PACKED Q ROW over the COMPACTED split rows, each
  // row owning num_kv_chunks consecutive slots, and partial_indptr is ONE head-agnostic base
  // per group. Checked against the writer's own address arithmetic, which is what
  // run_host_checks.sh never did.
  const size_t items3 = [&] {
    auto wi = host_of(plan.tasks[3].work_indptr_offset, SM_SPLIT + 1);
    return size_t(wi[SM_SPLIT]);
  }();
  const size_t nrows = size_t(plan.num_merge_rows);
  check(nrows > 0, "there are split rows to merge");
  auto mi = host_of(plan.merge_indptr_offset, nrows + 1);
  auto oi = host_of(plan.merge_o_indices_offset, nrows);
  check(mi[0] == 0, "merge_indptr starts at zero");
  bool rows_mono = true;
  for (size_t r = 0; r < nrows; ++r)
    if (mi[r + 1] - mi[r] <= 0) rows_mono = false;
  check(rows_mono, "every merged row owns at least one partial slot");

  // THE contract, checked directly: store_partial writes row r of a group at
  //   base + r * num_kv_chunks + kv_chunk_idx
  // and the merge reads row r's chunks consecutively from indptr[row_r]. So for every split
  // group, indptr for its rows must be base, base + chunks, base + 2*chunks, ...
  // This is the equality run_host_checks.sh never tested, and both earlier layout bugs would
  // have failed it on the first run.
  auto lkc2 = host_of(plan.len_kv_chunk_offset, 4);
  const int32_t chunks = lkc2[3] > 0 ? int32_t((kvl[0] + lkc2[3] - 1) / lkc2[3]) : 1;
  auto pi3 = host_of(plan.tasks[3].partial_indptr_offset, items3);
  bool stride_ok = true, found = false;
  for (size_t i = 0; i < items3; ++i) if (pi3[i] >= 0) { found = true; break; }
  // EXACT check, replacing an inequality that wrongly assumed one chunk count for the whole
  // batch: group the task-3 items by their OWN (batch_idx, q_start) and require every member to
  // carry the same base. Chunk counts differ per request -- here 10 for the 8192-token row and 7
  // for the 6144 one -- so any check that folds them into a single number is measuring nothing.
  auto bi3 = host_of(plan.tasks[3].batch_idx_offset, items3);
  auto qs3 = host_of(plan.tasks[3].q_start_offset, items3);
  std::map<std::pair<int32_t, int32_t>, int32_t> base_of;
  bool base_uniform = true;
  size_t with_base = 0;
  for (size_t i = 0; i < items3; ++i) {
    if (pi3[i] < 0) continue;
    ++with_base;
    const auto key = std::make_pair(bi3[i], qs3[i]);
    auto it = base_of.find(key);
    if (it == base_of.end()) {
      base_of.emplace(key, pi3[i]);
    } else if (it->second != pi3[i]) {
      base_uniform = false;
    }
  }
  check(base_uniform, "members of a group share ONE head-agnostic base");
  check(with_base == items3, "every split task-3 item got a base");
  printf("  (%zu groups, %zu items, %zu with base)\n", base_of.size(), items3, with_base);
  // rows of a group step by exactly `chunks`
  for (size_t r = 0; r + 1 < nrows && r < 8; ++r)
    if (mi[r + 1] - mi[r] != chunks) stride_ok = false;
  check(stride_ok, "merge_indptr steps by num_kv_chunks per row");
  bool oi_ok = true;
  for (size_t r = 0; r < nrows; ++r) if (oi[r] < 0) oi_ok = false;
  check(oi_ok, "merge_o_indices are valid output rows");

  printf("\n%s (%d failure%s)\n", failures ? "FAILED" : "ALL PASS", failures,
         failures == 1 ? "" : "s");
  return failures ? 1 : 0;
}

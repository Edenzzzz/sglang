"""Request-matched zero-load and token-window SLO evaluation."""

import hashlib
import json
import math


def request_key(prompt, output_len):
    encoded = json.dumps(
        {"prompt": prompt, "output_len": int(output_len)},
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode()
    return hashlib.sha256(encoded).hexdigest()


def token_arrivals(events, output_len):
    arrivals = []
    previous_count = 0
    previous_time = 0.0
    for count, timestamp in events:
        if not isinstance(count, int) or count <= previous_count or count > output_len:
            raise ValueError(
                "Token-event counts must strictly increase within the output"
            )
        if not math.isfinite(timestamp) or timestamp <= 0 or timestamp < previous_time:
            raise ValueError(
                "Token-event timestamps must be finite, positive and ordered"
            )
        arrivals.extend([timestamp] * (count - previous_count))
        previous_count, previous_time = count, timestamp
    if previous_count != output_len or not arrivals:
        raise ValueError("Token events must cover the completed output")
    return arrivals


def worst_window_tpot_ms(events, output_len, window=10):
    if window <= 0:
        raise ValueError("Token window must be positive")
    arrivals = token_arrivals(events, output_len)
    if output_len == 1:
        return 0.0
    span = min(window, output_len - 1)
    return max(
        (arrivals[index + span] - arrivals[index]) * 1000.0 / span
        for index in range(output_len - span)
    )


def validate_reference(reference):
    count = len(reference["request_keys"])
    if reference.get("max_concurrency") != 1 or reference.get("completed") != count:
        raise ValueError(
            "Reference must complete all requests at client concurrency one"
        )
    if any(reference.get("errors", [])):
        raise ValueError("Reference contains failed requests")
    fields = (
        "ttfts",
        "request_start_times",
        "request_end_times",
        "output_lens",
        "token_events",
    )
    if any(len(reference[field]) != count for field in fields):
        raise ValueError("Reference arrays have inconsistent lengths")
    previous_end = -math.inf
    for start, end in sorted(
        zip(reference["request_start_times"], reference["request_end_times"])
    ):
        if not math.isfinite(start) or not math.isfinite(end) or end <= start:
            raise ValueError("Reference has invalid request intervals")
        if start < previous_end - 1e-6:
            raise ValueError("Reference requests overlap")
        previous_end = end
    for ttft, events, output_len in zip(
        reference["ttfts"], reference["token_events"], reference["output_lens"]
    ):
        if not math.isfinite(ttft) or ttft <= 0:
            raise ValueError("Reference TTFT must be finite and positive")
        token_arrivals(events, output_len)


def score_requests(result, reference, ttft_slowdown, tpot_ms):
    validate_reference(reference)
    if result["request_keys"] != reference["request_keys"]:
        raise ValueError("Loaded and isolated requests do not match")
    if ttft_slowdown <= 0 or tpot_ms <= 0:
        raise ValueError("SLO thresholds must be positive")
    count = len(result["request_keys"])
    fields = ("ttfts", "output_lens", "token_events", "errors")
    if any(len(result[field]) != count for field in fields):
        raise ValueError("Loaded result arrays have inconsistent lengths")
    rows = []
    for index in range(count):
        threshold = reference["ttfts"][index] * ttft_slowdown * 1000.0
        failed = bool(result["errors"][index])
        window_ms = None
        ttft_ms = result["ttfts"][index] * 1000.0
        if not failed:
            if not math.isfinite(ttft_ms) or ttft_ms <= 0:
                raise ValueError("Successful request has invalid TTFT")
            window_ms = worst_window_tpot_ms(
                result["token_events"][index], result["output_lens"][index]
            )
        passed = not failed and ttft_ms <= threshold and window_ms <= tpot_ms
        rows.append(
            {
                "request_key": result["request_keys"][index],
                "ttft_ms": ttft_ms,
                "ttft_slo_ms": threshold,
                "worst_tpot_10_ms": window_ms,
                "tpot_slo_ms": tpot_ms,
                "passed": passed,
                "failed": failed,
            }
        )
    passing = sum(row["passed"] for row in rows)
    return {
        "requests": count,
        "passed": passing,
        "slo_attainment": passing / count,
        "goodput_req_s": passing / result["duration"],
        "capacity_point_feasible": (count - passing) / count < 0.1,
        "requests_detail": rows,
    }

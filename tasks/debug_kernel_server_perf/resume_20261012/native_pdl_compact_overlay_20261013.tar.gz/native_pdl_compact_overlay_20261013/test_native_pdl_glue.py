import ast
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

import torch
import numpy as np
import os


class NativePdlGlueTest(unittest.TestCase):
    def run_partition(self, fa3_indices, fa2_indices, fa3_span, fa2_span):
        source = Path(__file__).parent / "up_racefix/python/sglang/srt/layers/attention/flashinfer_backend.py"
        syntax = ast.parse(source.read_text())
        method = next(node for node in ast.walk(syntax) if isinstance(node, ast.FunctionDef) and node.name == "_native_pdl_dispatch")
        calls = []
        phase = ["prepare"]

        def primary(*arguments):
            calls.append("primary")
            arguments[4].copy_(arguments[0] + 1)
            phase[0] = "primary"

        def native(*arguments):
            self.assertEqual(phase[0], "primary")
            phase[0] = "native"
            calls.append("native")
            self.assertEqual(arguments[13:15], (True, True))
            arguments[7].copy_(arguments[0] + 2)

        def finish(*arguments):
            self.assertEqual(phase[0], "native")
            calls.append("finish")
            arguments[0].add_(2)
            phase[0] = "finish"

        operations = types.SimpleNamespace(fused_primary_compact=primary, native_fa2_run=native, fused_primary_finish=finish)

        class TorchProxy:
            ops = types.SimpleNamespace(native_test=operations)

            def __getattr__(self, name):
                return getattr(torch, name)

            def empty(self, *arguments, **keywords):
                if phase[0] == "primary":
                    raise AssertionError("Allocation between PDL launches")
                return torch.empty(*arguments, **keywords)

            def empty_like(self, *arguments, **keywords):
                if phase[0] == "primary":
                    raise AssertionError("Allocation between PDL launches")
                return torch.empty_like(*arguments, **keywords)

        environment = {"torch": TorchProxy(), "FUSED_SPLIT_VERIFY": False,
                       "logger": types.SimpleNamespace(info=lambda *arguments: None)}
        executable = ast.fix_missing_locations(ast.Module(body=[method], type_ignores=[]))
        exec(compile(executable, str(source), "exec"), environment)
        query = torch.arange(8, dtype=torch.bfloat16).view(8, 1, 1).expand(8, 28, 128).clone()
        cache = torch.zeros(8, 1, 4, 128, dtype=torch.bfloat16)
        empty = torch.empty(0)
        wrapper = types.SimpleNamespace(**{key: empty for key in (
            "_qo_indptr_buf", "_paged_kv_indptr_buf", "_paged_kv_indices_buf",
            "_paged_kv_last_page_len_buf", "_float_workspace_buffer", "_int_workspace_buffer")})
        wrapper._plan_info = [0] * 15
        backend = types.SimpleNamespace(
            page_size=1, fused_fa2_wrapper=wrapper, fused_split_calls=0,
            token_to_kv_pool=types.SimpleNamespace(get_kv_buffer=lambda layer: (cache, cache)),
        )
        layer = types.SimpleNamespace(tp_q_head_num=28, tp_k_head_num=4, tp_v_head_num=4,
                                      head_dim=128, v_head_dim=128, scaling=0.088, layer_id=0)
        plan = {"fa3_span": fa3_span, "fa2_span": fa2_span,
                "fa3_tok": torch.tensor(fa3_indices), "fa2_tok": torch.tensor(fa2_indices),
                "n_fa3": len(fa3_indices), "n_fa2": len(fa2_indices)}
        kernel = {key: empty for key in (
            "kv_indices", "fa3_int", "pers_int", "pers_float", "fa3_sparse",
            "kv_lens", "q_indptr", "kv_indptr", "empty_lse", "empty_timeline")}
        kernel.update(op_namespace="native_test", fa3_plan=[0] * 9, pers_plan=[0] * 59,
                      sm_split=112, fa3_tokens=len(fa3_indices), fa3_num_ctas=112,
                      fa3_pages=1, num_requests=len(fa3_indices), max_pages=1, max_q=4)
        kernel["pers_plan"][54] = 2
        module_name = "sglang.srt.mem_cache.layout.paged_view"
        view_module = types.ModuleType(module_name)
        view_module.paged_kv_view = lambda tensor, *arguments: tensor
        original_getitem = torch.Tensor.__getitem__

        def getitem(tensor, index):
            if phase[0] == "primary":
                raise AssertionError("Tensor indexing between PDL launches")
            return original_getitem(tensor, index)

        with patch.dict(sys.modules, {module_name: view_module}), patch.object(torch.Tensor, "__getitem__", getitem):
            output = environment["_native_pdl_dispatch"](backend, query, layer, plan, kernel, True, 0, None, None)
        expected = query.clone()
        expected[fa3_indices] += 3
        expected[fa2_indices] += 2
        self.assertTrue(torch.equal(output, expected))
        self.assertEqual(calls, ["primary", "native", "finish"])
        self.assertEqual(backend.fused_split_calls, 1)

    def test_prefix_views(self):
        self.run_partition([0, 1, 2], [3, 4, 5, 6, 7], (0, 3), (3, 8))

    def test_suffix_views(self):
        self.run_partition([5, 6, 7], [0, 1, 2, 3, 4], (5, 8), (0, 5))

    def test_scattered_partition(self):
        self.run_partition([0, 3, 5], [1, 2, 4, 6, 7], None, None)

    def test_compact_primary_planning(self):
        source = Path(__file__).parent / "up_racefix/python/sglang/srt/layers/attention/flashinfer_backend.py"
        syntax = ast.parse(source.read_text())
        method = next(node for node in ast.walk(syntax) if isinstance(node, ast.FunctionDef) and node.name == "_prepare_fused_kernel_plan")
        events = []

        class Event:
            def synchronize(self):
                events.append("wait")

            def record(self):
                events.append("record")

        def build(*arguments):
            events.append("build")
            self.assertEqual(arguments[3].tolist(), [0, 17, 49])
            self.assertEqual(arguments[4].tolist(), [0, 64, 160])
            self.assertEqual(arguments[5].tolist(), [64, 96])
            self.assertEqual(arguments[6].tolist(), [True, True])
            return [0] * 59

        class TorchProxy:
            ops = types.SimpleNamespace(native_test=types.SimpleNamespace(build_fused_plan=build))
            cuda = types.SimpleNamespace(get_device_properties=lambda device: types.SimpleNamespace(multi_processor_count=132), Event=Event)

            def __getattr__(self, name):
                return getattr(torch, name)

            def empty(self, size, **keywords):
                keywords.pop("pin_memory", None)
                return torch.empty(min(size, 128), **keywords)

        environment = {"torch": TorchProxy(), "os": os, "FUSED_NATIVE_PDL": True,
                       "FUSED_SPLIT_VERIFY": False,
                       "logger": types.SimpleNamespace(info=lambda *arguments: None)}
        executable = ast.fix_missing_locations(ast.Module(body=[method], type_ignores=[]))
        exec(compile(executable, str(source), "exec"), environment)
        loader_name = "sglang.srt.layers.attention.fused_fa3_loader"
        loader = types.ModuleType(loader_name)
        loader.load_fused_fa3 = lambda **keywords: "native_test"
        flashinfer = types.ModuleType("flashinfer")

        def unused_plan(*arguments, **keywords):
            raise AssertionError("Legacy FA3 wrapper was constructed")

        flashinfer.BatchPrefillWithPagedKVCacheWrapper = unused_plan
        backend = types.SimpleNamespace(_fused_kernel_state=None, page_size=1,
                                        req_to_token_pool=types.SimpleNamespace(req_to_token=torch.arange(512, dtype=torch.int32).reshape(4, 128)))
        updater = types.SimpleNamespace(num_qo_heads=28, num_kv_heads=4, head_dim=128,
                                        q_data_type=torch.bfloat16, data_type=torch.bfloat16)
        plan = {}
        with patch.dict(sys.modules, {loader_name: loader, "flashinfer": flashinfer}), patch.dict(os.environ, {"SGLANG_FUSED_SM_FA3": "112"}):
            for repeat in range(2):
                environment["_prepare_fused_kernel_plan"](
                    backend, None, plan, np.array([1, 3]), np.array([0, 2]),
                    np.array([4, 17, 4, 32]), torch.tensor([8, 64, 16, 96]),
                    np.array([0, 1, 2, 3]), np.array([0, 4, 21, 25, 57]), updater, torch.device("cpu"),
                )
        kernel = plan["fused_kernel"]
        self.assertIsNone(kernel["fa3_int"])
        self.assertIsNone(kernel["fa3_plan"])
        self.assertNotIn("fa3_workspace", backend._fused_kernel_state)
        self.assertEqual(kernel["fa3_tokens"], 49)
        self.assertEqual(kernel["num_requests"], 2)
        self.assertEqual(kernel["kv_indices"].tolist(), list(range(128, 192)) + list(range(384, 480)))
        self.assertEqual(events, ["build", "record", "wait", "build", "record"])


if __name__ == "__main__":
    unittest.main()

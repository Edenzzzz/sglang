/*
 * Copyright (c) 2024 by FlashInfer team.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef FLASHINFER_ATTENTION_HOPPER_SPARSE_MAINLOOP_CUH_
#define FLASHINFER_ATTENTION_HOPPER_SPARSE_MAINLOOP_CUH_

#include <cutlass/array.h>
#include <cutlass/cutlass.h>
#include <cutlass/numeric_conversion.h>
#include <cutlass/numeric_types.h>
#if FLASHINFER_FA3_KV_SHARE
#include <cooperative_groups.h>
#include <cstdlib>
#endif

#include "../../fastdiv.cuh"
#include "../../math.cuh"
#include "cute/tensor.hpp"
#include "cutlass/gemm/collective/collective_builder.hpp"
#include "cutlass/pipeline/pipeline.hpp"
#include "named_barrier.cuh"
#include "utils.cuh"

namespace flashinfer {

using namespace cute;

template <typename AdditionalParams, typename Ktraits, bool CAUSAL, bool MULTIITEMSCORING = false>
struct SparseCollectiveMainloop {
  using DTypeQ = typename Ktraits::DTypeQ;
  using DTypeKV = typename Ktraits::DTypeKV;
  using IdType = typename Ktraits::IdType;
  using TileShape_QKD = typename Ktraits::TileShape_QKD;
  using TileShape_PDV = typename Ktraits::TileShape_PDV;
  static constexpr int CTA_Q = get<0>(TileShape_QKD{});
  static constexpr int CTA_KV = get<1>(TileShape_QKD{});

  static constexpr int NUM_STAGES = Ktraits::NUM_STAGES;
  static constexpr int HEAD_DIM_QK = Ktraits::HEAD_DIM_QK;
  static constexpr int HEAD_DIM_VO = Ktraits::HEAD_DIM_VO;
  static_assert(HEAD_DIM_QK == HEAD_DIM_VO);
  static constexpr int NUM_COPY_THREADS = cutlass::NumThreadsPerWarpGroup;

  using GmemTiledCopyQ = cute::SM90_TMA_LOAD;
  static constexpr auto AlignmentKV = 128 / cutlass::sizeof_bits<DTypeKV>::value;
  using AlignmentTypeKV = cute::uint_byte_t<static_cast<int>(sizeof(DTypeKV)) * AlignmentKV>;
  // NOTE(Zihao): use SM80_CP_ASYNC for sparse loading of KV-cache
  using GmemCopyAtomKV = cute::Copy_Atom<SM80_CP_ASYNC_CACHEGLOBAL_ZFILL<AlignmentTypeKV>, DTypeKV>;
  using GmemTiledCopyK =
      decltype(cutlass::gemm::collective::detail::make_simt_gmem_tiled_copy<
               GmemCopyAtomKV, NUM_COPY_THREADS, AlignmentKV,
               cutlass::detail::TagToStrideB_t<cutlass::layout::ColumnMajor>,
               decltype(cute::get<1>(TileShape_QKD{})), decltype(cute::get<2>(TileShape_QKD{}))>());
  using GmemTiledCopyV =
      decltype(cutlass::gemm::collective::detail::make_simt_gmem_tiled_copy<
               GmemCopyAtomKV, NUM_COPY_THREADS, AlignmentKV,
               cutlass::detail::TagToStrideB_t<cutlass::layout::ColumnMajor>,
               decltype(cute::get<2>(TileShape_PDV{})), decltype(cute::get<1>(TileShape_PDV{}))>());

  using SmemLayoutQ = typename Ktraits::SmemLayoutQ;
  using SmemLayoutK = typename Ktraits::SmemLayoutK;
  using SmemLayoutV = typename Ktraits::SmemLayoutV;
  using SmemLayoutVt = typename Ktraits::SmemLayoutVt;

  using ShapeT = cute::Shape<int32_t, int32_t, int32_t>;
  using StrideT = cute::Shape<int64_t, _1, int64_t>;  // (N, D, H)
  using LayoutT = cute::Layout<ShapeT, StrideT>;

  using ShapeLseT = cute::Shape<int32_t, int32_t>;
  using StrideLseT = cute::Shape<_1, int64_t>;
  using LayoutLseT = cute::Layout<ShapeLseT, StrideLseT>;

  using TMA_Q = decltype(make_tma_copy(
      GmemTiledCopyQ{},
      make_tensor(make_gmem_ptr(static_cast<DTypeQ const*>(nullptr)),
                  repeat_like(StrideT{}, int32_t(0)), StrideT{}),
      SmemLayoutQ{}, select<0, 2>(TileShape_QKD{}), _1{}));  // no mcast for Q

  static constexpr bool USE_TMA_LOAD_KV = false;
  static constexpr int NUM_MMA_THREADS = size(typename Ktraits::TiledMmaQK{});
  // Verify NUM_PRODUCER_THREADS matches NUM_COPY_THREADS for sparse loading
  static_assert(Ktraits::NUM_PRODUCER_THREADS == NUM_COPY_THREADS,
                "NUM_PRODUCER_THREADS must equal NUM_COPY_THREADS for sparse/paged KV loading");
  using MainloopPipeline = typename Ktraits::MainloopPipeline;
  using PipelineParams = typename MainloopPipeline::Params;
  using PipelineState = typename MainloopPipeline::PipelineState;

  static constexpr uint32_t TmaTransactionBytesQ =
      static_cast<uint32_t>(size(SmemLayoutQ{}) * cutlass::sizeof_bits_v<DTypeQ> / 8);

  static constexpr bool UseSchedulerBarrier =
      cutlass::sizeof_bits_v<DTypeQ> == 8 ? HEAD_DIM_VO >= 128 : HEAD_DIM_VO <= 128;
  using MultiWarpgroupScheduler = flashinfer::WarpScheduler<Ktraits, UseSchedulerBarrier>;
  struct WarpScheduler {
    static CUTLASS_DEVICE void barrier_sync() {
      if constexpr (NUM_MMA_THREADS > cutlass::NumThreadsPerWarpGroup) {
        MultiWarpgroupScheduler::barrier_sync();
      }
    }
    static CUTLASS_DEVICE void barrier_arrive() {
      if constexpr (NUM_MMA_THREADS > cutlass::NumThreadsPerWarpGroup) {
        MultiWarpgroupScheduler::barrier_arrive();
      }
    }
    static CUTLASS_DEVICE void mma_init() {
      if constexpr (NUM_MMA_THREADS > cutlass::NumThreadsPerWarpGroup) {
        MultiWarpgroupScheduler::mma_init();
      } else {
        cutlass::arch::NamedBarrier::arrive(
            NUM_MMA_THREADS + Ktraits::NUM_PRODUCER_THREADS,
            static_cast<int>(NamedBarriers::kQueryEmpty));
      }
    }
  };

  // Host side kernel arguments
  struct Arguments {
    DTypeQ const* Q_ptr;
    LayoutT layout_Q;
    DTypeKV const* K_ptr;
    LayoutT layout_K;
    DTypeKV const* V_ptr;
    LayoutT layout_V;
    IdType const* kv_indices;
    int window_left;
    int64_t k_page_stride;  // Stride between pages for K (paged_k.stride(0))
    int64_t v_page_stride;  // Stride between pages for V (paged_v.stride(0))
    uint32_t page_size;     // Size of each page
    AdditionalParams additional_params;
    // Packed-GQA path only: it addresses Q rows as (token, head-in-group) pairs, which the Q
    // tensormap cannot express, so it needs the raw pointer and the group size. Defaulted and
    // LAST so every existing aggregate initialisation of this struct is unchanged -- which is
    // also why 0.7 inserting k_page_stride / v_page_stride / page_size in the MIDDLE broke our
    // call site silently rather than loudly.
    DTypeQ const* packed_Q_ptr = nullptr;
    int group_size = 1;
  };

  // Device side kernel params
  struct Params {
    LayoutT layout_Q;
    LayoutT layout_K;
    LayoutT layout_V;
    TMA_Q tma_load_Q;
    DTypeKV* K_ptr;
    DTypeKV* V_ptr;
    IdType* kv_indices;
    int window_left;
    int64_t k_page_stride;   // Stride between pages for K
    int64_t v_page_stride;   // Stride between pages for V
    uint_fastdiv page_size;  // Size of each page (as fastdiv for efficient divmod)
    AdditionalParams additional_params;
    // Packed-GQA path only: it addresses Q rows as (token, head-in-group) pairs, which the Q
    // tensormap cannot express, so it needs the raw pointer and the group size. Defaulted and
    // LAST so every existing aggregate initialisation of this struct is unchanged -- which is
    // also why 0.7 inserting k_page_stride / v_page_stride / page_size in the MIDDLE broke our
    // call site silently rather than loudly.
    DTypeQ const* packed_Q_ptr = nullptr;
    int group_size = 1;
#if FLASHINFER_FA3_KV_SHARE
    bool kv_share_enabled = false;
    bool kv_share_trace = false;
    bool kv_share_bulk = false;
#endif
  };

  static Params to_underlying_arguments(Arguments const& args) {
    Tensor mQ = make_tensor(make_gmem_ptr(args.Q_ptr), args.layout_Q);
    TMA_Q tma_load_Q =
        make_tma_copy(GmemTiledCopyQ{}, mQ, SmemLayoutQ{}, select<0, 2>(TileShape_QKD{}), _1{});
    return {args.layout_Q,
            args.layout_K,
            args.layout_V,
            tma_load_Q,
            const_cast<DTypeKV*>(args.K_ptr),
            const_cast<DTypeKV*>(args.V_ptr),
            const_cast<IdType*>(args.kv_indices),
            args.window_left,
            args.k_page_stride,            // Use stride from arguments
            args.v_page_stride,            // Use stride from arguments
            uint_fastdiv(args.page_size),  // Convert page_size to fastdiv
            args.additional_params,
            args.packed_Q_ptr,
            args.group_size
#if FLASHINFER_FA3_KV_SHARE
            , [] {
              const char* configured = std::getenv("FUSED_FA3_KV_SHARE");
              return configured != nullptr && configured[0] == '1';
            }(), [] {
              const char* configured = std::getenv("FUSED_FA3_KV_SHARE_TRACE");
              return configured != nullptr && configured[0] == '1';
            }(), [] {
              const char* configured = std::getenv("FUSED_FA3_KV_SHARE_BULK");
              return configured != nullptr && configured[0] == '1';
            }()
#endif
    };
  }

  CUTLASS_DEVICE
  static void prefetch_tma_descriptors(Params const& mainloop_params) {
    cute::prefetch_tma_descriptor(mainloop_params.tma_load_Q.get_tma_descriptor());
  }

  CUTLASS_DEVICE
  // causal_kv_len: the ABSOLUTE causal bound for this item (kv_total - chunk_base). -1 means
  // "same as kv_len", which is right for every unsplit item and for upstream's scheduler. It must
  // be separate from kv_len because kv_len is also the iteration bound below.
  int get_num_kv_tiles(Params const& mainloop_params, int q_tile_idx, const int qo_len,
                       const int kv_len, const int causal_kv_len = -1) {
    static constexpr int CTA_Q = get<0>(TileShape_QKD{});
    static constexpr int CTA_KV = get<1>(TileShape_QKD{});
    int num_kv_tiles = cute::ceil_div(kv_len, CTA_KV);
    if constexpr (CAUSAL) {
#ifdef FLASHINFER_FUSED_PACKED_Q
      // PACKED-GQA causal kv-tile count. Same correction as col_limit_right in mainloop_mma.cuh,
      // in a second place: 0.7's `(q_tile_idx + 1) * CTA_Q + kv_len - qo_len` is token-indexed,
      // but our unified FA3 role tiles over PACKED rows, so both the tile extent and qo_len are
      // G times too large on the q axis.
      //
      // MEASURED consequence, which is how this was found: at G=4 with 128 tokens (512 packed
      // rows, 4 q tiles) the stock expression gives, for q tile 0,
      //     (0 + 1) * 128 + 128 - 512 = -256  ->  num_kv_tiles <= 0  ->  EARLY EXIT, NO STORE.
      // Only q tile 3 survived (512 + 128 - 512 = 128), so exactly 32 of 128 token rows were
      // written and the other 96 stayed zero -- while the scheduler was correctly dispatching all
      // 28 items (7 per q tile, span=1, nchunks=1, partial=-1, verified by probe). The defect was
      // entirely inside this bound.
      //
      // The tile's last packed row is (q_tile_idx + 1) * CTA_Q - 1, whose TOKEN is that divided
      // by G; the causal bound is that token + 1 + kv_len - qo_tokens. At G=1 this reduces to
      // 0.7's expression exactly, which is why the G=1 arms passed either way.
      const int g_pk = mainloop_params.group_size;
      const int last_tok = ((q_tile_idx + 1) * CTA_Q - 1) / g_pk;
      const int ckv = (causal_kv_len >= 0) ? causal_kv_len : kv_len;
      num_kv_tiles =
          std::min(num_kv_tiles, cute::ceil_div(last_tok + 1 + ckv - qo_len / g_pk, CTA_KV));
#else
      const int ckv = (causal_kv_len >= 0) ? causal_kv_len : kv_len;
      num_kv_tiles = std::min(num_kv_tiles,
                              cute::ceil_div((q_tile_idx + 1) * CTA_Q + ckv - qo_len, CTA_KV));
#endif
    }
    if constexpr (MULTIITEMSCORING) {
      // TODO(packed-GQA): token-indexed, so wrong by G on the packed path for the same reason as
      // the CAUSAL branch above. Unreachable here -- MULTIITEMSCORING is false for every
      // configuration the fused kernel instantiates -- so this is not a silent fallback, but
      // enabling it on the packed path needs the same /group_size treatment.
      num_kv_tiles = std::min(num_kv_tiles,
                              cute::ceil_div((q_tile_idx + 1) * CTA_Q + kv_len - qo_len, CTA_KV));
    }

    return num_kv_tiles;
  }

  template <bool LEFT_SLIDING_WINDOW, typename BlockCoord, typename Scheduler,
            typename SharedStorage>
  CUTLASS_DEVICE void load(Params const& mainloop_params, MainloopPipeline pipeline_k,
                           MainloopPipeline pipeline_v, PipelineState& smem_pipe_write_k,
                           PipelineState& smem_pipe_write_v, SharedStorage& shared_storage,
                           Scheduler& scheduler, typename Scheduler::Params const& scheduler_params,
                           typename Scheduler::WorkTileInfo& work_tile_info,
                           BlockCoord const& block_coord, int work_idx,
                           const int num_kv_tiles_outside_items_window = 0,
                           const int num_kv_tiles_prefix = 0, int* dbg_commit_k = nullptr,
                           int* dbg_commit_v = nullptr, int* dbg_sig = nullptr) {
    int thread_idx = threadIdx.x;
    int warp_idx_in_warpgroup = __shfl_sync(0xffffffff, (thread_idx / 32) % 4, 0);
    Tensor sQ = make_tensor(make_smem_ptr(shared_storage.smem_q.data()), SmemLayoutQ{});
    Tensor sK = make_tensor(make_smem_ptr(shared_storage.smem_k.data()), SmemLayoutK{});
    Tensor sV = make_tensor(make_smem_ptr(shared_storage.smem_v.data()), SmemLayoutV{});

    Tensor mQ = mainloop_params.tma_load_Q.get_tma_tensor(mainloop_params.layout_Q.shape());

    auto [q_tile_idx, qo_head_idx, kv_head_idx, qo_indptr, kv_indptr, qo_len, kv_len, batch_idx] =
        block_coord;

#if FLASHINFER_FA3_KV_SHARE
    const uint32_t cluster_rank = cute::block_rank_in_cluster();
    const uint32_t peer_rank = cluster_rank ^ 1u;
    bool share_kv = false;
    if constexpr (!LEFT_SLIDING_WINDOW && !MULTIITEMSCORING &&
                  fused_has_causal_kv_len<typename Scheduler::WorkTileInfo>::value) {
      if (mainloop_params.kv_share_enabled) {
        const auto peer = scheduler.get_peer_work(scheduler_params, work_tile_info);
        if (peer.is_valid(scheduler_params) && peer.q_tile_idx * CTA_Q < peer.qo_len &&
            peer.qo_indptr == qo_indptr && peer.kv_indptr == kv_indptr &&
            peer.qo_len == qo_len && peer.kv_len == kv_len && peer.kv_head_idx == kv_head_idx &&
            peer.causal_kv_len == work_tile_info.causal_kv_len) {
          const int tile_count = get_num_kv_tiles(
              mainloop_params, q_tile_idx, qo_len, kv_len, work_tile_info.causal_kv_len);
          const int peer_tile_count = get_num_kv_tiles(
              mainloop_params, peer.q_tile_idx, peer.qo_len, peer.kv_len, peer.causal_kv_len);
          share_kv = tile_count > 0 && tile_count == peer_tile_count;
        }
      }
    }
    if (share_kv && mainloop_params.kv_share_trace && threadIdx.x == 0) {
      ++shared_storage.kv_share_items;
      if (mainloop_params.kv_share_bulk) ++shared_storage.kv_share_bulk_items;
    }
#endif

#if FUSED_Q_REUSE_FENCE
    // CROSS-ITEM Q FENCE (ours). Every write to smem_q is below this point.
    //
    // smem_q is ONE buffer reused by every work item this CTA runs. TiledMmaQK is
    // GMMA::ss_op_selector, so tSrQ is a smem DescriptorIterator rather than a register fragment
    // and the consumer re-reads sQ on EVERY kv tile -- not just the first. Stock's only cross-item
    // fence, barrier_O, sits BELOW the Q load and is an sO/smem_v handshake in any case, so
    // nothing stopped the refill for item N+1 landing while item N was still reading sQ.
    //
    // Item 0 has no predecessor, hence the guard. barrier_Qdone takes exactly one arrival per
    // item, so waiting for item N-1's completion is parity (N-1) % 2 -- the same convention
    // barrier_Q uses one line below, where the k-th completion is awaited with parity k % 2.
    if (work_idx != 0) {
      shared_storage.barrier_Qdone.wait((work_idx - 1) % 2);
    }
#endif

    // Prepare the TMA loads
    Tensor gQ = get_local_tile_tensor(mQ, select<0, 2>(TileShape_QKD{}), qo_head_idx, qo_indptr,
                                      qo_len)(_, _, q_tile_idx);  // (Q, D)

    Tensor sQ_x = make_tensor(sQ.data(), make_layout(sQ.layout(), Layout<_1>{}));
    Tensor gQ_x = make_tensor(gQ.data(), make_layout(gQ.layout(), Layout<_1>{}));
    auto [tQgQ, tQsQ] =
        tma_partition(mainloop_params.tma_load_Q, _0{}, Layout<_1>{}, group_modes<0, 2>(sQ_x),
                      group_modes<0, 2>(gQ_x));  // (TMA), (TMA)

    // load and mma MUST agree on the tile count or the pipeline deadlocks, so both take the
    // same absolute causal bound off work_tile_info.
    int num_kv_tiles = get_num_kv_tiles(mainloop_params, q_tile_idx, qo_len, kv_len,
                                        fused_causal_kv_len(work_tile_info, kv_len));
    int kv_tile_idx = num_kv_tiles - 1;
    int swa_begin_kv_tile_idx = 0;
    if constexpr (LEFT_SLIDING_WINDOW) {
      swa_begin_kv_tile_idx = get_swa_begin_kv_tile_idx<CTA_Q, CTA_KV>(mainloop_params.window_left,
                                                                       q_tile_idx, qo_len, kv_len);
    }

    constexpr int HEAD_DIM_QK = get<2>(TileShape_QKD{});
    constexpr int HEAD_DIM_VO = get<1>(TileShape_PDV{});
    constexpr int CTA_KV = get<1>(TileShape_QKD{});

    // Store base pointers and indices for manual page table lookup
    DTypeKV* K_ptr_base = mainloop_params.K_ptr + kv_head_idx * stride<2>(mainloop_params.layout_K);
    DTypeKV* V_ptr_base = mainloop_params.V_ptr + kv_head_idx * stride<2>(mainloop_params.layout_V);
    IdType const* kv_indices_ptr = mainloop_params.kv_indices + kv_indptr;
    // Use the page stride (stride between pages) and stride within page
    int64_t k_page_stride = mainloop_params.k_page_stride;
    int64_t v_page_stride = mainloop_params.v_page_stride;
    int64_t k_stride_n =
        stride<0>(mainloop_params.layout_K);  // Stride within page (between tokens)
    int64_t v_stride_n = stride<0>(mainloop_params.layout_V);

    // Create dummy tensors for partitioning with contiguous column-major layout
    // NOTE: We use a virtual contiguous layout for correct partitioning,
    // actual addressing uses page table lookup
    Tensor gK =
        make_tensor(make_gmem_ptr(static_cast<DTypeKV*>(nullptr)), make_shape(CTA_KV, HEAD_DIM_QK),
                    make_stride(HEAD_DIM_QK, _1{}));  // Column-major: (KV, D)
    Tensor gK_tiled =
        local_tile(gK, select<1, 2>(TileShape_QKD{}), make_coord(_, _0{}));  // (KV, D_K, kv)
    Tensor gV =
        make_tensor(make_gmem_ptr(static_cast<DTypeKV*>(nullptr)), make_shape(CTA_KV, HEAD_DIM_VO),
                    make_stride(HEAD_DIM_VO, _1{}));  // Column-major: (KV, D)
    Tensor gV_tiled =
        local_tile(gV, select<2, 1>(TileShape_PDV{}), make_coord(_, _0{}));  // (KV, D_V, kv)
    Tensor cK = cute::make_identity_tensor(gK_tiled.shape());
    Tensor cV = cute::make_identity_tensor(gV_tiled.shape());

    GmemTiledCopyK gmem_tiled_copy_k;
    GmemTiledCopyV gmem_tiled_copy_v;
    auto gmem_thr_copy_k = gmem_tiled_copy_k.get_slice(thread_idx);
    auto gmem_thr_copy_v = gmem_tiled_copy_v.get_slice(thread_idx);

    Tensor tKgK = gmem_thr_copy_k.partition_S(gK_tiled);  // (CPY, CPY_KV, CPY_D, kv)
    Tensor tKsK = gmem_thr_copy_k.partition_D(sK);        // (CPY, CPY_KV, CPY_D, PIPE)
    Tensor tVgV = gmem_thr_copy_v.partition_S(gV_tiled);  // (CPY, CPY_KV, CPY_D, kv)
    Tensor tVsV = gmem_thr_copy_v.partition_D(sV);        // (CPY, CPY_KV, CPY_D, PIPE)
    Tensor tKcK = gmem_thr_copy_k.partition_D(cK);        // (CPY, CPY_KV, CPY_D, kv)
    Tensor tVcV = gmem_thr_copy_v.partition_D(cV);        // (CPY, CPY_KV, CPY_D, kv)

    int valid_last_kv_tile_size = std::min<int>(kv_len - kv_tile_idx * CTA_KV, CTA_KV);
    auto kv_tile_idx_decrement = [&](int kv_tile_idx) {
      int result = kv_tile_idx - 1;
      if constexpr (MULTIITEMSCORING) {
        if ((kv_tile_idx == num_kv_tiles_outside_items_window) &
            (kv_tile_idx >= num_kv_tiles_prefix)) {
          result = num_kv_tiles_prefix - 1;
        }
      }
      return result;
    };

    // FA3-style cooperative loading: store pre-computed base offset for each KV position
    int64_t my_kv_offset[2];  // Rolling buffer: page_idx * page_stride + entry_idx * stride_n
    int parity = 0;           // Buffer parity for double buffering, toggled with ^= 1

    // Group organization based on partition strategy
    constexpr int NUM_KV_PER_ITER = decltype(size<1>(tKcK))::value;   // e.g., 12
    constexpr int KV_STRIDE = CTA_KV / NUM_KV_PER_ITER;               // 96/12 = 8
    constexpr int NUM_GROUPS = KV_STRIDE;                             // 8 groups (one per lane)
    constexpr int THREADS_PER_GROUP = NUM_COPY_THREADS / NUM_GROUPS;  // 128/8 = 16
    constexpr int NUM_ITERS_PER_GROUP = NUM_KV_PER_ITER;              // 12 iterations per group

    int group_id = thread_idx / THREADS_PER_GROUP;         // 0-7
    int thread_in_group = thread_idx % THREADS_PER_GROUP;  // 0-15

    // Prefetch: compute page_idx * page_stride + entry_idx * stride_n
    // NOTE: Assumes K and V have same strides (asserted on host side)
    // Uses parity to select buffer slot, caller must toggle parity after load
    auto prefetch_kv_offset = [&](int kv_tile_idx, bool use_predicate) {
      int kv_base_idx = kv_tile_idx * CTA_KV;

      int kv_idx_read = kv_base_idx + group_id + thread_in_group * KV_STRIDE;
      bool valid_read =
          thread_in_group < NUM_ITERS_PER_GROUP && (!use_predicate || kv_idx_read < kv_len);

      if (valid_read) {
        // Use divmod to find page and offset within page
        uint32_t page_iter, entry_idx;
        mainloop_params.page_size.divmod(kv_idx_read, page_iter, entry_idx);
        IdType page_idx = kv_indices_ptr[page_iter];
        // Pre-compute: page_idx * page_stride + entry_idx * stride_n
        my_kv_offset[parity] = page_idx * k_page_stride + entry_idx * k_stride_n;
      } else {
        my_kv_offset[parity] = 0;
      }
    };

    // Unified helper lambda to load K or V with pre-computed offsets
    // Uses parity to select buffer slot, caller must toggle parity after load
    auto load_kv_with_gather = [&](auto&& tXsX, auto&& tXcX, auto&& shared_tensor,
                                   DTypeKV* base_ptr, int kv_tile_idx,
                                   int stage_idx, bool use_predicate) {
      using Vec = AlignmentTypeKV;
      constexpr int VecSize = sizeof(Vec) / sizeof(DTypeKV);

      int kv_base_idx = kv_tile_idx * CTA_KV;
#if FUSED_TILE_TRACE
      const int dbg_work_idx = work_idx;
#endif

      auto dst = recast<Vec>(flatten(tXsX(_, _, _, stage_idx)));
      auto c = flatten(tXcX(_, _, _, kv_tile_idx));
#if FLASHINFER_FA3_KV_SHARE
      constexpr uint32_t stage_elements = decltype(size<0>(shared_tensor))::value *
                                          decltype(size<1>(shared_tensor))::value;
      constexpr uint32_t half_bytes = stage_elements * sizeof(DTypeKV) / 2;
      static_assert(half_bytes % 16 == 0);
      auto* stage_base = &shared_tensor(0, 0, stage_idx);
      const uint32_t stage_address = cute::cast_smem_ptr_to_uint(stage_base);
#endif

      constexpr unsigned FULL_MASK = 0xffffffff;

      // Load using FA3-style shuffle with pre-computed offsets
      CUTLASS_PRAGMA_UNROLL
      for (int i = 0; i < size(dst); ++i) {
        auto coord = c(VecSize * i);
        int kv_offset = get<0>(coord);
        int d_idx = get<1>(coord);
        int kv_idx = kv_base_idx + kv_offset;
        bool guard = !use_predicate || kv_idx < kv_len;

        // Shuffle the pre-computed offset (page_idx * page_stride + entry_idx * stride_n)
        int src_thread = group_id * THREADS_PER_GROUP + kv_offset / KV_STRIDE;
#if FLASHINFER_FA3_PARTIAL_PROBE
        // The shuffle takes the offset from `group_id * THREADS_PER_GROUP + kv_offset/KV_STRIDE`,
        // using THIS thread's group_id. prefetch_kv_offset stored, in thread (g, t), the offset
        // for kv_offset == g + t * KV_STRIDE. So the fetch is only correct when
        //     kv_offset % KV_STRIDE == group_id
        // for every (thread, i) pair. Where it does not hold, the thread reads another kv row's
        // page offset and loads the WRONG keys -- and kv_offset 0 still resolves correctly for
        // group 0, which is the measured "only key 0 right" signature.
        //
        // EXPECTED OUTPUT, stated before running:
        //   * one [kvinv-dims] line per block (gated threadIdx.x == 0) giving the constants;
        //   * [kvinv-bad] ONLY if the invariant is violated, at most once per thread;
        //   * one [kvinv-ok] line per block reporting how many (thread, i) pairs thread 0
        //     checked -- so "no bad lines" cannot be confused with "the probe never ran".
        if (threadIdx.x == 0 && i == 0) {
          printf("[kvinv-dims] blk=%u CTA_KV=%d NUM_KV_PER_ITER=%d KV_STRIDE=%d NUM_GROUPS=%d "
                 "THREADS_PER_GROUP=%d NUM_ITERS_PER_GROUP=%d size(dst)=%d NUM_COPY_THREADS=%d\n",
                 blockIdx.x, int(CTA_KV), int(NUM_KV_PER_ITER), int(KV_STRIDE), int(NUM_GROUPS),
                 int(THREADS_PER_GROUP), int(NUM_ITERS_PER_GROUP), int(size(dst)),
                 int(NUM_COPY_THREADS));
        }
        if ((kv_offset % KV_STRIDE) != group_id) {
          if (i == 0 || threadIdx.x == 0) {
            printf("[kvinv-bad] blk=%u tid=%u i=%d kv_offset=%d kv_offset%%KV_STRIDE=%d "
                   "group_id=%d src_thread=%d (WRONG ROW SHUFFLED)\n",
                   blockIdx.x, threadIdx.x, i, kv_offset, kv_offset % KV_STRIDE, group_id,
                   src_thread);
          }
        }
        if (threadIdx.x == 0 && i == size(dst) - 1) {
          int checked = 0, bad = 0;
          CUTLASS_PRAGMA_UNROLL
          for (int j = 0; j < size(dst); ++j) {
            auto cj = c(VecSize * j);
            ++checked;
            if ((get<0>(cj) % KV_STRIDE) != group_id) ++bad;
          }
          printf("[kvinv-ok] blk=%u tid=0 checked=%d bad=%d\n", blockIdx.x, checked, bad);
        }
#endif
#if FUSED_PIPE_COUNT
        // PRE-REGISTERED (see the doc entry written before this ran): the sequence of
        // (kv_tile_idx, parity) pairs THIS THREAD actually gathered. Registers only; compared
        // within the warp after the loop, so silence is the pass condition.
        if (dbg_sig) *dbg_sig = *dbg_sig * 31 + (kv_tile_idx * 2 + parity);
#endif
#if FUSED_TILE_TRACE
        // IS THE DETERMINISTIC SEQUENCE CORRECT? The signature proved it is the SAME every run, not
        // that it is right. One block, one item, one thread, first element only -- so the output is
        // ~32 lines and directly checkable against the fixture's geometry rather than against
        // another arm of the kernel.
        //
        // EXPECTED, stated before running: this fixture is kv=2048 with CTA_KV=128 and a full
        // causal bound, so an item must gather tiles 15,14,...,0 exactly once each for K and once
        // each for V, with stage alternating 0,1,0,1,... Any repeat, gap or out-of-order index is
        // the deterministic wrong-tile bug.
        if (blockIdx.x == 0 && threadIdx.x == 0 && i == 0) {
          printf("[tile] work=%d kv_tile_idx=%d parity=%d stage=%d kv_len=%d\n", dbg_work_idx,
                 kv_tile_idx, parity, stage_idx, kv_len);
        }
#endif
        int64_t base_offset = __shfl_sync(FULL_MASK, my_kv_offset[parity], src_thread);

        // Final address: base_ptr + base_offset + d_idx
        // where base_offset = page_idx * page_stride + entry_idx * stride_n
        Vec const* src_ptr = reinterpret_cast<Vec const*>(base_ptr + base_offset + d_idx);
#if FLASHINFER_FA3_KV_SHARE
        static_assert(HEAD_DIM_QK % (2 * VecSize) == 0);
        const uint32_t owner = mainloop_params.kv_share_bulk
                                   ? (cute::cast_smem_ptr_to_uint(&dst(i)) - stage_address) / half_bytes
                                   : uint32_t(d_idx >= HEAD_DIM_QK / 2);
        if (!share_kv || owner == cluster_rank) {
#endif
        cutlass::arch::cp_async_zfill<sizeof(Vec), cutlass::arch::CacheOperation::Global>(
            &dst(i), src_ptr, guard);
#if FLASHINFER_FA3_KV_SHARE
        }
#endif
      }
#if FLASHINFER_FA3_KV_SHARE
      if (share_kv) {
        const uint32_t bulk_phase = shared_storage.kv_share_bulk_phase;
        if (threadIdx.x == 0) {
          shared_storage.kv_share_stage = uint32_t(stage_idx);
          if (mainloop_params.kv_share_bulk) {
            shared_storage.barrier_kv_bulk.arrive_and_expect_tx(half_bytes);
          }
        }
        cute::cp_async_fence();
        cute::cp_async_wait<0>();
        cutlass::arch::fence_view_async_shared();
        shared_storage.barrier_kv_share.arrive();
        shared_storage.barrier_kv_share.arrive(peer_rank, 1);
        shared_storage.barrier_kv_share.wait(0);
        const auto cluster = cooperative_groups::this_cluster();
        const uint32_t peer_stage =
            *cluster.map_shared_rank(&shared_storage.kv_share_stage, peer_rank);
        if (mainloop_params.kv_share_bulk) {
          if (threadIdx.x == 0) {
            const uint32_t source_address = stage_address + cluster_rank * half_bytes;
            const uint32_t destination_address = cute::set_block_rank(
                cute::cast_smem_ptr_to_uint(&shared_tensor(0, 0, peer_stage)) +
                    cluster_rank * half_bytes,
                peer_rank);
            const uint32_t barrier_address = cute::set_block_rank(
                cute::cast_smem_ptr_to_uint(&shared_storage.barrier_kv_bulk), peer_rank);
            asm volatile(
                "cp.async.bulk.shared::cluster.shared::cta.mbarrier::complete_tx::bytes "
                "[%0], [%1], %2, [%3];"
                :
                : "r"(destination_address), "r"(source_address), "r"(half_bytes),
                  "r"(barrier_address)
                : "memory");
            if (mainloop_params.kv_share_trace) ++shared_storage.kv_share_bulk_copies;
          }
          shared_storage.barrier_kv_bulk.wait(bulk_phase);
          if (threadIdx.x == 0) shared_storage.kv_share_bulk_phase = bulk_phase ^ 1u;
        } else {
          auto peer_dst = recast<Vec>(flatten(tXsX(_, _, _, peer_stage)));
          CUTLASS_PRAGMA_UNROLL
          for (int index = 0; index < size(dst); ++index) {
            const auto coordinate = c(VecSize * index);
            if (uint32_t(get<1>(coordinate) >= HEAD_DIM_QK / 2) != cluster_rank) {
              dst(index) = *cluster.map_shared_rank(&peer_dst(index), peer_rank);
            }
          }
        }
        cutlass::arch::fence_view_async_shared();
        shared_storage.barrier_kv_share.arrive();
        shared_storage.barrier_kv_share.arrive(peer_rank, 1);
        shared_storage.barrier_kv_share.wait(1);
      }
#endif
    };

    // load last k-tile
    // parity=0: prefetch kv_tile_idx -> my_kv_offset[0]
    {
      prefetch_kv_offset(kv_tile_idx, true);
      pipeline_k.producer_acquire(smem_pipe_write_k);
      load_kv_with_gather(tKsK, tKcK, sK, K_ptr_base, kv_tile_idx, smem_pipe_write_k.index(), true);
      pipeline_k.producer_commit(smem_pipe_write_k, cutlass::arch::cpasync_barrier_arrive);
#if FUSED_PIPE_COUNT
      if (dbg_commit_k) ++*dbg_commit_k;
#endif
      ++smem_pipe_write_k;
      // Note: don't toggle parity here, we reuse the same buffer for V below
    }

    // All producer threads sync on kQueryEmpty barrier before loading Q
    cutlass::arch::NamedBarrier::sync(NUM_MMA_THREADS + Ktraits::NUM_PRODUCER_THREADS,
                                      static_cast<int>(NamedBarriers::kQueryEmpty));

    // load Q tile
#ifdef FLASHINFER_FUSED_PACKED_Q
    // ONE WARP, like the TMA path it replaces. 0.7 guards its Q load with
    // `if (warp_idx_in_warpgroup == 0)`, and splicing this arm in place of that `if` dropped the
    // guard, so all FOUR producer warps ran the gather. That is one cause for both FA3 symptoms:
    //   * 4x redundant cp.async into the SAME sQ rows -> the corrupted values;
    //   * 4 x 32 = 128 arrivals on a barrier_Q armed for 32 -> the phase over-advances past what
    //     the consumer waits for (work_idx % 2) -> the intermittent stall.
    // The Q-load probe showed four prints per execution and I attributed that to the print's own
    // `lane == 0` gate; it was in fact four warps executing the body.
    if (warp_idx_in_warpgroup == 0) {
      // Packed-GQA Q load for the unified role. The work item's rows are PACKED
      // rows of one kv head's group, so row p is token p / G and head
      // kv_head * G + p % G -- see get_packed_gqa_tensor, whose mapping is checked
      // by tests/test_packed_gqa_layout.cu including a tile that straddles heads.
      //
      // Correctness first: this copies through registers rather than issuing
      // cp.async, so it is slower than the TMA path it replaces. The point is to
      // validate the mapping end to end; the async form is the optimisation that
      // follows, and the mapping does not change with it.
      {
        const int G = mainloop_params.group_size;
        Tensor mQ_raw = make_tensor(make_gmem_ptr(mainloop_params.packed_Q_ptr), mainloop_params.layout_Q);
        auto gQp = get_packed_gqa_tensor(mQ_raw, select<0, 2>(TileShape_QKD{}), kv_head_idx, G,
                                        qo_indptr, qo_len / G);
        const int tile_base = q_tile_idx * get<0>(TileShape_QKD{});
        const int lane = threadIdx.x % cutlass::NumThreadsPerWarp;
        // The global side is vectorised, the shared side is not. D has stride 1
        // in global memory so an 8-element bf16 read is one 16-byte transaction,
        // while sQ's layout is swizzled and only its own indexing is guaranteed
        // to place an element correctly -- so the gather reads wide and writes
        // element-wise. Global latency is what dominates here.
        // cp.async, not a register round trip. The first version read each 16 B
        // chunk into registers and stored it, which is 64 dependent global loads
        // per thread for a 32 KB tile -- measured at -69% end to end. These are
        // issued and overlapped instead, so the warp pays one latency rather than
        // 64. The smem address still comes from sQ's own indexing, which is what
        // keeps the swizzle correct.
        constexpr int kVec = 16 / sizeof(DTypeQ);
        // Declared ABOVE the SKIP guard. These were below it, which put them in the scope
        // of the `if (false)` that guard emits -- so SKIP_PACKED_Q=1 did not compile at
        // all ("identifier dbg_n is undefined"). The diagnostic has been unusable since
        // the coverage counters were added.
        int dbg_n = 0, dbg_maxi = -1, dbg_nvalid = 0;
#if FLASHINFER_SKIP_PACKED_Q
        // Diagnostic only: skip the packed-GQA Q gather and leave whatever is in
        // smem, so the difference in kernel time bounds what this load costs. The
        // barrier arrival below still runs, so the consumer does not hang. Output
        // is garbage by construction -- this measures the load, not the kernel.
        if (false)
#endif
#if FLASHINFER_FA3_PARTIAL_PROBE
        // What the gather SOURCES for row 0 of this tile, read straight off the device. The store
        // addresses are already verified exact, and the stored values come back with elements
        // 0/2/3 identical within a row -- a broadcast or wrong stride, which would originate
        // here. Printed before the loop so it is its own null case.
        if (lane == 0) {
          const int pr0 = tile_base;
          const DTypeQ* r0 = (pr0 < qo_len) ? &gQp(packed_coord(pr0, G), 0) : nullptr;
          printf("[qld] blk=%u tile=%d base=%d qo_len(packed)=%d G=%d tok=%d hig=%d "
                 "src_off=%lld tileQ=%d dmax=%d\n",
                 blockIdx.x, int(tile_base / get<0>(TileShape_QKD{})), tile_base, int(qo_len), G,
                 pr0 / G, pr0 % G,
                 r0 ? (long long)(r0 - mainloop_params.packed_Q_ptr) : -1LL,
                 int(get<0>(TileShape_QKD{})), int(get<1>(TileShape_QKD{})));
        }
#endif
        for (int i = lane; i < get<0>(TileShape_QKD{}); i += cutlass::NumThreadsPerWarp) {
          ++dbg_n; dbg_maxi = i;
          const int pr = tile_base + i;
          const bool valid = pr < qo_len;  // qo_len is packed here
          if (valid) ++dbg_nvalid;
          const DTypeQ* row = valid ? &gQp(packed_coord(pr, G), 0) : nullptr;
#pragma unroll
          for (int d = 0; d < get<1>(TileShape_QKD{}); d += kVec) {
            cutlass::arch::cp_async<16, cutlass::arch::CacheOperation::Always>(
                &sQ(i, d), row + d, valid);
          }
        }
#if FLASHINFER_FA3_PARTIAL_PROBE
        // COVERAGE of the gather loop. Expected, stated before running: each lane runs
        // i = lane, lane+32, lane+64, lane+96 over a 128-row tile, so n=4 and max_i=lane+96; and
        // valid = (tile_base + i) < qo_len should hold for ALL of them when the tile is full.
        // Token 0 being the only correct token means packed rows 0..3 landed and 4..511 did not,
        // so either n is smaller than 4 or `valid` is false for i >= 4 -- this distinguishes them.
        if (lane == 0 || lane == 31) {
          printf("[cov] blk=%u tile=%d lane=%d n=%d max_i=%d nvalid=%d qo_len=%d tile_base=%d\n",
                 blockIdx.x, int(tile_base / get<0>(TileShape_QKD{})), lane, dbg_n, dbg_maxi,
                 dbg_nvalid, int(qo_len), tile_base);
        }
        // What LANDED in sQ, versus the source offset printed above. Expected multiplicity,
        // stated before running per the rule added after the lane==0 retraction: gated on
        // threadIdx.x == 0, which is ONE thread per BLOCK, so one line per work item -> 56 for
        // this fixture. Any other count means the gate is wrong, not the kernel.
        //
        // cp.async is in flight here, so this reads sQ BEFORE the arrival it is compared against
        // -- the point is whether the bytes are landing at all and in what pattern, not to race
        // the barrier. A second print after the arrival would be the clean version.
        __syncwarp();
        if (threadIdx.x == 0) {
          printf("[sqv] blk=%u tile=%d sQ[0,0..3]=%f %f %f %f  sQ[1,0..3]=%f %f %f %f\n",
                 blockIdx.x, int(tile_base / get<0>(TileShape_QKD{})),
                 float(sQ(0, 0)), float(sQ(0, 1)), float(sQ(0, 2)), float(sQ(0, 3)),
                 float(sQ(1, 0)), float(sQ(1, 1)), float(sQ(1, 2)), float(sQ(1, 3)));
        }
#endif
        // Completion, and this is where a hang was bought and paid for.
        //
        // barrier_Q is a ClusterTransactionBarrier. The TMA path arms it with
        // arrive_and_expect_tx(TmaTransactionBytesQ) and the consumer waits for
        // that transaction count. Signalling it with cpasync_barrier_arrive
        // instead -- from all 32 lanes, no less -- arrives without satisfying any
        // transaction count, and the consumer's wait never completes: fixture 2
        // hung for 1500 s, which is also exactly what the serving path did.
        //
        // So drain the cp.async group and arrive from ONE thread, matching the
        // arrival count the TMA path produces under elect_one_sync. A per-lane
        // cpasync_barrier_arrive cannot replace the drain: that instruction only
        // tracks the cp.async of its own issuing thread, so all 32 lanes would
        // have to arrive on a barrier whose arrival count is 1. The drain covers
        // Q alone only because load_q_tile runs before the K tile is issued.
#if FLASHINFER_FUSED_Q_MBARRIER
        // Each lane arrives for its own copies: no commit_group, so nothing
        // sweeps the producer's outstanding KV cp.async into Q's completion.
        // barrier_Q is armed for 32 arrivals to match (see prefill_sm90.cuh).
        //
        // _noinc, and that is the whole difference between this working and
        // hanging. cp.async.mbarrier.arrive INCREMENTS the mbarrier's pending
        // count before arriving on completion, so 32 lanes raise the expected
        // total to 32 + 32 while supplying only 32 arrivals: the barrier never
        // completes and the server stops responding on its first fused batch,
        // which is what happened. The _noinc form only arrives, which is what
        // pairs with a barrier armed for 32 up front. The consumer never arrives
        // on barrier_Q -- it only wait()s on phase work_idx % 2, and the barrier
        // completing once per work item keeps that phase in step.
        cutlass::arch::cpasync_barrier_arrive_noinc(
            reinterpret_cast<cutlass::arch::ClusterTransactionBarrier::ValueType const*>(
                &shared_storage.barrier_Q));
#else
        // Correct and ~3x slow: commit_group sweeps every cp.async this thread
        // still has uncommitted -- the producer's in-flight KV copies included,
        // since those signal through cpasync_barrier_arrive and are never
        // committed to a group -- and committed groups retire in order, so no
        // wait_group bound and no placement of the Q load avoids it. Hoisting Q
        // above the first K tile was measured not to recover the cost.
        cutlass::arch::cp_async_fence();
        cutlass::arch::cp_async_wait<0>();
        if (cute::elect_one_sync()) {
          shared_storage.barrier_Q.arrive();
        }
#endif
      }    }
#else
    // (only warp 0 issues TMA)
    if (warp_idx_in_warpgroup == 0) {
      int lane_predicate = cute::elect_one_sync();
      if (lane_predicate) {
        shared_storage.barrier_Q.arrive_and_expect_tx(TmaTransactionBytesQ);
        copy(mainloop_params.tma_load_Q.with(
                 reinterpret_cast<cutlass::arch::ClusterTransactionBarrier::ValueType&>(
                     shared_storage.barrier_Q),
                 /*mcast_mask=*/0),
             tQgQ, tQsQ);
      }
    }
#endif

    shared_storage.barrier_O.wait((work_idx + 1) % 2);

    if (kv_tile_idx == swa_begin_kv_tile_idx) {
      // kv_tile_idx already prefetched above (parity=0), reuse it for V
      pipeline_v.producer_acquire(smem_pipe_write_v);
      load_kv_with_gather(tVsV, tVcV, sV, V_ptr_base, kv_tile_idx, smem_pipe_write_v.index(), true);
      pipeline_v.producer_commit(smem_pipe_write_v, cutlass::arch::cpasync_barrier_arrive);
#if FUSED_PIPE_COUNT
      if (dbg_commit_v) ++*dbg_commit_v;
#endif
      ++smem_pipe_write_v;
    } else {
      // load second last k-tile and last v-tile
      // parity=0: kv_tile_idx is in my_kv_offset[0]
      // Now prefetch kv_tile_k into my_kv_offset[1]
      int kv_tile_k = kv_tile_idx_decrement(kv_tile_idx);
      parity ^= 1;  // parity=1
      prefetch_kv_offset(kv_tile_k, false);
      pipeline_k.producer_acquire(smem_pipe_write_k);
      load_kv_with_gather(tKsK, tKcK, sK, K_ptr_base, kv_tile_k, smem_pipe_write_k.index(), false);
      pipeline_k.producer_commit(smem_pipe_write_k, cutlass::arch::cpasync_barrier_arrive);
#if FUSED_PIPE_COUNT
      if (dbg_commit_k) ++*dbg_commit_k;
#endif
      ++smem_pipe_write_k;

      // Load V for kv_tile_idx using my_kv_offset[0]
      parity ^= 1;  // parity=0
      pipeline_v.producer_acquire(smem_pipe_write_v);
      load_kv_with_gather(tVsV, tVcV, sV, V_ptr_base, kv_tile_idx, smem_pipe_write_v.index(), true);
      pipeline_v.producer_commit(smem_pipe_write_v, cutlass::arch::cpasync_barrier_arrive);
#if FUSED_PIPE_COUNT
      if (dbg_commit_v) ++*dbg_commit_v;
#endif
      kv_tile_idx = kv_tile_idx_decrement(kv_tile_idx);
      ++smem_pipe_write_v;
      // Now kv_tile_idx == kv_tile_k, and its offset is in my_kv_offset[1]
      parity ^= 1;  // parity=1, pointing to kv_tile_idx's offset

      // load remaining k/v tiles
#pragma unroll 2
      for (; kv_tile_idx > swa_begin_kv_tile_idx;
           kv_tile_idx = kv_tile_idx_decrement(kv_tile_idx)) {
        // parity points to current kv_tile_idx's offset
        // Prefetch next K tile into the other buffer
        int kv_tile_k = kv_tile_idx_decrement(kv_tile_idx);
        parity ^= 1;  // Toggle to other buffer for prefetch
        prefetch_kv_offset(kv_tile_k, false);
        pipeline_k.producer_acquire(smem_pipe_write_k);
        load_kv_with_gather(tKsK, tKcK, sK, K_ptr_base, kv_tile_k, smem_pipe_write_k.index(), false);
        pipeline_k.producer_commit(smem_pipe_write_k, cutlass::arch::cpasync_barrier_arrive);
#if FUSED_PIPE_COUNT
      if (dbg_commit_k) ++*dbg_commit_k;
#endif
        ++smem_pipe_write_k;

        // Load V for kv_tile_idx using the previous buffer
        parity ^= 1;  // Toggle back to kv_tile_idx's buffer
        pipeline_v.producer_acquire(smem_pipe_write_v);
        load_kv_with_gather(tVsV, tVcV, sV, V_ptr_base, kv_tile_idx, smem_pipe_write_v.index(), false);
        pipeline_v.producer_commit(smem_pipe_write_v, cutlass::arch::cpasync_barrier_arrive);
#if FUSED_PIPE_COUNT
      if (dbg_commit_v) ++*dbg_commit_v;
#endif
        ++smem_pipe_write_v;
        // After loop update, kv_tile_idx becomes kv_tile_k
        // Toggle parity to point to kv_tile_k's buffer for next iteration
        parity ^= 1;
      }
      scheduler.prefetch_next_work(scheduler_params, work_tile_info);

      // load first v tile (tile 0)
      {
        prefetch_kv_offset(0, false);
        pipeline_v.producer_acquire(smem_pipe_write_v);
        load_kv_with_gather(tVsV, tVcV, sV, V_ptr_base, 0, smem_pipe_write_v.index(), false);
        pipeline_v.producer_commit(smem_pipe_write_v, cutlass::arch::cpasync_barrier_arrive);
#if FUSED_PIPE_COUNT
      if (dbg_commit_v) ++*dbg_commit_v;
#endif
        ++smem_pipe_write_v;
      }
    }

    scheduler.broadcast_next_work(work_tile_info);
  }

  CUTLASS_DEVICE void load_tail(MainloopPipeline pipeline_k, MainloopPipeline pipeline_v,
                                PipelineState& smem_pipe_write_k,
                                PipelineState& smem_pipe_write_v) {
    pipeline_k.producer_tail(smem_pipe_write_k);
    pipeline_v.producer_tail(smem_pipe_write_v);
  }
};

}  // namespace flashinfer

#endif  // FLASHINFER_ATTENTION_HOPPER_SPARSE_MAINLOOP_CUH_

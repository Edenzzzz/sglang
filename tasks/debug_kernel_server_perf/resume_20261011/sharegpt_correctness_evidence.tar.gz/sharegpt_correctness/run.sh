set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi HF_HOME=/dev/shm/w/hf
export FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=64,32,16 FUSED_CONST_PERS_PARAMS=1 FLASHINFER_FUSED_BACKFILL=1 FUSED_FA2_KV_CHUNK=1024
export CORRECTNESS_SYNTHETIC=0 CORRECTNESS_DATASET=/dev/shm/w/datasets/ShareGPT.original.json
export DISABLE_CUDA_GRAPH=1 BENCH_CHUNK=512 CORRECTNESS_DECODE_TOKENS=1200 SGLANG_FUSED_DECODE_GUARD=0 SGLANG_FUSED_SPLIT_VERIFY=1
for arm in MTP_LPT MTPMIX MTPMIXFUSED; do
 /dev/shm/w/venv/bin/python -u /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py $arm /dev/shm/w/sharegpt_correctness
done
status=0
for arm in MTPMIX MTPMIXFUSED; do
 if ! /dev/shm/w/venv/bin/python /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py --compare /dev/shm/w/sharegpt_correctness MTP_LPT $arm; then status=1; fi
done
echo SHAREGPT_OUTPUT_GATES_STATUS=$status
exit $status

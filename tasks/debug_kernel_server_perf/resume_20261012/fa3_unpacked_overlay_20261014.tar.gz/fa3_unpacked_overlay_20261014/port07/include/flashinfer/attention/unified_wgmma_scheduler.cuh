/*!
 * \brief Tile scheduler that drives FA3's wgmma mainloop from task 3 of the
 *        unified HolisticPlanInfo plan, instead of from PrefillSM90Plan.
 *
 * Why this exists. PrefillSM90Plan emits one work item per
 * (q-tile x qo head x row) carrying the FULL kv_len, with no partial-O/LSE
 * buffers and no merge map, so the wgmma role as the server planned it had
 * neither GQA packing nor split-KV. Measured consequence: it is 2.63x faster
 * than the FA2 mainloop on the row that carries 93% of a mixed step's attention,
 * and none of that reached the server.
 *
 * TwoStageHolisticPlan already emits, per task: q_indptr, kv_indptr, q_len,
 * kv_len, q_start, kv_start, kv_end, kv_head_idx, work_indptr, partial_indptr
 * and group_id. Reading task 3 through this scheduler therefore gives the wgmma
 * mainloop split-KV for free -- a KV chunk is a shifted kv_indptr with a shorter
 * kv_len, and this path is non-causal, so the mainloop needs no change at all --
 * plus a JIT-reduction group id for the in-kernel merge.
 *
 * What it does NOT yet give: packed-GQA addressing. The plan tiles PACKED rows,
 * so a task-3 item covers packed rows [q_start, q_start + tile) of one kv head,
 * spanning several qo heads, and the mainloop's Q load and O store must map
 * packed row p -> (token = p / G, head = kv_head * G + p % G). That is the
 * remaining mainloop change; until it lands, admission must keep the wgmma class
 * to rows whose packed tile lies within a single head
 * (FLASHINFER_FA3_MIN_PACKED_QO default 128 at gqa 7 means qo_len >= 19, so a
 * 128-row packed tile can straddle heads -- the caller is responsible for not
 * routing such rows here yet).
 */
#ifndef FLASHINFER_ATTENTION_UNIFIED_WGMMA_SCHEDULER_CUH_
#define FLASHINFER_ATTENTION_UNIFIED_WGMMA_SCHEDULER_CUH_

#include <cutlass/fast_math.h>

#include <cute/tensor.hpp>

namespace flashinfer {

/*!
 * \brief Drop-in replacement for BatchPrefillPersistentTileScheduler whose work
 *        list is one task of the unified plan.
 *
 * The contract is the one FA3's mainloop expects: Params of device arrays,
 * get_initial_work / get_next_work, and a WorkTileInfo whose get_block_coord
 * returns {q_tile_idx, qo_head_idx, kv_head_idx, qo_indptr, kv_indptr, qo_len,
 * kv_len, batch_idx}.
 */
template <typename IdType>
struct UnifiedWgmmaTileScheduler {
 public:
  struct Arguments {
    // task-3 arrays of HolisticPlanInfo, device pointers
    IdType *work_indptr, *q_indptr, *kv_indptr, *q_len, *kv_len, *q_start, *kv_start, *kv_end,
        *kv_head_idx, *partial_indptr;
  // NOTE: there is no group_id array. FusedPlanInfo dropped the plan's per-item group_id with
  // K1a's JIT-reduction rendezvous, and group_id's only surviving role is the boolean "does this
  // row need a merge". That is derivable from data the plan does carry, so WorkTileInfo computes
  // it as (num_kv_chunks > 1) rather than reading a table.
    // Task 3's KV chunk length. The partial slab is strided by chunk index, which
    // is kv_start / len_kv_chunk -- the same derivation persistent.cuh makes.
    IdType* len_kv_chunk;
    cutlass::FastDivmod group_size_fastdiv;  // qo heads per kv head
    uint32_t cta_tile_q;
    uint32_t page_size = 1;
  };

  struct Params {
    IdType *work_indptr, *q_indptr, *kv_indptr, *q_len, *kv_len, *q_start, *kv_start, *kv_end,
        *kv_head_idx, *partial_indptr;
    IdType* len_kv_chunk;
    cutlass::FastDivmod group_size_fastdiv;
    uint32_t cta_tile_q;
    uint32_t page_size = 1;
  };

  static Params to_underlying_arguments(Arguments const& a) {
    return {a.work_indptr, a.q_indptr,   a.kv_indptr,      a.q_len,   a.kv_len,
            a.q_start,     a.kv_start,   a.kv_end,         a.kv_head_idx,
            a.partial_indptr, a.len_kv_chunk, a.group_size_fastdiv, a.cta_tile_q, a.page_size};
  }

  static dim3 get_grid_dim(Arguments const& args, int num_sm) { return {(unsigned)num_sm}; }

  struct WorkTileInfo {
    int q_tile_idx = 0;
    int qo_head_idx = 0;
    int kv_head_idx = 0;
    int qo_indptr = 0;
    int kv_indptr = 0;
    int qo_len = 0;
    int kv_len = 0;
    int batch_idx = 0;
    // Split-KV bookkeeping, carried so the epilogue can write a partial and the
    // last arrival of the group can reduce it without a grid barrier.
    int partial_indptr = 0;
    int group_id = -1;
    // Which chunk of its merge group this item is. The epilogue needs it to place
    // the partial at group_base + row * num_kv_chunks + kv_chunk_idx.
    int kv_chunk_idx = 0;
    // How many chunks this item's row was split into. Taken from the PLAN's own formula --
    // ceil_div(kv_len, len_kv_chunk), uniform per request and with NO causal adjustment,
    // because that is exactly what EnumerateFusedWorkItems counted as `splits` when it sized
    // the partial slab and BuildFusedMergeLayout built merge_indptr. Re-deriving it with the
    // FA2 side's causal-adjusted formula would disagree with the plan, and a layout
    // disagreement here is what made fixture 2 leave 511/512 rows unwritten.
    int num_kv_chunks = 1;
    // ABSOLUTE causal bound for this item: the request's total kv_len minus this chunk's
    // base. block_coord carries the CHUNK's kv_len (the scheduler shifts the base), and
    // masking causally against that is wrong -- it cut each chunk to token+97 of 128 keys,
    // identified from partial_lse as log2(97)=6.5999 vs a measured 6.60012. Kept separate
    // from kv_len because kv_len is also the ITERATION bound; see fused_causal_kv_len.
    int causal_kv_len = 0;
    int counter = 0;
    int ptr_begin = 0;
    int ptr_end = 0;

    CUTLASS_DEVICE
    bool is_valid(Params const& params) const { return counter + ptr_begin < ptr_end; }

    CUTLASS_DEVICE
    bool is_split_kv() const { return group_id >= 0; }

    CUTLASS_DEVICE
    auto get_block_coord(Params const& params) const {
      return cute::tuple{q_tile_idx, qo_head_idx, kv_head_idx, qo_indptr,
                         kv_indptr,  qo_len,      kv_len,      batch_idx};
    }
  };

 private:
  CUTLASS_DEVICE
  static WorkTileInfo load(Params const& params, int work_idx, int ptr_begin, int ptr_end,
                           int counter) {
#if FUSED_FA3_UNPACKED
    const int kv_head = int(params.kv_head_idx[work_idx]) / int(params.group_size_fastdiv.divisor);
#else
    const int kv_head = int(params.kv_head_idx[work_idx]);
#endif
    const int kv_begin = int(params.kv_start[work_idx]);
    // Split-KV with no mainloop change: hand it a base shifted to the chunk and
    // a length of just that chunk. Legal because this path is non-causal.
    const int kv_chunk = int(params.kv_end[work_idx]) - kv_begin;
    // q_start is in PACKED rows (the plan tiles qo_len * gqa_group_size) while
    // q_len is in unpacked tokens. FA3's mainloop validates the tile index
    // against qo_len, so handing it a packed tile index with a token length makes
    // every tile look out of range: measured as 116 task-3 work items sitting in
    // exactly the right clusters and silently producing nothing. Present the q
    // extent in the same packed units as the tile index.
    const int packed_qo_len = int(params.q_len[work_idx])
#if !FUSED_FA3_UNPACKED
                             * int(params.group_size_fastdiv.divisor)
#endif
                             ;
    // The PLAN's formula -- uniform chunk per request, no causal adjustment -- because this must
    // agree with the `splits` EnumerateFusedWorkItems counted when it sized the partial slab.
    const int nchunks = (params.len_kv_chunk != nullptr && params.len_kv_chunk[0] > 0)
                            ? int(ceil_div(int(params.kv_len[work_idx]),
                                           int(params.len_kv_chunk[0])))
                            : 1;
    // DESIGNATED initialisers. The positional form had kv_chunk_idx and group_id in the
    // opposite order to the struct (partial_indptr, group_id, kv_chunk_idx, num_kv_chunks), so
    // group_id silently received the CHUNK INDEX -- 0 for the first chunk, which opens the
    // `group_id >= 0` gate on every row. The FA3 epilogue then called store_partial for rows the
    // plan had marked unsplit with partial_indptr = -1, and the negative index ran off the front
    // of the float workspace: 4-byte write 44 B before the base, which is (-2)*7 + 3 at
    // num_kv_heads = 7. The trace showed the contradiction directly -- group_id=0 with chunks=1
    // and partial_indptr=-1, three values that cannot hold together.
#if FLASHINFER_FA3_PARTIAL_PROBE
    // Every work item the scheduler hands out, one line each.
    // EXPECTED, stated before running: 28 lines for MODE=fa3_1chunk at G=4 (4 q tiles x 7 kv
    // heads for the single request), with span = ptr_end - ptr_begin telling us how many items
    // each block owns. Only 7 items reached write_packed, all of them q tile 3, so either 21
    // items never appear here (the plan/partition dropped them) or they appear and took the
    // split path -- nchunks > 1 / group_id >= 0 -- which bypasses write_packed.
    if (threadIdx.x == 0) {
      printf("[sched] blk=%u work_idx=%d span=%d(%d..%d) counter=%d qtile=%d kvh=%d nchunks=%d "
             "partial=%d q_start=%d packed_qo=%d kv_len=%d chunk=%d\n",
             blockIdx.x, work_idx, ptr_end - ptr_begin, ptr_begin, ptr_end, counter,
             int(params.q_start[work_idx]) / int(params.cta_tile_q), kv_head, nchunks,
             int(params.partial_indptr[work_idx]), int(params.q_start[work_idx]), packed_qo_len,
             int(params.kv_len[work_idx]), kv_chunk);
    }
#endif
    return {.q_tile_idx = int(params.q_start[work_idx]) / int(params.cta_tile_q),
            .qo_head_idx =
#if FUSED_FA3_UNPACKED
                int(params.kv_head_idx[work_idx]),
#else
                kv_head * int(params.group_size_fastdiv.divisor),
#endif
            .kv_head_idx = kv_head,
            .qo_indptr = int(params.q_indptr[work_idx]),
            .kv_indptr = int(params.kv_indptr[work_idx]) + kv_begin / int(params.page_size),
            .qo_len = packed_qo_len,
            .kv_len = kv_chunk,
            .batch_idx = 0,
            .partial_indptr = int(params.partial_indptr[work_idx]),
            // DERIVED, not read from the plan: a row needs a merge exactly when it was cut into
            // more than one chunk, and the value is only ever tested as >= 0, so the group INDEX
            // it used to carry has no remaining reader.
            .group_id = (nchunks > 1) ? 0 : -1,
            .kv_chunk_idx = (params.len_kv_chunk != nullptr && params.len_kv_chunk[0] > 0)
                                ? kv_begin / int(params.len_kv_chunk[0])
                                : 0,
            .num_kv_chunks = nchunks,
            .causal_kv_len = int(params.kv_len[work_idx]) - kv_begin,
            .counter = counter,
            .ptr_begin = ptr_begin,
            .ptr_end = ptr_end};
  }

 public:
  CUTLASS_DEVICE
  UnifiedWgmmaTileScheduler() {}

  CUTLASS_DEVICE
  WorkTileInfo get_peer_work(Params const& params, WorkTileInfo const& current_work) const {
    const uint32_t peer_cta = blockIdx.x ^ 1u;
    const int begin = int(params.work_indptr[peer_cta]);
    const int end = int(params.work_indptr[peer_cta + 1]);
    const int index = begin + current_work.counter;
    if (index >= end) return WorkTileInfo{};
    return load(params, index, begin, end, current_work.counter);
  }

  CUTLASS_DEVICE
  WorkTileInfo get_initial_work(Params const& params) const {
    const int ptr_begin = int(params.work_indptr[blockIdx.x]);
    const int ptr_end = int(params.work_indptr[blockIdx.x + 1]);
    if (ptr_begin < ptr_end) return load(params, ptr_begin, ptr_begin, ptr_end, 0);
    // DESIGNATED, for the same reason load() is. WorkTileInfo has 15 fields and this return
    // listed 13 positionally, so `counter` received ptr_begin, `ptr_begin` received ptr_end and
    // `ptr_end` defaulted to 0 -- the exact hazard the comment in load() documents, left live in
    // the two terminal returns when load() was converted.
    return {.q_tile_idx = -1,
            .qo_head_idx = -1,
            .kv_head_idx = -1,
            .qo_indptr = -1,
            .kv_indptr = -1,
            .qo_len = -1,
            .kv_len = -1,
            .batch_idx = 0,
            .partial_indptr = 0,
            .group_id = -1,
            .kv_chunk_idx = 0,
            .num_kv_chunks = 1,
            .causal_kv_len = 0,
            .counter = 0,
            .ptr_begin = ptr_begin,
            .ptr_end = ptr_end};
  }

  CUTLASS_DEVICE
  void init_consumer() const {}

  CUTLASS_DEVICE
  void prefetch_next_work(Params const& params, WorkTileInfo& current_work) const {}

  CUTLASS_DEVICE
  void broadcast_next_work(WorkTileInfo& current_work) const {}

  template <bool is_producer = false>
  CUTLASS_DEVICE WorkTileInfo get_next_work(Params const& params,
                                            WorkTileInfo const& current_work) const {
    const int work_idx = current_work.ptr_begin + current_work.counter + 1;
    if (work_idx < current_work.ptr_end) {
      return load(params, work_idx, current_work.ptr_begin, current_work.ptr_end,
                  current_work.counter + 1);
    }
    // DESIGNATED. Positionally this listed 14 values into 15 fields, so `num_kv_chunks` received
    // counter+1, `counter` received ptr_begin and `ptr_begin` received ptr_end.
    return {.q_tile_idx = -1,
            .qo_head_idx = -1,
            .kv_head_idx = -1,
            .qo_indptr = -1,
            .kv_indptr = -1,
            .qo_len = -1,
            .kv_len = -1,
            .batch_idx = 0,
            .partial_indptr = 0,
            .group_id = -1,
            .kv_chunk_idx = 0,
            .num_kv_chunks = 1,
            .causal_kv_len = 0,
            .counter = current_work.counter + 1,
            .ptr_begin = current_work.ptr_begin,
            .ptr_end = current_work.ptr_end};
  }
};

/*!
 * \brief Task-3 device pointers, as the ext reads them out of a 4-task plan.
 *
 * Kept as a POD so the ext can build it from HolisticPlanInfo<4> without the
 * dispatch having to know about plan layouts, and so the scheduler's Arguments
 * can be produced in one place rather than at each call site.
 */
template <typename IdType>
struct UnifiedWgmmaPlanPtrs {
  IdType *work_indptr, *q_indptr, *kv_indptr, *q_len, *kv_len, *q_start, *kv_start, *kv_end,
      *kv_head_idx, *partial_indptr;
  // Request index per item, for upstream's bidb (it indexes cu_seqlens by batch).
  IdType* batch_idx;
  // Points at TASK 3's element of the plan's per-task len_kv_chunk array, so the
  // scheduler can read it as [0].
  IdType* len_kv_chunk;
  // Workspace for the upstream FA3 port. Separate from the FA2 roles' partial_o
  // because upstream's ElementPartial is float while ours is bf16 -- sharing the
  // buffer would have upstream write floats over half as many elements as it
  // believes it owns. dense_page_table is the [batch, max_pages] table upstream
  // indexes as page_table[bidb * stride + block], scattered from our ragged
  // kv_indices. All three are preallocated so the path stays CUDA-graph safe.
  float* upstream_partial_o;
  float* upstream_partial_lse;
  IdType* dense_page_table;
  int max_pages_per_seq;
  int total_q;
  // Batch and page counts. Neither is recoverable from FA3Params (it carries the
  // ragged indptr but no batch count, and no page total), and the scatter kernel
  // plus upstream's shape_K both need them, so the ext passes them explicitly.
  int num_requests;
  int num_pages;
  // Max q length over requests, for the combine pass's grid.
  int max_seqlen_q;
  // RAW page ids, which is NOT what FA3Params::kv_indices holds. flashinfer's FA3
  // takes vector-sparse offsets because its mainloop multiplies the index by
  // k_stride_n; upstream's paged path indexes page_table[bidb*stride + block] as a
  // real page number and does the stride arithmetic itself. Feeding it the
  // vector-sparse array made it read far outside the cache (illegal access on the
  // first launch), so the port carries the page ids separately.
  IdType* page_indices;
  // Per-request split counts for the combine pass (num_requests ints), filled on
  // device by FillNumSplitsDynamic.
  int* num_splits_dynamic;
  // PER-REQUEST varlen descriptors. These are NOT the plan's q_indptr / kv_len:
  // scheduler.cuh pushes those once per WORK ITEM inside the cluster loop
  // (:1582), while upstream indexes cu_seqlens_q[bidb] and seqused_k[bidb] as
  // request boundaries. Handing it the per-item arrays made it read arbitrary work
  // items as request offsets, which corrupted the mainloop's Q/KV addressing, the
  // epilogue's output offsets and the combine pass's row ranges at once.
  IdType* kv_lens_per_req;
  IdType* q_indptr_per_req;
  // Per-request PAGE offsets, for the ragged -> dense page-table scatter. The plan's
  // kv_indptr is per work item, so using it there gave each request a page range taken
  // from an arbitrary work item and upstream read the wrong KV for every wgmma row.
  IdType* kv_indptr_per_req;
  // Compact list of requests the planner routed to THIS queue, and its length. The
  // combine pass runs over only these, via upstream's varlen_batch_idx_ptr.
  IdType* fa3_batch_list;
  int num_fa3_requests;
  // Upstream's split count. It MUST equal the count the partial buffers were sized
  // for and the one the adapter's split_idx is derived against; leaving it at 1
  // while the planner chose more let split_idx > 0 address past the partials.
  int num_splits;
  uint32_t num_qo_heads, num_kv_heads, cta_tile_q;
};

template <typename IdType>
inline typename UnifiedWgmmaTileScheduler<IdType>::Arguments make_unified_wgmma_args(
    UnifiedWgmmaPlanPtrs<IdType> const& p, uint32_t page_size = 1) {
  return {p.work_indptr,
          p.q_indptr,
          p.kv_indptr,
          p.q_len,
          p.kv_len,
          p.q_start,
          p.kv_start,
          p.kv_end,
          p.kv_head_idx,
          p.partial_indptr,
          p.len_kv_chunk,
          cutlass::FastDivmod(int(p.num_qo_heads / p.num_kv_heads)),
          p.cta_tile_q,
          page_size};
}

/*!
 * \brief FA3's params plus the task-3 plan pointers the unified scheduler needs.
 *
 * The dispatch reaches `params.wgmma_plan` only inside
 * `if constexpr (kUnifiedWgmma)`, and `params` is a template parameter there, so
 * the member is required only when that instantiation is actually requested --
 * which is why the switch could land without touching existing call sites. The
 * mainloop and epilogue keep reading the inherited pointer and stride fields;
 * only the work distribution moves to the unified plan.
 */
template <typename Base, typename IdType>
struct UnifiedWgmmaParams : Base {
  UnifiedWgmmaPlanPtrs<IdType> wgmma_plan;
};

}  // namespace flashinfer

#endif  // FLASHINFER_ATTENTION_UNIFIED_WGMMA_SCHEDULER_CUH_

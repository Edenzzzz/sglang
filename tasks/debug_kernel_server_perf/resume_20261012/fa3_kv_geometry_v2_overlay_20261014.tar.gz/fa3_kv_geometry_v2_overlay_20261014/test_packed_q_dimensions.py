from pathlib import Path
import re
import unittest


class PackedQueryDimensions(unittest.TestCase):
    def test_copy_bound_is_head_dimension(self):
        source = (Path(__file__).parent / "port07/include/flashinfer/attention/hopper/sparse_mainloop.cuh").read_text()
        self.assertRegex(source, r"for \(int d = 0; d < HEAD_DIM_QK; d \+= kVec\)")
        self.assertNotRegex(source, r"for \(int d = 0; d < get<1>\(TileShape_QKD\{\}\)")

    def test_warp_covers_every_query_component(self):
        for kv_tile in (64, 96, 128):
            query_rows, head_dimension = 128, 128
            coverage = [[0] * head_dimension for _ in range(query_rows)]
            for lane in range(32):
                for row in range(lane, query_rows, 32):
                    for column in range(0, head_dimension, 8):
                        for element in range(column, column + 8):
                            coverage[row][element] += 1
            self.assertTrue(all(count == 1 for row in coverage for count in row), kv_tile)
            old_columns = set(range(kv_tile))
            if kv_tile < head_dimension:
                self.assertLess(len(old_columns), head_dimension)


if __name__ == "__main__":
    unittest.main()

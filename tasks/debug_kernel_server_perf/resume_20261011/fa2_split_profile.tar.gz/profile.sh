set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi
export HEADS=28,4 SM_SPLIT=64 FUSED_REFERENCE_WORKSPACE_BYTES=16 FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=64,32,16 FUSED_CONST_PERS_PARAMS=1 FUSED_FA2_KV_CHUNK=1024 FLASHINFER_FUSED_BACKFILL=0
export MODE=band1 BAND_SIDE=fa2 BAND_QO=4 BAND_ROWS=8 BAND_KV=2048
/usr/local/cuda/bin/ncu --set basic --kernel-name regex:FusedFA3Persistent --launch-count 1 --force-overwrite -o /dev/shm/w/independent_fa2_empty_fixed/fa2_split_profile /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/independent_fa2_empty_fixed/fa2_split_profile.log 2>&1
/usr/local/cuda/bin/cuobjdump --dump-resource-usage /home/tiger/.cache/torch_extensions/py312_cu130/fused_fa3/fused_fa3.so > /dev/shm/w/independent_fa2_empty_fixed/fa2_split_resources.log
echo FA2_SPLIT_PROFILE_DONE

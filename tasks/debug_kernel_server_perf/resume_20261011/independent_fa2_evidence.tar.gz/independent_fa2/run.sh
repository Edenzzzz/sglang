set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi HF_HOME=/dev/shm/w/hf
export HEADS=28,4 SM_SPLIT=64 FUSED_REFERENCE_WORKSPACE_BYTES=16 FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=64,32,16 FUSED_CONST_PERS_PARAMS=1 FLASHINFER_FUSED_BACKFILL=1
for mode in fa2_2tile fa2 fa3_1chunk mixed_verify; do
 FUSED_FA2_KV_CHUNK=128 MODE=$mode /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/independent_fa2/verify_$mode.log 2>&1
done
echo INDEPENDENT_FA2_REFERENCE_PASS
SM_SPLIT=all FUSED_FA2_KV_CHUNK=256 MODE=mixed_verify /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/independent_fa2/backfill_all.log 2>&1
for chunk in 1024 512 256 128; do
 FUSED_FA2_KV_CHUNK=$chunk MODE=mixed_verify TIME_AB=1 TIME_ITERS=100 /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/independent_fa2/timing_$chunk.log 2>&1
done
echo INDEPENDENT_FA2_TIMINGS_PASS
DISABLE_CUDA_GRAPH=1 BENCH_CHUNK=512 CORRECTNESS_DECODE_TOKENS=1200 SGLANG_FUSED_DECODE_GUARD=0 /dev/shm/w/venv/bin/python -u /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py MTP_LPT /dev/shm/w/independent_fa2
echo UNFUSED_SERVING_BASELINE_PASS

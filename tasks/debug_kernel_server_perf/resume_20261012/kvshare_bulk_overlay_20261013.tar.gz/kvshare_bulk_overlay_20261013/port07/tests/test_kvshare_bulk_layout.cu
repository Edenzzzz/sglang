#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <vector>

#include "flashinfer/attention/hopper/kernel_traits.cuh"

struct TestAttentionVariant {};

template <class Layout>
bool check_layout(const char* name, int stages) {
  constexpr int tile_elements = 128 * 128;
  constexpr int half_elements = tile_elements / 2;
  constexpr int storage_elements = cute::cosize_v<Layout>;
  Layout layout;
  int cases = 0;
  for (int first_stage = 0; first_stage < stages; ++first_stage) {
    for (int second_stage = 0; second_stage < stages; ++second_stage) {
      for (int valid_rows : {1, 17, 127, 128}) {
        std::array<std::vector<uint16_t>, 2> storage = {
            std::vector<uint16_t>(storage_elements, 0xffff),
            std::vector<uint16_t>(storage_elements, 0xffff)};
        const std::array<int, 2> active_stages = {first_stage, second_stage};
        std::array<int, 2> bases;
        for (int rank = 0; rank < 2; ++rank) {
          bases[rank] = layout(cute::make_coord(0, 0, active_stages[rank]));
          if ((bases[rank] * sizeof(uint16_t)) % 16 != 0) return false;
          std::vector<bool> visited(tile_elements, false);
          for (int row = 0; row < 128; ++row) {
            for (int dimension = 0; dimension < 128; ++dimension) {
              const int offset = layout(cute::make_coord(row, dimension, active_stages[rank]));
              const int relative = offset - bases[rank];
              if (relative < 0 || relative >= tile_elements || visited[relative]) return false;
              visited[relative] = true;
              if (dimension % 8 == 0) {
                if (relative % 8 != 0 || relative / half_elements !=
                    (relative + 7) / half_elements) return false;
                for (int lane = 0; lane < 8; ++lane) {
                  if (layout(cute::make_coord(row, dimension + lane, active_stages[rank])) !=
                      offset + lane) return false;
                }
              }
              if (relative / half_elements == rank) {
                storage[rank][offset] = row < valid_rows ? row * 128 + dimension + 1 : 0;
              }
            }
          }
        }
        for (int rank = 0; rank < 2; ++rank) {
          std::copy_n(storage[rank].begin() + bases[rank] + rank * half_elements,
                      half_elements,
                      storage[rank ^ 1].begin() + bases[rank ^ 1] + rank * half_elements);
        }
        for (int rank = 0; rank < 2; ++rank) {
          for (int row = 0; row < 128; ++row) {
            for (int dimension = 0; dimension < 128; ++dimension) {
              const int offset = layout(cute::make_coord(row, dimension, active_stages[rank]));
              const uint16_t expected = row < valid_rows ? row * 128 + dimension + 1 : 0;
              if (storage[rank][offset] != expected) return false;
            }
          }
        }
        ++cases;
      }
    }
  }
  std::printf("%s stages=%d cases=%d PASS\n", name, stages, cases);
  return true;
}

template <int Stages>
bool check_stages() {
  using Traits = flashinfer::AttentionKernelTraits<
      false, 128, 128, 128, 128, Stages, cutlass::bfloat16_t, cutlass::bfloat16_t,
      cutlass::bfloat16_t, int32_t, TestAttentionVariant>;
  return check_layout<typename Traits::SmemLayoutK>("K", Stages) &&
         check_layout<typename Traits::SmemLayoutV>("V", Stages);
}

int main() {
  return check_stages<1>() && check_stages<2>() && check_stages<3>() ? 0 : 1;
}

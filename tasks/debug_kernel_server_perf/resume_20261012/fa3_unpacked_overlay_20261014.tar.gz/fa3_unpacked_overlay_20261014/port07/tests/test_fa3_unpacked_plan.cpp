#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <vector>

#include <flashinfer/attention/fused_plan.cuh>

int main() {
  static_assert(FUSED_FA3_UNPACKED == 1);
  setenv("FUSED_FA2_TILES", "64,32,16", 1);
  const int32_t queries[] = {512, 17, 129, 4, 8};
  const int32_t lengths[] = {65536, 4097, 32769, 8193, 4096};
  const int32_t offsets[] = {0, 512, 529, 658, 662, 670};
  const bool roles[] = {true, true, true, false, false};
  for (const char* ordering : {"0", "1"}) {
    setenv("FUSED_GROUP_MAJOR", ordering, 1);
    std::vector<flashinfer::FusedWorkItem> work[4];
    int32_t maximum_splits = 0;
    std::vector<int32_t> requests;
    flashinfer::EnumerateFusedWorkItems(queries, lengths, roles, 5, 7, 4, 128, 512,
                                      work, &maximum_splits, &requests, 256);
    assert(maximum_splits == 1 && requests == std::vector<int32_t>({0, 1, 2}));
    assert(work[3].size() == 196);
    std::vector<int> coverage(658 * 28, 0);
    for (const auto& item : work[3]) {
      assert(item.batch_idx >= 0 && item.batch_idx < 3);
      assert(item.kv_head_idx >= 0 && item.kv_head_idx < 28);
      assert(item.kv_head_idx / 7 < 4);
      assert(item.kv_start == 0 && item.kv_end == lengths[item.batch_idx]);
      assert(item.q_start >= 0 && item.q_start + item.q_len <= queries[item.batch_idx]);
      for (int row = 0; row < item.q_len; ++row) {
        ++coverage[(offsets[item.batch_idx] + item.q_start + row) * 28 + item.kv_head_idx];
      }
    }
    for (int count : coverage) assert(count == 1);
    flashinfer::FusedMergeLayout merge;
    flashinfer::BuildFusedMergeLayout(work, lengths, 5, 4, offsets, 7, &merge);
    assert(merge.num_merge_tiles > 0);
    for (int offset : merge.partial_indptr[3]) assert(offset == -1);
    for (int row : merge.merge_o_indices) assert(row >= offsets[3] * 28);
    std::printf("unpacked head/token coverage, no FA3 splits, FA2 merge retained: group_major=%s PASS\n", ordering);
  }
}

/*
 * Copyright (c) 2024, Jay Shah, Ganesh Bikshandi, Ying Zhang, Vijay Thakkar, Pradeep Ramani, Tri
 * Dao. Licensed under the BSD 3-Clause.
 *
 * Modified by the FlashInfer team.
 */
#ifndef FLASHINFER_ATTENTION_HOPPER_PREFILL_SM90_CUH_
#define FLASHINFER_ATTENTION_HOPPER_PREFILL_SM90_CUH_

#ifndef FUSED_O_HANDSHAKE
#define FUSED_O_HANDSHAKE 0
#endif
#include <cuda.h>
#include <cuda_device_runtime_api.h>
#include <cutlass/arch/reg_reconfig.h>
#include <cutlass/array.h>
#include <cutlass/cutlass.h>
#include <cutlass/numeric_conversion.h>
#include <cutlass/numeric_types.h>

#include <type_traits>
#include <vector>

#include "../../cutlass_utils.cuh"
#include "../../exception.h"
#include "../mask.cuh"
#include "cute/tensor.hpp"
#include "cutlass/pipeline/pipeline.hpp"
#include "epilogue.cuh"
#include "kernel_traits.cuh"
#include "mainloop.cuh"
#include "mainloop_mma.cuh"
#include "sparse_mainloop.cuh"
#include "tile_scheduler.cuh"
#include "utils.cuh"

namespace flashinfer {

using namespace cute;


// Shared with prefill.cuh: both headers define these member probes and the fused FA3+FA2
// kernel includes both in one translation unit.
#ifndef FLASHINFER_SHARED_HAS_MEMBER_PROBES
#define FLASHINFER_SHARED_HAS_MEMBER_PROBES
DEFINE_HAS_MEMBER(maybe_prefix_len_ptr)
DEFINE_HAS_MEMBER(maybe_token_pos_in_items_ptr)
DEFINE_HAS_MEMBER(token_pos_in_items_len)
DEFINE_HAS_MEMBER(maybe_max_item_len_ptr)
#endif

// Does this scheduler's WorkTileInfo carry the unified split-KV reduction's per-item fields?
// True for UnifiedWgmmaTileScheduler, false for the upstream one. `block_coord` is destructured
// at a fixed arity of 8 by the body below, so these cannot ride along it; detecting them on the
// work tile avoids touching upstream's scheduler.
//
// NOTE: this probes the SCHEDULER's `group_id`, which lives in unified_wgmma_scheduler.cuh and
// is retained. It is NOT the PLAN's `group_id` that K1a dropped with the JIT-reduction
// rendezvous -- conflating the two would wrongly suggest this trait can be deleted.
template <typename S, typename = void>
struct fa3_has_split_kv : std::false_type {};
template <typename S>
struct fa3_has_split_kv<S, std::void_t<decltype(std::declval<typename S::WorkTileInfo>().group_id)>>
    : std::true_type {};

// Body extracted into a __device__ function so a FUSED kernel can invoke FA3 on one range of
// SMs while the FA2-lineage persistent mainloop runs on the rest (see persistent_fa3_fused.cuh).
// `shared_memory` arrives as a parameter because the fused kernel partitions one dynamic smem
// allocation between the two roles, so the callee must not declare its own.
// The __global__ entry point below is unchanged for every existing caller.
template <typename CollectiveMainloop, typename CollectiveEpilogue, typename Ktraits,
          bool LEFT_SLIDING_WINDOW, bool CAUSAL, typename TileScheduler,
          bool MULTIITEMSCORING = false>
__device__ __forceinline__ void fa3_prefill_body(
    typename CollectiveMainloop::Params const& mainloop_params,
    typename CollectiveEpilogue::Params const& epilogue_params,
    typename TileScheduler::Params const& scheduler_params, char* shared_memory,
    uint32_t entry_register_count = 0) {
  using DTypeQ = typename Ktraits::DTypeQ;
  using DTypeKV = typename Ktraits::DTypeKV;
  using DTypeO = typename Ktraits::DTypeO;
  using DTypeQKAccum = typename Ktraits::DTypeQKAccum;
  using TileShape_QKD = typename Ktraits::TileShape_QKD;
  using TileShape_PDV = typename Ktraits::TileShape_PDV;
  using AttentionVariant = typename Ktraits::AttentionVariant;

  static constexpr int NUM_MMA_THREADS = Ktraits::NUM_MMA_THREADS;
  static constexpr int NUM_COPY_THREADS = cutlass::NumThreadsPerWarpGroup;
  static constexpr int CTA_Q = Ktraits::CTA_Q;
  static constexpr int CTA_KV = Ktraits::CTA_KV;

  static constexpr bool use_tma_load_kv = CollectiveMainloop::USE_TMA_LOAD_KV;

  using MainloopPipeline = typename CollectiveMainloop::MainloopPipeline;
  using PipelineParams = typename MainloopPipeline::Params;
  using PipelineState = typename MainloopPipeline::PipelineState;

  auto& shared_storage = *reinterpret_cast<typename Ktraits::SharedStorage*>(shared_memory);

  int const lane_predicate = cute::elect_one_sync();
  int const warp_idx = cutlass::canonical_warp_idx_sync();

  // Issue Tma Descriptor Prefetch from a single thread
  if (warp_idx == 0 && lane_predicate) {
    CollectiveMainloop::prefetch_tma_descriptors(mainloop_params);
    CollectiveEpilogue::prefetch_tma_descriptors(epilogue_params);
  }

  // Obtain warp index
  int const warp_group_thread_idx = threadIdx.x % cutlass::NumThreadsPerWarpGroup;

  PipelineParams pipeline_params;
  int warp_group_idx = cutlass::canonical_warp_group_idx();
  pipeline_params.role = warp_group_idx == 0 ? MainloopPipeline::ThreadCategory::Producer
                                             : MainloopPipeline::ThreadCategory::Consumer;
  if constexpr (use_tma_load_kv) {
    pipeline_params.is_leader = warp_group_thread_idx == 0;
    pipeline_params.num_consumers = NUM_MMA_THREADS;
  } else {
    pipeline_params.producer_arv_count = NUM_COPY_THREADS;
    pipeline_params.consumer_arv_count = NUM_MMA_THREADS;
  }

  if (warp_idx == 0 && lane_predicate) {
// This arming MUST agree with the arrival side in sparse_mainloop.cuh: the mbarrier form arrives
// from all 32 lanes, the #else drain form arrives ONCE, and arming for 32 against a single arrival
// hangs (1500 s on MODE=fa3_1chunk).
//
// It tests the macro's VALUE, and requires PACKED_Q, for two reasons each found by a hang:
//   * `defined(FLASHINFER_FUSED_Q_MBARRIER)` was wrong as soon as the flag became settable:
//     -DFLASHINFER_FUSED_Q_MBARRIER=0 IS defined, so the drain form (gated `#if <value>` on the
//     arrival side) met a barrier armed for 32. Both sides must test the value.
//   * the 32-lane arrival exists ONLY inside the packed gather. With PACKED_Q off, Q comes in by
//     TMA with one arrive_and_expect_tx from one thread, so arming for 32 hangs there too.
#if FLASHINFER_FUSED_Q_MBARRIER && defined(FLASHINFER_FUSED_PACKED_Q)
    // The packed-GQA Q loader is ONE WARP issuing its own cp.async, completed with
    // cp.async.mbarrier.arrive, which tracks only the issuing thread's copies -- so all 32 lanes
    // must arrive for themselves. Arming for 32 is also what lets Q complete WITHOUT a cp.async
    // group drain: cp.async.commit_group sweeps the producer's in-flight KV copies into the group
    // it closes for Q, and committed groups retire in order, so a drain waits on the whole KV
    // pipeline no matter where the Q load sits (0.3.1 prices that form at ~3x slow).
    //
    // Arriving from 32 lanes on a barrier armed for 1 is what hung for 1500 s before -- and what
    // hung MODE=fa3_1chunk once the packed-Q load was spliced in without this init.
    shared_storage.barrier_Q.init(/*num_threads=*/cutlass::NumThreadsPerWarp);
#else
    shared_storage.barrier_Q.init(/*num_threads=*/1);
#endif
    shared_storage.barrier_O.init(/*num_threads=*/1);
#if FLASHINFER_FA3_KV_SHARE
    shared_storage.barrier_kv_share.init(2 * NUM_COPY_THREADS);
    shared_storage.kv_share_items = 0;
#endif
#if FUSED_Q_REUSE_FENCE
    // One arrival per work item, from the mma warpgroup's last warp.
    shared_storage.barrier_Qdone.init(/*num_threads=*/1);
#endif
  }
  // We're counting on pipeline_k to call cutlass::arch::fence_barrier_init();
  MainloopPipeline pipeline_k = [&] {
    if constexpr (use_tma_load_kv) {
      pipeline_params.transaction_bytes = CollectiveMainloop::TmaTransactionBytesK;
      return MainloopPipeline(shared_storage.pipeline_k, pipeline_params,
                              /*cluster_shape=*/Shape<_1, _1, _1>{});
    } else {
      return MainloopPipeline(shared_storage.pipeline_k, pipeline_params);
    }
  }();

  MainloopPipeline pipeline_v = [&] {
    if constexpr (use_tma_load_kv) {
      pipeline_params.transaction_bytes = CollectiveMainloop::TmaTransactionBytesV;
      return MainloopPipeline(shared_storage.pipeline_v, pipeline_params,
                              /*cluster_shape=*/Shape<_1, _1, _1>{});
    } else {
      return MainloopPipeline(shared_storage.pipeline_v, pipeline_params);
    }
  }();

  CollectiveMainloop collective_mainloop;
  CollectiveEpilogue collective_epilogue;

  // We need this to guarantee that the Pipeline init is visible to all producers and consumer
  // blocks in the Cluster
  __syncthreads();
#if FLASHINFER_FA3_KV_SHARE
  cutlass::arch::fence_barrier_init();
  cute::cluster_arrive_relaxed();
  cute::cluster_wait();
#endif

  uint32_t* maybe_prefix_len_ptr = nullptr;
  if constexpr (has_maybe_prefix_len_ptr_v<decltype(mainloop_params.additional_params)>) {
    maybe_prefix_len_ptr = mainloop_params.additional_params.maybe_prefix_len_ptr;
  }
  uint16_t* maybe_token_pos_in_items_ptr = nullptr;
  if constexpr (has_maybe_token_pos_in_items_ptr_v<decltype(mainloop_params.additional_params)>) {
    maybe_token_pos_in_items_ptr = mainloop_params.additional_params.maybe_token_pos_in_items_ptr;
  }
  uint32_t token_pos_in_items_len = 0;
  if constexpr (has_token_pos_in_items_len_v<decltype(mainloop_params.additional_params)>) {
    token_pos_in_items_len = mainloop_params.additional_params.token_pos_in_items_len;
  }
  uint16_t* maybe_max_item_len_ptr = nullptr;
  if constexpr (has_maybe_max_item_len_ptr_v<decltype(mainloop_params.additional_params)>) {
    maybe_max_item_len_ptr = mainloop_params.additional_params.maybe_max_item_len_ptr;
  }

  // STORE-COMPLETION HANDSHAKE (ours; FUSED_O_HANDSHAKE=1).
  //
  // `sO` is UNIONED with `smem_v`, so the producer refilling V for work item N+1 can overwrite the
  // sO the consumer is still reading for item N. With <= 1 work item per CTA sO is never reused and
  // this cannot fire; at 4-7 items per CTA it does, and that is the measured failure (0/296 clean
  // at 2.5 items/CTA, 1 bad row at 5.5, 76/384 at 7.2). FA3_STAGES=2 only narrows the window --
  // it does not order the accesses.
  //
  // So: both loops rendezvous at the END of each work item. The producer cannot begin item N+1's
  // V load until the consumer has finished reading sO for item N.
  //
  // Barrier id 7: flashinfer's NamedBarriers enum uses 0-6 and CUTLASS's ReservedNamedBarriers sit
  // at the top of the 0-15 hardware range, so 7 is free.
  //
  // Participants = NUM_MMA_THREADS + NUM_COPY_THREADS, because the producer branch is taken by all
  // of warpgroup 0 and the consumer branch by all MMA warpgroups. BOTH loops must arrive exactly
  // once per executed item or this deadlocks -- which is why it sits after the work and before
  // `++work_idx` on each side, and why both `continue` paths (tile out of range, num_kv_tiles <= 0)
  // skip it on BOTH sides symmetrically.
  constexpr int kFusedOStoreDone = 7;
  constexpr int kFusedHandshakeThreads = NUM_MMA_THREADS + NUM_COPY_THREADS;

  if (warp_group_idx == 0) {  // Producer
    if constexpr (use_tma_load_kv) {
      cutlass::arch::warpgroup_reg_dealloc<Ktraits::NUM_WARPS == 12 ? 24 : 32>();
    } else {
      cutlass::arch::warpgroup_reg_dealloc<72>();
    }

    int warp_idx_in_warpgroup = __shfl_sync(0xffffffff, (threadIdx.x / 32) % 4, 0);
    if (!use_tma_load_kv || warp_idx_in_warpgroup == 0) {  // Load Q, K, V
      PipelineState smem_pipe_write_k = cutlass::make_producer_start_state<MainloopPipeline>();
      PipelineState smem_pipe_write_v = cutlass::make_producer_start_state<MainloopPipeline>();

      int work_idx = 0;
#if FUSED_PIPE_COUNT
      int dbg_loaded = 0, dbg_items = 0;
      int dbg_loaded_full = 0, dbg_items_full = 0;   // packed_qo >= CTA_Q  (prefill tiles)
      int dbg_loaded_part = 0, dbg_items_part = 0;   // packed_qo <  CTA_Q  (decode tiles)
      // PER-THREAD commit counts. All NUM_COPY_THREADS producer threads execute load() and each
      // must call producer_commit once per tile, because producer_arv_count == NUM_COPY_THREADS.
      // A thread diverging through use_predicate or the kv_tile_idx == swa_begin special case
      // would arrive a different number of times: an OVER-arrival releases the consumer early
      // (a race with no deadlock -- the observed signature), an UNDER-arrival would deadlock.
      int dbg_commit_k = 0, dbg_commit_v = 0;
      int dbg_sig = 0;
#endif

      TileScheduler scheduler;
      for (auto work_tile_info = scheduler.get_initial_work(scheduler_params);
           work_tile_info.is_valid(scheduler_params);
           work_tile_info = scheduler.template get_next_work</*is_producer=*/true>(
               scheduler_params, work_tile_info)) {
        auto block_coord = work_tile_info.get_block_coord(scheduler_params);
        auto [q_tile_idx, qo_head_idx, kv_head_idx, qo_indptr, kv_indptr, qo_len, kv_len,
              batch_idx] = block_coord;

        if (q_tile_idx * CTA_Q >= qo_len) {
          continue;
        }
        int num_kv_tiles =
            collective_mainloop.get_num_kv_tiles(
                mainloop_params, q_tile_idx, qo_len, kv_len,
                fused_causal_kv_len(work_tile_info, kv_len));
        if (num_kv_tiles <= 0) {
          scheduler.prefetch_next_work(scheduler_params, work_tile_info);
          scheduler.broadcast_next_work(work_tile_info);
          continue;
        }
        int num_kv_tiles_outside_items_window = 0;
        int num_kv_tiles_prefix = 0;
        if constexpr (MULTIITEMSCORING) {
          auto prefix_len = __ldg(maybe_prefix_len_ptr + batch_idx);
          auto max_item_len = __ldg(maybe_max_item_len_ptr + batch_idx);
          auto valid_items_window_len =
              std::max(0, q_tile_idx * CTA_Q + kv_len - qo_len - max_item_len);
          num_kv_tiles_outside_items_window = valid_items_window_len / CTA_KV;
          num_kv_tiles_prefix = cute::ceil_div(prefix_len, CTA_KV);
        }
        if constexpr (MULTIITEMSCORING) {
          collective_mainloop.load<LEFT_SLIDING_WINDOW>(
              mainloop_params, pipeline_k, pipeline_v, smem_pipe_write_k, smem_pipe_write_v,
              shared_storage, scheduler, scheduler_params, work_tile_info, block_coord, work_idx,
              num_kv_tiles_outside_items_window, num_kv_tiles_prefix,
          // Absolute causal bound; a split item's kv_len is only its chunk.
          fused_causal_kv_len(work_tile_info, kv_len));
        } else {
          collective_mainloop.template load<LEFT_SLIDING_WINDOW>(
              mainloop_params, pipeline_k, pipeline_v, smem_pipe_write_k, smem_pipe_write_v,
              shared_storage, scheduler, scheduler_params, work_tile_info, block_coord, work_idx
#if FUSED_PIPE_COUNT
              // This is the branch taken when MULTIITEMSCORING is off, i.e. OUR path. The first
              // version of this instrument passed the counters to the MULTIITEMSCORING branch
              // instead, which is never instantiated here -- so both counters stayed 0 and every
              // thread would have reported false asymmetry.
              ,
              /*num_kv_tiles_outside_items_window=*/0, /*num_kv_tiles_prefix=*/0, &dbg_commit_k,
              &dbg_commit_v, &dbg_sig
#endif
          );
        }
#if FUSED_PIPE_COUNT
        // Intended loads for THIS item. Registers only -- printed after the loop, never inside it,
        // because every instrument that slowed this kernel down (printf probe, racecheck,
        // memcheck) masked the defect completely.
        //
        // SPLIT BY TILE OCCUPANCY. The first version summed over ALL items in the block, so a
        // partial-tile item over-releasing by k and a full-tile item under-releasing by k CANCELLED
        // and the instrument reported 0 mismatches on 132/132 blocks -- which it did. A decode item
        // (packed_qo = 4) and a prefill item (packed_qo = 1024) are the two populations, and only a
        // per-population count can see an imbalance between them.
        if (int(qo_len) >= int(CTA_Q)) {
          dbg_loaded_full += num_kv_tiles;
          ++dbg_items_full;
        } else {
          dbg_loaded_part += num_kv_tiles;
          ++dbg_items_part;
        }
        dbg_loaded += num_kv_tiles;
        ++dbg_items;
#endif
#if FUSED_O_HANDSHAKE
        // Wait for the consumer to finish reading sO for THIS item before looping to load the
        // next item's V into the memory sO aliases.
        cutlass::arch::NamedBarrier::sync(kFusedHandshakeThreads, kFusedOStoreDone);
#endif
        ++work_idx;
      }
#if FUSED_PIPE_COUNT
      // Only a thread whose own commit count disagrees with its own intended loads prints, so
      // SILENCE here is the pass condition and any line is the defect.
      // PARITY DIVERGENCE CHECK. Every producer thread in a warp gathers the SAME sequence of
      // (kv_tile_idx, parity) pairs if parity is uniform, so lane 0's signature must equal every
      // other lane's. Printing only on disagreement makes silence the pass condition and bounds
      // the output; a per-block line from thread 0 additionally lets the signature be compared
      // ACROSS RUNS, which separates "timing-dependent divergence" from "deterministic sequence,
      // variance from elsewhere".
      {
        int ref_sig = __shfl_sync(0xffffffff, dbg_sig, 0);
        if (dbg_sig != ref_sig) {
          printf("[sig-DIVERGE] blk=%u tid=%u sig=%d lane0=%d\n", blockIdx.x, threadIdx.x, dbg_sig,
                 ref_sig);
        }
        if (threadIdx.x == 0) {
          printf("[sig] blk=%u tid0 sig=%d items=%d\n", blockIdx.x, dbg_sig, dbg_items);
        }
      }
      if (dbg_commit_k != dbg_loaded || dbg_commit_v != dbg_loaded) {
        printf("[pipe-ASYM] blk=%u tid=%u items=%d loaded=%d commit_k=%d commit_v=%d\n",
               blockIdx.x, threadIdx.x, dbg_items, dbg_loaded, dbg_commit_k, dbg_commit_v);
      }
      if (threadIdx.x % cutlass::NumThreadsPerWarpGroup == 0) {
        printf("[pipe] blk=%u PRODUCER items=%d loaded=%d commit_k=%d commit_v=%d "
               "| FULL items=%d loaded=%d | PART items=%d loaded=%d\n", blockIdx.x, dbg_items,
               dbg_loaded, dbg_commit_k, dbg_commit_v, dbg_items_full, dbg_loaded_full,
               dbg_items_part, dbg_loaded_part);
      }
#endif
      collective_mainloop.load_tail(pipeline_k, pipeline_v, smem_pipe_write_k, smem_pipe_write_v);
    }
  } else {  // Consumer
#ifndef FUSED_FA3_CONSUMER_REGS
#define FUSED_FA3_CONSUMER_REGS 0
#endif
    constexpr uint32_t producer_register_count =
        use_tma_load_kv ? (Ktraits::NUM_WARPS == 12 ? 24 : 32) : 72;
    constexpr uint32_t consumer_register_count =
        FUSED_FA3_CONSUMER_REGS > 0
            ? FUSED_FA3_CONSUMER_REGS
            : (use_tma_load_kv ? (Ktraits::NUM_WARPS == 12 ? 240 : 160)
                               : (Ktraits::NUM_WARPS == 12 ? 216 : 144));
    static_assert(consumer_register_count >= 24 && consumer_register_count <= 256 &&
                  consumer_register_count % 8 == 0);
    static_assert(consumer_register_count * NUM_MMA_THREADS +
                      producer_register_count * NUM_COPY_THREADS <=
                  65536);
    if (entry_register_count > consumer_register_count) {
      cutlass::arch::warpgroup_reg_dealloc<consumer_register_count>();
    } else {
      cutlass::arch::warpgroup_reg_alloc<consumer_register_count>();
    }

    TileScheduler scheduler;
    // Initialize matmul objects.
    typename Ktraits::TiledMmaPV tiled_mma_pv;

#if FUSED_PIPE_COUNT
    // Counted in REGISTERS across every work item and printed once after the loop. The producer
    // reports what it intended to LOAD, this reports what was actually CONSUMED. A per-block
    // difference is the imbalance the source audit says should not exist.
    int dbg_consumed_k = 0, dbg_consumed_v = 0;
    int dbg_cons_full = 0, dbg_cons_part = 0;
#endif
    PipelineState smem_pipe_read_k, smem_pipe_read_v;
    // We don't need separate variables smem_pipe_release_k and smem_pipe_release_v
    // (like in Cutlass's gemm) because the read and release pipeline states are always the same.

    CollectiveMainloop::WarpScheduler::mma_init();
    scheduler.init_consumer();

    int work_idx = 0;
    CUTLASS_PRAGMA_NO_UNROLL
    for (auto work_tile_info = scheduler.get_initial_work(scheduler_params);
         work_tile_info.is_valid(scheduler_params);
         work_tile_info = scheduler.template get_next_work</*is_producer=*/false>(scheduler_params,
                                                                                  work_tile_info)) {
      // Attention output (GEMM-II) accumulator.
      Tensor tOrO = partition_fragment_C(tiled_mma_pv, select<0, 1>(TileShape_PDV{}));

      auto block_coord = work_tile_info.get_block_coord(scheduler_params);
      auto [q_tile_idx, qo_head_idx, kv_head_idx, qo_indptr, kv_indptr, qo_len, kv_len, batch_idx] =
          block_coord;

      AttentionVariant variant(mainloop_params, block_coord);
      auto attention_updater =
          variant.template GetAttentionUpdater<2 * (2 * CTA_Q / NUM_MMA_THREADS)>();

      if (q_tile_idx * CTA_Q >= qo_len) {
        continue;
      }
      int num_kv_tiles =
          collective_mainloop.get_num_kv_tiles(
              mainloop_params, q_tile_idx, qo_len, kv_len,
              fused_causal_kv_len(work_tile_info, kv_len));
      if (num_kv_tiles <= 0) {  // We exit early and write 0 to gO and -inf to gLSE.
        // A SPLIT item's fully masked chunk must write its PARTIAL slot, not the final O: the
        // merge counts the chunk either way (the plan chunks uniformly, with no causal
        // adjustment, so the count matches the slab sizing), and an unwritten partial_lse slot
        // reads as 0.0 and folds a zero O in with weight 2^(0 - lse_true) -- a ~1% dilution,
        // measured as the intermittent rel 0.03311 on row 0. store_zero would also write the
        // final O through a token-indexed mapping that is wrong on the packed path.
        bool zeroed_partial = false;
        if constexpr (fa3_has_split_kv<TileScheduler>::value) {
          if (work_tile_info.group_id >= 0 && epilogue_params.partial_o != nullptr) {
            collective_epilogue.store_partial_zero(
                epilogue_params, threadIdx.x - NUM_COPY_THREADS, block_coord,
                work_tile_info.partial_indptr, work_tile_info.kv_chunk_idx,
                work_tile_info.num_kv_chunks);
            zeroed_partial = true;
          }
        }
        if (!zeroed_partial) {
          collective_epilogue.store_zero(epilogue_params, shared_storage,
                                         threadIdx.x - NUM_COPY_THREADS, block_coord);
        }
        continue;
      }

      int swa_begin_kv_tile_idx = 0;
      int swa_end_kv_tile_idx = -1;
      if constexpr (LEFT_SLIDING_WINDOW) {
        swa_begin_kv_tile_idx = get_swa_begin_kv_tile_idx<CTA_Q, CTA_KV>(
            mainloop_params.window_left, q_tile_idx, qo_len, kv_len);
        swa_end_kv_tile_idx = get_swa_end_kv_tile_idx<CTA_Q, CTA_KV>(mainloop_params.window_left,
                                                                     q_tile_idx, qo_len, kv_len);
      }

      uint32_t prefix_len = 0;
      uint16_t* token_pos_in_items = nullptr;
      if constexpr (MULTIITEMSCORING) {
        prefix_len = __ldg(maybe_prefix_len_ptr + batch_idx);
        token_pos_in_items = maybe_token_pos_in_items_ptr + batch_idx * token_pos_in_items_len;
      }
      int num_kv_tiles_outside_items_window = 0;
      int num_kv_tiles_prefix = 0;
      if constexpr (MULTIITEMSCORING) {
        auto prefix_len = __ldg(maybe_prefix_len_ptr + batch_idx);
        auto max_item_len = __ldg(maybe_max_item_len_ptr + batch_idx);
        auto valid_items_window_len =
            std::max(0, q_tile_idx * CTA_Q + kv_len - qo_len - max_item_len);
        num_kv_tiles_outside_items_window = valid_items_window_len / CTA_KV;
        num_kv_tiles_prefix = cute::ceil_div(prefix_len, CTA_KV);
      }
#if FLASHINFER_FUSED_TRACE_WRITE
      // How many KV tiles the mainloop will actually iterate, from every block. A
      // zero-iteration mainloop leaves tOrO untouched, which is what a 3.076e+06 residual on an
      // otherwise-correct work item looks like. Printed BEFORE the call so it is its own null
      // case.
      if (threadIdx.x == NUM_COPY_THREADS) {
        printf("[fa3 mma] blk=%u work=%u num_kv_tiles=%d swa=[%d,%d) qo_len=%d kv_len=%d\n",
               blockIdx.x, work_idx, int(num_kv_tiles), int(swa_begin_kv_tile_idx),
               int(swa_end_kv_tile_idx), int(qo_len), int(kv_len));
      }
#endif
      mma_f16<Ktraits, /*LEFT_SLIDING_WINDOW=*/LEFT_SLIDING_WINDOW, CAUSAL, MULTIITEMSCORING,
              CollectiveMainloop::WarpScheduler>(
          mainloop_params, variant, pipeline_k, pipeline_v, smem_pipe_read_k, smem_pipe_read_v,
          tOrO, attention_updater, num_kv_tiles,
#if FUSED_PIPE_COUNT
          &dbg_consumed_k, &dbg_consumed_v, &dbg_cons_full, &dbg_cons_part,
#else
          nullptr, nullptr, nullptr, nullptr,
#endif
          swa_begin_kv_tile_idx, swa_end_kv_tile_idx,
          threadIdx.x - NUM_COPY_THREADS, work_idx, q_tile_idx, shared_storage, qo_len, kv_len,
          qo_head_idx, kv_head_idx, prefix_len, token_pos_in_items,
          num_kv_tiles_outside_items_window, num_kv_tiles_prefix,
          // Absolute causal bound; a split item's kv_len is only its chunk.
          fused_causal_kv_len(work_tile_info, kv_len));
      // A split-KV item writes a PARTIAL, not final O: its slice covers only one kv chunk and
      // needs the scheduled merge to combine it. A whole row writes final O directly.
      // group_id >= 0 is the plan's own marker that this item belongs to a merge group, set by
      // the same LPT splitter that drives the FA2 roles. fa3_has_split_kv gates the whole thing
      // because upstream's scheduler has no such field on its WorkTileInfo.
      //
      // One store per work item, always. The first version of 0.3.1's probe ran store_partial
      // AND store for the same item, which double-arrives on EpilogueBarrier and desynchronises
      // the producer -- corrupting the run it was meant to measure.
#if FUSED_TILE_TRACE
      // ITEM IDENTITY, one line per (block, work item), consumer side. This is what the previous
      // trace lacked: without it a device trace samples one block of 132 and hopes. q_tile_idx and
      // qo_indptr map this item to the OUTPUT ROWS it owns, so a BADROWS index from the harness can
      // be matched to the item that produced it -- and only then is tracing that item's tile
      // sequence meaningful.
      if (threadIdx.x == NUM_COPY_THREADS) {
        printf("[item] blk=%u work=%d q_tile=%d qo_indptr=%d qo_len=%d kv_len=%d ckv=%d tiles=%d "
               "batch=%d\n",
               blockIdx.x, work_idx, int(q_tile_idx), int(qo_indptr), int(qo_len), int(kv_len),
               int(fused_causal_kv_len(work_tile_info, kv_len)), int(num_kv_tiles), int(batch_idx));
      }
#endif
      bool wrote_partial = false;
      if constexpr (fa3_has_split_kv<TileScheduler>::value) {
#if FLASHINFER_FUSED_TRACE_WRITE
        // BEFORE the gate, from EVERY block (999), so this is its own null case. The question is
        // what the scheduler ACTUALLY read -- a negative partial index reached partial_lse in
        // MODE=fa3_1chunk, where the plan marks every row unsplit (partial_indptr = -1), so the
        // gate should have been closed.
        if (threadIdx.x == NUM_COPY_THREADS) {
          printf("[fa3 gate] blk=%u work=%u group_id=%d chunks=%d partial_indptr=%d qo_len=%d "
                 "kv_len=%d chunk_idx=%d partial_o=%d\n",
                 blockIdx.x, work_idx, int(work_tile_info.group_id),
                 int(work_tile_info.num_kv_chunks), int(work_tile_info.partial_indptr),
                 int(work_tile_info.qo_len), int(work_tile_info.kv_len),
                 int(work_tile_info.kv_chunk_idx),
                 int(epilogue_params.partial_o != nullptr));
        }
#endif
        if (work_tile_info.group_id >= 0 && epilogue_params.partial_o != nullptr) {
          collective_epilogue.store_partial(
              epilogue_params, tOrO, attention_updater.get_lse(), shared_storage, tiled_mma_pv,
              threadIdx.x - NUM_COPY_THREADS, block_coord, work_tile_info.partial_indptr,
              work_tile_info.kv_chunk_idx, work_tile_info.num_kv_chunks);
          wrote_partial = true;
        }
      }
      if (!wrote_partial) {
        collective_epilogue.store(epilogue_params, tOrO, attention_updater.get_lse(),
                                  shared_storage, tiled_mma_pv, threadIdx.x - NUM_COPY_THREADS,
                                  block_coord);
      }
#if FUSED_O_HANDSHAKE
      // sO has been fully read by now (store/store_partial both finish their global writes before
      // returning), so release the producer to refill the aliased smem_v.
      cutlass::arch::NamedBarrier::sync(kFusedHandshakeThreads, kFusedOStoreDone);
#endif

      ++work_idx;
    }
#if FUSED_PIPE_COUNT
    if (threadIdx.x == NUM_COPY_THREADS) {
      printf("[pipe] blk=%u CONSUMER items=%d consumed_k=%d consumed_v=%d "
             "| FULL cons=%d | PART cons=%d\n", blockIdx.x, work_idx, dbg_consumed_k,
             dbg_consumed_v, dbg_cons_full, dbg_cons_part);
    }
#endif
    collective_epilogue.store_tail();
  }
}

template <typename CollectiveMainloop, typename CollectiveEpilogue, typename Ktraits,
          bool LEFT_SLIDING_WINDOW, bool CAUSAL, typename TileScheduler,
          bool MULTIITEMSCORING = false>
__global__ void __launch_bounds__(Ktraits::NUM_WARPS* cutlass::NumThreadsPerWarp, 1)
    PrefillWithKVCacheKernel(CUTE_GRID_CONSTANT
                             typename CollectiveMainloop::Params const mainloop_params,
                             CUTE_GRID_CONSTANT
                             typename CollectiveEpilogue::Params const epilogue_params,
                             CUTE_GRID_CONSTANT
                             typename TileScheduler::Params const scheduler_params) {
  extern __shared__ char shared_memory[];
  fa3_prefill_body<CollectiveMainloop, CollectiveEpilogue, Ktraits, LEFT_SLIDING_WINDOW, CAUSAL,
                   TileScheduler, MULTIITEMSCORING>(mainloop_params, epilogue_params,
                                                    scheduler_params, shared_memory);
}


template <typename KernelTraits, bool LEFT_SLIDING_WINDOW, bool CAUSAL, typename Params>
cudaError_t SinglePrefillWithKVCacheKernelTraitsDispatched(Params& params, cudaStream_t stream) {
  using DTypeQ = typename KernelTraits::DTypeQ;
  using DTypeKV = typename KernelTraits::DTypeKV;
  using DTypeO = typename KernelTraits::DTypeO;

  using CollectiveMainloop =
      CollectiveMainloop<typename Params::AdditionalParams, KernelTraits, CAUSAL>;
  using CollectiveEpilogue = CollectiveEpilogue<KernelTraits>;
  using Scheduler = SingleTileScheduler;
  typename CollectiveMainloop::Params mainloop_params = CollectiveMainloop::to_underlying_arguments(
      {params.q_ptr,
       get_gmem_layout(params.qo_len, params.num_qo_heads, KernelTraits::HEAD_DIM_QK,
                       params.q_stride_n,
                       params.q_stride_h),  // layout_Q
       params.k_ptr,
       get_gmem_layout(params.kv_len, params.num_kv_heads, KernelTraits::HEAD_DIM_QK,
                       params.k_stride_n,
                       params.k_stride_h),  // layout_K
       params.v_ptr,
       get_gmem_layout(params.kv_len, params.num_kv_heads, KernelTraits::HEAD_DIM_VO,
                       params.v_stride_n,
                       params.v_stride_h),  // layout_V
       params.window_left, params.additional_params});
  typename CollectiveEpilogue::Params epilogue_params =
      CollectiveEpilogue::to_underlying_arguments({
          static_cast<DTypeO*>(params.o_ptr),
          get_gmem_layout(params.qo_len, params.num_qo_heads, KernelTraits::HEAD_DIM_VO,
                          params.o_stride_n,
                          params.o_stride_h),  // layout_O
          static_cast<float*>(params.lse_ptr),
          get_lse_gmem_layout(params.qo_len, params.num_qo_heads),  // layout_LSE
      });

  int num_tiles_q = cutlass::ceil_div(params.qo_len, KernelTraits::CTA_Q);
  // TODO(Zihao): also support kv-head major
  typename Scheduler::Arguments scheduler_args = {
      num_tiles_q, params.num_qo_heads, params.qo_len, params.kv_len,
      cutlass::FastDivmod(params.num_qo_heads / params.num_kv_heads)};
  typename Scheduler::Params scheduler_params = Scheduler::to_underlying_arguments(scheduler_args);

  auto kernel =
      (void*)PrefillWithKVCacheKernel<CollectiveMainloop, CollectiveEpilogue, KernelTraits,
                                      LEFT_SLIDING_WINDOW, CAUSAL, Scheduler>;
  int smem_size = sizeof(typename KernelTraits::SharedStorage);
  FLASHINFER_CUDA_CALL(
      cudaFuncSetAttribute(kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, smem_size));

  int device;
  cudaGetDevice(&device);
  int multiprocessor_count;
  FLASHINFER_CUDA_CALL(
      cudaDeviceGetAttribute(&multiprocessor_count, cudaDevAttrMultiProcessorCount, device));
  dim3 grid_dims = Scheduler::get_grid_dim(scheduler_args, multiprocessor_count);
  static constexpr int num_ctas = KernelTraits::NUM_WARPS * 32;
  dim3 block_dims(num_ctas);
  void* args[] = {&mainloop_params, &epilogue_params, &scheduler_params};
  FLASHINFER_CUDA_CALL(cudaLaunchKernel(kernel, grid_dims, block_dims, args, smem_size, stream));

  return cudaSuccess;
}

template <typename KernelTraits, bool LEFT_SLIDING_WINDOW, bool CAUSAL,
          bool SAME_SCHEDULE_FOR_ALL_HEADS, typename Params, bool MULTIITEMSCORING = false>
cudaError_t BatchPrefillWithPagedKVCacheKernelTraitsDispatched(Params& params,
                                                               cudaStream_t stream) {
  using DTypeQ = typename KernelTraits::DTypeQ;
  using DTypeKV = typename KernelTraits::DTypeKV;
  using DTypeO = typename KernelTraits::DTypeO;
  using IdType = typename KernelTraits::IdType;

  using CollectiveMainloop = SparseCollectiveMainloop<typename Params::AdditionalParams,
                                                      KernelTraits, CAUSAL, MULTIITEMSCORING>;
  using CollectiveEpilogue = CollectiveEpilogue<KernelTraits>;
  using Scheduler =
      std::conditional_t<SAME_SCHEDULE_FOR_ALL_HEADS, BatchPrefillTileScheduler<IdType>,
                         BatchPrefillPersistentTileScheduler<IdType>>;

  typename CollectiveMainloop::Params mainloop_params = CollectiveMainloop::to_underlying_arguments(
      {params.q_ptr,
       get_gmem_layout(params.nnz_qo, params.num_qo_heads, KernelTraits::HEAD_DIM_QK,
                       params.q_stride_n,
                       params.q_stride_h),  // layout_Q
       params.k_ptr,
       // NOTE(Zihao): nnz was useless here, we can just pass 0
       get_gmem_layout(/*nnz=*/0, params.num_kv_heads, KernelTraits::HEAD_DIM_QK, params.k_stride_n,
                       params.k_stride_h),  // layout_K
       params.v_ptr,
       get_gmem_layout(/*nnz=*/0, params.num_kv_heads, KernelTraits::HEAD_DIM_VO, params.v_stride_n,
                       params.v_stride_h),  // layout_V
       params.kv_indices, params.window_left,
       params.k_page_stride,                     // Stride between pages for K
       params.v_page_stride,                     // Stride between pages for V
       static_cast<uint32_t>(params.page_size),  // Page size
       params.additional_params});
  typename CollectiveEpilogue::Params epilogue_params =
      CollectiveEpilogue::to_underlying_arguments({
          params.o_ptr,
          get_gmem_layout(params.nnz_qo, params.num_qo_heads, KernelTraits::HEAD_DIM_VO,
                          params.o_stride_n,
                          params.o_stride_h),                                       // layout_O
          params.lse_ptr, get_lse_gmem_layout(params.nnz_qo, params.num_qo_heads),  // layout_LSE
      });

  typename Scheduler::Arguments scheduler_args = {
      params.work_indptr,
      params.head_indices,
      params.qo_tile_indices,
      params.qo_indptr,
      params.kv_indptr,
      params.qo_lens,
      params.kv_lens,
      params.batch_indices,
      cutlass::FastDivmod(params.num_qo_heads / params.num_kv_heads),
      params.num_qo_heads};
  typename Scheduler::Params scheduler_params = Scheduler::to_underlying_arguments(scheduler_args);

  // Get the ptr to kernel function.
  auto kernel =
      (void*)PrefillWithKVCacheKernel<CollectiveMainloop, CollectiveEpilogue, KernelTraits,
                                      LEFT_SLIDING_WINDOW, CAUSAL, Scheduler, MULTIITEMSCORING>;
  int smem_size = sizeof(typename KernelTraits::SharedStorage);
  FLASHINFER_CUDA_CALL(
      cudaFuncSetAttribute(kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, smem_size));

  int device;
  cudaGetDevice(&device);
  int multiprocessor_count;
  FLASHINFER_CUDA_CALL(
      cudaDeviceGetAttribute(&multiprocessor_count, cudaDevAttrMultiProcessorCount, device));
  dim3 grid_dims = Scheduler::get_grid_dim(scheduler_args, multiprocessor_count);
  static constexpr int ctaSize = KernelTraits::NUM_WARPS * 32;
  dim3 block_dims(ctaSize);
  void* args[] = {&mainloop_params, &epilogue_params, &scheduler_params};
  FLASHINFER_CUDA_CALL(cudaLaunchKernel(kernel, grid_dims, block_dims, args, smem_size, stream));

  return cudaSuccess;
}

template <typename KernelTraits, bool LEFT_SLIDING_WINDOW, bool CAUSAL,
          bool SAME_SCHEDULE_FOR_ALL_HEADS, typename Params>
cudaError_t BatchPrefillWithRaggedKVCacheKernelTraitsDispatched(Params& params,
                                                                cudaStream_t stream) {
  using DTypeQ = typename KernelTraits::DTypeQ;
  using DTypeKV = typename KernelTraits::DTypeKV;
  using DTypeO = typename KernelTraits::DTypeO;
  using IdType = typename KernelTraits::IdType;

  using CollectiveMainloop =
      CollectiveMainloop<typename Params::AdditionalParams, KernelTraits, CAUSAL>;
  using CollectiveEpilogue = CollectiveEpilogue<KernelTraits>;
  using Scheduler =
      std::conditional_t<SAME_SCHEDULE_FOR_ALL_HEADS, BatchPrefillTileScheduler<IdType>,
                         BatchPrefillPersistentTileScheduler<IdType>>;
  typename CollectiveMainloop::Params mainloop_params = CollectiveMainloop::to_underlying_arguments(
      {params.q_ptr,
       get_gmem_layout(params.nnz_qo, params.num_qo_heads, KernelTraits::HEAD_DIM_QK,
                       params.q_stride_n,
                       params.q_stride_h),  // layout_Q
       params.k_ptr,
       // NOTE(Zihao): nnz was useless here, we can just pass 0
       get_gmem_layout(params.nnz_kv, params.num_kv_heads, KernelTraits::HEAD_DIM_QK,
                       params.k_stride_n,
                       params.k_stride_h),  // layout_K
       params.v_ptr,
       get_gmem_layout(params.nnz_kv, params.num_kv_heads, KernelTraits::HEAD_DIM_VO,
                       params.v_stride_n,
                       params.v_stride_h),  // layout_V
       params.window_left, params.additional_params});
  typename CollectiveEpilogue::Params epilogue_params =
      CollectiveEpilogue::to_underlying_arguments({
          params.o_ptr,
          get_gmem_layout(params.nnz_qo, params.num_qo_heads, KernelTraits::HEAD_DIM_VO,
                          params.o_stride_n,
                          params.o_stride_h),                                       // layout_O
          params.lse_ptr, get_lse_gmem_layout(params.nnz_qo, params.num_qo_heads),  // layout_LSE
      });

  // NOTE(Zihao): add support for kv head-major later
  typename Scheduler::Arguments scheduler_args = {
      params.work_indptr,
      params.head_indices,
      params.qo_tile_indices,
      params.qo_indptr,
      params.kv_indptr,
      params.qo_lens,
      params.kv_lens,
      params.batch_indices,
      cutlass::FastDivmod(params.num_qo_heads / params.num_kv_heads),
      params.num_qo_heads};
  typename Scheduler::Params scheduler_params = Scheduler::to_underlying_arguments(scheduler_args);

  // Get the ptr to kernel function.
  auto kernel =
      (void*)PrefillWithKVCacheKernel<CollectiveMainloop, CollectiveEpilogue, KernelTraits,
                                      LEFT_SLIDING_WINDOW, CAUSAL, Scheduler>;
  int smem_size = sizeof(typename KernelTraits::SharedStorage);
  FLASHINFER_CUDA_CALL(
      cudaFuncSetAttribute(kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, smem_size));

  int device;
  cudaGetDevice(&device);
  int multiprocessor_count;
  FLASHINFER_CUDA_CALL(
      cudaDeviceGetAttribute(&multiprocessor_count, cudaDevAttrMultiProcessorCount, device));
  dim3 grid_dims = Scheduler::get_grid_dim(scheduler_args, multiprocessor_count);
  static constexpr int ctaSize = KernelTraits::NUM_WARPS * 32;
  dim3 block_dims(ctaSize);
  void* args[] = {&mainloop_params, &epilogue_params, &scheduler_params};
  FLASHINFER_CUDA_CALL(cudaLaunchKernel(kernel, grid_dims, block_dims, args, smem_size, stream));

  return cudaSuccess;
}

template <uint32_t HEAD_DIM_QK, uint32_t HEAD_DIM_VO, bool CAUSAL>
constexpr auto getCTATileSize() {
  if constexpr (HEAD_DIM_QK == HEAD_DIM_VO) {
    if constexpr (HEAD_DIM_QK == 64) {
      return std::make_tuple(192, 128);
    } else if constexpr (HEAD_DIM_QK == 128) {
      if constexpr (CAUSAL) {
        return std::make_tuple(128, 128);
      } else {
        return std::make_tuple(128, 192);
      }
    } else {
      return std::make_tuple(128, 64);
    }
  } else {
    // NOTE(Zihao) hack for deepseek prefill
    static_assert(HEAD_DIM_QK == 192 && HEAD_DIM_VO == 128);
    return std::make_tuple(128, 128);
  }
}

template <uint32_t HEAD_DIM_QK, uint32_t HEAD_DIM_VO, MaskMode MASK_MODE, bool LEFT_SLIDING_WINDOW,
          typename AttentionVariant, typename Params>
cudaError_t SinglePrefillWithKVCacheDispatched(Params& params, cudaStream_t stream) {
  static_assert(HEAD_DIM_VO == 64 || HEAD_DIM_VO == 128 || HEAD_DIM_VO == 256);
  if (MASK_MODE == MaskMode::kCustom) {
    return cudaErrorNotSupported;  // Not supported yet.
  }
  constexpr bool CAUSAL = MASK_MODE == MaskMode::kCausal;
  constexpr auto CTA_TILE_SIZE = getCTATileSize<HEAD_DIM_QK, HEAD_DIM_VO, CAUSAL>();
  SinglePrefillWithKVCacheKernelTraitsDispatched<
      AttentionKernelTraits</*USE_TMA_LOAD_KV=*/true, HEAD_DIM_QK, HEAD_DIM_VO,
                            /*CTA_Q_=*/get<0>(CTA_TILE_SIZE),
                            /*CTA_KV_=*/get<1>(CTA_TILE_SIZE),
                            /*NUM_STAGES_=*/2, typename Params::DTypeQ, typename Params::DTypeKV,
                            typename Params::DTypeO, typename Params::IdType, AttentionVariant>,
      LEFT_SLIDING_WINDOW, CAUSAL>(params, stream);
  cudaError_t status = cudaGetLastError();
  return status;
}

template <uint32_t HEAD_DIM_QK, uint32_t HEAD_DIM_VO, MaskMode MASK_MODE, bool LEFT_SLIDING_WINDOW,
          bool SAME_SCHEDULE_FOR_ALL_HEADS, typename AttentionVariant, typename Params>
cudaError_t BatchPrefillWithRaggedKVCacheDispatched(Params& params, bool enable_pdl,
                                                    cudaStream_t stream) {
  static_assert(HEAD_DIM_VO == 64 || HEAD_DIM_VO == 128 || HEAD_DIM_VO == 256);
  if (MASK_MODE == MaskMode::kCustom) {
    return cudaErrorNotSupported;  // Not supported yet.
  }
  constexpr bool CAUSAL = MASK_MODE == MaskMode::kCausal;
  constexpr auto CTA_TILE_SIZE = getCTATileSize<HEAD_DIM_QK, HEAD_DIM_VO, CAUSAL>();
  BatchPrefillWithRaggedKVCacheKernelTraitsDispatched<
      AttentionKernelTraits</*USE_TMA_LOAD_KV=*/true, HEAD_DIM_QK, HEAD_DIM_VO,
                            /*CTA_Q_=*/get<0>(CTA_TILE_SIZE),
                            /*CTA_KV_=*/get<1>(CTA_TILE_SIZE),
                            /*NUM_STAGES_=*/2, typename Params::DTypeQ, typename Params::DTypeKV,
                            typename Params::DTypeO, typename Params::IdType, AttentionVariant>,
      LEFT_SLIDING_WINDOW, CAUSAL, SAME_SCHEDULE_FOR_ALL_HEADS>(params, stream);
  cudaError_t status = cudaGetLastError();
  return status;
}

template <uint32_t HEAD_DIM_QK, uint32_t HEAD_DIM_VO, MaskMode MASK_MODE, bool LEFT_SLIDING_WINDOW,
          bool SAME_SCHEDULE_FOR_ALL_HEADS, typename AttentionVariant, typename Params>
cudaError_t BatchPrefillWithPagedKVCacheDispatched(Params& params, bool enable_pdl,
                                                   cudaStream_t stream) {
  static_assert(HEAD_DIM_VO == 64 || HEAD_DIM_VO == 128 || HEAD_DIM_VO == 256);
  if (MASK_MODE == MaskMode::kCustom) {
    return cudaErrorNotSupported;  // Not supported yet.
  }
  constexpr bool CAUSAL = MASK_MODE == MaskMode::kCausal;
  constexpr bool MULTIITEMSCORING = MASK_MODE == MaskMode::kMultiItemScoring;
  if constexpr (HEAD_DIM_QK == HEAD_DIM_VO) {
    if constexpr (HEAD_DIM_VO == 64) {
      // NOTE(Zihao): CTA_KV not tuned for HEAD_DIM == 64, need to optimize later
      BatchPrefillWithPagedKVCacheKernelTraitsDispatched<
          AttentionKernelTraits</*USE_TMA_LOAD_KV=*/false, HEAD_DIM_QK, HEAD_DIM_VO,
                                /*CTA_Q_=*/192,
                                /*CTA_KV_=*/96,
                                /*NUM_STAGES_=*/2, typename Params::DTypeQ,
                                typename Params::DTypeKV, typename Params::DTypeO,
                                typename Params::IdType, AttentionVariant>,
          LEFT_SLIDING_WINDOW, CAUSAL, SAME_SCHEDULE_FOR_ALL_HEADS, Params, MULTIITEMSCORING>(
          params, stream);
    } else if constexpr (HEAD_DIM_VO == 128) {
      BatchPrefillWithPagedKVCacheKernelTraitsDispatched<
          AttentionKernelTraits</*USE_TMA_LOAD_KV=*/false, HEAD_DIM_QK, HEAD_DIM_VO,
                                /*CTA_Q_=*/128,
                                /*CTA_KV_=*/96,
                                /*NUM_STAGES_=*/2, typename Params::DTypeQ,
                                typename Params::DTypeKV, typename Params::DTypeO,
                                typename Params::IdType, AttentionVariant>,
          LEFT_SLIDING_WINDOW, CAUSAL, SAME_SCHEDULE_FOR_ALL_HEADS, Params, MULTIITEMSCORING>(
          params, stream);
    } else {
      // HEAD_DIM == 256;
      // NOTE(Zihao): CTA_KV not tuned for HEAD_DIM == 256, need to optimize later
      BatchPrefillWithPagedKVCacheKernelTraitsDispatched<
          AttentionKernelTraits</*USE_TMA_LOAD_KV=*/false, HEAD_DIM_QK, HEAD_DIM_VO,
                                /*CTA_Q_=*/128,
                                /*CTA_KV_=*/32,
                                /*NUM_STAGES_=*/2, typename Params::DTypeQ,
                                typename Params::DTypeKV, typename Params::DTypeO,
                                typename Params::IdType, AttentionVariant>,
          LEFT_SLIDING_WINDOW, CAUSAL, SAME_SCHEDULE_FOR_ALL_HEADS, Params, MULTIITEMSCORING>(
          params, stream);
    }
  } else {
    return cudaErrorNotSupported;
  }
  cudaError_t status = cudaGetLastError();
  return status;
};

}  // namespace flashinfer

#endif  // FLASHINFER_ATTENTION_HOPPER_PREFILL_SM90_CUH_

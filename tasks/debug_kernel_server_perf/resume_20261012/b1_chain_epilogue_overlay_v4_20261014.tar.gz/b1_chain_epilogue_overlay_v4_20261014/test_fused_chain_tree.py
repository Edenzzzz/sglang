import importlib.util
import os
from pathlib import Path
import unittest

import torch


source = Path(
    os.environ.get(
        "CHAIN_TREE_SOURCE",
        Path(__file__).resolve().parents[2]
        / "python/sglang/srt/speculative/fused_chain_tree.py",
    )
)
specification = importlib.util.spec_from_file_location("chain_tree_candidate", source)
candidate = importlib.util.module_from_spec(specification)
specification.loader.exec_module(candidate)
build_fused_chain_tree = candidate.build_fused_chain_tree


def fixture(batch_size, width, length=31, strided=False):
    spacing = 2 if strided else 1
    bonus = torch.arange(batch_size * spacing, device="cuda", dtype=torch.int32)[
        ::spacing
    ]
    draft = torch.arange(batch_size * (width - 1) * spacing, device="cuda").reshape(
        batch_size, (width - 1) * spacing
    )[:, ::spacing]
    lengths = torch.tensor(
        [length + index % 5 for index in range(batch_size * spacing)],
        dtype=torch.int32,
        device="cuda",
    )[::spacing]
    return bonus, draft, lengths


def reference(bonus, draft, lengths, mode, prefix=True):
    bonus, draft, lengths = bonus.cpu(), draft.cpu(), lengths.cpu()
    batch_size, depth = draft.shape
    width = depth + 1
    indices = torch.arange(batch_size * width).reshape(batch_size, width)
    next_tokens = torch.arange(1, width + 1).expand(batch_size, width).clone()
    if batch_size:
        next_tokens[:, -1] = -1
    if mode == 0:
        rows = [
            torch.arange(int(length) + width)[None, :]
            <= int(length) + torch.arange(width)[:, None]
            for length in lengths
        ]
        mask = (
            torch.cat([row.flatten() for row in rows])
            if rows
            else torch.empty(0, dtype=torch.bool)
        )
    elif mode == 1:
        mask = (
            torch.ones(width, width, dtype=torch.bool)
            .tril()
            .expand(batch_size, width, width)
            .flatten()
        )
    else:
        dtype = (
            torch.uint8 if width <= 8 else torch.uint16 if width <= 16 else torch.uint32
        )
        mask = torch.tensor(
            [(1 << (column + 1)) - 1 for column in range(width)], dtype=dtype
        )
        mask = mask.expand(batch_size, width).flatten()
    positions = (lengths[:, None] + torch.arange(width)).flatten().long()
    tokens = torch.cat((bonus[:, None], draft), dim=1).flatten()
    return mask, positions, indices, next_tokens, torch.full_like(indices, -1), tokens


@unittest.skipUnless(torch.cuda.is_available(), "requires CUDA")
class TestFusedChainTree(unittest.TestCase):
    def assert_outputs(self, actual, expected):
        for index, (output, reference_output) in enumerate(zip(actual[:6], expected)):
            torch.testing.assert_close(
                output.cpu(), reference_output, rtol=0, atol=0, msg=f"output {index}"
            )

    def test_all_masks_widths_and_strides(self):
        for batch_size in (0, 1, 8, 33):
            for width in (1, 2, 4, 8, 16, 32):
                for mode in (0, 1, 2):
                    with self.subTest(batch=batch_size, width=width, mode=mode):
                        inputs = fixture(batch_size, width, strided=True)
                        actual = build_fused_chain_tree(
                            *inputs, int(inputs[2].sum()), mode
                        )
                        self.assert_outputs(actual, reference(*inputs, mode))

    def test_long_full_masks(self):
        for length in (0, 32768, 65536, 131072, 262144):
            inputs = fixture(8, 4, length)
            actual = build_fused_chain_tree(*inputs, int(inputs[2].sum()), 0)
            self.assert_outputs(actual, reference(*inputs, 0))

    def test_preserves_unread_prefix_and_buffer_tail(self):
        inputs = fixture(8, 4, 65536)
        expected = reference(*inputs, 0)
        buffer = torch.zeros(expected[0].numel() + 257, device="cuda", dtype=torch.bool)
        actual = build_fused_chain_tree(
            *inputs,
            int(inputs[2].sum()),
            0,
            tree_mask_buf=buffer,
            fill_prefix_mask=False,
        )
        offset = 0
        for length in inputs[2].cpu().tolist():
            count = (length + 4) * 4
            expected[0][offset : offset + count].view(4, -1)[:, :length] = False
            offset += count
        self.assert_outputs((actual[0][:offset], *actual[1:]), expected)
        self.assertFalse(bool(buffer[offset:].any()))

    def test_cache_locations_and_mrope(self):
        inputs = fixture(8, 4, 57, strided=True)
        table = torch.arange(16 * 128 * 2, device="cuda", dtype=torch.int32).reshape(
            16, 256
        )[:, ::2]
        request_indices = torch.arange(16, device="cuda")[::2]
        actual = build_fused_chain_tree(
            *inputs,
            int(inputs[2].sum()),
            0,
            req_pool_indices=request_indices,
            req_to_token=table,
            with_mrope=True,
        )
        self.assert_outputs(actual, reference(*inputs, 0))
        expected_locations = table[
            request_indices[:, None],
            inputs[2][:, None] + torch.arange(4, device="cuda"),
        ]
        torch.testing.assert_close(
            actual[6], expected_locations.flatten().long(), rtol=0, atol=0
        )
        torch.testing.assert_close(actual[7], actual[1].expand(3, -1), rtol=0, atol=0)

    def test_graph_replay_uses_updated_inputs(self):
        inputs = fixture(8, 4)
        length_bound = int(inputs[2].sum())
        for mode in (0, 1, 2):
            build_fused_chain_tree(*inputs, length_bound, mode)
            torch.cuda.synchronize()
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                actual = build_fused_chain_tree(*inputs, length_bound, mode)
            for iteration in range(3):
                inputs[0].add_(3)
                inputs[1].add_(5)
                inputs[2].copy_(inputs[2].roll(1))
                graph.replay()
                self.assert_outputs(actual, reference(*inputs, mode))

    def test_one_kernel_launch(self):
        inputs = fixture(8, 4, 65536)
        length_bound = int(inputs[2].sum())
        build_fused_chain_tree(*inputs, length_bound, 0)
        torch.cuda.synchronize()
        with torch.profiler.profile(
            activities=[torch.profiler.ProfilerActivity.CUDA]
        ) as profile:
            build_fused_chain_tree(*inputs, length_bound, 0)
            torch.cuda.synchronize()
        kernels = [
            event for event in profile.events() if event.device_type.name == "CUDA"
        ]
        self.assertEqual(len(kernels), 1)
        self.assertIn("_fused_chain_tree_kernel", kernels[0].name)

    def test_upstream_reference(self):
        from sglang.srt.speculative.eagle_utils import (
            TreeMaskMode,
            build_tree_kernel_efficient,
        )

        for width in (2, 4, 8, 16):
            inputs = fixture(8, width, 4096)
            parents = (
                torch.arange(-1, width - 2, device="cuda").expand(8, -1).contiguous()
            )
            selected = torch.arange(width - 1, device="cuda").expand(8, -1).contiguous()
            for mode in (0, 1, 2):
                upstream = build_tree_kernel_efficient(
                    inputs[0].long(),
                    parents,
                    selected,
                    inputs[1],
                    inputs[2].long(),
                    int(inputs[2].sum()),
                    1,
                    width - 1,
                    width,
                    TreeMaskMode(mode),
                )
                actual = build_fused_chain_tree(*inputs, int(inputs[2].sum()), mode)
                for output, expected in zip(actual[:6], upstream):
                    torch.testing.assert_close(output, expected, rtol=0, atol=0)


if __name__ == "__main__":
    unittest.main(verbosity=2)

#!/bin/bash
set -e
W=/dev/shm/w
OUT=$W/a2_fresh_lpt
rm -rf "$OUT"; mkdir -p "$OUT"
export PYTHONPATH=$W/validated_upstream/python SGLANG_FUSED_FI_ROOT=$W/fi HF_HOME=$W/hf
export FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=48,32,16 FUSED_CONST_PERS_PARAMS=1 FLASHINFER_FUSED_BACKFILL=1 FUSED_FA2_KV_CHUNK=1024
export CORRECTNESS_SYNTHETIC=0 CORRECTNESS_DATASET=$W/datasets/ShareGPT.original.json
export DISABLE_CUDA_GRAPH=1 BENCH_CHUNK=512 CORRECTNESS_DECODE_TOKENS=1200 SGLANG_FUSED_DECODE_GUARD=0 SGLANG_FUSED_SPLIT_VERIFY=1 SGLANG_FUSED_SPLIT_EXCESS_TOL=0.001
$W/venv/bin/python -u $W/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py MTP_LPT "$OUT" > "$OUT/run.log" 2>&1
echo FRESH_LPT_DONE >> "$OUT/run.log"

set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi
export HEADS=28,4 SM_SPLIT=64 FUSED_REFERENCE_WORKSPACE_BYTES=16 FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=64,32,16 FUSED_CONST_PERS_PARAMS=1 FUSED_FA2_REG_REALLOC=1 FLASHINFER_FUSED_BACKFILL=1 FUSED_FA2_KV_CHUNK=1024
export SGLANG_FUSED_FA2_MMA_KV=2 SGLANG_FUSED_FA2_QSPLIT=0 FA3_STAGES=2
for width in 128 64; do
 export FA3_CTA_Q=$width
 for mode in fa2 fa3_1chunk mixed_verify; do
  MODE=$mode /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fa3_register_direction/${width}_${mode}.log 2>&1
 done
 FUSED_WORK_BUDGET_SPLIT=0 PREFILL_QO=504 PREFILL_KV=504 MODE=mixed_verify /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fa3_register_direction/${width}_masked.log 2>&1
 SM_SPLIT=all MODE=mixed_verify /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fa3_register_direction/${width}_backfill.log 2>&1
 MODE=mixed_verify TIME_AB=1 TIME_CUDA_GRAPH=1 TIME_ITERS=100 /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fa3_register_direction/${width}_timing.log 2>&1
 /usr/local/cuda/bin/cuobjdump --dump-resource-usage /home/tiger/.cache/torch_extensions/py312_cu130/fused_fa3/fused_fa3.so > /dev/shm/w/fa3_register_direction/${width}_resources.log
 echo GEOMETRY_${width}_PASS
done

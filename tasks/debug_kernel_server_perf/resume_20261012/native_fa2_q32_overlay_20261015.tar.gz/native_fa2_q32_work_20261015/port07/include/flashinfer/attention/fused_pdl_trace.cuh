#pragma once

#include <cuda_runtime.h>
#include <type_traits>
#include <utility>

namespace flashinfer {

enum FusedPdlTraceSlot { kPdlFa3Start = 0, kPdlFa3End = 1, kPdlFa2Start = 2, kPdlFa2End = 3 };

template <int Slot, bool Maximum = false>
__device__ __forceinline__ void FusedPdlRecord(unsigned long long* timeline) {
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 900
  if (timeline != nullptr && threadIdx.x == 0 && threadIdx.y == 0 && threadIdx.z == 0) {
    unsigned long long timestamp;
    asm volatile("mov.u64 %0, %globaltimer;" : "=l"(timestamp) :: "memory");
    if constexpr (Maximum) atomicMax(timeline + Slot, timestamp);
    else atomicMin(timeline + Slot, timestamp);
  }
#endif
}

template <typename Params, typename = void>
struct FusedNativePdlParams : std::false_type {};

template <typename Params>
struct FusedNativePdlParams<Params, std::void_t<
    decltype(std::declval<Params>().independent_pdl),
    decltype(std::declval<Params>().pdl_timeline)>> : std::true_type {};

template <typename Params>
__device__ __forceinline__ bool FusedNativeIndependentPdl(const Params& params) {
  if constexpr (FusedNativePdlParams<Params>::value) return params.independent_pdl;
  return false;
}

template <int Slot, typename Params>
__device__ __forceinline__ void FusedNativePdlRecord(const Params& params) {
  if constexpr (FusedNativePdlParams<Params>::value) FusedPdlRecord<Slot>(params.pdl_timeline);
}

}

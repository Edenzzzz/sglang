import argparse
import hashlib
import json
from pathlib import Path
import statistics

import torch

from load_native_q32 import build
from test_native_q32 import assert_numerical, execute, make_case, reference


def benchmark(case, mode, expected, iterations):
    def launch():
        if mode == "public64":
            return case.wrapper.run(case.query, (case.key, case.value))
        execute(case, 32 if mode == "native32" else 0)
        return case.output

    for warmup in range(20):
        launch()
    torch.cuda.synchronize()
    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        result = launch()
    result.fill_(float("nan"))
    graph.replay()
    torch.cuda.synchronize()
    worst = assert_numerical(result, expected)
    samples = []
    for repeat in range(3):
        started = torch.cuda.Event(enable_timing=True)
        finished = torch.cuda.Event(enable_timing=True)
        started.record()
        for iteration in range(iterations):
            graph.replay()
        finished.record()
        finished.synchronize()
        samples.append(started.elapsed_time(finished) / iterations)
    return {"mode": mode, "milliseconds": statistics.median(samples), "samples_ms": samples,
            "worst_head_relative_error": worst, "cuda_graph": True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--iterations", type=int, default=100)
    args = parser.parse_args()
    if args.iterations < 1:
        raise ValueError("iterations must be positive")
    torch.backends.cuda.matmul.allow_tf32 = False
    build()
    fixtures = (
        ("one4k", [4], [4096], 28, None),
        ("one64k", [4], [65536], 28, None),
        ("eight16k", [4] * 8, [16384] * 8, 28, None),
        ("fortysix48k", [4] * 46, [49152] * 46, 28, None),
        ("sixteen128k", [4] * 16, [131072] * 16, 28, None),
        ("twentyfour256k", [4] * 24, [262144] * 24, 28, None),
        ("varlen", [3, 4] * 16, [8192, 49152] * 16, 28, None),
        ("split64k", [4] * 8, [65536] * 8, 28, 4096),
        ("gqa4_q8", [8] * 16, [49152] * 16, 16, None),
    )
    report = {"cases": [], "source_sha256": {}}
    for name in ("native_fa2_q32.cu", "native_prefill_bridge.cuh", "load_native_q32.py",
                 "port07/include/flashinfer/attention/prefill.cuh", "test_native_q32.py", "bench_native_q32.py"):
        path = Path(__file__).parent / name
        report["source_sha256"][name] = hashlib.sha256(path.read_bytes()).hexdigest()
    for name, query, lengths, heads, split_size in fixtures:
        torch.manual_seed(20261015)
        case = make_case(query, lengths, heads=heads, split_size=split_size)
        if case.wrapper._plan_info[3] != 64:
            raise AssertionError((name, case.wrapper._plan_info))
        expected = reference(case)
        baseline = case.wrapper.run(case.query, (case.key, case.value)).clone()
        assert_numerical(baseline, expected)
        execute(case, 0)
        torch.cuda.synchronize()
        torch.testing.assert_close(case.output, baseline, rtol=0, atol=0)
        for repeat in (1, 2):
            modes = ("public64", "native64", "native32") if repeat == 1 else ("native32", "native64", "public64")
            for mode in modes:
                entry = benchmark(case, mode, expected, args.iterations)
                entry.update(case=name, repeat=repeat, query_lengths=query, kv_lengths=lengths,
                             query_heads=heads, kv_heads=case.kv_heads,
                             plan_cta_q=int(case.wrapper._plan_info[3]), plan_split_kv=int(case.wrapper._plan_info[14]))
                report["cases"].append(entry)
                args.output.write_text(json.dumps(report, indent=2) + "\n")
                print("NATIVE_Q32_CASE_PASS", json.dumps(entry), flush=True)
        del case, expected, baseline
        torch.cuda.empty_cache()
    if len(report["cases"]) != 54:
        raise AssertionError("Incomplete Q32 matrix")
    print("NATIVE_Q32_MATRIX_PASS cases=54", flush=True)


if __name__ == "__main__":
    main()

import os, shutil
from huggingface_hub import hf_hub_download
source=hf_hub_download("anon8231489123/ShareGPT_Vicuna_unfiltered", "ShareGPT_V3_unfiltered_cleaned_split.json", repo_type="dataset")
os.makedirs("/dev/shm/w/datasets", exist_ok=True)
shutil.copyfile(source, "/dev/shm/w/datasets/ShareGPT.original.json")
print("SHAREGPT_DOWNLOAD_COMPLETE", os.path.getsize("/dev/shm/w/datasets/ShareGPT.original.json"), flush=True)

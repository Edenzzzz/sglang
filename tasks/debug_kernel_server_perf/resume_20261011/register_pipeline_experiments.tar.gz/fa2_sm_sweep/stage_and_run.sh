set -e
mkdir -p /dev/shm/w/workloads/tracelab
/opt/tiger/arnold/hdfs_client/hdfs dfs -get 'hdfs://haruna/tmp/vibecuda-f096519a4d17aa1c-tracelab-1791719040/syfi_coding_trace.jsonl.gz' /dev/shm/w/workloads/tracelab/syfi_coding_trace.jsonl.gz.part
printf '%s\n' '9d265eae69a31cae203848bea936f018148eed7ca8bf56050c5abe96da0b4e6b /dev/shm/w/workloads/tracelab/syfi_coding_trace.jsonl.gz.part' | sha256sum -c -
gzip -t /dev/shm/w/workloads/tracelab/syfi_coding_trace.jsonl.gz.part
mv /dev/shm/w/workloads/tracelab/syfi_coding_trace.jsonl.gz.part /dev/shm/w/workloads/tracelab/syfi_coding_trace.jsonl.gz
echo TRACELAB_EXACT_FILE_VERIFIED
bash /dev/shm/w/fa2_sm_sweep/run.sh

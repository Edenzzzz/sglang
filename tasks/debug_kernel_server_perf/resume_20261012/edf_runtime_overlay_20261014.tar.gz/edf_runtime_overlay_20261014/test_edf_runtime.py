import ast
import importlib.util
import logging
import os
from pathlib import Path
import sys
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parent
MANAGERS = ROOT / "python/sglang/srt/managers"
SPEC = importlib.util.spec_from_file_location(
    "edf_runtime_test_module", MANAGERS / "edf_scheduler.py"
)
EDF = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(EDF)
TREE = ast.parse((MANAGERS / "scheduler.py").read_text())
NAMES = {
    "_init_edf_runtime",
    "_edf_limit_chunk",
    "_edf_observe_batch",
    "_add_request_to_queue",
}
METHODS = [
    node
    for node in ast.walk(TREE)
    if isinstance(node, ast.FunctionDef) and node.name in NAMES
]
NAMESPACE = {
    "os": os,
    "time": time,
    "logger": logging.getLogger(__name__),
    "Req": SimpleNamespace,
    "DisaggregationMode": SimpleNamespace(
        NULL="null", PREFILL="prefill", DECODE="decode"
    ),
}
exec(
    compile(
        ast.Module(body=METHODS, type_ignores=[]),
        str(MANAGERS / "scheduler.py"),
        "exec",
    ),
    NAMESPACE,
)
SCHEDULER = type("TestScheduler", (), {name: NAMESPACE[name] for name in NAMES})


class EdfRuntimeTest(unittest.TestCase):
    def setUp(self):
        self.modules = patch.dict(
            sys.modules, {"sglang.srt.managers.edf_scheduler": EDF}
        )
        self.modules.start()
        self.addCleanup(self.modules.stop)
        self.clock = patch.object(time, "monotonic", return_value=100.0)
        self.clock.start()
        self.addCleanup(self.clock.stop)
        self.settings = patch.multiple(
            EDF,
            EDF_ENABLED=True,
            ACCEPT_MODE="req",
            ITL_SLO_MS=20.0,
            TTFT_SLO_MS=2000.0,
            _acc_global=None,
            MAX_PROFILED_PREFILL_PREFIX=262144.0,
            LONG_PREFIX_PROJECTION_THRESHOLD=262145.0,
        )
        self.settings.start()
        self.addCleanup(self.settings.stop)

    def request(self, input_tokens=100):
        return SimpleNamespace(
            origin_input_ids=[0] * input_tokens,
            output_ids=[],
            priority=None,
            prefix_len=100,
            host_hit_length=0,
            init_next_round_input=lambda cache: None,
            time_stats=SimpleNamespace(set_wait_queue_entry_time=lambda: None),
        )

    def scheduler(self):
        scheduler = SCHEDULER()
        scheduler.edf_enabled = True
        scheduler.edf_queue_calls = scheduler.edf_chunk_calls = 0
        scheduler.edf_observe_calls = 0
        scheduler.edf_latency_predictor = SimpleNamespace(
            predict=lambda tokens, *args: 5 + tokens * 0.2
        )
        scheduler.is_mixed_chunk = True
        scheduler.chunked_req = None
        scheduler.waiting_queue = [self.request()]
        scheduler.tree_cache = object()
        scheduler.page_size = 16
        scheduler.pool_stats_observer = SimpleNamespace(
            get_pool_stats=lambda: SimpleNamespace(get_max_pool_usage=lambda: 0.5)
        )
        scheduler._set_or_validate_priority = lambda request: True
        scheduler._abort_on_queued_limit = lambda request: False
        scheduler._prefetch_kvcache = lambda request: None
        scheduler.disaggregation_mode = "null"
        scheduler.processed_tokens_counter = 0
        return scheduler

    def batch(self, request):
        return SimpleNamespace(
            reqs=[request], seq_lens_cpu=SimpleNamespace(tolist=lambda: [8192])
        )

    def test_disabled_initialization_does_not_load_model(self):
        scheduler = SCHEDULER()
        with patch.dict(os.environ, {"SGLANG_EDF_SCHEDULING": "0"}), patch.object(
            EDF, "try_load_latency_predictor", side_effect=AssertionError
        ):
            scheduler._init_edf_runtime()
        self.assertFalse(scheduler.edf_enabled)
        self.assertIsNone(scheduler.edf_latency_predictor)

    def test_enabled_initialization_loads_predictor(self):
        scheduler = SCHEDULER()
        predictor = object()
        with patch.dict(os.environ, {"SGLANG_EDF_SCHEDULING": "1"}), patch.object(
            EDF, "try_load_latency_predictor", return_value=predictor
        ):
            scheduler._init_edf_runtime()
        self.assertIs(scheduler.edf_latency_predictor, predictor)

    def test_new_schema_request_gets_absolute_deadline_without_last_tic(self):
        scheduler = self.scheduler()
        scheduler.waiting_queue = []
        short = self.request()
        long = self.request(32768)
        scheduler._add_request_to_queue(long)
        scheduler._add_request_to_queue(short)
        self.assertEqual(short.priority, 102.0)
        self.assertGreater(long.priority, short.priority)
        self.assertEqual(scheduler.edf_queue_calls, 2)

    def test_retracted_decode_keeps_urgent_deadline(self):
        scheduler = self.scheduler()
        request = self.request()
        request.priority = 105.0
        request._edf_last_step_time = 99.9
        scheduler._add_request_to_queue(request, is_retracted=True)
        self.assertAlmostEqual(request.priority, 99.92)

    def test_chunk_cap_uses_request_acceptance_and_page_alignment(self):
        scheduler = self.scheduler()
        request = self.request()
        request._edf_last_step_time = 100.0
        request._edf_acc_hat = 2.0
        chosen = scheduler._edf_limit_chunk(self.batch(request), 512)
        self.assertEqual(chosen, 160)
        self.assertEqual(scheduler.edf_chunk_calls, 1)

    def test_overdue_decode_defers_prefill(self):
        scheduler = self.scheduler()
        request = self.request()
        request._edf_last_step_time = 99.0
        self.assertEqual(scheduler._edf_limit_chunk(self.batch(request), 512), 0)

    def test_no_model_or_disabled_preserves_chunk(self):
        scheduler = self.scheduler()
        scheduler.edf_latency_predictor = None
        self.assertEqual(
            scheduler._edf_limit_chunk(self.batch(self.request()), 512), 512
        )
        scheduler.edf_enabled = False
        self.assertIsNone(scheduler._edf_limit_chunk(self.batch(self.request()), None))

    def test_observer_updates_tokens_per_step_after_commit(self):
        scheduler = self.scheduler()
        request = self.request()
        request.output_ids = [1]
        scheduler._edf_observe_batch(self.batch(request))
        request.output_ids.extend([2, 3, 4])
        scheduler._edf_observe_batch(self.batch(request))
        self.assertEqual(request._edf_acc_hat, 3.0)
        self.assertEqual(request._edf_last_step_time, 100.0)
        with patch.object(time, "monotonic", return_value=101.0):
            scheduler._edf_observe_batch(self.batch(request))
        self.assertEqual(request._edf_last_step_time, 100.0)

    def test_integration_hooks_exist_in_runtime_methods(self):
        wanted = {
            "init_schedule_policy": "_init_edf_runtime",
            "_get_new_batch_prefill_raw": "_edf_limit_chunk",
            "process_batch_result": "_edf_observe_batch",
        }
        for method, called in wanted.items():
            function = next(
                node
                for node in ast.walk(TREE)
                if isinstance(node, ast.FunctionDef) and node.name == method
            )
            calls = [
                node.func.attr
                for node in ast.walk(function)
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
            ]
            self.assertIn(called, calls)


if __name__ == "__main__":
    unittest.main()

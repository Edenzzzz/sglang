import importlib.util
from pathlib import Path
import unittest

import torch


SOURCE = Path(__file__).resolve().parents[3] / "python/sglang/srt/layers/attention/fused_fa3_validation.py"
SPEC = importlib.util.spec_from_file_location("fused_head_reference", SOURCE)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class FusedHeadReferenceTest(unittest.TestCase):
    def setUp(self):
        generator = torch.Generator().manual_seed(7)
        self.query = torch.randn(3, 4, 4, generator=generator)
        self.keys = torch.randn(8, 2, 2, 4, generator=generator)
        self.values = torch.randn(8, 2, 2, 4, generator=generator)
        self.query_offsets = torch.tensor([0, 2, 3])
        self.page_offsets = torch.tensor([0, 3, 5])
        self.lengths = torch.tensor([5, 4])
        self.indices = torch.tensor([4, 0, 6, 2, 1])

    def reference(self, causal=True, softcap=0.0, key_scale=1.0, value_scale=1.0):
        result = torch.empty_like(self.query)
        for row in range(3):
            request = 0 if row < 2 else 1
            pages = self.indices[self.page_offsets[request]:self.page_offsets[request + 1]]
            keys = self.keys[pages].flatten(0, 1).double()
            values = self.values[pages].flatten(0, 1).double()
            end = int(self.lengths[request])
            if causal:
                end -= int(self.query_offsets[request + 1]) - row - 1
            for head in range(4):
                scores = keys[:end, head // 2] @ self.query[row, head].double() * 0.5 * key_scale
                if softcap:
                    scores = softcap * torch.tanh(scores / softcap)
                result[row, head] = scores.softmax(0) @ values[:end, head // 2] * value_scale
        return result

    def verify(self, output, stock, disputed, **kwargs):
        return MODULE.verify_disputed_heads(
            self.query, self.keys, self.values, output, stock, self.query_offsets,
            self.page_offsets, self.lengths, self.indices, torch.tensor(disputed),
            scale=0.5, tolerance=0.02, **kwargs,
        )

    def test_inaccurate_stock_does_not_reject_correct_fused_output(self):
        expected = self.reference()
        stock = expected.clone()
        stock[0, 1, 0] += expected[0, 1].norm() * 0.1
        report = self.verify(expected, stock, [[0, 1]])[0]
        self.assertTrue(report["passed"])
        self.assertLess(report["fused_relative_error"], 1e-5)
        self.assertGreater(report["stock_relative_error"], 0.09)

    def test_inaccurate_fused_output_is_rejected(self):
        expected = self.reference()
        output = expected.clone()
        output[2, 3, 0] += expected[2, 3].norm() * 0.05
        report = self.verify(output, expected, [[2, 3]])[0]
        self.assertFalse(report["passed"])
        self.assertGreater(report["fused_relative_error"], 0.04)

    def test_noncausal_softcap_and_cache_scales(self):
        expected = self.reference(causal=False, softcap=1.5, key_scale=0.7, value_scale=1.3)
        reports = self.verify(
            expected, expected, [[0, 0], [1, 3], [2, 1]],
            causal=False, logits_soft_cap=1.5, key_scale=0.7, value_scale=1.3,
        )
        self.assertTrue(all(report["passed"] for report in reports))
        self.assertLess(max(report["fused_relative_error"] for report in reports), 1e-5)


if __name__ == "__main__":
    unittest.main()

/*!
 * \brief Plan descriptor for the fused FA3+FA2 SM-pre-assignment kernel.
 *
 * DELIBERATELY SEPARATE from flashinfer's own `HolisticPlanInfo`. Extending that struct in place
 * changes its serialised length (36 instead of 28 at NUM_TASKS=2), and
 * `BatchAttention._plan_info` is produced by flashinfer's OWN JIT-compiled module rather than by
 * our extension -- so the two sides would disagree on the format and the kernel would reject
 * every plan, the same class of failure as "persistent plan has 28 entries, expected 56 or 68".
 *
 * On the 0.3.1 source tree the problem did not exist: flashinfer's JIT compiled `BatchAttention`
 * from the same modified headers, so our struct changes were automatically on both sides. With
 * the 0.7 wheel that coupling is gone, and flashinfer releases have already broken this work
 * twice (plan-struct redesign, removal of `block_sparse_indices_to_vector_sparse_offsets`).
 * A private struct in a private header is therefore the robust choice: 0.7's `scheduler.cuh` is
 * not overlaid at all, and upgrades cannot silently change our plan layout.
 *
 * Differences from 0.7's HolisticPlanInfo:
 *   +1 per task  -- `batch_idx_offset`, which upstream FA3's scheduler adapter needs because it
 *                   indexes cu_seqlens_q / seqused_k by batch index.
 *   +6 shared    -- the dynamic cluster cursor and counts (cross-role backfill), the FA3 split
 *                   bound, and the compact FA3 request list for the combine pass.
 *   NOT ported   -- `group_id`: K1a dropped the in-kernel JIT-reduction rendezvous after
 *                   measuring its ceiling at 0.6% of GPU time, so the scheduled merge
 *                   (merge_indptr / merge_o_indices) is used instead.
 */
#ifndef FLASHINFER_ATTENTION_FUSED_PLAN_CUH_
#define FLASHINFER_ATTENTION_FUSED_PLAN_CUH_

#include <map>
#include <sstream>
#include <utility>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cstring>
#include <vector>

// Angle-bracket, NOT relative: this header lives in an OVERLAY that mirrors only
// flashinfer/attention/, so a relative path resolves inside the overlay and misses the wheel's
// copy. Path-based includes let unmirrored headers fall through to 0.7's tree.
#include <flashinfer/exception.h>

namespace flashinfer {

template <uint32_t NUM_TASKS>
struct FusedPlanInfo {
  int64_t num_blks_x;
  int64_t num_blks_y;
  struct {
    int64_t q_indptr_offset;
    int64_t kv_indptr_offset;
    int64_t partial_indptr_offset;
    int64_t q_len_offset;
    int64_t kv_len_offset;
    int64_t q_start_offset;
    int64_t kv_start_offset;
    int64_t kv_end_offset;
    int64_t kv_head_idx_offset;
    // The request this work item belongs to. Upstream FA3 indexes cu_seqlens_q / seqused_k by
    // batch index, so its scheduler adapter needs this per item; flashinfer's own path gets
    // away without it by pushing q_indptr instead.
    int64_t batch_idx_offset;
    int64_t work_indptr_offset;
  } tasks[NUM_TASKS];
  int64_t len_kv_chunk_offset;
  int64_t partial_o_offset;
  int64_t partial_lse_offset;
  int64_t merge_indptr_offset;
  int64_t merge_o_indices_offset;
  int64_t num_qo_len_offset;
  // --- fused FA3+FA2 additions, ported from the 0.3.1 tree ---
  // One device-side cursor every block pulls persistent cluster indices from once its own work
  // is done: this is what lets an SM that finished FA3 backfill the tile-16 queue instead of
  // idling, which a static split gives up.
  int64_t cluster_cursor_offset = 0;
  int64_t num_pers_clusters = 0;
  // Max KV splits of any single q-tile in the wgmma task. The FA3 port sizes its float partial
  // O/LSE by total_q * num_splits and nothing downstream can recompute it.
  int64_t max_splits_fa3 = 1;
  // Compact list of REQUEST indices routed to the wgmma queue, plus its length. The combine
  // pass takes this as varlen_batch_idx_ptr so it runs only over those requests; over the whole
  // batch it reduces never-written partials onto the other executor's correct output (measured:
  // an FA2-only decode row went 5.8e-4 -> 0.155).
  int64_t fa3_batch_list_offset = 0;
  int64_t num_fa3_requests = 0;
  // COMPACTED split-row count == merge_o_indices.size(), which is what the merge takes as
  // num_packed_qo_len. It cannot be recomputed from the batch: deriving it that way makes the
  // merge visit unsplit rows, whose num_index_sets of 0 fills their output with ZEROS over the
  // direct write.
  int64_t num_merge_rows = 0;
  // Kept LAST on purpose: the harness reads the chosen split as plan_info[-1], so anything
  // appended after this hands it a different integer -- a plausible small value that would plan
  // FA3 for the wrong CTA count with no error.
  int64_t num_fa3_clusters = 0;

  // 0.7 upstream is 8 shared / 10 per task (28 at NUM_TASKS=2). The fused build adds 7 shared
  // and 1 per task -> 15 / 11, i.e. 59 at NUM_TASKS=4. `group_id` is deliberately NOT ported:
  // K1a dropped the in-kernel JIT-reduction rendezvous after measuring its ceiling at 0.6% of
  // GPU time, so the scheduled merge (merge_indptr / merge_o_indices) is used instead.
  static constexpr uint32_t NUM_TASK_ARGS = 11;
  // 15, not 14: num_merge_rows was added for the merge's num_packed_qo_len. ToVector and this
  // count are the SAME contract -- leaving it at 14 made FromVector reject every plan ToVector
  // produced ("should be 58, but got 59"), which the reference driver caught on its first run.
  static constexpr uint32_t NUM_SHARED_ARGS = 15;

  std::vector<int64_t> ToVector() const {
    std::vector<int64_t> vec;
    vec.push_back(num_blks_x);
    vec.push_back(num_blks_y);
    for (uint32_t i = 0; i < NUM_TASKS; ++i) {
      vec.push_back(tasks[i].q_indptr_offset);
      vec.push_back(tasks[i].kv_indptr_offset);
      vec.push_back(tasks[i].partial_indptr_offset);
      vec.push_back(tasks[i].q_len_offset);
      vec.push_back(tasks[i].kv_len_offset);
      vec.push_back(tasks[i].q_start_offset);
      vec.push_back(tasks[i].kv_start_offset);
      vec.push_back(tasks[i].kv_end_offset);
      vec.push_back(tasks[i].kv_head_idx_offset);
      vec.push_back(tasks[i].batch_idx_offset);
      vec.push_back(tasks[i].work_indptr_offset);
    }
    vec.push_back(len_kv_chunk_offset);
    vec.push_back(partial_o_offset);
    vec.push_back(partial_lse_offset);
    vec.push_back(merge_indptr_offset);
    vec.push_back(merge_o_indices_offset);
    vec.push_back(num_qo_len_offset);
    vec.push_back(cluster_cursor_offset);
    vec.push_back(num_pers_clusters);
    vec.push_back(max_splits_fa3);
    vec.push_back(fa3_batch_list_offset);
    vec.push_back(num_fa3_requests);
    vec.push_back(num_merge_rows);
    vec.push_back(num_fa3_clusters);
    return vec;
  }

  void FromVector(const std::vector<int64_t>& vec) {
    if (vec.size() != NUM_SHARED_ARGS + NUM_TASKS * NUM_TASK_ARGS) {
      std::ostringstream err_msg;
      err_msg << "FusedPlanInfo::FromVector: vec.size() should be "
              << NUM_SHARED_ARGS + NUM_TASKS * NUM_TASK_ARGS << ", but got " << vec.size();
      FLASHINFER_ERROR(err_msg.str());
    }
    num_blks_x = vec[0];
    num_blks_y = vec[1];
    for (uint32_t i = 0; i < NUM_TASKS; ++i) {
      tasks[i].q_indptr_offset = vec[2 + i * NUM_TASK_ARGS + 0];
      tasks[i].kv_indptr_offset = vec[2 + i * NUM_TASK_ARGS + 1];
      tasks[i].partial_indptr_offset = vec[2 + i * NUM_TASK_ARGS + 2];
      tasks[i].q_len_offset = vec[2 + i * NUM_TASK_ARGS + 3];
      tasks[i].kv_len_offset = vec[2 + i * NUM_TASK_ARGS + 4];
      tasks[i].q_start_offset = vec[2 + i * NUM_TASK_ARGS + 5];
      tasks[i].kv_start_offset = vec[2 + i * NUM_TASK_ARGS + 6];
      tasks[i].kv_end_offset = vec[2 + i * NUM_TASK_ARGS + 7];
      tasks[i].kv_head_idx_offset = vec[2 + i * NUM_TASK_ARGS + 8];
      tasks[i].batch_idx_offset = vec[2 + i * NUM_TASK_ARGS + 9];
      tasks[i].work_indptr_offset = vec[2 + i * NUM_TASK_ARGS + 10];
    }
    len_kv_chunk_offset = vec[2 + NUM_TASKS * NUM_TASK_ARGS];
    partial_o_offset = vec[3 + NUM_TASKS * NUM_TASK_ARGS];
    partial_lse_offset = vec[4 + NUM_TASKS * NUM_TASK_ARGS];
    merge_indptr_offset = vec[5 + NUM_TASKS * NUM_TASK_ARGS];
    merge_o_indices_offset = vec[6 + NUM_TASKS * NUM_TASK_ARGS];
    num_qo_len_offset = vec[7 + NUM_TASKS * NUM_TASK_ARGS];
    cluster_cursor_offset = vec[8 + NUM_TASKS * NUM_TASK_ARGS];
    num_pers_clusters = vec[9 + NUM_TASKS * NUM_TASK_ARGS];
    max_splits_fa3 = vec[10 + NUM_TASKS * NUM_TASK_ARGS];
    fa3_batch_list_offset = vec[11 + NUM_TASKS * NUM_TASK_ARGS];
    num_fa3_requests = vec[12 + NUM_TASKS * NUM_TASK_ARGS];
    num_merge_rows = vec[13 + NUM_TASKS * NUM_TASK_ARGS];
    num_fa3_clusters = vec[14 + NUM_TASKS * NUM_TASK_ARGS];
  }
};
// ---------------------------------------------------------------------------
// Host-side work-item enumeration.
//
// Split out of the planner deliberately: this is the scheduling DECISION (which row goes to
// which task, and how each task's rows are chopped into work items), and it is pure host
// arithmetic over the row lengths. The CUDA planner's remaining job is to upload the result and
// size the partial buffers, so getting this right on the host de-risks the part that needs a GPU
// to test. The same approach caught a real bug in the two-executor dispatch: enumerating its
// index arithmetic on the host found the FA3 page table being indexed by batch row instead of
// req_pool_index, 400/400, before any GPU run.
//
// Task assignment matches what the kernel reads:
//   task 0  FA2, tile128  (packed_qo > 64)
//   task 1  FA2, tile64   (16 < packed_qo <= 64)
//   task 2  FA2, tile16   (packed_qo <= 16)
//   task 3  wgmma / FA3   (every row the caller's mask marks)
struct FusedWorkItem {
  int32_t batch_idx;   // request this item belongs to
  int32_t q_start;     // q offset WITHIN the request
  int32_t q_len;       // rows this item covers
  int32_t kv_start;    // kv range, for split-KV
  int32_t kv_end;
  int32_t kv_head_idx;
};

// FUSED_FA2_KV_CHUNK=auto: the chunk is chosen per batch by FusedAutoFa2KvChunk in the planner and
// handed to EnumerateFusedWorkItems as fa2_chunk_override; here it reads as "no fixed chunk".
inline bool FusedFa2KvChunkAuto() {
  const char* configured = std::getenv("FUSED_FA2_KV_CHUNK");
  return configured != nullptr &&
         (std::strcmp(configured, "auto") == 0 || std::strcmp(configured, "auto4096") == 0);
}

inline std::vector<int32_t> FusedRoleKvChunkLengths(int32_t maximum_kv,
                                                  int32_t fa2_chunk, int32_t fa3_chunk) {
  const int32_t unsplit = std::max<int32_t>(maximum_kv, 1);
  const int32_t fa2 = fa2_chunk > 0 ? fa2_chunk : unsplit;
  const int32_t fa3 = fa3_chunk > 0 ? fa3_chunk : unsplit;
  return {fa2, fa2, fa2, fa3};
}

inline int32_t FusedFa2KvChunk(uint32_t fa3_chunk) {
  if (FusedFa2KvChunkAuto()) return 0;
  if (const char* configured = std::getenv("FUSED_FA2_KV_CHUNK")) {
    int32_t chunk = 0;
    std::istringstream input(configured);
    if (!(input >> chunk) || !input.eof() || chunk <= 0 || chunk % 128 != 0) {
      FLASHINFER_ERROR("FUSED_FA2_KV_CHUNK must be a positive multiple of 128");
    }
    return chunk;
  }
  const char* enabled = std::getenv("FUSED_FA2_SPLIT");
  return enabled && enabled[0] == '1' ? static_cast<int32_t>(fa3_chunk) : 0;
}

// Returns per-task work-item lists. `fa3_mask[i]` selects task 3 for request i.
// `tile_q_of_task` gives the q-tile width each FA2 task uses; task 3's width is the FA3 tile.
// `kv_chunk` of 0 disables split-KV (one item spans the whole kv range).
inline void EnumerateFusedWorkItems(
    const int32_t* qo_lens, const int32_t* kv_lens, const bool* fa3_mask, uint32_t batch_size,
    uint32_t gqa_group_size, uint32_t num_kv_heads, uint32_t fa3_tile_q, uint32_t kv_chunk,
    std::vector<FusedWorkItem> out[4], int32_t* max_splits_fa3,
    std::vector<int32_t>* fa3_batch_list, int32_t fa2_chunk_override = 0) {
  // A2/A3: the FA2 tile classes and the FA3 routing threshold, both configurable so the user's
  // hypothesis -- "only do tile 16, 32, 48; >=64 should be more performant with FA3" -- can be
  // MEASURED rather than assumed.
  //
  // Defaults preserve today's behaviour ({128,64,16}, routing by the caller's fa3_mask alone).
  // FUSED_FA2_TILES="a,b,c" sets the three class widths, largest first.
  // FUSED_FA3_MIN_PACKED=<n> additionally routes any row with packed_qo >= n to FA3, on top of
  // whatever the caller's mask says. n=64 is the hypothesis under test.
  //
  // WARP-LAYOUT CONSTRAINT: warps_q * num_mma_q * 16 == CTA_TILE_Q and
  // warps_q * warps_kv == kFa2Warps.
  //
  // RETRACTION, in place. This comment previously said "48 needs 3 q-warps and 8/3 is not
  // integral -- tile 48 requires a 6- or 12-warp layout", and called that a real limit on the
  // {16,32,48} set. **That was wrong.** It assumed warps_q == CTA_TILE_Q/16; nothing requires
  // that, because num_mma_q absorbs the leftover factor. Choosing the largest DIVISOR of
  // kFa2Warps whose q-width divides CTA_TILE_Q makes every one of {16,32,48,64,96,128}
  // expressible at the existing 8 warps -- tile 48 as 1q x 8kv with num_mma_q=3, tile 96 as
  // 2q x 4kv with num_mma_q=3. The old helper only failed because kFa2Warps/3 truncated to 2 and
  // produced a 6-warp layout against the required 8. See fa2_warps_q in
  // tests/fused_fa3_persistent_ext.cu.
  //
  // So the user's {16,32,48} hypothesis needs NO change to FusedPlanInfo<4>: the three widths fit
  // the three FA2 task slots exactly. The widths are compile-time on the runner side
  // (FUSED_FA2_W0/W1/W2) and must be kept in step with FUSED_FA2_TILES here.
  static uint32_t kFa2TileQ[3] = {128u, 64u, 16u};
  if (const char* e = std::getenv("FUSED_FA2_TILES")) {
    unsigned a = 0, b = 0, c = 0;
    if (std::sscanf(e, "%u,%u,%u", &a, &b, &c) == 3 && a && b && c) {
      kFa2TileQ[0] = a; kFa2TileQ[1] = b; kFa2TileQ[2] = c;
    }
  }
  int32_t fa3_min_packed = 0;
  if (const char* e = std::getenv("FUSED_FA3_MIN_PACKED")) fa3_min_packed = std::atoi(e);
  for (int t = 0; t < 4; ++t) out[t].clear();
  if (max_splits_fa3) *max_splits_fa3 = 1;
  if (fa3_batch_list) fa3_batch_list->clear();
  const int32_t fa2_chunk =
      fa2_chunk_override > 0 ? fa2_chunk_override : FusedFa2KvChunk(kv_chunk);
  const char* fine_tail_setting = std::getenv("FUSED_FA2_FINE_TAIL");
  const bool fine_tail = fine_tail_setting && fine_tail_setting[0] == '1';

  for (uint32_t i = 0; i < batch_size; ++i) {
    const int32_t qo = qo_lens[i];
    const int32_t kv = kv_lens[i] > 0 ? kv_lens[i] : 1;
    const int64_t packed_qo_pre = static_cast<int64_t>(qo) * gqa_group_size;
    const bool is_fa3 = (fa3_mask && fa3_mask[i]) ||
                        (fa3_min_packed > 0 && packed_qo_pre >= fa3_min_packed);
    const int64_t packed_qo = static_cast<int64_t>(qo) * gqa_group_size;

    int task;
    uint32_t tile_q;
    if (is_fa3) {
      task = 3;
      tile_q = fa3_tile_q;
      if (fa3_batch_list) fa3_batch_list->push_back(static_cast<int32_t>(i));
    } else if (packed_qo > int64_t(kFa2TileQ[1])) {
      // Thresholds DERIVED from the configured widths, not hardcoded 64/16: a row goes to the
      // smallest class that can still be filled by it. With {128,64,16} this reproduces the old
      // `> 64` / `> 16` exactly.
      task = 0;
      tile_q = kFa2TileQ[0];
    } else if (packed_qo > int64_t(kFa2TileQ[2])) {
      task = 1;
      tile_q = kFa2TileQ[1];
    } else {
      task = 2;
      tile_q = kFa2TileQ[2];
    }

    const int32_t role_chunk = task == 3 ? static_cast<int32_t>(kv_chunk) : fa2_chunk;
    auto task_for_remaining = [&](int64_t remaining) {
      if (!fine_tail || task == 3) return task;
      if (remaining > int64_t(kFa2TileQ[1])) return 0;
      return remaining > int64_t(kFa2TileQ[2]) ? 1 : 2;
    };
    const int32_t chunk = role_chunk > 0 ? role_chunk : kv;
    int32_t splits = 0;
    // LOOP ORDER MATTERS FOR CORRECTNESS, not just locality (FUSED_GROUP_MAJOR=1).
    //
    // Default (chunk outer) emits items whose consecutive entries differ in q0/h, so a CTA's
    // contiguous run of work items almost never shares a `(batch, q_start)` group -- meaning `sQ`
    // is refilled with a DIFFERENT Q tile between items. Group-major (chunk innermost) makes
    // consecutive items share `(batch, q_start)` and differ only in kv chunk, so `sQ` holds the
    // same tile across the run.
    //
    // Why this is the live hypothesis: 1 request at ~217 items/CTA PASSES while 97 requests at
    // ~5.5 items/CTA FAILS. Items-per-CTA cannot order those; what differs is that the one-request
    // run is nearly all same-group. Group-major reordering tests that at IDENTICAL total work.
    //
    // `splits` must be counted once per chunk regardless of order, because the partial-slab sizing
    // and BuildFusedMergeLayout both depend on it.
    const bool group_major = [] {
      const char* e = std::getenv("FUSED_GROUP_MAJOR");
      return e && e[0] == '1';
    }();
    if (group_major) {
      for (int32_t kv0 = 0; kv0 < kv; kv0 += chunk) ++splits;
      for (uint32_t h = 0; h < num_kv_heads; ++h) {
        for (int64_t q0 = 0; q0 < packed_qo;) {
          const int64_t rem = packed_qo - q0;
          const int work_task = task_for_remaining(rem);
          const uint32_t work_tile_q = work_task == 3 ? tile_q : kFa2TileQ[work_task];
          for (int32_t kv0 = 0; kv0 < kv; kv0 += chunk) {
            const int32_t kv1 = kv0 + chunk < kv ? kv0 + chunk : kv;
            out[work_task].push_back(FusedWorkItem{
                static_cast<int32_t>(i), static_cast<int32_t>(q0),
                static_cast<int32_t>(rem < work_tile_q ? rem : work_tile_q), kv0, kv1,
                static_cast<int32_t>(h)});
          }
          q0 += work_tile_q;
        }
      }
      if (task == 3 && max_splits_fa3 && splits > *max_splits_fa3) *max_splits_fa3 = splits;
      continue;
    }
    for (int32_t kv0 = 0; kv0 < kv; kv0 += chunk) {
      const int32_t kv1 = kv0 + chunk < kv ? kv0 + chunk : kv;
      ++splits;
      // One item per (q tile, kv chunk, kv head). packed_qo is the q extent AFTER GQA packing,
      // so the tile walk is over packed rows, not raw tokens.
      for (uint32_t h = 0; h < num_kv_heads; ++h) {
        for (int64_t q0 = 0; q0 < packed_qo;) {
          const int64_t rem = packed_qo - q0;
          const int work_task = task_for_remaining(rem);
          const uint32_t work_tile_q = work_task == 3 ? tile_q : kFa2TileQ[work_task];
          out[work_task].push_back(FusedWorkItem{
              static_cast<int32_t>(i), static_cast<int32_t>(q0),
              static_cast<int32_t>(rem < work_tile_q ? rem : work_tile_q), kv0, kv1,
              static_cast<int32_t>(h)});
          q0 += work_tile_q;
        }
      }
    }
    if (task == 3 && max_splits_fa3 && splits > *max_splits_fa3) *max_splits_fa3 = splits;
  }
}

// ---------------------------------------------------------------------------
// Host-side partial-buffer layout and merge lists.
//
// The second half of the planner's host arithmetic, after EnumerateFusedWorkItems. Given the
// work items, this decides where each split-KV partial lives and how the SCHEDULED merge
// (0.7's merge_indptr / merge_o_indices) reduces them. With this and the enumeration done on the
// host, the CUDA planner is reduced to uploading arrays and allocating buffers.
//
// Layout: one partial row per (work item) that belongs to a split row, laid out contiguously
// per output tile so the merge reads a contiguous range. `merge_indptr` is a CSR over output
// tiles into that partial array; `merge_o_indices` gives each tile's destination row offset.
//
// Rows that were NOT split (one kv chunk) need no merge and are written straight to the output
// by the mainloop, so they appear in neither list -- this is what makes the merge kernel's cost
// proportional to split work rather than to the batch, and it is the reason K1a could drop the
// in-kernel rendezvous without adding a merge over every row.
struct FusedMergeLayout {
  std::vector<int32_t> merge_indptr;      // size = num_merge_tiles + 1
  std::vector<int32_t> merge_o_indices;   // size = num_merge_tiles
  std::vector<int32_t> partial_indptr[4]; // per task: work item -> its partial row, -1 if direct
  int64_t total_partial_rows = 0;
  int32_t num_merge_tiles = 0;
};

// Builds the partial-slab layout and the merge lists, to the contract of
// `BlockBatchReductionPersistent::Run` in persistent.cuh -- which is 0.7's merge for the
// holistic path, NOT `cascade.cuh`'s PersistentVariableLengthMergeStatesKernel. That `Run` does:
//
//   for i in [0, num_packed_qo_len * num_kv_heads):
//     packed_qo_idx  = i / num_kv_heads
//     kv_head_idx    = i % num_kv_heads
//     num_index_sets = indptr[packed_qo_idx + 1] - indptr[packed_qo_idx]
//     slot           = (indptr[packed_qo_idx] + off) * num_kv_heads + kv_head_idx
//     output row     = o_indices[packed_qo_idx]
//
// Four things follow, and all four were got wrong by the first version:
//
//  1. `merge_indptr` is indexed by PACKED Q ROW, one entry per row plus a terminator -- not one
//     per (task, batch, q_start) group, which is what the first version pushed.
//  2. The list is COMPACTED over split rows only. `num_packed_qo_len` handed to the merge is the
//     number of split rows, and `o_indices[i]` maps entry i back to its real output row. That is
//     what o_indices is for; an uncompacted list would make the merge visit unsplit rows, whose
//     num_index_sets of 0 fills the output with ZEROS -- overwriting the direct write.
//  3. The partial base is HEAD-AGNOSTIC, with `* num_kv_heads` as the stride, so `kv_head_idx`
//     must stay OUT of the grouping key. The first version keyed on it, which made
//     total_partial_rows head-inclusive and the slab 7x too large at num_kv_heads=7.
//  4. A row's chunks are CONSECUTIVE from `indptr[row]`. So every member of a group shares ONE
//     base and the group advances by rows*chunks. The first version gave each chunk its own base
//     and laid chunks contiguously (base_c = g + c*rows), which is the same total size in a
//     different permutation: chunk 0 of row r collided with chunk r of row 0, silently.
//
// `store_partial` writes at `base + r * num_kv_chunks + kv_chunk_idx`, which equals
// `indptr[row_r] + kv_chunk_idx` exactly when each row of the group gets `num_kv_chunks`
// consecutive slots -- which is what the loop below emits. That equality IS the contract; if it
// is ever broken the merge reduces the wrong partials and nothing asserts.
//
// `packed_qo_indptr` is the per-request base in PACKED rows (tokens * gqa_group_size), needed to
// turn a group's request-relative q_start into the absolute output row o_indices wants.
inline void BuildFusedMergeLayout(const std::vector<FusedWorkItem> items[4],
                                  const int32_t* kv_lens, uint32_t batch_size,
                                  uint32_t num_kv_heads, const int32_t* token_qo_indptr,
                                  int32_t gqa_group_size, FusedMergeLayout* out) {
  out->merge_indptr.clear();
  out->merge_o_indices.clear();
  for (int t = 0; t < 4; ++t) out->partial_indptr[t].clear();
  out->total_partial_rows = 0;
  out->num_merge_tiles = 0;
  (void)kv_lens;
  (void)batch_size;
  if (num_kv_heads == 0) num_kv_heads = 1;

  // Group WITHOUT kv_head_idx: the head is carried by the slab stride, not by the base.
  struct Key {
    int32_t t, b, q;
    bool operator<(const Key& o) const {
      if (t != o.t) return t < o.t;
      if (b != o.b) return b < o.b;
      return q < o.q;
    }
  };
  std::map<Key, std::vector<std::pair<int, int>>> groups;  // key -> [(task, item index)]
  for (int t = 0; t < 4; ++t)
    for (size_t i = 0; i < items[t].size(); ++i) {
      const auto& it = items[t][i];
      groups[Key{t, it.batch_idx, it.q_start}].emplace_back(t, (int)i);
    }

  for (int t = 0; t < 4; ++t) out->partial_indptr[t].assign(items[t].size(), -1);

  out->merge_indptr.push_back(0);
  for (auto& kvp : groups) {
    auto& members = kvp.second;
    // members spans (chunk x kv_head) for this group, so the chunk count divides out the heads.
    const int32_t chunks = int32_t(members.size() / num_kv_heads);
    if (chunks <= 1) continue;  // not split: written straight to O, and must NOT be merged
    const int t0 = members[0].first;
    const int32_t rows = items[t0][members[0].second].q_len;
    const int32_t group_base = int32_t(out->total_partial_rows);

    // ONE base for every member of the group; the chunk offset comes from kv_chunk_idx.
    for (auto& m : members) out->partial_indptr[m.first][m.second] = group_base;

    // One merge entry per packed row of the group, each owning `chunks` consecutive slots.
    //
    // UNITS OF merge_o_indices, read off 0.7's own reduction rather than inferred. In
    // persistent.cuh, BlockBatchReductionPersistent::Run resolves its destination as
    //     o_indices[packed_qo_idx] + kv_head_idx * gqa_group_size
    // and indexes `v_merged` viewed as [qo_len, num_kv_heads, gqa_group_size, head_dim]. So the
    // value must be a FLAT row index over (token, qo_head) with the head-in-group folded in:
    //     o_indices = (token_base + token) * (num_kv_heads * G) + head_in_group
    // and the reduction then adds kv_head * G to select the kv head.
    //
    // This previously pushed the TOKEN index alone, which is wrong two ways: the token is not
    // scaled by num_qo_heads, and head_in_group is dropped entirely (four consecutive packed rows
    // of one token collapsed onto one destination).
    //
    // MEASURED, and it matches exactly: with values 0..31 plus kv_head * G <= 24, every write
    // landed in flat rows 0..55 of an 896-row space -- i.e. token 0 and token 1 only. The
    // fixture reported precisely "2/32 rows non-zero".
    const int32_t g = gqa_group_size > 0 ? gqa_group_size : 1;
    const int32_t nqo = int32_t(num_kv_heads) * g;
    const int32_t o_base = token_qo_indptr ? token_qo_indptr[kvp.first.b] : 0;
    for (int32_t r = 0; r < rows; ++r) {
      out->total_partial_rows += chunks;
      out->merge_indptr.push_back(int32_t(out->total_partial_rows));
      const int32_t pr = kvp.first.q + r;  // PACKED row within the request
      out->merge_o_indices.push_back((o_base + pr / g) * nqo + (pr % g));
    }
    ++out->num_merge_tiles;
  }
}

// ---------------------------------------------------------------------------
// Private 4-task planner.
//
// NOT a modification of 0.7's `TwoStageHolisticPlan`. That function shrank from 471 lines in
// 0.3.1 to 267 in 0.7 -- a 43% rewrite -- while our additions (+356 lines) were written against
// the larger version, so most of what they hook into no longer exists. Merging a +356 diff into
// a base that lost 204 lines is not a port; it is a rewrite with extra steps and no way to tell
// which behaviour survived.
//
// So the fused path owns its planner, consistent with owning its plan struct. 0.7's
// `TwoStageHolisticPlan` and `BatchAttention` stay untouched and keep serving the FA2 half.
//
// SPEC -- what this must produce, derived from the kernel's own reads:
//   tasks[0..2]  the three FA2 q-tile classes (tile128 for packed_qo > 64, tile64, tile16),
//                each with work items over the FA2 row subset only.
//   tasks[3]     the wgmma class: FA3's work items, pulled through
//                `UnifiedWgmmaTileScheduler`. This is the fused design -- FA3's work expressed
//                as a task inside the same plan, so one grid covers both roles.
//   per task     q_indptr, kv_indptr, partial_indptr, q_len, kv_len, q_start, kv_start, kv_end,
//                kv_head_idx, batch_idx, work_indptr.
//   shared       len_kv_chunk, partial_o, partial_lse, merge_indptr, merge_o_indices,
//                num_qo_len, plus the fused six: cluster_cursor (the device-side cursor that
//                lets a block which finished FA3 backfill the tile-16 queue), num_pers_clusters,
//                max_splits_fa3 (the FA3 port sizes partial O/LSE by total_q * num_splits and
//                nothing downstream can recompute it), fa3_batch_list + num_fa3_requests (the
//                combine pass takes this as varlen_batch_idx_ptr so it runs only over FA3's
//                requests -- over the whole batch it reduces never-written partials onto the
//                FA2 executor's correct output, measured as an FA2-only decode row going
//                5.8e-4 -> 0.155), and num_fa3_clusters LAST.
//
// Reduction: writes partials for 0.7's SCHEDULED merge (merge_indptr / merge_o_indices). The
// in-kernel JIT rendezvous is deliberately absent -- K1a measured its ceiling at 0.6% of GPU
// time, below the +/-1.5-3% serving noise floor.
//
// Guarded so the struct above stays host-checkable: port07/tests/run_host_checks.sh compiles
// this header with plain g++ to assert the ToVector/FromVector round-trip, and `cudaError_t`
// does not exist there. The declaration is only needed by the CUDA translation units.
// FA2 split-KV chunk for FUSED_FA2_KV_CHUNK=auto. Sized so the FA2 item count roughly matches the
// CTA slots the FA2 role can occupy: every SM when the batch has no FA3 work, otherwise the
// 2 x (num_sm - sm_split) slots left beside the FA3 grid (FA3 CTAs vacate theirs only at the end).
// Fewer, longer items starve a small batch of parallelism; more, shorter ones pay per-item and
// merge cost on a large one. Measured under the co-launch, classes 64/32/16
// (colaunch_chunk_20261012): the fixed best chunk ranged 256..2048 across seven fixtures and this
// rule picks the best or within 3% of it on each. A power of two >= 256, so a chunk boundary never
// falls inside a 128-key tile.
inline int32_t FusedAutoFa2KvChunk(const int32_t* qo_lens, const int32_t* kv_lens,
                                   const bool* fa3_mask, uint32_t batch_size,
                                   uint32_t gqa_group_size, uint32_t num_kv_heads,
                                   uint32_t largest_fa2_tile, uint32_t num_sm, uint32_t sm_split) {
  int64_t work = 0;
  bool has_fa3 = false;
  for (uint32_t i = 0; i < batch_size; ++i) {
    if (fa3_mask != nullptr && fa3_mask[i]) {
      has_fa3 = true;
      continue;
    }
    const int64_t packed = int64_t(qo_lens[i]) * gqa_group_size;
    const int64_t tiles = (packed + largest_fa2_tile - 1) / largest_fa2_tile;
    work += int64_t(num_kv_heads) * tiles * int64_t(kv_lens[i] > 0 ? kv_lens[i] : 1);
  }
  const int64_t free_sms = has_fa3 && sm_split < num_sm ? int64_t(num_sm - sm_split) : 0;
  const int64_t slots = has_fa3 ? std::max<int64_t>(2 * free_sms, 1) : int64_t(num_sm);
  const int64_t want = (work + slots - 1) / slots;
  int64_t chunk = 256;
  while (chunk < want) chunk *= 2;
  if (const char* configured = std::getenv("FUSED_FA2_KV_CHUNK");
      configured != nullptr && std::strcmp(configured, "auto4096") == 0) {
    chunk = std::min<int64_t>(chunk, 4096);
  }
  return int32_t(std::min<int64_t>(chunk, int64_t(1) << 30));
}

inline int32_t FusedWorkBudgetKvChunk(const int32_t* query_lengths,
                                     const int32_t* kv_lengths, const bool* fa3_mask,
                                     uint32_t batch_size, uint32_t gqa_group_size,
                                     uint32_t kv_heads, uint32_t query_tile,
                                     uint32_t fa3_ctas) {
  if (fa3_ctas == 0 || query_tile == 0) return 0;
  int64_t weighted_kv = 0;
  int64_t max_kv = 0;
  for (uint32_t request = 0; request < batch_size; ++request) {
    if (fa3_mask == nullptr || !fa3_mask[request] || query_lengths[request] <= 0) continue;
    const int64_t query_tiles =
        (int64_t(query_lengths[request]) * gqa_group_size + query_tile - 1) / query_tile;
    const int64_t context = std::max<int64_t>(kv_lengths[request], 1);
    weighted_kv += query_tiles * kv_heads * context;
    max_kv = std::max(max_kv, context);
  }
  if (max_kv == 0) return 0;
  const int64_t target = std::min(max_kv, (weighted_kv + fa3_ctas - 1) / fa3_ctas);
  return int32_t(((target + 127) / 128) * 128);
}

#if defined(__CUDACC__) || defined(FLASHINFER_FUSED_PLAN_WITH_CUDA)
template <uint32_t NUM_TASKS = 4, typename IdType = int32_t>
cudaError_t FusedFourTaskPlan(void* float_buffer, size_t float_workspace_size_in_bytes,
                              void* int_buffer, void* page_locked_int_buffer,
                              size_t int_workspace_size_in_bytes, FusedPlanInfo<NUM_TASKS>& plan,
                              IdType* qo_indptr_h, IdType* kv_indptr_h, IdType* kv_len_h,
                              const bool* fa3_row_mask_h, uint32_t batch_size,
                              uint32_t num_qo_heads, uint32_t num_kv_heads, uint32_t head_dim_qk,
                              uint32_t head_dim_vo, uint32_t page_size, uint32_t sm_split,
                              uint32_t num_sm, bool causal, cudaStream_t stream,
                              size_t* required_float_workspace_size = nullptr);
// ---------------------------------------------------------------------------
// K1c2: the device half.
//
// Composition only -- the row partition, per-class work-item enumeration and the merge layout
// are EnumerateFusedWorkItems and BuildFusedMergeLayout above, both already exercised by
// port07/tests/run_host_checks.sh. What this adds is the workspace layout, the per-task
// work_indptr that hands items to CTAs, and the one-shot H2D copy.
//
// Everything the device reads is staged into page_locked_int_buffer and copied ONCE. Writing
// the arrays straight into int_buffer with per-array cudaMemcpyAsync calls would be ~20 copies
// per layer, and the plan is rebuilt per step.
template <uint32_t NUM_TASKS, typename IdType>
cudaError_t FusedFourTaskPlan(void* float_buffer, size_t float_workspace_size_in_bytes,
                              void* int_buffer, void* page_locked_int_buffer,
                              size_t int_workspace_size_in_bytes, FusedPlanInfo<NUM_TASKS>& plan,
                              IdType* qo_indptr_h, IdType* kv_indptr_h, IdType* kv_len_h,
                              const bool* fa3_row_mask_h, uint32_t batch_size,
                              uint32_t num_qo_heads, uint32_t num_kv_heads, uint32_t head_dim_qk,
                              uint32_t head_dim_vo, uint32_t page_size, uint32_t sm_split,
                              uint32_t num_sm, bool causal, cudaStream_t stream,
                              size_t* required_float_workspace_size) {
  static_assert(NUM_TASKS == 4, "the fused plan is built for four tile classes");
  // FA3's q tile. 128 is CTA_Q for the Hopper mainloop this plan feeds; the FA2 classes' widths
  // (128/64/16) live in EnumerateFusedWorkItems, which is also where a finer dispatch (A1-A3)
  // would add more.
  // MUST equal the kernel's CTA_Q and the `cta_tile_q` the ext hands the scheduler. Three
  // independent literals had to agree: this one, FA3Traits' CTA_Q, and the ext's trailing `128u`.
  // The scheduler derives q_tile_idx as q_start / cta_tile_q while this decides the q_start values,
  // so a disagreement silently mis-tiles every FA3 item.
#ifndef FUSED_FA3_CTA_Q
#define FUSED_FA3_CTA_Q 128
#endif
  constexpr uint32_t kFa3TileQ = uint32_t(FUSED_FA3_CTA_Q);
  if (num_kv_heads == 0 || num_qo_heads % num_kv_heads != 0) return cudaErrorInvalidValue;
  const uint32_t gqa = num_qo_heads / num_kv_heads;

  // Per-request q and kv extents, in the units the enumerator wants: q in TOKENS (it packs by
  // gqa itself) and kv in elements.
  std::vector<int32_t> qo_lens(batch_size), kv_lens(batch_size);
  for (uint32_t i = 0; i < batch_size; ++i) {
    qo_lens[i] = int32_t(qo_indptr_h[i + 1] - qo_indptr_h[i]);
    kv_lens[i] = int32_t(kv_len_h[i]);
  }

  // The FA3 split chunk. Chosen so the wgmma task has roughly one chunk per SM it owns, which
  // is what split-KV is for: without it a single long row occupies one CTA while the rest idle.
  // Rounded UP to a multiple of TILE_KV so no chunk boundary falls mid-tile -- the mainloop is
  // handed a base and a length, and a partial tile at the seam would be masked twice.
  constexpr int32_t kTileKV = 128;
  int32_t kv_chunk = 0;
  {
    int64_t fa3_kv_total = 0;
    uint32_t fa3_rows = 0;
    for (uint32_t i = 0; i < batch_size; ++i) {
      if (fa3_row_mask_h != nullptr && fa3_row_mask_h[i]) {
        fa3_kv_total += kv_lens[i];
        ++fa3_rows;
      }
    }
    const uint32_t fa3_ctas = sm_split > 0 ? sm_split : num_sm;
    if (fa3_rows > 0 && fa3_ctas > 0) {
      const int64_t want = (fa3_kv_total + fa3_ctas - 1) / int64_t(fa3_ctas);
      kv_chunk = int32_t(((want + kTileKV - 1) / kTileKV) * kTileKV);
      if (kv_chunk < kTileKV) kv_chunk = kTileKV;
    }
    if (const char* enabled = std::getenv("FUSED_WORK_BUDGET_SPLIT");
        enabled != nullptr && enabled[0] == '1') {
      kv_chunk = FusedWorkBudgetKvChunk(qo_lens.data(), kv_lens.data(), fa3_row_mask_h,
                                       batch_size, gqa, num_kv_heads, kFa3TileQ, fa3_ctas);
    }
    // FUSED_KV_CHUNK_MULT=<n> multiplies the chosen chunk length, i.e. DIVIDES the chunk count.
    //
    // MEASURED motivation: the split path is 73% of the kernel's time and the MERGE is only 4.8%
    // (MODE=fa3: full 0.2582 ms, merge skipped 0.2457, no split 0.0576). So the cost is per-item
    // overhead multiplied by the chunk count, not the reduction -- at kv 2048 with chunk 128 that
    // is 8 q tiles x 7 heads x 16 chunks = 896 items each writing a 32 KB partial tile, about
    // 28.7 MB against 1.8 MB for the direct path. Fewer, larger chunks trade parallelism for a
    // proportional cut in that traffic, and the optimum is an empirical question the planner's
    // fixed `ceil(total_kv / fa3_ctas)` rounding never explores.
    if (const char* m = std::getenv("FUSED_KV_CHUNK_MULT")) {
      const int mult = std::atoi(m);
      if (mult > 1 && kv_chunk > 0) kv_chunk = int32_t(kv_chunk * mult);
    }
    // FUSED_NOSPLIT=1 forces kv_chunk to 0, which EnumerateFusedWorkItems reads as "one item
    // spans the whole kv range" -- no partials, no merge -- at whatever sizes the fixture uses.
    //
    // This isolation did not exist before: fa3_1chunk is the only unsplit fixture and it is also
    // the SMALLEST (kv=128), so "unsplit" and "short kv, one q tile" were never separable. Every
    // FA3 fixture that fails (fa3, fa3_split, fa3_multitile, mixed) splits, and the only one that
    // passes does not -- which is suggestive but not conclusive while the two differ in size too.
    //
    // Diagnostic only: it changes the plan, so it is not a performance configuration.
    if (const char* ns = std::getenv("FUSED_NOSPLIT")) {
      if (ns[0] == '1') kv_chunk = 0;
    }
  }

  // CTA slot counts the work_indptr arrays are partitioned over. FA3 MUST be sm_split: its
  // scheduler indexes work_indptr[blockIdx.x] over the planned count and
  // FusedFA3PersistentDispatched refuses a launch where the two disagree.
  const uint32_t fa3_ctas = sm_split > 0 ? sm_split : num_sm;
  const uint32_t fa2_ctas = num_sm;

  std::vector<FusedWorkItem> items[4];
  int32_t max_splits_fa3 = 1;
  std::vector<int32_t> fa3_batch_list;
  int32_t fa2_chunk_override = 0;
  if (FusedFa2KvChunkAuto()) {
    uint32_t largest_fa2_tile = 128u;
    if (const char* e = std::getenv("FUSED_FA2_TILES")) {
      unsigned a = 0, b = 0, c = 0;
      if (std::sscanf(e, "%u,%u,%u", &a, &b, &c) == 3 && a) largest_fa2_tile = a;
    }
    fa2_chunk_override = FusedAutoFa2KvChunk(qo_lens.data(), kv_lens.data(), fa3_row_mask_h,
                                             batch_size, gqa, num_kv_heads, largest_fa2_tile,
                                             num_sm, fa3_ctas);
  }
  EnumerateFusedWorkItems(qo_lens.data(), kv_lens.data(), fa3_row_mask_h, batch_size, gqa,
                          num_kv_heads, kFa3TileQ, uint32_t(kv_chunk < 0 ? 0 : kv_chunk),
                          items, &max_splits_fa3, &fa3_batch_list, fa2_chunk_override);

  FusedMergeLayout merge;
  // Per-request base in TOKEN rows, which is the unit merge_o_indices is in -- NOT packed rows.
  // BlockBatchReductionPersistent::Run writes
  //     v_merged + (pos * num_kv_heads + head_idx) * head_dim
  // over an output laid out [qo_len, num_kv_heads, gqa_group_size, head_dim], so `pos` indexes
  // TOKENS. Emitting packed rows (token * gqa_group_size) makes every index gqa times too large:
  // measured as a 16 B out-of-bounds write from the reduction's own grid, block (0,386,0).
  std::vector<int32_t> token_qo_indptr(batch_size + 1, 0);
  for (uint32_t i = 0; i < batch_size; ++i) {
    token_qo_indptr[i + 1] = token_qo_indptr[i] + qo_lens[i];
  }
  BuildFusedMergeLayout(items, kv_lens.data(), batch_size, num_kv_heads,
                        token_qo_indptr.data(), int32_t(gqa), &merge);

  // work_indptr: which items each CTA executes, per task. Items are handed out in plan order and
  // split as evenly as the count allows, so CTA c of task t runs [work_indptr[c], work_indptr[c+1]).
  // The FA3 task MUST be partitioned over exactly sm_split CTAs: its scheduler indexes
  // work_indptr[blockIdx.x] over the count the plan was built for, and FusedFA3PersistentDispatched
  // refuses a launch where that disagrees.
  std::vector<int32_t> work_indptr[4];
  for (int t = 0; t < 4; ++t) {
    const uint32_t ctas = (t == 3) ? fa3_ctas : fa2_ctas;
    const size_t n = items[t].size();
    work_indptr[t].resize(ctas + 1);
    for (uint32_t c = 0; c <= ctas; ++c) {
      work_indptr[t][c] = int32_t((n * c) / ctas);
    }
  }

  // ---- int workspace: a bump allocator over page-locked staging, mirrored on the device.
  // Offsets are BYTES from int_buffer, which is what GetPtrFromBaseOffset expects.
  size_t off = 0;
  std::vector<std::pair<size_t, std::vector<int32_t>>> staged;  // (byte offset, payload)
  auto place = [&](std::vector<int32_t>&& v) -> int64_t {
    const size_t at = off;
    off += ((v.size() * sizeof(int32_t)) + 15u) & ~size_t(15);  // 16 B aligned
    staged.emplace_back(at, std::move(v));
    return int64_t(at);
  };
  auto column = [&](int t, int32_t FusedWorkItem::*field) {
    std::vector<int32_t> v(items[t].size());
    for (size_t i = 0; i < items[t].size(); ++i) v[i] = items[t][i].*field;
    return v;
  };

  // Rows routed to FA3, which is exactly the pers_row_offset the caller advances the FA2
  // roles' q/o pointers by.
  int32_t total_q_tokens = 0;
  for (uint32_t i = 0; i < batch_size; ++i) total_q_tokens += qo_lens[i];
  int32_t fa3_rows_total = 0;
  // Pages routed to FA3, which is the pers_kv_page_offset the caller advances the FA2 roles'
  // kv_indices pointer by.
  int32_t fa3_pages_total = 0;
  for (uint32_t i = 0; i < batch_size; ++i) {
    if (fa3_row_mask_h != nullptr && fa3_row_mask_h[i]) {
      fa3_rows_total += qo_lens[i];
      fa3_pages_total += int32_t((kv_lens[i] + int32_t(page_size) - 1) / int32_t(page_size));
    }
  }

  plan.num_blks_x = int64_t(num_sm);
  plan.num_blks_y = 1;
  for (uint32_t t = 0; t < NUM_TASKS; ++t) {
    auto& T = plan.tasks[t];
    // q_indptr is the item's ABSOLUTE q offset (request base + offset within it); q_start is the
    // offset within the request, in packed rows, which is what the tile index is derived from.
    // q_indptr is RELATIVE TO THE TASK'S OWN ROW SUBSET, not absolute over the batch.
    //
    // The FA2 roles' final_o and q are handed to the kernel already advanced by
    // pers_row_offset (the FA3 row count), because FA3's rows come first in q/o. The unsplit
    // write is `final_o + q_indptr * o_stride_n`, so an absolute q_indptr counts those rows a
    // SECOND time: with 256 FA3 rows, the FA2 rows at absolute 256/257 land at 512/513 of a
    // 258-row tensor. Measured as compute-sanitizer "Invalid __global__ write of size 16 bytes"
    // from a block at or past sm_split, 1,266,688 bytes past the allocation.
    //
    // Task 3 keeps absolute offsets: FA3's own params are built over the FA3 subset, whose rows
    // start at 0, so for it the two coincide.
    const int32_t row_base = (t == 3) ? 0 : fa3_rows_total;
    std::vector<int32_t> q_abs(items[t].size());
    for (size_t i = 0; i < items[t].size(); ++i) {
      // The REQUEST's token base only -- NOT plus q_start. The kernel applies the tile offset
      // itself from packed_qo_start / q_start, so adding it here double-counts it, and the
      // unsplit write is final_o + q_indptr * o_stride_n. The trace showed q_indptr taking
      // 0,128,256,...,896 across the 8 q tiles of ONE request, where it should have been 0 for
      // all of them; only tile 0 (q_start == 0) landed correctly, which is exactly the 32 of 256
      // rows that passed in MODE=fa2_2tile (one tile128 = 128 packed / gqa 4 = 32 tokens).
      // At kv=2048 the same overshoot leaves the allocation and becomes the illegal access.
      q_abs[i] = int32_t(qo_indptr_h[items[t][i].batch_idx]) - row_base;
    }
    // kv_indptr is RELATIVE to the task's own page subset, for the same reason q_indptr is
    // relative to its row subset: the caller hands the FA2 roles a kv_indices pointer already
    // advanced by pers_kv_page_offset (the FA3 page total), so an ABSOLUTE kv_indptr counts those
    // pages twice. That offset is 0 in MODE=fa2, which is why the FA2 path passes there while the
    // same rows are wrong in MODE=mixed -- rel 18.29 and 23.82 on the two decode rows, identical
    // with the merge disabled, so not a merge effect.
    const int32_t page_base = (t == 3) ? 0 : fa3_pages_total;
    std::vector<int32_t> kv_abs(items[t].size());
    for (size_t i = 0; i < items[t].size(); ++i) {
      kv_abs[i] = int32_t(kv_indptr_h[items[t][i].batch_idx]) - page_base;
    }
    T.q_indptr_offset = place(std::move(q_abs));
    T.kv_indptr_offset = place(std::move(kv_abs));
    T.partial_indptr_offset = place(std::vector<int32_t>(merge.partial_indptr[t]));
    // q_len is the REQUEST's length in TOKENS, not the item's packed extent.
    // unified_wgmma_scheduler.cuh computes packed_qo_len = q_len[work_idx] * gqa_group_size, and
    // persistent.cuh uses q_len for the causal bound (kv_len - q_len) and as a row count for
    // write_o_reg_gmem -- all token units. Passing the item's PACKED extent is wrong by the GQA
    // factor and by tiling: at q_len 1 (packed 4) it stays inside the allocation, at 256 tokens
    // (packed 1024) it does not. MODE=fa2 faulted on exactly that, the tile-128 class on a long
    // row, which mixed mode never exercised.
    T.q_len_offset = place([&] {
      std::vector<int32_t> v(items[t].size());
      for (size_t i = 0; i < items[t].size(); ++i) v[i] = qo_lens[items[t][i].batch_idx];
      return v;
    }());
    T.kv_len_offset = place([&] {
      std::vector<int32_t> v(items[t].size());
      for (size_t i = 0; i < items[t].size(); ++i) v[i] = kv_lens[items[t][i].batch_idx];
      return v;
    }());
    T.q_start_offset = place(column(t, &FusedWorkItem::q_start));
    T.kv_start_offset = place(column(t, &FusedWorkItem::kv_start));
    T.kv_end_offset = place(column(t, &FusedWorkItem::kv_end));
    T.kv_head_idx_offset = place(column(t, &FusedWorkItem::kv_head_idx));
    T.batch_idx_offset = place(column(t, &FusedWorkItem::batch_idx));
    T.work_indptr_offset = place(std::move(work_indptr[t]));
  }

  // Per-task chunk length. The scheduler reads TASK 3's element as [0] through a pointer the ext
  // offsets by 3, so all four must be present and only task 3's may be non-zero -- the FA2
  // classes are not split.
  // Per-task chunk length. The FA2 classes are NOT split, but their length must NOT be 0:
  // persistent.cuh divides by it UNCONDITIONALLY --
  //     kv_chunk_idx   = kv_start / len_kv_chunk
  //     num_kv_chunks  = ceil_div(<causal bound>, len_kv_chunk)
  // -- so a 0 is an integer divide-by-zero on device. The symptom is not a trap: num_kv_chunks
  // comes out garbage, the row takes the SPLIT path, and store_partial writes a 16 B vector at a
  // wild offset. Measured as compute-sanitizer "Invalid __global__ write of size 16 bytes" in
  // FusedFA3PersistentKernel from block (17,0,0) -- i.e. a block at or past sm_split, so an
  // FA2-role block -- 2,617,249,280 bytes BEFORE the nearest allocation.
  //
  // So the FA2 classes get a chunk length that spans any row they can see, which makes
  // ceil_div give exactly 1 and sends them down the direct-write path, which is what "not
  // split" has to mean in 0.7's arithmetic.
  int32_t fa2_span = 1;
  for (uint32_t i = 0; i < batch_size; ++i) fa2_span = std::max(fa2_span, kv_lens[i]);
  // When FA2 splitting is enabled its classes need the SAME chunk length the enumeration used, or
  // persistent.cuh derives num_kv_chunks = ceil_div(kv_len, fa2_span) = 1 and the split rows take
  // the direct-write path while their partials go unmerged.
  const int32_t fa2_chunk = fa2_chunk_override > 0
                                ? fa2_chunk_override
                                : FusedFa2KvChunk(uint32_t(kv_chunk < 0 ? 0 : kv_chunk));
  plan.len_kv_chunk_offset = place(FusedRoleKvChunkLengths(fa2_span, fa2_chunk, kv_chunk));
  // num_merge_rows == merge_o_indices.size(): the COMPACTED split-row count, which is what the
  // merge takes as num_packed_qo_len. Derived here rather than recomputed downstream, where
  // getting it from the batch instead would make the merge visit unsplit rows and zero them.
  plan.num_merge_rows = int64_t(merge.merge_o_indices.size());
  plan.merge_indptr_offset = place(std::move(merge.merge_indptr));
  plan.merge_o_indices_offset = place(std::move(merge.merge_o_indices));
  plan.num_qo_len_offset = place([&] {
    std::vector<int32_t> v(batch_size);
    for (uint32_t i = 0; i < batch_size; ++i) v[i] = qo_lens[i] * int32_t(gqa);
    return v;
  }());
  // The cross-role backfill cursor. ONE int, and it must start at zero: the drain loop pulls
  // cluster indices with atomicAdd and compares against num_pers_clusters, so a non-zero start
  // silently skips that many FA2 clusters. Staged as zero and copied with everything else, which
  // also keeps it CUDA-graph safe -- the dispatcher's cudaMemsetAsync resets it per launch.
  plan.cluster_cursor_offset = place(std::vector<int32_t>{0});
  plan.fa3_batch_list_offset = place(std::vector<int32_t>(fa3_batch_list));

  if (const char* e = std::getenv("FLASHINFER_FUSED_PLAN_DEBUG"); e && *e != '0') {
    std::fprintf(stderr,
                 "[fused plan] items=%zu/%zu/%zu/%zu partial_rows=%lld int_bytes=%zu/%zu\n",
                 items[0].size(), items[1].size(), items[2].size(), items[3].size(),
                 (long long)merge.total_partial_rows, off, int_workspace_size_in_bytes);
  }
  // ---- unit audit -------------------------------------------------------------------------
  // Four of this builder's arrays have been wrong in the SAME way -- written against my reading
  // of the units instead of the consumer's (len_kv_chunk semantics, q_indptr frame,
  // merge_o_indices units, q_len units). This checks every array's unit in one pass, so the next
  // one fails here instead of as an illegal access N runs later. Units, from the consumers:
  //   q_start, item extents  PACKED rows   (tile index is derived from q_start / cta_tile_q)
  //   q_len                  TOKENS        (scheduler: packed_qo_len = q_len * gqa)
  //   q_indptr               TOKENS, relative to the TASK'S OWN row subset
  //   kv_start/kv_end/kv_len elements
  //   merge_o_indices        TOKENS, absolute
  //   len_kv_chunk           elements, NON-ZERO (divided by unconditionally)
  if (const char* e = std::getenv("FLASHINFER_FUSED_PLAN_AUDIT"); e && *e != '0') {
    int bad = 0;
    auto fail = [&](const char* what, int t, size_t i, long long got) {
      if (bad++ < 12)
        std::fprintf(stderr, "[plan audit] task %d item %zu: %s (got %lld)\n", t, i, what, got);
    };
    const int32_t subset_rows_fa2 = int32_t(total_q_tokens - fa3_rows_total);
    for (int t = 0; t < 4; ++t) {
      const int32_t base = (t == 3) ? 0 : fa3_rows_total;
      const int32_t subset = (t == 3) ? fa3_rows_total : subset_rows_fa2;
      for (size_t i = 0; i < items[t].size(); ++i) {
        const auto& it = items[t][i];
        const int32_t b = it.batch_idx;
        const int32_t qtok = qo_lens[b], kv = kv_lens[b];
        if (b < 0 || uint32_t(b) >= batch_size) fail("batch_idx out of range", t, i, b);
        if (it.q_start < 0 || it.q_start >= qtok * int32_t(gqa))
          fail("q_start not a packed row of its request", t, i, it.q_start);
        if (it.kv_start < 0 || it.kv_end > kv || it.kv_start >= it.kv_end)
          fail("kv range outside the request", t, i, it.kv_end);
        const int32_t qi = int32_t(qo_indptr_h[b]) - base + it.q_start;
        if (qi < 0 || qi > subset * int32_t(gqa))
          fail("q_indptr outside the task's own row subset", t, i, qi);
        if (merge.partial_indptr[t][i] >= 0 &&
            merge.partial_indptr[t][i] >= int32_t(merge.total_partial_rows))
          fail("partial_indptr past the slab", t, i, merge.partial_indptr[t][i]);
      }
    }
    for (size_t r = 0; r < merge.merge_o_indices.size(); ++r)
      if (merge.merge_o_indices[r] < 0 || merge.merge_o_indices[r] >= int32_t(total_q_tokens))
        fail("merge_o_indices not an absolute token row", 9, r, merge.merge_o_indices[r]);
    std::fprintf(stderr, "[plan audit] %s (%d problem%s)\n", bad ? "FAIL" : "OK", bad,
                 bad == 1 ? "" : "s");
  }
  if (off > int_workspace_size_in_bytes) return cudaErrorInvalidValue;

  // Persistent clusters: how many FA2 queue slots exist, which is the number of CTA SLOTS the
  // work_indptr arrays were partitioned over -- NOT the number of work items.
  //
  // fused_drain_queue pulls c with atomicAdd and passes it to Runner::Run as cluster_override,
  // and Run uses it directly as `work_indptr[cluster_idx] .. work_indptr[cluster_idx + 1]`
  // (persistent.cuh:362). So c lives in CTA-SLOT space. Setting this to the item count (70 for
  // the MODE=fa2 fixture) while work_indptr spans 132 slots means the queue stops at slot 69 and
  // every item partitioned into slots 70..131 is SILENTLY NEVER EXECUTED -- 26 of the 56
  // tile-128 items in that fixture. No error, no assert, just missing output.
  plan.num_pers_clusters = int64_t(fa2_ctas);
  // FUSED_NO_BACKFILL=1 disables the cross-role backfill by publishing ZERO persistent clusters,
  // so the drain loop's atomicAdd on cluster_cursor immediately exceeds the count and no block ever
  // pulls another block's cluster. Diagnostic for the CROSS-BLOCK dependence measured on
  // 2026-10-10: the defect tracks the TOTAL decode item count in the grid, not items-per-CTA
  // (packing prefill onto 8 blocks with no decode work is clean 0/6 at SM_SPLIT=8 and 16), and the
  // corrupted blocks are ~94% prefill -- so the interfering decode items are on OTHER blocks and
  // the route has to be device-global state. This cursor is the only cross-block mechanism the
  // fused kernel adds over stock.
  //
  // It REMOVES a capability rather than fixing anything: with backfill off, an SM that finishes its
  // own work idles instead of draining the FA2 queue, so any timing from this arm is meaningless.
  // Correctness only.
  if (const char* e = std::getenv("FUSED_NO_BACKFILL"); e && *e != '0') {
    plan.num_pers_clusters = 0;
  }
  plan.max_splits_fa3 = int64_t(max_splits_fa3 < 1 ? 1 : max_splits_fa3);
  plan.num_fa3_requests = int64_t(fa3_batch_list.size());
  // LAST, because the harness reads the chosen split as plan_info[-1].
  plan.num_fa3_clusters = int64_t(fa3_ctas);

  // ---- float workspace: partial O then partial LSE, both sized by the merge layout rather than
  // by the batch. total_partial_rows counts only rows that were actually split, so an unsplit
  // batch allocates nothing and the merge runs over an empty list.
  {
    const size_t o_bytes =
        size_t(merge.total_partial_rows) * num_kv_heads * head_dim_vo * sizeof(float);
    const size_t lse_bytes = size_t(merge.total_partial_rows) * num_kv_heads * sizeof(float);
    size_t foff = 0;
    plan.partial_o_offset = int64_t(foff);
    foff += (o_bytes + 15u) & ~size_t(15);
    plan.partial_lse_offset = int64_t(foff);
    foff += (lse_bytes + 15u) & ~size_t(15);
    if (const char* e = std::getenv("FLASHINFER_FUSED_PLAN_DEBUG"); e && *e != '0') {
      std::fprintf(stderr, "[fused plan] float_bytes=%zu/%zu (o=%zu lse=%zu)\n", foff,
                   float_workspace_size_in_bytes, o_bytes, lse_bytes);
    }
    if (required_float_workspace_size != nullptr) {
      *required_float_workspace_size = foff;
    } else if (foff > float_workspace_size_in_bytes) {
      return cudaErrorInvalidValue;
    }
    (void)float_buffer;
    (void)head_dim_qk;
    (void)page_size;
    (void)causal;
  }

  // One copy. Staged into the page-locked buffer at the same offsets the device sees.
  auto* host = reinterpret_cast<char*>(page_locked_int_buffer);
  std::memset(host, 0, off);
  for (auto& [at, v] : staged) {
    if (!v.empty()) std::memcpy(host + at, v.data(), v.size() * sizeof(int32_t));
  }
  return cudaMemcpyAsync(int_buffer, host, off, cudaMemcpyHostToDevice, stream);
}

#endif  // __CUDACC__ || FLASHINFER_FUSED_PLAN_WITH_CUDA

}  // namespace flashinfer

#endif  // FLASHINFER_ATTENTION_FUSED_PLAN_CUH_

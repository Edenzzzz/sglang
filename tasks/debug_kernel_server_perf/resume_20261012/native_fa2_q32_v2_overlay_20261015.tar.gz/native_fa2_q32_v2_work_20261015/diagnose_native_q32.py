import argparse
import json
from pathlib import Path

import torch

from load_native_q32 import build
from test_native_q32 import execute, make_case, reference


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--tile", type=int, default=32)
    parser.add_argument("--iterations", type=int, default=20)
    args = parser.parse_args()
    torch.manual_seed(20261015)
    torch.backends.cuda.matmul.allow_tf32 = False
    build()
    case = make_case([4], [65536])
    expected = reference(case)
    plan = list(case.wrapper._plan_info)
    integer_buffer = case.wrapper._int_workspace_buffer
    def integers(offset, count):
        return integer_buffer[offset:offset + count * 4].view(torch.int32).cpu().tolist()
    report = {
        "plan": plan,
        "query_tile_indices": integers(plan[5], plan[0]),
        "kv_tile_indices": integers(plan[6], plan[0]),
        "merge_indptr": integers(plan[7], 5),
        "output_indptr": integers(plan[8], 2),
        "kv_chunk_size": integers(plan[9], 1),
        "iterations": [],
    }
    for iteration in range(args.iterations):
        case.output.fill_(float("nan"))
        execute(case, args.tile)
        torch.cuda.synchronize()
        finite = torch.isfinite(case.output).all(dim=-1)
        relative = (case.output.float() - expected).norm(dim=-1) / expected.norm(dim=-1).clamp_min(1e-6)
        entry = dict(iteration=iteration, nonfinite_heads=torch.nonzero(~finite).cpu().tolist(),
                     incorrect_heads=int((~finite | (relative >= 0.02)).sum()),
                     worst_finite_error=float(relative[finite].max()) if finite.any() else None)
        report["iterations"].append(entry)
        print("Q32_DIAG", json.dumps(entry), flush=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()

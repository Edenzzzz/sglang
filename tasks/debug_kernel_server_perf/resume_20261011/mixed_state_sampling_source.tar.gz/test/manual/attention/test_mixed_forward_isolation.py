import ast
from contextlib import contextmanager
import dataclasses
from pathlib import Path
from types import SimpleNamespace
import unittest


SOURCE = Path(__file__).resolve().parents[3] / "python/sglang/srt/managers/scheduler.py"
TREE = ast.parse(SOURCE.read_text())
SCHEDULER = next(node for node in TREE.body if isinstance(node, ast.ClassDef) and node.name == "Scheduler")
METHODS = [node for node in SCHEDULER.body if isinstance(node, ast.FunctionDef) and node.name in {
    "record_batch_in_overlap", "_forward_isolation",
}]


@dataclasses.dataclass
class Batch:
    spec_algorithm: object
    sampling_info: object
    seq_lens: object
    spec_info: object
    mixed_spec_running: object = None


NAMESPACE = {"contextmanager": contextmanager, "dataclasses": dataclasses, "ScheduleBatch": Batch}
exec(compile(ast.Module(body=METHODS, type_ignores=[]), str(SOURCE), "exec"), NAMESPACE)
Scheduler = type("Scheduler", (), {name: NAMESPACE[name] for name in (
    "record_batch_in_overlap", "_forward_isolation",
)})


class MixedForwardIsolationTest(unittest.TestCase):
    def make_batch(self):
        sampling = SimpleNamespace(copy_for_forward=lambda: object())
        return Batch(SimpleNamespace(is_none=lambda: False), sampling, object(), object())

    def test_both_logical_batches_restore_state_and_keep_tensor_references(self):
        scheduler = Scheduler()
        scheduler.batch_record_ct = 0
        scheduler.batch_record_buf = [None, None]
        prefill = self.make_batch()
        running = self.make_batch()
        prefill.mixed_spec_running = running
        previous_prefill = dict(vars(prefill))
        previous_running = dict(vars(running))
        with scheduler._forward_isolation(prefill, overlap=True):
            self.assertIsNot(prefill.sampling_info, previous_prefill["sampling_info"])
            self.assertIsNot(running.sampling_info, previous_running["sampling_info"])
            prefill.seq_lens = object()
            running.seq_lens = object()
            running.spec_info = object()
        self.assertEqual(vars(prefill), previous_prefill)
        self.assertEqual(vars(running), previous_running)
        self.assertEqual(scheduler.batch_record_ct, 1)
        pinned = scheduler.batch_record_buf[1]
        self.assertIs(pinned[2], running)
        self.assertTrue(any(value is previous_running["seq_lens"] for value in pinned[3]))
        self.assertIsNone(scheduler.batch_record_buf[0])

    def test_exception_restores_both_without_overlap_storage(self):
        scheduler = Scheduler()
        prefill = self.make_batch()
        running = self.make_batch()
        prefill.mixed_spec_running = running
        previous = running.seq_lens
        with self.assertRaisesRegex(RuntimeError, "test"):
            with scheduler._forward_isolation(prefill, overlap=False):
                running.seq_lens = object()
                raise RuntimeError("test")
        self.assertIs(running.seq_lens, previous)


if __name__ == "__main__":
    unittest.main()

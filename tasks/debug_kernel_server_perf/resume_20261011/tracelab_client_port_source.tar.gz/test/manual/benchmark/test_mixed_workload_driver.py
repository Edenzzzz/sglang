import importlib.util
import json
import signal
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch


DRIVER_PATH = (
    Path(__file__).resolve().parents[3]
    / "tasks/realistic_workload_analysis/run_mixed_workloads.py"
)
SPEC = importlib.util.spec_from_file_location("mixed_workload_driver", DRIVER_PATH)
DRIVER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(DRIVER)


class MixedWorkloadDriverTest(unittest.TestCase):
    def test_teardown_targets_only_owned_process_group(self):
        process = Mock(pid=12345)
        with patch.object(DRIVER.os, "killpg") as kill:
            DRIVER.stop_owned_process(process)
        kill.assert_called_once_with(12345, signal.SIGKILL)
        process.wait.assert_called_once_with(timeout=30)

    def test_occupied_port_is_not_killed(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(DRIVER.socket, "socket") as socket, patch.object(
                DRIVER.subprocess, "Popen"
            ) as popen:
                socket.return_value.__enter__.return_value.connect_ex.return_value = 0
                with self.assertRaisesRegex(RuntimeError, "unowned server"):
                    DRIVER.run_method("MTP_LPT", {"streams": {}}, Path(directory))
                popen.assert_not_called()

    def test_client_exit_before_barrier_fails_even_with_zero_status(self):
        for exit_code in (0, 1):
            with self.subTest(exit_code=exit_code), tempfile.TemporaryDirectory() as directory:
                process = Mock()
                process.poll.return_value = exit_code
                with (
                    patch.dict(DRIVER.os.environ, {"BENCH_NO_BARRIER": ""}),
                    patch.object(DRIVER, "wait_health", return_value=True),
                    patch.object(DRIVER.subprocess, "run"),
                    patch.object(DRIVER.subprocess, "Popen", return_value=process),
                    patch.object(DRIVER, "stop_owned_process") as stop,
                ):
                    with self.assertRaisesRegex(RuntimeError, "before start barrier"):
                        DRIVER.run_clients(
                            "MTP_LPT", {"streams": {"trace": ["--num-prompts", "2"]}},
                            Path(directory), {}, Mock(), Path(directory, "server.log"),
                        )
                    stop.assert_called_once_with(process)

    def test_partial_completion_does_not_produce_validation_marker(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            process = Mock()
            process.wait.return_value = 0

            def launch(*args, **kwargs):
                (root / "MTP_LPT_trace.json").write_text(json.dumps({"completed": 1, "errors": []}))
                return process

            with (
                patch.dict(DRIVER.os.environ, {"BENCH_NO_BARRIER": "1"}),
                patch.object(DRIVER, "wait_health", return_value=True),
                patch.object(DRIVER.subprocess, "run"),
                patch.object(DRIVER.subprocess, "Popen", side_effect=launch),
                patch.object(DRIVER, "stop_owned_process"),
            ):
                with self.assertRaisesRegex(RuntimeError, "all 2 requests"):
                    DRIVER.run_clients(
                        "MTP_LPT", {"streams": {"trace": ["--num-prompts", "2"]}},
                        root, {}, Mock(), root / "server.log",
                    )
            self.assertFalse((root / "MTP_LPT_validation.json").exists())


if __name__ == "__main__":
    unittest.main()

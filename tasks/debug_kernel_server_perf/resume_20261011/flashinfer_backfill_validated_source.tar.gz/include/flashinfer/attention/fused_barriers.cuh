/*!
 * \brief Named-barrier ids for the fused FA3+FA2 kernel.
 *
 * Carved out of our `prefill.cuh` changes rather than overlaying that file. 0.7 grew
 * `prefill.cuh` from 2734 to 4871 lines, so overlaying it to obtain two constants would put a
 * heavily-rewritten 4800-line file under our maintenance for no reason -- the same argument that
 * keeps `scheduler.cuh` out of the overlay.
 *
 * Why these ids and not 0-7: on this path ids 0-7 are all taken. flashinfer's FA3 NamedBarriers
 * occupy 0-6 and CUTLASS's ReservedNamedBarriers occupy 1-7, which is why CUTLASS defines
 * `FirstUserBarrier = 8`. Taking 1 and 2 collided with `EpilogueBarrier` and
 * `kWarpSchedulerWG1`, and the symptom was `cudaErrorIllegalInstruction` -- a failure that names
 * nothing about barriers, so it is recorded here rather than rediscovered.
 */
#ifndef FLASHINFER_ATTENTION_FUSED_BARRIERS_CUH_
#define FLASHINFER_ATTENTION_FUSED_BARRIERS_CUH_

#include <cutlass/arch/barrier.h>

namespace flashinfer {

static constexpr int kPersistentMainloopBarrier = 2;
static constexpr int kFusedQueueBarrier = 5;
static_assert(kFusedQueueBarrier + 2 <
              static_cast<int>(cutlass::arch::ReservedNamedBarriers::FirstUserBarrier));


// The two values the cross-role backfill queue needs: the device-side cursor blocks pull
// persistent cluster indices from, and how many there are.
//
// These are deliberately NOT fields of PersistentParams. That struct is generated from
// upstream's csrc/batch_attention_customize_config.jinja, so carrying them there means
// patching a template inside the installed wheel -- unreproducible, and a hard blocker for
// upstreaming, since every stock BatchAttention build would have to grow two fields it never
// uses. The 0.3.1 tree did patch the jinja; 0.7 does not need to, because only our own kernel
// reads these and it can take them as an argument.
struct FusedQueueParams {
  int32_t* cluster_cursor = nullptr;
  uint32_t num_pers_clusters = 0;
};

}  // namespace flashinfer

#endif  // FLASHINFER_ATTENTION_FUSED_BARRIERS_CUH_

/*
 * Copyright (c) 2024 by FlashInfer team.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef FLASHINFER_ATTENTION_HOPPER_VARIANT_HELPER_H
#define FLASHINFER_ATTENTION_HOPPER_VARIANT_HELPER_H

#include <cuda_runtime.h>

#include <cstdint>

// --- fused FA3+FA2 co-inclusion ---------------------------------------------------------------
// 0.7 has no translation unit that includes both the FA2-lineage tree and the Hopper tree; POD
// attention (pod.cuh) is FA2-only. The fused kernel is the first thing that needs both, and the
// two trees define several of the same names in namespace flashinfer. 0.3.1's upstream carried
// `...Sm90` suffixes on the Hopper spellings, which is why this never arose there; 0.7 dropped
// them because nothing needed them.
//
// The Hopper names are suffixed here and the unsuffixed spellings kept as aliases, so every stock
// FA3 module is unaffected -- they are generated with variant_name "DefaultAttention<...>", so a
// tree-wide rename would break all of them. A TU that includes BOTH trees defines
// FLASHINFER_SM90_SUPPRESS_UNSUFFIXED_NAMES to drop the aliases and name the suffixed types
// explicitly. Omitting that define yields a loud redefinition error, never a silent bind to the
// FA2 type of the same name.
// -------------------------------------------------------------------------------------------

namespace flashinfer {

#ifndef REGISTER_QUERY_TRANSFORM
#define REGISTER_QUERY_TRANSFORM(params, q, ...)                                            \
  template <typename MainloopParams, typename T>                                            \
  __device__ __forceinline__ T QueryTransform(const MainloopParams& params, void* q_smem) { \
    __VA_ARGS__                                                                             \
  }
#endif

#ifndef REGISTER_KEY_TRANSFORM
#define REGISTER_KEY_TRANSFORM(params, k, ...)                                            \
  template <typename MainloopParams, typename T>                                          \
  __device__ __forceinline__ T KeyTransform(const MainloopParams& params, void* k_smem) { \
    __VA_ARGS__                                                                           \
  }
#endif

#ifndef REGISTER_LOGITS_TRANSFORM
#define REGISTER_LOGITS_TRANSFORM(params, logits, batch_idx, qo_idx, kv_idx, qo_head_idx, \
                                  kv_head_idx, ...)                                       \
  template <typename MainloopParams, typename T>                                          \
  __device__ __forceinline__ T LogitsTransform(                                           \
      const MainloopParams& params, T logits, uint32_t batch_idx, uint32_t qo_idx,        \
      uint32_t kv_idx, uint32_t qo_head_idx, uint32_t kv_head_idx) {                      \
    __VA_ARGS__                                                                           \
  }
#endif

#ifndef REGISTER_LOGITS_MASK
#define REGISTER_LOGITS_MASK(params, batch_idx, qo_idx, kv_idx, qo_head_idx, kv_head_idx, ...) \
  template <typename MainloopParams>                                                           \
  __device__ __forceinline__ bool LogitsMask(const MainloopParams& params, uint32_t batch_idx, \
                                             uint32_t qo_idx, uint32_t kv_idx,                 \
                                             uint32_t qo_head_idx, uint32_t kv_head_idx) {     \
    __VA_ARGS__                                                                                \
  }
#endif

struct AttentionVariantBaseSm90 {
  REGISTER_LOGITS_TRANSFORM(params, logits, batch_idx, qo_idx, kv_idx, qo_head_idx, kv_head_idx,
                            { return logits; })

  REGISTER_LOGITS_MASK(params, batch_idx, qo_idx, kv_idx, qo_head_idx, kv_head_idx,
                       { return true; })
};

#ifndef FLASHINFER_SM90_SUPPRESS_UNSUFFIXED_NAMES
using AttentionVariantBase = AttentionVariantBaseSm90;
#endif

}  // namespace flashinfer

#endif  // FLASHINFER_ATTENTION_HOPPER_VARIANT_HELPER_H

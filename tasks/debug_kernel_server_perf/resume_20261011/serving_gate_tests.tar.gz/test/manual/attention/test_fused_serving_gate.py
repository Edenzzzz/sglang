import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch


DRIVER_PATH = (
    Path(__file__).resolve().parents[3]
    / "tasks/fused_specdec_workload/drivers/srv_correctness.py"
)
SPEC = importlib.util.spec_from_file_location("fused_serving_gate", DRIVER_PATH)
DRIVER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(DRIVER)


class FusedServingGateTest(unittest.TestCase):
    def compare(self, baseline, candidate):
        with tempfile.TemporaryDirectory() as directory:
            for name, output in (("baseline", baseline), ("candidate", candidate)):
                Path(directory, name + ".json").write_text(json.dumps(output))
            DRIVER.compare(directory, "baseline", "candidate")

    def test_matching_outputs_pass(self):
        output = {"l0": list(range(12)), "_fallbacks": 0, "_tracebacks": 0}
        self.compare(output, output)

    def test_mismatch_and_runtime_failures_raise(self):
        baseline = {"l0": list(range(12)), "_fallbacks": 0, "_tracebacks": 0}
        for update in (
            {"l0": [99] * 12},
            {"_fallbacks": 1},
            {"_tracebacks": 1},
            {"l0": [0, 1]},
        ):
            with self.subTest(update=update):
                with self.assertRaises(RuntimeError):
                    self.compare(baseline, dict(baseline, **update))

    def test_no_long_requests_fails(self):
        output = {"s0": list(range(12)), "_fallbacks": 0, "_tracebacks": 0}
        with self.assertRaises(RuntimeError):
            self.compare(output, output)

    def test_missing_dataset_does_not_silently_use_synthetic_prompts(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(DRIVER.os.environ, {
                "CORRECTNESS_DATASET": str(Path(directory, "missing.json")),
                "CORRECTNESS_SYNTHETIC": "0",
            }):
                with self.assertRaises(FileNotFoundError):
                    DRIVER.prompts()

    def test_explicit_synthetic_prompts_are_repeatable(self):
        with patch.dict(DRIVER.os.environ, {"CORRECTNESS_SYNTHETIC": "1"}):
            short, long_prompts = DRIVER.prompts()
            self.assertEqual((short, long_prompts), DRIVER.prompts())
        self.assertEqual([len(prompt) for prompt in short], [2048] * 8)
        self.assertEqual([len(prompt) for prompt in long_prompts], [12000] * 4)


if __name__ == "__main__":
    unittest.main()

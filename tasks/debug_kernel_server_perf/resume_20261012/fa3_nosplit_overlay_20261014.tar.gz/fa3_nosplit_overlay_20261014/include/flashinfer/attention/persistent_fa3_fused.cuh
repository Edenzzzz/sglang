/*
 * Fused FA3 + FA2 kernel with SM pre-assignment.
 *
 * One launch, one grid of num_sm CTAs. The scheduler hands each task a
 * contiguous cluster range (see TwoStageHolisticPlan's task_lo/task_hi), and
 * this kernel honours that split at the SM level:
 *
 *   blockIdx.x <  sm_split : runs FA3's warp-specialised TMA + wgmma mainloop
 *                            over the large-tile task.
 *
 * sm_split is CAPPED, not taken from the work ratio. Measured on the MTP
 * schedule, a work-proportional split hands FA3 98-124 of 132 SMs and the fused
 * kernel then loses to plain sequential (1.23x vs 1.41x over the monolithic
 * kernel); capping FA3 at 8-32 SMs wins instead (1.62x, i.e. 1.148x over
 * sequential, on 24/24 steps). The rate constant that would predict the measured
 * optimum varies 40x across steps, so it is not a rate: the persistent side is
 * bandwidth-bound and needs SMs out of proportion to its share of the work.
 *   blockIdx.x >= sm_split : runs the FA2-lineage persistent mainloop over the
 *                            remaining tile classes, driven by our work queue.
 *
 * Two things make this possible, and neither is incidental:
 *
 * 1. FA3 is warp-specialised: 12 warps per CTA, one producer warpgroup issuing
 *    TMA loads and two consumer warpgroups running wgmma. A CTA that contains a
 *    TMA producer can never take part in a grid-wide barrier, because the
 *    producer's mbarrier waits are not visible to cooperative_groups. The
 *    persistent kernel used to end with grid.sync() + a single-shot reduction,
 *    which is exactly the construct FA3 cannot join. Just-in-time reduction
 *    removed that barrier -- producers now reduce their own groups as they
 *    complete -- so the two mainloops can finally live in one launch. The JIT
 *    reduction is the enabler here, not a borrowed optimisation.
 *
 * 2. The two mainloops want different CTA shapes: FA3 needs 384 threads,
 *    the persistent mainloop 128. The CTA is launched at FA3's width and the
 *    persistent side runs in warpgroup 0 only, syncing with a named barrier of
 *    width 128 (KTraits::NAMED_BARRIER_SYNC) rather than __syncthreads(), so
 *    the warps it does not use simply exit. That costs occupancy on the FA2
 *    side, which is the price of the shared smem budget; v2 gives each of the
 *    three warpgroups its own queue slot to win it back.
 */
#ifndef FLASHINFER_ATTENTION_PERSISTENT_FA3_FUSED_CUH_
#define FLASHINFER_ATTENTION_PERSISTENT_FA3_FUSED_CUH_

#include <string>

#include <cutlass/arch/barrier.h>
#include "fused_pdl_trace.cuh"

#if FLASHINFER_FA3_UPSTREAM
// This TU includes BOTH the FA2-lineage tree (via persistent.cuh) and the Hopper tree, which
// 0.7 never does anywhere -- see the note in hopper/variant_helper.cuh. Building it requires
// -DFLASHINFER_SM90_SUPPRESS_UNSUFFIXED_NAMES=1, which drops the unsuffixed Hopper aliases so
// the two trees stop colliding. It has to be a TU-wide compile flag, not a #define here:
// whichever header reaches hopper/variant_helper.cuh first wins, and that is not always this
// one. Without the flag the build fails with a redefinition error naming those aliases.
#include "hopper/fa3_upstream.cuh"
#endif
#include "hopper/prefill_sm90.cuh"
#include "persistent.cuh"
#include "unified_wgmma_scheduler.cuh"

namespace flashinfer {

// Byte offset at which the FA2 mainloop's shared storage begins inside the
// kernel's dynamic shared memory. 0 means it sits on top of FA3's storage, which
// is the historical behaviour; with FLASHINFER_FUSED_DISJOINT_SMEM it sits past
// it instead. Reusing FA3's region is the remaining hazard class on the backfill
// path -- a backfilling CTA reinterprets memory FA3's warp specialisation was
// using, pipeline mbarriers included -- and making the two disjoint lets that
// class be ruled in or out by measurement. It only fits with a shallower FA3
// pipeline: 163920 + 69632 exceeds the 232448-byte opt-in limit, while one K/V
// stage puts FA3 near 96000 and the pair near 165600.
//
// MEASURED, and it does not work: with FA3 at one stage so that it fits, the
// disjoint layout fails 2 configurations on every run (0 clean in 10), while the
// same 1-stage FA3 with shared memory REUSED is clean 14 times in 14. So the
// offsetting itself is wrong somewhere, and -- more to the point -- reuse is not
// the hazard it was meant to test. Left off; do not enable without fixing it.
//
// Original note: with FA3 left at NUM_STAGES = 2 this mode does not launch at all --
// 163920 + 69632 + 16 is 233568 against a 232448-byte limit, so
// cudaFuncSetAttribute refuses it. Enabling it therefore also requires building
// FA3Traits with NUM_STAGES = 1, which is a change to FA3's pipeline depth and
// so to its performance, not just its memory. Left opt-in and off by default.
template <size_t kFA3Bytes>
__device__ __host__ constexpr size_t fused_pers_smem_base() {
  // Now DISJOINT BY DEFAULT, because symmetric mode's FA3 output is wrong
  // nondeterministically (rel err 1.93 / 2.53 / 3.31 across identical runs, one
  // run exact) and only when a CTA drains FA2 before entering FA3. A CUTLASS
  // warp-specialised kernel initialises its pipeline mbarriers in shared memory
  // at entry, before the sm_split branch, and with a base of 0 the drain's slot
  // and its cursor/merge tail at ~69648 land inside FA3's 98352-byte
  // SharedStorage. That is a race, and this is the layout that removes it.
  //
  // It fits because FA3 runs one K/V stage here (FUSED_FA3_STAGES=1, ~98 KB):
  // 98352 rounded to 98304 plus one 69632-byte slot plus the 48-byte tail is
  // 167984 against the 232448-byte opt-in limit. Three slots would not fit, so a
  // warpgroup-reentrant drain needs FA3's state re-initialised after the
  // rendezvous instead of a disjoint layout.
#ifdef FLASHINFER_FUSED_ALIAS_SMEM
  return 0u;
#else
  return (kFA3Bytes + 1023u) & ~size_t(1023u);
#endif
}


// Flip the persistent mainloop onto a warpgroup-scoped barrier and the 1-D
// fused grid (cluster index from blockIdx.x, cluster_size pinned to 1).
// Both overrides are now A/B-able, because they are the leading suspects for the FA2-only path
// being ~20x slower than the same kernel family under stock traits -- and three hypotheses about
// that gap have already been refuted by guessing. NAMED_BARRIER_SYNC replaces __syncthreads() with
// a warpgroup-scoped named barrier at prefill.cuh:2111 and :2187, which sit in the per-kv-tile
// loop; at 2048 keys that is a round trip per iteration. FUSED_GRID pins cluster_size to 1 and
// takes the cluster index from blockIdx.x.
//
// Defaults preserve current behaviour. FUSED_NB_SYNC=0 / FUSED_GRID_1D=0 turn them off.
#ifndef FUSED_NB_SYNC
#define FUSED_NB_SYNC 1
#endif
#ifndef FUSED_GRID_1D
#define FUSED_GRID_1D 1
#endif
template <typename Base>
struct FusedWarpgroupTraits : Base {
  static constexpr bool NAMED_BARRIER_SYNC = (FUSED_NB_SYNC != 0);
  static constexpr bool FUSED_GRID = (FUSED_GRID_1D != 0);
};

// kBackfill: let a block that finished FA3 keep pulling persistent queue slots
// instead of idling. This is the property a two-kernel co-launch cannot have and
// the reason a shared LPT heap beat a static split in earlier measurements.
// Inlined, not out of line. Taking it out of line costs correctness on the
// backfill path for the same reason the FA3 body cannot leave: a backfilling CTA
// reaches here on a warpgroup whose register budget FA3 raised to 240 with
// setmaxnreg, while the ABI frame of a call assumes the kernel's 168, and the
// call then raises cudaErrorIllegalInstruction. An FA2-role CTA never ran
// setmaxnreg and so never saw it, which is why only one configuration crashed.
// The cost is that FA3's live range and this one share an allocation; that is a
// spill-count problem, and spills are cheaper than wrong answers.
// kTidBase is a template parameter, not an argument. As a runtime value it
// defeats constant folding of every index expression derived from the thread
// id: ptxas reported 6284 bytes of spill stores in this function against 604
// when the base was provably zero.
// Bytes reserved per warpgroup for one persistent mainloop's SharedStorage,
// 16-byte aligned. Sized from the LARGEST tile class (tile 16 at 69632 B, not
// tile 128 at 49152), because a warpgroup may draw any class from the queue.
template <typename Runner1, typename Runner2, typename Runner3>
__device__ __host__ __forceinline__ constexpr size_t kPersSlotBytes() {
  constexpr size_t a = sizeof(typename Runner1::KTraits::SharedStorage);
  constexpr size_t b = sizeof(typename Runner2::KTraits::SharedStorage);
  constexpr size_t c = sizeof(typename Runner3::KTraits::SharedStorage);
  constexpr size_t m = a > b ? (a > c ? a : c) : (b > c ? b : c);
  return (m + 15u) & ~size_t(15u);
}

// FLASHINFER_FUSED_DRAIN_NOINLINE=1 gives the FA2 role its OWN register
// allocation. ptxas allocates per function, so while this body is inlined the FA2
// mainloop's live ranges share one allocation with the FA3 role's even though the
// two roles sit in mutually exclusive branches. Measured: upstream FA3 spills
// 33 676 B inside this kernel against 52 B compiled alone in the same template, at
// the same 168 registers and the same launch bounds.
//
// Only the FA2 side may be outlined. The FA3 body cannot -- it contains the warp
// specialisation's warpgroup_reg_dealloc/alloc, and setmaxnreg across an ABI call
// boundary left FA3's output intermittently corrupt (recorded at the call site).
// The FA2 mainloop runs at the default allocation and issues no setmaxnreg, so it
// carries no such constraint.
#ifndef FLASHINFER_FUSED_DRAIN_NOINLINE
#define FLASHINFER_FUSED_DRAIN_NOINLINE 0
#endif

template <uint32_t kTidBase, size_t FA3SmemBytes, typename Runner1, typename Runner2,
          typename Runner3>
#if FLASHINFER_FUSED_DRAIN_NOINLINE
__device__ __noinline__ void fused_drain_queue(typename Runner1::Params const& params_1,
#else
__device__ __forceinline__ void fused_drain_queue(typename Runner1::Params const& params_1,
#endif
                                               typename Runner2::Params const& params_2,
                                               typename Runner3::Params const& params_3,
                                               uint8_t* smem, FusedQueueParams const& queue) {
  constexpr uint32_t tid_base = kTidBase;
  // Slot INDEX, not warpgroup id. Only FLASHINFER_FUSED_WG_DRAIN slots are
  // allocated, so a narrow drain running on warpgroup 1 must still use slot 0 --
  // deriving the index from kTidBase made it address slot 1 of a one-slot
  // allocation and fault with an illegal access 69632 bytes past the end.
#ifndef FLASHINFER_FUSED_WG_DRAIN
#define FLASHINFER_FUSED_WG_DRAIN 1
#endif
  constexpr uint32_t kWgSlot = FLASHINFER_FUSED_WG_DRAIN == 1 ? 0u : kTidBase / 128u;
  const uint32_t ltid = threadIdx.x - tid_base;
  // kFusedDisjointSmem puts the FA2 mainloop's storage PAST FA3's instead of on
  // top of it. Reusing FA3's region is the whole remaining hazard class on the
  // backfill path -- a backfilling CTA reinterprets memory that FA3's warp
  // specialisation was using, including its pipeline mbarriers -- and this makes
  // the two disjoint so the class can be ruled in or out by measurement rather
  // than argument. It only fits if FA3 runs a shallower pipeline: 163920 + 69632
  // exceeds the 232448-byte opt-in limit, while one K/V stage brings FA3 to
  // ~96000 and the pair to ~165600.
  uint8_t* pers_smem_base = smem + fused_pers_smem_base<FA3SmemBytes>();
  // One mainloop storage slot PER WARPGROUP. All three warpgroups drain the
  // queue at once in symmetric mode, so a single slot has them overwriting each
  // other's Q/K/V tiles and mdo scratch -- the cursor and merge flag were
  // already split this way, the storage was not. Measured sizes (sm_90a):
  // tile128 49152, tile64 32768, tile16 69632 B, so three slots of the largest
  // class are 208896 B against the 232448-byte opt-in limit. They fit only on
  // top of FA3's region (98352 B), which is the default here and is sound
  // because a CTA runs FA3 work or FA2 work, never both at once.
  uint8_t* pers_smem = pers_smem_base + kWgSlot * kPersSlotBytes<Runner1, Runner2, Runner3>();
  auto& smem_storage_1 =
      reinterpret_cast<typename Runner1::KTraits::SharedStorage&>(*pers_smem);
  auto& smem_storage_2 =
      reinterpret_cast<typename Runner2::KTraits::SharedStorage&>(*pers_smem);
  auto& smem_storage_3 =
      reinterpret_cast<typename Runner3::KTraits::SharedStorage&>(*pers_smem);
  // The block-wide slot for the claimed cluster lives at the END of the dynamic
  // shared memory, NOT in a static __shared__ variable: a static allocation
  // shifts the dynamic base and breaks the alignment FA3's SharedStorage needs
  // (compute-sanitizer: "Misaligned shared or local address" in an FA3 block).
  // Past the LARGER of the two mainloops' storage, not Runner2's. Runner2 (tile
  // 64) needs 32768 bytes but Runner3 (tile 16) needs 69632, because it runs 4
  // KV warps and so a CTA_TILE_KV of 128. Sizing this from Runner2 alone put the
  // queue cursor and the merge flag inside the region Runner3 writes, which
  // corrupted them from the second queue slot onward -- worst where a CTA drains
  // many slots, which is exactly the backfill-on, small-sm_split case.
  constexpr size_t kR12 = sizeof(typename Runner1::KTraits::SharedStorage) >
                                  sizeof(typename Runner2::KTraits::SharedStorage)
                              ? sizeof(typename Runner1::KTraits::SharedStorage)
                              : sizeof(typename Runner2::KTraits::SharedStorage);
  constexpr size_t kPersStorage =
      kR12 > sizeof(typename Runner3::KTraits::SharedStorage)
          ? kR12
          : sizeof(typename Runner3::KTraits::SharedStorage);
  // Past every warpgroup slot that is actually reserved. One slot's worth put
  // the tail inside warpgroup 1's storage; always reserving three made the
  // disjoint layout exceed the 232448-byte opt-in limit and so untestable.
#ifndef FLASHINFER_FUSED_WG_DRAIN
#define FLASHINFER_FUSED_WG_DRAIN 1
#endif
  constexpr size_t kCursorOff =
      size_t(FLASHINFER_FUSED_WG_DRAIN) * kPersSlotBytes<Runner1, Runner2, Runner3>();
  // Per-warpgroup slot and barrier id, derived from kTidBase. The symmetric
  // kernel lets all three warpgroups drain the queue at once, and they would
  // otherwise race on one cluster cursor and one merge flag, and mis-match on a
  // single CTA-wide named barrier that each expects 128 arrivals at.
  constexpr uint32_t kWg = FLASHINFER_FUSED_WG_DRAIN == 1 ? 0u : kTidBase / 128u;
  constexpr uint32_t kQueueBarrier = kFusedQueueBarrier + kWg;
  uint32_t* s_cluster = reinterpret_cast<uint32_t*>(pers_smem_base + kCursorOff + kWg * 16u);
  // The second 8 bytes of each warpgroup's 16-byte tail slot held the JIT merge's "am I the
  // last arrival" broadcast. 0.7 has no such rendezvous -- split rows are combined by the
  // scheduled merge over merge_indptr / merge_o_indices -- so there is nothing to broadcast and
  // Run no longer takes it. The slot stride stays at 16 B: shrinking it is a shared-memory
  // layout change, and the fp32 reference is not passing yet to catch one.
  const uint32_t n_clusters = queue.num_pers_clusters;
#if FLASHINFER_FUSED_TRACE_WRITE
  // NULL CASE for the write trace. Without a line that is guaranteed to print, a missing write
  // trace cannot be told apart from a module served from cpp_extension's cache with the trace
  // never compiled in -- and four gates this session have already reported success while
  // covering nothing.
  if (ltid == 0 && blockIdx.x == FLASHINFER_FUSED_TRACE_WRITE - 1) {
    printf("[fa2 enter] blk=%u wg=%u n_clusters=%u\n", blockIdx.x, kWg, n_clusters);
  }
#endif
  while (true) {
    if (ltid == 0) {
      *s_cluster = static_cast<uint32_t>(atomicAdd(queue.cluster_cursor, 1));
    }
    cutlass::arch::NamedBarrier::sync(
        Runner1::KTraits::NUM_THREADS,
        static_cast<cutlass::arch::ReservedNamedBarriers>(kQueueBarrier));
    const uint32_t c = *s_cluster;
    if (c >= n_clusters) break;
    // Diagnostic: keep the queue's barrier and cursor traffic but run no
    // mainloop. Separates "entering FA3 after divergent code" from "the mainloop
    // bodies clobber something FA3 needs" as the cause of symmetric mode's wrong
    // FA3 output. FA2 rows are of course unwritten under this flag.
#ifndef FLASHINFER_FUSED_DRAIN_NOOP
    Runner1::Run(params_1, &smem_storage_1, c, tid_base);
    Runner2::Run(params_2, &smem_storage_2, c, tid_base);
    Runner3::Run(params_3, &smem_storage_3, c, tid_base);
#endif
    cutlass::arch::NamedBarrier::sync(
        Runner1::KTraits::NUM_THREADS,
        static_cast<cutlass::arch::ReservedNamedBarriers>(kQueueBarrier));
  }
}

#ifndef FUSED_CONST_PERS_PARAMS
#define FUSED_CONST_PERS_PARAMS 0
#endif
#if FUSED_CONST_PERS_PARAMS
#define FUSED_PERS_QUALIFIER CUTE_GRID_CONSTANT const
#else
#define FUSED_PERS_QUALIFIER
#endif

template <typename FA3Mainloop, typename FA3Epilogue, typename FA3Traits, bool LEFT_SLIDING_WINDOW,
          bool CAUSAL, typename FA3TileScheduler, typename Runner1, typename Runner2,
          typename Runner3>
__global__ void __launch_bounds__(FA3Traits::NUM_WARPS* cutlass::NumThreadsPerWarp, 1)
    FusedFA3PersistentKernel(
#if FLASHINFER_FA3_UPSTREAM
        // Upstream's Params carries TMA descriptors too, and the note below says
        // what happens when such a struct is not first: the descriptors must sit
        // 64B-aligned in the kernel parameter buffer, and structs placed ahead of
        // them shift that alignment until cudaLaunchKernel fails with "misaligned
        // address". So it goes FIRST, and the three flashinfer params it replaces
        // drop out entirely rather than sitting alongside it.
        CUTE_GRID_CONSTANT
        typename UpstreamFA3Kernel<FA3Traits::HEAD_DIM_VO, int32_t>::Params const upstream_fa3,
#else
        CUTE_GRID_CONSTANT typename FA3Mainloop::Params const fa3_mainloop_params,
        CUTE_GRID_CONSTANT typename FA3Epilogue::Params const fa3_epilogue_params,
        CUTE_GRID_CONSTANT typename FA3TileScheduler::Params const fa3_scheduler_params,
#endif
        FUSED_PERS_QUALIFIER typename Runner1::Params params_1,
        FUSED_PERS_QUALIFIER typename Runner2::Params params_2,
        FUSED_PERS_QUALIFIER typename Runner3::Params params_3,
        const uint32_t sm_split, const bool backfill,
        const FusedQueueParams queue, const uint32_t entry_register_count) {
  // NOTE: element type must match persistent_template.cuh's declaration of the
  // same extern array, or the two TUs disagree on `flashinfer::smem`.
  extern __shared__ uint8_t smem[];
  // Lets a programmatic dependent (the co-launched FA2 executor) start as soon as every CTA of
  // this grid is resident, instead of at grid completion. A no-op without a dependent.
  asm volatile("griddepcontrol.launch_dependents;" ::: "memory");
  FusedPdlRecord<kPdlFa3Start>(queue.pdl_timeline);

  // FLASHINFER_FUSED_SKIP_FA3 is a diagnostic, not a feature: it sends every CTA
  // straight to the FA2 queue so a cluster launch can be exercised without FA3's
  // CUTLASS pipeline in the picture. Output is deliberately wrong (the FA3 rows go
  // unwritten); the only signal wanted is crash vs no crash, to establish whether
  // FA3 is what a cluster launch breaks rather than assuming it from the
  // hardcoded cluster_shape in prefill_sm90.cuh.
  const bool skip_fa3 = (sm_split & 0x40000000u) != 0u;
  const uint32_t eff_split = sm_split & 0x3FFFFFFFu;

  if (!skip_fa3 && blockIdx.x < eff_split) {
    // ---- FA3 role: TMA producer + wgmma consumers over the large-tile task
    // Inlined deliberately. fa3_prefill_body contains the warp-specialisation's
    // warpgroup_reg_dealloc<24> / warpgroup_reg_alloc<240>, and setmaxnreg
    // cannot safely cross an ABI call boundary: the caller's frame assumes a
    // fixed register budget that the callee then changes under it. With the body
    // behind a __noinline__ wrapper the FA3 output was intermittently corrupt --
    // adjacent row pairs (one thread's two output rows) holding unnormalised
    // values ~20x the correct magnitude, at a rate that grew with the number of
    // work items a CTA processed (8/8 launches wrong at 11.5 items/CTA, 2/8 at
    // 2.9). flashinfer's own FA3 kernel, which inlines the same body, is stable.
#if FLASHINFER_FA3_UPSTREAM
    // Upstream flash-attention's FA3 body, in place of flashinfer's simplified
    // port. Measured motivation: the simplified one runs 772 us against the FA2
    // persistent kernel's 421 us on a long-prefix fixture, of which the K/V stage
    // count explains ~15% and the packed-Q gather nothing at all -- the remainder
    // is the mainloop. Upstream brings TMA Q, pack_gqa.h, paged_kv.h and
    // IntraWGOverlap, and its kernel is templated on the scheduler, so our plan
    // still decides which CTA does which work.
    //
    // smem: the FA3 role owns [0, 134144) of the request; the FA2 roles' slot sits
    // past it at fused_pers_smem_base(), which is why the disjoint layout still
    // fits (203776 of the 232448 opt-in limit).
    UpstreamFA3Kernel<FA3Traits::HEAD_DIM_VO, int32_t>{}(upstream_fa3,
                                                        reinterpret_cast<char*>(smem));
#else
    fa3_prefill_body<FA3Mainloop, FA3Epilogue, FA3Traits, LEFT_SLIDING_WINDOW, CAUSAL,
                     FA3TileScheduler, /*MULTIITEMSCORING=*/false>(
        fa3_mainloop_params, fa3_epilogue_params, fa3_scheduler_params,
        reinterpret_cast<char*>(smem), entry_register_count);
#endif
    // CROSS-ROLE BACKFILL. An FA3 block may go on to drain the persistent
    // queue, but only after its epilogue's async TMA stores have actually
    // retired: CollectiveEpilogue::store_tail() has its tma_store_wait<0>()
    // commented out, so __syncthreads() alone does NOT order them against the
    // persistent mainloop reinterpreting the same shared memory (observed as
    // cudaErrorMisalignedAddress). Wait for them explicitly, then hand over.
    // Unconditional, in both modes. CollectiveEpilogue::store_tail() has its own
    // tma_store_wait<0>() commented out, so nothing here guarantees FA3's async
    // output stores have retired. In flashinfer's own kernel that is harmless:
    // the kernel ends immediately and completion flushes them. Here the kernel
    // keeps running -- the FA2 CTAs are still draining the queue -- and leaving
    // without the wait left FA3's rows wrong by 28-47x the output magnitude on
    // every shape tested, while the backfill path, which already had the wait,
    // was correct. So the wait belongs to the FA3 role, not to backfill.
    cute::tma_store_wait<0>();
    // The epilogue's output stores are TMA, which the wait above covers. The
    // MAINLOOP's K/V loads are not TMA at all: paged KV sets USE_TMA_LOAD_KV =
    // false (sparse_mainloop.cuh) and gathers with cp.async, which
    // tma_store_wait does not touch. An in-flight cp.async issued by FA3's
    // producer warpgroup otherwise landed in shared memory after a backfilling
    // CTA had already reinterpreted that memory as the FA2 mainloop's K/V tiles,
    // corrupting whatever work item it had picked up. It showed as 2-3 runs in 10
    // giving wrong output for SHORT, UNSPLIT decode rows and never for the
    // KV-split row, which is what ruled out the JIT reduction as the cause.
    cp_async::wait_group<0>();
    // Also unconditional, and this is the one that actually matters: with the
    // threads of an FA3 CTA returning as they arrived, its output rows came out
    // wrong by 24-52x the output magnitude on every shape, while the backfill
    // path -- which had this barrier -- was correct. The epilogue stages O
    // through shared memory and hands it to a designated writer warp across a
    // named barrier, so no thread of the CTA may leave until the whole block has
    // passed the last work item's epilogue.
    __syncthreads();

    FusedPdlRecord<kPdlFa3End, true>(queue.pdl_timeline);
    // A runtime predicate, not a template parameter. As a template parameter it
    // produced a second instantiation that was deterministically wrong -- FA3
    // output off by 29-40x the output magnitude at every split, including with
    // no FA2 CTAs present at all -- from code identical up to the `if constexpr`.
    // Whatever ptxas did differently there, an A/B whose control is a separately
    // compiled kernel is not an A/B of backfill. One instantiation, one
    // predicate, so both arms run the same machine code.
    if (!backfill) {
      return;
    }
  }

  // ---- Dynamic scheduler.
  //
  // Both roles converge here. Rather than giving the persistent side a fixed
  // slice of the grid, every block -- including the ones that just finished FA3
  // -- pulls queue slots from one device-side cursor until the queue is drained.
  // A static split cannot do this: it was measured losing to a shared LPT heap
  // precisely because the heap backfills small tile-16 items into SMs that would
  // otherwise idle through the prefill tail. Here sm_split only decides who
  // starts on FA3, not who finishes the rest, so a mis-sized split costs much
  // less than it did.
  //
  // The FA2 role's width is the runners' own, not a hardcoded 128. With
  // FLASHINFER_FA2_QSPLIT the runners are 8 warps (256 threads) so that each warp
  // owns 16 q rows instead of 32, which halves the per-thread O accumulator -- the
  // thing that actually makes this role spill. Gating at 128 while the mainloop
  // expects 256 left half its barrier participants missing, and the symptom was the
  // FA3 role's output wrong by 8.94x while both FA2 rows stayed correct.
  //
  // All three runners must agree, because one gated thread region hosts whichever
  // runner the work item's tile class selects.
  constexpr uint32_t kFa2Threads = Runner1::KTraits::NUM_WARPS * 32u;
  static_assert(Runner2::KTraits::NUM_WARPS * 32u == kFa2Threads &&
                    Runner3::KTraits::NUM_WARPS * 32u == kFa2Threads,
                "the three FA2 runners must have equal thread width: one gated region "
                "serves all of them, so a narrower runner would leave threads inside its "
                "barriers");
  static_assert(kFa2Threads <= FA3Traits::NUM_WARPS * 32u,
                "the FA2 role cannot be wider than the CTA");
  if (!skip_fa3 && blockIdx.x < eff_split) {
    constexpr uint32_t kBackfillBase = FA3Traits::NUM_WARPS * 32u - kFa2Threads;
    static_assert(kBackfillBase >= 128u,
                  "backfill must start at or above warpgroup 1: warpgroup 0 is FA3's TMA "
                  "producer and holds 24 registers");
    if (threadIdx.x < kBackfillBase) {
#if defined(FUSED_FA2_REG_REALLOC) && FUSED_FA2_REG_REALLOC
      cutlass::arch::warpgroup_reg_dealloc<24>();
#endif
      return;
    }
#if defined(FUSED_FA2_REG_REALLOC) && FUSED_FA2_REG_REALLOC
    cutlass::arch::warpgroup_reg_alloc<240>();
#endif
    fused_drain_queue<kBackfillBase, sizeof(typename FA3Traits::SharedStorage), Runner1,
                      Runner2, Runner3>(params_1, params_2, params_3, smem, queue);
  } else {
#if defined(FUSED_FA2_REG_REALLOC) && FUSED_FA2_REG_REALLOC
    static_assert(kFa2Threads % 128u == 0u);
    static_assert(kFa2Threads * 240u +
                      (FA3Traits::NUM_WARPS * 32u - kFa2Threads) * 24u <=
                  65536u);
    if (threadIdx.x >= kFa2Threads) {
      cutlass::arch::warpgroup_reg_dealloc<24>();
      return;
    }
    if (entry_register_count > 240u) {
      cutlass::arch::warpgroup_reg_dealloc<240>();
    } else {
      cutlass::arch::warpgroup_reg_alloc<240>();
    }
#else
    if (threadIdx.x >= kFa2Threads) return;
#endif
    fused_drain_queue<0u, sizeof(typename FA3Traits::SharedStorage), Runner1, Runner2,
                      Runner3>(params_1, params_2, params_3, smem, queue);
  }
}

// ---------------------------------------------------------------------------
// TWO EXECUTORS, ONE PLAN.
//
// Measured reason this exists: a single kernel cannot give both roles their native
// register allocation. Upstream FA3 spills 33 676 B co-compiled with the FA2 runners
// against 52 B alone in the same template; outlining the FA2 body takes FA3 to 64 B and
// moves 17 500 B onto FA2; halving FA2's accumulator reaches 88 B isolated but only
// 1 504 B fused. Shared memory is over the 232 448 B opt-in limit by 1 120 B as well.
// Both constraints are co-residency artifacts, not costs of the work.
//
// So each role gets its own __global__ at its own geometry, and both read ONE
// FusedPlanInfo<4> (our private struct; see fused_plan.cuh): task 3 to the wgmma executor, tasks 0-2 to the FA2 executor. The
// 4-mode tile assignment, the per-queue split length, the JIT reduction and the spec
// epilogue all live in the plan, so none of them is given up. What is given up is
// cross-role backfill inside a CTA -- which is exactly the construct that caused the
// 33 676 B.
//
// Grids are FIXED at the SM count so the launch geometry never encodes the split: a CTA
// whose queue is empty exits. That keeps one CUDA graph per batch bucket instead of one
// per PD token ratio, and it is the same bucket-and-pad idea sglang already uses a level
// up, where unused request slots become zero-length sentinels.

// FA2 executor: the persistent LPT kernel at its native 128 threads x 2 CTAs/SM, which
// is where it gets 255 registers and zero spill. Drains tasks 0-2 only.
template <typename FA3Mainloop, typename FA3Epilogue, typename FA3Traits,
          bool LEFT_SLIDING_WINDOW, bool CAUSAL, typename FA3TileScheduler,
          typename Runner1, typename Runner2, typename Runner3>
__global__ void __launch_bounds__(FA3Traits::NUM_WARPS * cutlass::NumThreadsPerWarp, 1)
    DedicatedFA3PrimaryKernel(
#if FLASHINFER_FA3_UPSTREAM
        CUTE_GRID_CONSTANT typename UpstreamFA3Kernel<FA3Traits::HEAD_DIM_VO, int32_t>::Params const upstream_fa3,
#else
        CUTE_GRID_CONSTANT typename FA3Mainloop::Params const fa3_mainloop_params,
        CUTE_GRID_CONSTANT typename FA3Epilogue::Params const fa3_epilogue_params,
        CUTE_GRID_CONSTANT typename FA3TileScheduler::Params const fa3_scheduler_params,
#endif
        FUSED_PERS_QUALIFIER typename Runner1::Params params_1,
        FUSED_PERS_QUALIFIER typename Runner2::Params params_2,
        FUSED_PERS_QUALIFIER typename Runner3::Params params_3,
        const uint32_t sm_split, const bool backfill, const FusedQueueParams queue,
        const uint32_t entry_register_count) {
  extern __shared__ uint8_t smem[];
  asm volatile("griddepcontrol.launch_dependents;" ::: "memory");
  FusedPdlRecord<kPdlFa3Start>(queue.pdl_timeline);
#if FLASHINFER_FA3_UPSTREAM
  UpstreamFA3Kernel<FA3Traits::HEAD_DIM_VO, int32_t>{}(upstream_fa3, reinterpret_cast<char*>(smem));
#else
  fa3_prefill_body<FA3Mainloop, FA3Epilogue, FA3Traits, LEFT_SLIDING_WINDOW, CAUSAL,
                   FA3TileScheduler, false>(fa3_mainloop_params, fa3_epilogue_params,
                                           fa3_scheduler_params, reinterpret_cast<char*>(smem),
                                           entry_register_count);
#endif
  cute::tma_store_wait<0>();
  cp_async::wait_group<0>();
  __syncthreads();
#if FLASHINFER_FUSED_PAGED_TMA
  if (fa3_mainloop_params.tma_trace && threadIdx.x == 0 && blockIdx.x == 0) {
    auto* storage = reinterpret_cast<typename FA3Traits::SharedStorage*>(smem);
    printf("FA3_PAGED_TMA load_tiles=%u multicast_tiles=%u tail_tiles=%u\n",
           storage->tma_load_tiles, storage->tma_multicast_tiles, storage->tma_tail_tiles);
  }
  cute::cluster_arrive_relaxed();
  cute::cluster_wait();
#endif
  FusedPdlRecord<kPdlFa3End, true>(queue.pdl_timeline);
}

#if !FLASHINFER_FA3_UPSTREAM && !FLASHINFER_FUSED_PAGED_TMA
template <typename FA3Mainloop, typename FA3Epilogue, typename FA3Traits,
          bool LEFT_SLIDING_WINDOW, bool CAUSAL, typename FA3TileScheduler,
          typename Runner1, typename Runner2, typename Runner3>
__global__ void __launch_bounds__(FA3Traits::NUM_WARPS * cutlass::NumThreadsPerWarp, 1)
    UnsplitFA3PrimaryKernel(
        CUTE_GRID_CONSTANT typename FA3Mainloop::Params const mainloop_params,
        CUTE_GRID_CONSTANT typename FA3Epilogue::Params const epilogue_params,
        CUTE_GRID_CONSTANT typename FA3TileScheduler::Params const scheduler_params,
        FUSED_PERS_QUALIFIER typename Runner1::Params params_1,
        FUSED_PERS_QUALIFIER typename Runner2::Params params_2,
        FUSED_PERS_QUALIFIER typename Runner3::Params params_3,
        const uint32_t sm_split, const bool backfill, const FusedQueueParams queue,
        const uint32_t entry_register_count) {
  extern __shared__ uint8_t smem[];
  asm volatile("griddepcontrol.launch_dependents;" ::: "memory");
  FusedPdlRecord<kPdlFa3Start>(queue.pdl_timeline);
  fa3_prefill_body<FA3Mainloop, FA3Epilogue, FA3Traits, LEFT_SLIDING_WINDOW, CAUSAL,
                   FA3TileScheduler, false, false>(
      mainloop_params, epilogue_params, scheduler_params, reinterpret_cast<char*>(smem),
      entry_register_count);
  cute::tma_store_wait<0>();
  cp_async::wait_group<0>();
  __syncthreads();
  FusedPdlRecord<kPdlFa3End, true>(queue.pdl_timeline);
}
#endif

template <typename FA3Traits, typename Runner1, typename Runner2, typename Runner3>
__global__ void __launch_bounds__(128, 2)
    FA2ExecutorKernel(typename Runner1::Params params_1, typename Runner2::Params params_2,
                      typename Runner3::Params params_3, const FusedQueueParams queue) {
  extern __shared__ uint8_t smem[];
  // kFa3SmemBytes is 0: this kernel has no FA3 region ahead of the persistent slot, which
  // is the whole point -- it owns all 232 448 B instead of the 134 048 B left over.
  fused_drain_queue<0u, 0u, Runner1, Runner2, Runner3>(params_1, params_2, params_3, smem, queue);
  // Under a programmatic launch this executor may overlap the FA3 grid; waiting here makes its
  // completion imply the FA3 grid's, so the merge launched after it reads finished partials.
  // Returns immediately when launched without the attribute.
  asm volatile("griddepcontrol.wait;" ::: "memory");
}

#if FLASHINFER_FA3_UPSTREAM
// wgmma executor: flash-attention's own FA3 kernel, 384 threads at 1 CTA/SM, reading
// task 3 through UpstreamFA3SchedulerAdapter. Not flashinfer's simplified mainloop.
template <int HeadDim, typename IdType>
__global__ void __launch_bounds__(384, 1)
    FA3ExecutorKernel(CUTE_GRID_CONSTANT
                      typename UpstreamFA3Kernel<HeadDim, IdType>::Params const params) {
  extern __shared__ char smem_fa3[];
  UpstreamFA3Kernel<HeadDim, IdType>{}(params, smem_fa3);
}
#endif

// Symmetric variant: FA2-role CTAs also execute FA3 work, which the asymmetric
// kernel above cannot do.
//
// Measured motivation. Backfill only ever runs FA3 -> FA2, so when FA3 is the
// longer role the FA2-role CTAs finish early and idle. That is visible: raising
// chunked-prefill-size from 512 to 2048 (which multiplies FA3's work per step)
// widens the end-to-end gap from -3.6% to -17.8% and triples p99 ITL, while the
// persistent kernel's single shared queue absorbs the same imbalance. Sweeping
// the split does not fix it, because the optimum does not move with the work mix.
//
// Why the order is FA2 first and not FA3 first. A rendezvous AFTER fa3_prefill_body
// is unsafe: the body's warp specialisation lets warpgroups exit at different
// times, and __syncthreads() with exited warps is undefined -- the same reason a
// CTA holding a TMA producer can never join a grid-wide sync. Before the body,
// nothing has exited, so consumer warpgroups can park at __syncthreads() while
// warpgroup 0 drains the FA2 queue, and all 384 threads then enter FA3 together.
// setmaxnreg is also safe in this order: the FA2 mainloop runs at the default
// allocation and FA3's dealloc/alloc sequence then runs from a clean state.
//
// This requires FA3 to be planned for the WHOLE grid, not for sm_split, so that
// a CTA at blockIdx.x >= sm_split has its own FA3 slice to execute. The dispatch
// enforces fa3_num_ctas == num_sm in this mode, replacing the
// fa3_num_ctas == sm_split contract that guards the asymmetric mode.
template <typename FA3Mainloop, typename FA3Epilogue, typename FA3Traits, bool LEFT_SLIDING_WINDOW,
          bool CAUSAL, typename FA3TileScheduler, typename Runner1, typename Runner2,
          typename Runner3>
__global__ void __launch_bounds__(FA3Traits::NUM_WARPS* cutlass::NumThreadsPerWarp, 1)
    FusedFA3PersistentSymmetricKernel(
        CUTE_GRID_CONSTANT typename FA3Mainloop::Params const fa3_mainloop_params,
        CUTE_GRID_CONSTANT typename FA3Epilogue::Params const fa3_epilogue_params,
        CUTE_GRID_CONSTANT typename FA3TileScheduler::Params const fa3_scheduler_params,
        FUSED_PERS_QUALIFIER typename Runner1::Params params_1,
        FUSED_PERS_QUALIFIER typename Runner2::Params params_2,
        FUSED_PERS_QUALIFIER typename Runner3::Params params_3,
        const uint32_t sm_split, const bool backfill,
        const FusedQueueParams queue, const uint32_t entry_register_count) {
  extern __shared__ uint8_t smem[];

  if (blockIdx.x >= sm_split) {
    // FA2 on all three warpgroups, each draining the queue independently with
    // its own cursor, merge flag, mainloop storage slot and barrier ids.
    //
    // This is what recovers the FA2 role's thread count. The plan gives the
    // mainloop 2 CTAs/SM natively (num_sm *= 2) at ~128 threads each, while this
    // kernel is 1 CTA/SM by construction (384 threads, ~98 KB of FA3 storage),
    // so a WG0-only drain leaves the role with 128 threads per SM against ~256.
    // Three drains give it 384.
    //
    // It deadlocked before for two reasons, both now removed: the mainloop's
    // syncs were one shared named barrier at width 128, so warpgroup 0 at its
    // first queue slot paired with warpgroup 1 at its third, and all three
    // warpgroups' mainloop storage aliased one base.
    // Drain width is compile-time so the two forms can be bisected against each
    // other: 1 is the form whose numerics are known good, 3 is the one that gives
    // the FA2 role 384 threads per SM instead of 128.
#ifndef FLASHINFER_FUSED_WG_DRAIN
#define FLASHINFER_FUSED_WG_DRAIN 1
#endif
    // At width 1 the drain runs on warpgroup 1, not 0. Warpgroup 0 is FA3's TMA
    // producer and reaches `warpgroup_reg_dealloc<24>`
    // (hopper/prefill_sm90.cuh:155 at NUM_WARPS == 12), while warpgroups 1 and 2
    // are wgmma consumers holding ~240. The asymmetric backfill path already
    // made this choice for exactly that reason; the symmetric drain did not, and
    // it is the one structural difference between the mode that computes FA3
    // correctly and the mode that corrupts it nondeterministically. Measured:
    // the fused body compiles to 168 registers with up to 4.4 KB of spill loads,
    // so a warpgroup that drains and then enters the producer role has state the
    // dealloc does not keep.
    // Warpgroup 0, measured. Draining on warpgroup 1 -- the choice the
    // asymmetric BACKFILL makes, because it runs AFTER FA3 when consumers hold
    // ~240 registers -- breaks FA2 as well when it runs BEFORE FA3's body:
    // all three rows fail (FA3 3.57/4.13/4.41, task0 1.34/0.95/1.22, task2
    // 3.59/3.03/3.62 over three repeats), against FA2 being exact on
    // warpgroup 0. The two phases are not interchangeable.
    const uint32_t kNarrowWg = 0u;
    const uint32_t wg = FLASHINFER_FUSED_WG_DRAIN == 1 ? kNarrowWg : threadIdx.x / 128u;
    if (FLASHINFER_FUSED_WG_DRAIN == 1 && (threadIdx.x / 128u) != kNarrowWg) {
      // only the chosen warpgroup drains in the narrow form
    } else if (wg == 1u) {
      fused_drain_queue<128u, sizeof(typename FA3Traits::SharedStorage), Runner1, Runner2,
                        Runner3>(params_1, params_2, params_3, smem, queue);
    } else if (wg == 0u) {
      fused_drain_queue<0u, sizeof(typename FA3Traits::SharedStorage), Runner1, Runner2,
                        Runner3>(params_1, params_2, params_3, smem, queue);
    } else {
      fused_drain_queue<256u, sizeof(typename FA3Traits::SharedStorage), Runner1, Runner2,
                        Runner3>(params_1, params_2, params_3, smem, queue);
    }
    __syncthreads();
  }

  // Every CTA runs its own FA3 slice. FA3's storage is re-initialised by the
  // body, so the FA2 mainloop having reinterpreted the same region above is not
  // a hazard.
  fa3_prefill_body<FA3Mainloop, FA3Epilogue, FA3Traits, LEFT_SLIDING_WINDOW, CAUSAL,
                   FA3TileScheduler, /*MULTIITEMSCORING=*/false>(
      fa3_mainloop_params, fa3_epilogue_params, fa3_scheduler_params,
      reinterpret_cast<char*>(smem), entry_register_count);

  cute::tma_store_wait<0>();
  cp_async::wait_group<0>();
  __syncthreads();
  if (blockIdx.x < sm_split && backfill) {
    // unchanged FA3 -> FA2 direction, consumer warpgroup 1, no rendezvous
    if (threadIdx.x < 128u || threadIdx.x >= 256u) return;
    fused_drain_queue<128u, sizeof(typename FA3Traits::SharedStorage), Runner1, Runner2,
                      Runner3>(params_1, params_2, params_3, smem, queue);
  }
}

// ---------------------------------------------------------------------------
// Standalone launch of 0.7's state reduction.
//
// 0.7 runs this as a THIRD ROLE inside one cooperative kernel
// (persistent.cuh: PersistentKernelTemplate<Attn1, Attn2, Reduction> via
// cudaLaunchCooperativeKernel), where the cooperative grid supplies the sync that lets the
// reduction run after every partial is written. The fused kernel deliberately does NOT follow
// that: a cooperative launch caps the grid at what fits co-resident, and that is exactly the
// quantity sm_split pre-assignment manipulates, so making the fused kernel cooperative would
// couple the SM split to an occupancy constraint. K1a also already priced the separate pass --
// the in-kernel JIT rendezvous that avoided it had a 0.6%-of-GPU-time ceiling, under the
// +/-1.5-3% serving noise floor.
//
// GRID SHAPE IS NOT FREE HERE. Run() derives
//     worker_id   = blockIdx.y * num_warps + warp_idx
//     num_workers = gridDim.x * gridDim.y * gridDim.z * num_warps
// so the stride counts every block while the id only varies in Y. Launched as (N, 1, 1) every
// block computes the SAME worker_id and the rows not congruent to it are never written -- the
// same silent partial-coverage signature as fixture 2's 511/512. The blocks therefore go in
// gridDim.Y, with x = z = 1.
template <typename ReductionKTraits>
__global__ void __launch_bounds__(ReductionKTraits::NUM_THREADS, 1) FusedStateReductionKernel(
    typename ReductionKTraits::DTypeIn* V, typename ReductionKTraits::DTypeO* v_merged, float* S,
    float* s_merged, typename ReductionKTraits::IdType num_packed_qo_len,
    uint_fastdiv gqa_group_size, uint32_t num_kv_heads,
    typename ReductionKTraits::IdType* indptr, typename ReductionKTraits::IdType* o_indices) {
  extern __shared__ uint8_t smem[];
  BlockBatchReductionPersistent<ReductionKTraits>::Run(V, v_merged, S, s_merged,
                                                       num_packed_qo_len, gqa_group_size,
                                                       num_kv_heads, indptr, o_indices, smem);
}

// Reduce the split-KV partials the fused attention grid just wrote. A no-op when nothing split,
// which is the common decode-only case -- num_merge_rows is the COMPACTED split-row count from
// the plan, so zero here means zero work rather than "merge the whole batch".
template <uint32_t HEAD_DIM_VO, typename DTypeO, typename IdType>
cudaError_t FusedLaunchStateReduction(DTypeO* partial_o, float* partial_lse, DTypeO* o,
                                      float* lse, IdType* merge_indptr, IdType* merge_o_indices,
                                      int64_t num_merge_rows, uint32_t num_kv_heads,
                                      uint32_t gqa_group_size, cudaStream_t stream) {
  if (num_merge_rows <= 0 || partial_o == nullptr || merge_indptr == nullptr) return cudaSuccess;
  // Bisect: skip the merge entirely. Isolates whether the attention grid alone is clean, which
  // is the question an address pattern cannot answer. Split rows are of course unreduced under
  // this flag, so output is wrong by construction -- it measures the fault, not the kernel.
  if (const char* e = std::getenv("FLASHINFER_FUSED_NO_MERGE"); e && *e != '0') return cudaSuccess;
  constexpr uint32_t kNumThreads = 128;
  using RKT = StateReductionKernelTraits<HEAD_DIM_VO, 4, kNumThreads, DTypeO, DTypeO, IdType>;
  const size_t smem_size = RKT::SMEM_SIZE;
  auto kernel = FusedStateReductionKernel<RKT>;
  FLASHINFER_CUDA_CALL(
      cudaFuncSetAttribute(kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, int(smem_size)));
  // One warp per (row, kv head) item, blocks along Y for the reason above.
  constexpr uint32_t kWarps = kNumThreads / 32;
  const uint64_t items = uint64_t(num_merge_rows) * num_kv_heads;
  uint32_t blocks_y = uint32_t((items + kWarps - 1) / kWarps);
  if (blocks_y == 0) blocks_y = 1;
  dim3 nblks(1, blocks_y, 1);
  dim3 nthrs(kNumThreads);
  kernel<<<nblks, nthrs, smem_size, stream>>>(partial_o, o, partial_lse, lse,
                                              IdType(num_merge_rows),
                                              uint_fastdiv(gqa_group_size), num_kv_heads,
                                              merge_indptr, merge_o_indices);
  return cudaGetLastError();
}

template <typename KernelTraits, bool LEFT_SLIDING_WINDOW, bool CAUSAL,
          bool SAME_SCHEDULE_FOR_ALL_HEADS, typename FA3Params, typename Runner1,
          typename Runner2, typename Runner3, bool MULTIITEMSCORING = false,
          // Drive the wgmma role from task 3 of the unified plan instead of from
          // PrefillSM90Plan. Defaulted off: every existing instantiation keeps
          // the old scheduler and the old work arrays.
          bool kUnifiedWgmma = false>
// fa3_num_ctas is the CTA count the FA3 plan was built for, and it MUST equal
// sm_split. FA3's scheduler reads work_indptr[blockIdx.x], which is indexed over
// that planned count and knows nothing about where this kernel puts the role
// boundary. When the two disagree, every FA3 work item assigned to a CTA at or
// past sm_split is simply never executed -- at sm_split=16 against a plan built
// for 132 CTAs that is ~88% of the prefill work, silently, and the kernel looks
// fast for it. The count is not recoverable from the scheduler params (they
// carry a bare pointer), so the caller passes it and this refuses to launch on a
// mismatch.
cudaError_t FusedFA3PersistentDispatched(FA3Params& params,
                                         typename Runner1::Params const& params_1,
                                         typename Runner2::Params const& params_2,
                                         typename Runner3::Params const& params_3,
                                         uint32_t sm_split, uint32_t fa3_num_ctas,
                                         FusedQueueParams queue, cudaStream_t stream,
                                         bool launch_fa2 = true, int64_t physical_kv_tokens = 0,
                                         bool fa3_unsplit_proven = false) {
  // In symmetric mode every CTA has an FA3 slice, so the plan must cover the whole
  // grid; in asymmetric mode only CTAs below sm_split do, and a mismatch there
  // silently drops the rest of FA3's work. Both are checked, against different
  // expected values.
  int sym_expected = 0;
  {
    const char* e = std::getenv("FLASHINFER_FUSED_SYMMETRIC");
    if (e != nullptr && std::atoi(e) != 0) {
      int dev = 0, nsm = 0;
      cudaGetDevice(&dev);
      cudaDeviceGetAttribute(&nsm, cudaDevAttrMultiProcessorCount, dev);
      sym_expected = nsm;
    }
  }
  if (sym_expected != 0 && fa3_num_ctas != uint32_t(sym_expected)) {
    FLASHINFER_ERROR("fused FA3+FA2 symmetric launch: the FA3 plan was built for " +
                     std::to_string(fa3_num_ctas) + " CTAs but symmetric mode needs " +
                     std::to_string(sym_expected) +
                     " (one slice per CTA); otherwise the CTAs at or past sm_split have no "
                     "FA3 work and the mode degenerates to the asymmetric one.");
    return cudaErrorInvalidValue;
  }
  if (sym_expected == 0 && fa3_num_ctas != sm_split) {
    FLASHINFER_ERROR("fused FA3+FA2 launch: the FA3 plan was built for " +
                     std::to_string(fa3_num_ctas) + " CTAs but sm_split is " +
                     std::to_string(sm_split) +
                     ". Plan FA3 with exactly sm_split CTAs (FLASHINFER_FA3_MAX_CTAS), or its "
                     "work for CTAs >= sm_split would be dropped without a trace.");
  }
  using IdType = typename KernelTraits::IdType;
  using CollectiveMainloop = SparseCollectiveMainloop<typename FA3Params::AdditionalParams,
                                                      KernelTraits, CAUSAL, MULTIITEMSCORING>;
  using CollectiveEpilogue = CollectiveEpilogue<KernelTraits>;
  using Scheduler = std::conditional_t<
      kUnifiedWgmma, UnifiedWgmmaTileScheduler<IdType>,
      std::conditional_t<SAME_SCHEDULE_FOR_ALL_HEADS, BatchPrefillTileScheduler<IdType>,
                         BatchPrefillPersistentTileScheduler<IdType>>>;

  typename CollectiveMainloop::Params mainloop_params = CollectiveMainloop::to_underlying_arguments(
      // DESIGNATED initialisers, not positional. 0.7 inserted k_page_stride / v_page_stride /
      // page_size into this struct AFTER window_left, and because every field it shifted onto
      // happened to be assignable the old positional form did not fail where the change was --
      // it failed three fields later with "no suitable conversion from AdditionalParams to
      // int64_t". Naming the fields makes the next insertion a missing-member error instead.
      {.Q_ptr = params.q_ptr,
       .layout_Q = get_gmem_layout(params.nnz_qo, params.num_qo_heads, KernelTraits::HEAD_DIM_QK,
                                   params.q_stride_n, params.q_stride_h),
       .K_ptr = params.k_ptr,
       .layout_K = get_gmem_layout(physical_kv_tokens, params.num_kv_heads, KernelTraits::HEAD_DIM_QK,
                                   params.k_stride_n, params.k_stride_h),
       .V_ptr = params.v_ptr,
       .layout_V = get_gmem_layout(physical_kv_tokens, params.num_kv_heads, KernelTraits::HEAD_DIM_VO,
                                   params.v_stride_n, params.v_stride_h),
       .kv_indices = params.kv_indices,
       .window_left = params.window_left,
       .k_page_stride = params.k_page_stride,
       .v_page_stride = params.v_page_stride,
       .page_size = uint32_t(params.page_size),
       .additional_params = params.additional_params,
       // packed-GQA path: the raw Q pointer and the group size, which the Q
       // tensormap cannot carry because packed rows are (token, head) pairs
       .packed_Q_ptr = params.q_ptr,
       .group_size = int(params.num_qo_heads / params.num_kv_heads)});
  typename CollectiveEpilogue::Params epilogue_params =
      CollectiveEpilogue::to_underlying_arguments({
          // Designated, for the same reason as the mainloop above.
          .O_ptr = params.o_ptr,
          .layout_O = get_gmem_layout(params.nnz_qo, params.num_qo_heads,
                                      KernelTraits::HEAD_DIM_VO, params.o_stride_n,
                                      params.o_stride_h),
          .lse_ptr = params.lse_ptr,
          .layout_LSE = get_lse_gmem_layout(params.nnz_qo, params.num_qo_heads),
          // Unified reduction. The wgmma role writes the SAME partial buffers and
          // merges through the SAME group tables as the FA2 roles, so they come
          // straight off the persistent params the one plan already filled --
          // taking them from Runner1 is safe because every task shares them.
          // Without this they stay nullptr (the fields are defaulted so existing
          // positional init kept compiling), store_partial skips its handshake,
          // and every split chunk writes a partial that nothing ever merges:
          // fixture 2 showed 511/512 rows unwritten.
          // The persistent params hold __nv_bfloat16* while the FA3 epilogue's DTypeO
          // is cutlass::bfloat16_t*. Layout-identical wrappers over the same bits, so
          // bridge them here, mirroring what the merge call does on the other side.
          .partial_o = reinterpret_cast<typename CollectiveEpilogue::DTypeO*>(params_1.partial_o),
          .partial_lse = params_1.partial_lse,
          .merge_indptr = params_1.merge_indptr,
          // group_row_begin / group_nrows / group_kv_head / group_nchunks / group_counter are
          // NOT passed: K1a dropped the in-kernel JIT-reduction rendezvous after measuring its
          // ceiling at 0.6% of GPU time (flashinfer's own scheduled merge is 1682 launches /
          // 10.66 ms in the B1b trace). Partials go to merge_indptr / merge_o_indices and 0.7's
          // PersistentVariableLengthMergeStatesKernel reduces them. The epilogue signature in
          // hopper/prefill_sm90.cuh must match this shorter list.
          .merge_o_indices = params_1.merge_o_indices,
          .num_kv_heads = int(params.num_kv_heads),
          .gqa_group_size = int(params.num_qo_heads / params.num_kv_heads),
      });
  typename Scheduler::Arguments scheduler_args = [&] {
    if constexpr (kUnifiedWgmma) {
      // Task 3's arrays, carried on the params struct the ext fills from a
      // 4-task plan. Split-KV arrives through kv_start/kv_end here rather than
      // needing anything from the mainloop.
      return make_unified_wgmma_args(params.wgmma_plan, uint32_t(params.page_size));
    } else {
      return typename Scheduler::Arguments{
          params.work_indptr,    params.head_indices, params.qo_tile_indices,
          params.qo_indptr,      params.kv_indptr,    params.qo_lens,
          params.kv_lens,        params.batch_indices,
          cutlass::FastDivmod(params.num_qo_heads / params.num_kv_heads),
          params.num_qo_heads};
    }
  }();
  typename Scheduler::Params scheduler_params = Scheduler::to_underlying_arguments(scheduler_args);

  // Read every call, not once. As a function-local static this latched on the
  // first launch in the process, so flipping the environment variable between
  // iterations of an A/B silently measured one variant twice.
  // Read every call, not once: as a function-local static this latched on the
  // first launch in the process, so an A/B flipping it between iterations
  // measured one variant twice.
  // Defaults OFF, and that is a correctness decision, not a performance one.
  // Backfill-on has a residual fault on the one batch shape whose FA2-class rows
  // split their KV: H200 runs 4 clean matrices in 8, H20 masked it. Backfill-off
  // is clean on both devices across every configuration. It is kept reachable
  // (FLASHINFER_FUSED_BACKFILL=1) rather than removed, because it is the property
  // that distinguishes this kernel from a two-kernel co-launch and because the
  // A/B is a real measurement: worth 1.2% of the best split on H200 and 1.9-6.9%
  // on H20. Shipping it on by default would mean shipping known-wrong output.
  // FLASHINFER_FUSED_COLAUNCH=1: the FA2 roles leave this kernel. The FA3 grid runs on exactly
  // sm_split CTAs and FA2ExecutorKernel -- the same runners and queue at their native 128x2
  // geometry -- is launched as its programmatic dependent on the same stream. Inside this kernel
  // the FA2 body is compiled at the FA3 role's 168 registers with a 4200-byte stack, and one
  // 8-token decode row at kv 4096 measured 0.35 ms against 0.016 ms for BatchAttention. The two
  // grids cannot share an SM (FA3 needs 164 KB of shared memory), so FA2 CTAs fill the SMs FA3
  // does not hold, and later ones land on SMs that FA3 CTAs vacate: hardware backfill.
  const bool colaunch = [] {
    const char* e = std::getenv("FLASHINFER_FUSED_COLAUNCH");
    return e != nullptr && std::atoi(e) != 0;
  }();
  const bool backfill = !colaunch && [] {
    const char* e = std::getenv("FLASHINFER_FUSED_BACKFILL");
    return e != nullptr && std::atoi(e) != 0;
  }();
  // FLASHINFER_FUSED_SYMMETRIC=1 selects the variant where FA2-role CTAs also run
  // FA3 work. Read every call, not latched in a static, so an A/B that flips it
  // between iterations does not measure one variant twice.
  const bool symmetric = [] {
    const char* e = std::getenv("FLASHINFER_FUSED_SYMMETRIC");
    return e != nullptr && std::atoi(e) != 0;
  }();
  auto kernel =
      symmetric
          ? (void*)FusedFA3PersistentSymmetricKernel<CollectiveMainloop, CollectiveEpilogue,
                                                     KernelTraits, LEFT_SLIDING_WINDOW, CAUSAL,
                                                     Scheduler, Runner1, Runner2, Runner3>
          : (void*)FusedFA3PersistentKernel<CollectiveMainloop, CollectiveEpilogue, KernelTraits,
                                            LEFT_SLIDING_WINDOW, CAUSAL, Scheduler, Runner1,
                                            Runner2, Runner3>;
  if (!launch_fa2) {
    const char* dedicated = std::getenv("FUSED_FA3_DEDICATED_PRIMARY");
    if (dedicated != nullptr && dedicated[0] == '1') {
      if (!colaunch || symmetric) {
        FLASHINFER_ERROR("dedicated FA3 primary requires asymmetric co-launch mode");
        return cudaErrorInvalidValue;
      }
      kernel = (void*)DedicatedFA3PrimaryKernel<CollectiveMainloop, CollectiveEpilogue,
                                                KernelTraits, LEFT_SLIDING_WINDOW, CAUSAL,
                                                Scheduler, Runner1, Runner2, Runner3>;
    }
  }
  const bool specialize_unsplit = [] {
    const char* setting = std::getenv("FUSED_FA3_NOSPLIT_SPECIALIZE");
    return setting != nullptr && setting[0] == '1';
  }();
  if (specialize_unsplit && fa3_unsplit_proven) {
    if (launch_fa2 || !colaunch || symmetric) {
      FLASHINFER_ERROR("unsplit FA3 specialization requires the native-FA2 PDL path");
      return cudaErrorInvalidValue;
    }
#if FLASHINFER_FA3_UPSTREAM || FLASHINFER_FUSED_PAGED_TMA
    FLASHINFER_ERROR("unsplit FA3 specialization currently supports the gather primary only");
    return cudaErrorInvalidValue;
#else
    kernel = (void*)UnsplitFA3PrimaryKernel<CollectiveMainloop, CollectiveEpilogue,
                                          KernelTraits, LEFT_SLIDING_WINDOW, CAUSAL,
                                          Scheduler, Runner1, Runner2, Runner3>;
    static bool unsplit_logged = false;
    if (!unsplit_logged) {
      std::fprintf(stderr, "FA3_PRIMARY_NOSPLIT active\n");
      unsplit_logged = true;
    }
#endif
  }
  cudaFuncAttributes kernel_attributes{};
  FLASHINFER_CUDA_CALL(cudaFuncGetAttributes(&kernel_attributes, kernel));
  uint32_t entry_register_count = uint32_t(kernel_attributes.numRegs);
  // One CTA serves whichever role its SM was assigned, so the dynamic shared
  // memory has to cover the larger of the two mainloops.
  // The FA2 roles' storage is reserved only if an FA2 role can actually run. Taking the max
  // unconditionally meant every CTA carried the largest FA2 tile class (tile-16 at 69632 B) even
  // when sm_split assigned every SM to FA3 -- which is what made FA3_STAGES=2 fail to launch at
  // SM_SPLIT=all, since FA3's two-stage storage plus that reservation exceeds the 232 KB limit.
  //
  // Measured consequence of the old behaviour: FA3 was pinned to one pipeline stage on this GPU
  // regardless of the split. Keeping the max when ANY SM is assigned to FA2 is still required --
  // one CTA then genuinely serves whichever role its SM was given.
  // Queried here rather than reusing multiprocessor_count, which is declared ~50 lines below.
  int nsm_for_smem = 0;
  {
    int dev = 0;
    cudaGetDevice(&dev);
    cudaDeviceGetAttribute(&nsm_for_smem, cudaDevAttrMultiProcessorCount, dev);
  }
  const bool fa2_can_run =
      !colaunch && (backfill || (nsm_for_smem == 0) || (sm_split < uint32_t(nsm_for_smem)));
  int smem_size = int(sizeof(typename KernelTraits::SharedStorage));
  // FUSED_SMEM_REPORT=1 prints the actual byte requirements and the device max. Guessing which
  // tile to shrink to buy a second K/V stage wasted two attempts (CTA_KV=64 compiles but NaNs,
  // CTA_Q=64 fails named_barrier's static asserts) when the quantity to shave was never measured.
  if (const char* e = std::getenv("FUSED_SMEM_REPORT"); e && *e != '0') {
    int dev2 = 0, maxsh = 0;
    cudaGetDevice(&dev2);
    cudaDeviceGetAttribute(&maxsh, cudaDevAttrMaxSharedMemoryPerBlockOptin, dev2);
    std::fprintf(stderr,
                 "[smem] FA3=%zu  FA2_r1=%zu r2=%zu r3=%zu  fa2_can_run=%d  "
                 "device_max_optin=%d  sm_split=%u nsm=%d\n",
                 sizeof(typename KernelTraits::SharedStorage),
                 sizeof(typename Runner1::KTraits::SharedStorage),
                 sizeof(typename Runner2::KTraits::SharedStorage),
                 sizeof(typename Runner3::KTraits::SharedStorage), int(fa2_can_run), maxsh,
                 sm_split, nsm_for_smem);
  }
  if (fa2_can_run) {
    smem_size = std::max(smem_size, int(sizeof(typename Runner1::KTraits::SharedStorage)));
    smem_size = std::max(smem_size, int(sizeof(typename Runner2::KTraits::SharedStorage)));
    smem_size = std::max(smem_size, int(sizeof(typename Runner3::KTraits::SharedStorage)));
  }
  // Room for the dynamic scheduler's cluster slot past the persistent storage -- needed ONLY when
  // an FA2-role block can exist to drain through that storage. At sm_split == nsm every block
  // takes the FA3 role, nothing drains through FA2's SharedStorage, and the slot is pure waste.
  //
  // MEASURED, and this is what blocked the second K/V pipeline stage: at STAGES=2 the final
  // request was 234544 B against a 232448 B device max -- over by 2096 B -- and the breakdown was
  // fa3_base 164864 + slot 69632 + 48. FA3's own storage (163920) fits with 68 KB spare. So
  // "STAGES=2 does not fit" was wrong twice (first blamed on the fusion, then on a traits limit);
  // the cause is this slot, added unconditionally, which is why SM_SPLIT=all gave the same number.
  // This reservation is NOT just a backfill queue -- it is where the FA2 runners' SharedStorage
  // LIVES, placed past FA3's region by fused_pers_smem_base. Gating it off (FUSED_WG_DRAIN_SLOT=0)
  // starved every FA2-role block of its workspace: `mixed` went to 25 FAILURES / 25. Reverted.
  //
  // WHY THIS MATTERS, because it is what blocks NUM_STAGES=2 in the co-resident case: the
  // allocation must cover FA3's layout (any block may take the FA3 role) PLUS the FA2 region at an
  // offset past it, i.e. FA3_size + FA2_size = 164864 + 69632 + 48 = 234544 against a 232448 B
  // device max. STAGES=2 and co-residency are therefore incompatible with the CURRENT layout.
  //
  // And STAGES=2 is not optional: stock 0.7 unions smem_v with smem_o and relies on DOUBLE
  // BUFFERING to make that union safe. Our STAGES=1 removed that invariant, which is the measured
  // race (3/35 at STAGES=1, 0/35 at STAGES=2).
  //
  // THE RIGHT FIX, identified but not implemented: FA2-role blocks should address their storage
  // from OFFSET 0, not past FA3's. A block is either FA3-role or FA2-role, never both, so the two
  // layouts can ALIAS across roles -- making smem_size = max(FA3, FA2) = 163920, which fits with
  // room to spare. The past-FA3 placement is only required if one block does both, which is the
  // cross-role drain (B2c, still unimplemented).
  if (fa2_can_run) {
    const size_t pers =
        std::max({sizeof(typename Runner1::KTraits::SharedStorage),
                  sizeof(typename Runner2::KTraits::SharedStorage),
                  sizeof(typename Runner3::KTraits::SharedStorage)});
    const size_t base = fused_pers_smem_base<sizeof(typename KernelTraits::SharedStorage)>();
    // THREE mainloop slots, one per warpgroup, then three 16-byte slots for the
    // per-warpgroup cursor and merge flag. One slot's worth was enough only
    // while a single warpgroup drained the queue; with all three draining, the
    // request has to cover every slot or warpgroup 2 writes past the allocation.
    const size_t slot = (pers + 15u) & ~size_t(15u);
    smem_size = std::max(smem_size, int(base + size_t(FLASHINFER_FUSED_WG_DRAIN) * slot + 48u));
  }
  if (const char* e = std::getenv("FUSED_SMEM_REPORT"); e && *e != '0') {
    // The FINAL value handed to the launch, which is what matters -- the earlier report prints
    // sizeof(SharedStorage) BEFORE the FA2 max() and before the cluster-slot block below, and
    // that block can add FLASHINFER_FUSED_WG_DRAIN * slot past the FA3 base. Measuring the wrong
    // one is why "STAGES=2 does not fit" was believed twice without ever being true.
    const size_t pers2 =
        std::max({sizeof(typename Runner1::KTraits::SharedStorage),
                  sizeof(typename Runner2::KTraits::SharedStorage),
                  sizeof(typename Runner3::KTraits::SharedStorage)});
    std::fprintf(stderr,
                 "[smem] FINAL smem_size=%d  (fa3_base=%zu wg_drain=%d slot=%zu)\n", smem_size,
                 fused_pers_smem_base<sizeof(typename KernelTraits::SharedStorage)>(),
                 int(FLASHINFER_FUSED_WG_DRAIN), (pers2 + 15u) & ~size_t(15u));
  }
  FLASHINFER_CUDA_CALL(
      cudaFuncSetAttribute(kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, smem_size));

  if (std::getenv("FLASHINFER_FUSED_DEBUG")) {
    int dev = 0, maxsmem = 0;
    cudaGetDevice(&dev);
    cudaDeviceGetAttribute(&maxsmem, cudaDevAttrMaxSharedMemoryPerBlockOptin, dev);
    cudaPointerAttributes pa{};
    cudaError_t pe = cudaPointerGetAttributes(&pa, queue.cluster_cursor);
    std::fprintf(stderr,
                 "[fused] smem_size=%d device_max_optin=%d | FA3=%zu R128=%zu R64=%zu R16=%zu\n"
                 "[fused] cursor=%p ptr_attr_rc=%d type=%d dev=%d | sm_split=%u fa3_ctas=%u "
                 "n_pers_clusters=%u\n",
                 smem_size, maxsmem, sizeof(typename KernelTraits::SharedStorage),
                 sizeof(typename Runner1::KTraits::SharedStorage),
                 sizeof(typename Runner2::KTraits::SharedStorage),
                 sizeof(typename Runner3::KTraits::SharedStorage),
                 (void*)queue.cluster_cursor, int(pe), int(pa.type), pa.device, sm_split,
                 fa3_num_ctas, queue.num_pers_clusters);
  }

  // Same per-launch reset as the standalone persistent path: these counters are
  // consumed by the kernel, so a second launch of the same plan must not see
  // them saturated.
  FLASHINFER_CUDA_CALL(cudaMemsetAsync(queue.cluster_cursor, 0, sizeof(int), stream));

  int device, multiprocessor_count;
  cudaGetDevice(&device);
  FLASHINFER_CUDA_CALL(
      cudaDeviceGetAttribute(&multiprocessor_count, cudaDevAttrMultiProcessorCount, device));
  dim3 grid_dims(colaunch ? sm_split : uint32_t(multiprocessor_count));
  static constexpr int ctaSize = KernelTraits::NUM_WARPS * 32;
  dim3 block_dims(ctaSize);
  // The skip-FA3 diagnostic rides in the top bit of sm_split so the kernel
  // signature does not change. Applied AFTER the contract checks above, which must
  // still see the real split.
  uint32_t sm_split_arg = sm_split;
  if (const char* e = std::getenv("FLASHINFER_FUSED_SKIP_FA3")) {
    if (std::atoi(e) != 0) sm_split_arg |= 0x40000000u;
  }
#if FLASHINFER_FA3_UPSTREAM
  // Assemble upstream's Params from the plan the ext already fills, then pass it
  // as the FIRST kernel argument -- the three flashinfer params drop out under
  // this macro, which keeps upstream's TMA descriptors at the front of the
  // parameter buffer where their 64B alignment holds.
  UpstreamFA3Plan up{};
  // Every field comes from FA3Params, which is the role's own params -- reading
  // the FA2 role's params_1 for the KV pointers and strides was wrong on two
  // counts: PersistentParams has no such fields (k/v and k_stride_n, not
  // k_data/kv_stride_n), and the FA2 role's strides describe the same cache only
  // by coincidence of this harness. The wgmma role must be self-contained.
  up.q_ptr = params.q_ptr;
  up.k_ptr = params.k_ptr;
  up.v_ptr = params.v_ptr;
  up.page_table = params.wgmma_plan.dense_page_table;
  // Per-REQUEST, because upstream indexes both by bidb. The plan's q_indptr and
  // kv_len are per work item and must not be used here.
  up.cu_seqlens_q = params.wgmma_plan.q_indptr_per_req;
  up.seqused_k = params.wgmma_plan.kv_lens_per_req;
  up.total_q = params.wgmma_plan.total_q;
  up.num_pages = params.wgmma_plan.num_pages;
  up.page_size = params.page_size;
  up.num_qo_heads = params.num_qo_heads;
  up.num_kv_heads = params.num_kv_heads;
  up.head_dim = KernelTraits::HEAD_DIM_VO;
  up.q_stride_tok = params.q_stride_n;
  up.q_stride_head = params.q_stride_h;
  up.kv_stride_page = params.k_stride_n * int64_t(params.page_size);
  up.kv_stride_tok = params.k_stride_n;
  up.kv_stride_head = params.k_stride_h;
  up.o_stride_tok = params.o_stride_n;
  up.o_stride_head = params.o_stride_h;
  up.num_requests_for_combine = params.wgmma_plan.num_requests;
  up.max_seqlen_q = params.wgmma_plan.max_seqlen_q;
  up.num_splits_dynamic = params.wgmma_plan.num_splits_dynamic;
  up.fa3_batch_list = params.wgmma_plan.fa3_batch_list;
  up.num_fa3_requests = params.wgmma_plan.num_fa3_requests;
  up.softmax_scale = params.additional_params.sm_scale;
  up.num_splits = params.wgmma_plan.num_splits > 0 ? params.wgmma_plan.num_splits : 1;

  // Ragged -> dense page table. Device side, into the preallocated buffer, so the
  // path stays CUDA-graph safe.
  // Per-request split counts, needed before the combine pass and cheap enough to
  // refill each launch (one int per request).
  if (up.num_splits > 1 && params.wgmma_plan.num_splits_dynamic != nullptr) {
    FLASHINFER_CUDA_CALL(LaunchFillNumSplitsDynamic<int32_t>(
        params.wgmma_plan.kv_lens_per_req, params.wgmma_plan.len_kv_chunk,
        params.wgmma_plan.num_splits_dynamic, params.wgmma_plan.num_requests, stream));
  }
  FLASHINFER_CUDA_CALL(LaunchScatterRaggedPageTable<int32_t>(
      params.wgmma_plan.kv_indptr_per_req, params.wgmma_plan.page_indices,
      params.wgmma_plan.dense_page_table, params.wgmma_plan.num_requests,
      params.wgmma_plan.max_pages_per_seq, stream));

  auto upstream_params = MakeUpstreamFA3Params<KernelTraits::HEAD_DIM_VO, int32_t>(
      MakeUpstreamMainloopArgs<KernelTraits::HEAD_DIM_VO>(
          up, params.wgmma_plan.dense_page_table, params.wgmma_plan.max_pages_per_seq,
          params.wgmma_plan.num_requests),
      MakeUpstreamEpilogueArgs<KernelTraits::HEAD_DIM_VO>(
          up, params.o_ptr,
          params.wgmma_plan.upstream_partial_o, params.lse_ptr,
          params.wgmma_plan.upstream_partial_lse),
      make_unified_wgmma_upstream_sched(params.wgmma_plan), multiprocessor_count);
  void* args[] = {&upstream_params, (void*)&params_1, (void*)&params_2, (void*)&params_3,
                  &sm_split_arg, (void*)&backfill,
                  (void*)&queue, &entry_register_count};
#else
  void* args[] = {&mainloop_params, &epilogue_params, &scheduler_params,
                  (void*)&params_1,  (void*)&params_2,  (void*)&params_3,
                  &sm_split_arg,     (void*)&backfill,
                  (void*)&queue, &entry_register_count};
#endif
  // FLASHINFER_FUSED_CLUSTER=N launches with a real thread-block cluster, which
  // is the prerequisite for sharing a gathered KV tile across cluster peers via
  // distributed shared memory. flashinfer's attention has never launched with a
  // cluster dimension anywhere (cudaLaunchKernelEx appears only in sampling.cuh,
  // norm.cuh and vendored trtllm code, and persistent.cuh's own "cluster" is a
  // logical work index with cluster_size pinned to 1), so this is added as an
  // opt-in and verified to leave output unchanged before anything depends on it.
  //
  // Measured motivation: tests/dsmem_kv_share.cu shows DSMEM sharing of a paged
  // gather beating redundant gathering 1.587x on the access pattern this kernel
  // has, where every q-tile of a prefill row re-gathers the same KV.
  const int cluster = [] {
    const char* e = std::getenv("FLASHINFER_FUSED_CLUSTER");
    const int v = e ? std::atoi(e) : 1;
    return v < 1 ? 1 : v;
  }();
  if (specialize_unsplit && fa3_unsplit_proven && cluster != 1) {
    FLASHINFER_ERROR("unsplit FA3 specialization requires an unclustered primary");
    return cudaErrorInvalidValue;
  }
#if FLASHINFER_FUSED_PAGED_TMA
  const char* dedicated_primary = std::getenv("FUSED_FA3_DEDICATED_PRIMARY");
  if (cluster != 2 || !colaunch || symmetric || launch_fa2 ||
      dedicated_primary == nullptr || dedicated_primary[0] != '1') {
    FLASHINFER_ERROR("paged TMA requires a two-CTA dedicated native-PDL primary");
    return cudaErrorInvalidValue;
  }
#endif
  if (cluster > 1) {
    // A cluster launch requires gridDim.x to be a multiple of the cluster
    // dimension. Rounding down would change the CTA count that both roles'
    // plans were built for -- FA3's contract checks it exactly -- so refuse
    // rather than silently reshape the grid.
    if (multiprocessor_count % cluster != 0) {
      FLASHINFER_ERROR("fused FA3+FA2 cluster launch: FLASHINFER_FUSED_CLUSTER=" +
                       std::to_string(cluster) + " does not divide the SM count " +
                       std::to_string(multiprocessor_count) +
                       "; rounding the grid would break the planned CTA count.");
      return cudaErrorInvalidValue;
    }
    cudaLaunchConfig_t cfg{};
    cfg.gridDim = grid_dims;
    cfg.blockDim = block_dims;
    cfg.dynamicSmemBytes = smem_size;
    cfg.stream = stream;
    cudaLaunchAttribute attr[1];
    attr[0].id = cudaLaunchAttributeClusterDimension;
    attr[0].val.clusterDim.x = cluster;
    attr[0].val.clusterDim.y = 1;
    attr[0].val.clusterDim.z = 1;
    cfg.attrs = attr;
    cfg.numAttrs = 1;
    FLASHINFER_CUDA_CALL(cudaLaunchKernelExC(&cfg, kernel, args));
  } else {
    FLASHINFER_CUDA_CALL(
        cudaLaunchKernel(kernel, grid_dims, block_dims, args, smem_size, stream));
  }
  if (colaunch && launch_fa2) {
    if (symmetric || cluster > 1) {
      FLASHINFER_ERROR("FLASHINFER_FUSED_COLAUNCH runs the FA3 grid alone on sm_split CTAs; it "
                       "cannot be combined with FLASHINFER_FUSED_SYMMETRIC or a cluster launch");
      return cudaErrorInvalidValue;
    }
    static_assert(Runner1::KTraits::NUM_THREADS == 128u,
                  "FA2ExecutorKernel's launch bounds assume the 128-thread runners");
    auto fa2_kernel = FA2ExecutorKernel<KernelTraits, Runner1, Runner2, Runner3>;
    // One mainloop slot at offset 0 plus the drain's 16-byte cursor tail (kCursorOff).
    const size_t slot = kPersSlotBytes<Runner1, Runner2, Runner3>();
    const int fa2_smem = int(size_t(FLASHINFER_FUSED_WG_DRAIN) * slot + 48u);
    FLASHINFER_CUDA_CALL(cudaFuncSetAttribute(
        fa2_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, fa2_smem));
    // Two CTAs per SM over the whole device by default: the CTAs that find the queue empty exit
    // at once, so oversubscription costs only their launch. FUSED_FA2_EXEC_CTAS overrides it.
    uint32_t fa2_ctas = 2u * uint32_t(multiprocessor_count);
    if (const char* e = std::getenv("FUSED_FA2_EXEC_CTAS")) {
      const int v = std::atoi(e);
      if (v > 0) fa2_ctas = uint32_t(v);
    }
    cudaLaunchConfig_t fa2_cfg{};
    fa2_cfg.gridDim = dim3(fa2_ctas);
    fa2_cfg.blockDim = dim3(Runner1::KTraits::NUM_THREADS);
    fa2_cfg.dynamicSmemBytes = fa2_smem;
    fa2_cfg.stream = stream;
    cudaLaunchAttribute fa2_attr[1];
    fa2_attr[0].id = cudaLaunchAttributeProgrammaticStreamSerialization;
    fa2_attr[0].val.programmaticStreamSerializationAllowed = 1;
    fa2_cfg.attrs = fa2_attr;
    fa2_cfg.numAttrs = 1;
    FLASHINFER_CUDA_CALL(
        cudaLaunchKernelEx(&fa2_cfg, fa2_kernel, params_1, params_2, params_3, queue));
  }
#if FLASHINFER_FA3_UPSTREAM
  // Split-KV reduction for the wgmma role. Required, not optional: under
  // Split && Varlen upstream's epilogue takes the is_split branch whenever the
  // item's num_splits exceeds 1 (epilogue_fwd.hpp:232) and writes a partial
  // instead of final O, so without this pass those rows stay unwritten -- measured
  // on fixture 2 as 511/512 unwritten with max_splits_fa3=2, the one correct row
  // being the FA2 decode row.
  //
  // At num_splits == 1 the epilogue writes final O directly, which is why this is
  // guarded rather than unconditional; that is also what upstream's own flash_api
  // does.
  //
  // It is a SECOND LAUNCH, which is upstream's structure too
  // (run_mha_fwd_combine). Replacing it with the in-kernel JIT reduction is the
  // improvement over that baseline, not a precondition for matching it.
  // wgmma_plan exists only on the unified params type, so this must be a discarded
  // statement for kUnifiedWgmma=false -- a plain `if` made the non-unified instantiation
  // ill-formed, which broke any build without -DFLASHINFER_FUSED_UNIFIED_WGMMA=1 (the sglang
  // serving path's SPLIT arm among them). The non-unified path has no upstream partials.
  if constexpr (kUnifiedWgmma) {
    if (up.num_splits > 1) {
      FLASHINFER_CUDA_CALL(LaunchUpstreamCombine<KernelTraits::HEAD_DIM_VO>(
          up, params.o_ptr, params.lse_ptr, params.wgmma_plan.upstream_partial_o,
          params.wgmma_plan.upstream_partial_lse, stream));
    }
  }
#endif
  return cudaSuccess;
}

}  // namespace flashinfer

#endif  // FLASHINFER_ATTENTION_PERSISTENT_FA3_FUSED_CUH_

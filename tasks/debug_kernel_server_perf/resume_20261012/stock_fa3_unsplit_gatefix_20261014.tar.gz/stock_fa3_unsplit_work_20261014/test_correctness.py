import unittest

from correctness import validate_execution


class TestExecutionAudit(unittest.TestCase):
    def result(self):
        return {**{f"request{index}": [1] for index in range(12)},
                "_fallbacks": 0, "_tracebacks": 0, "_mixed_spec_lines": ["MIXEDSPEC_STEPS 1"],
                "_fused_kernel_calls": 1, "_fused_split_calls": 0}

    def test_fused_unsplit_uses_fused_counter(self):
        validate_execution("MTPMIXFUSED_UNSPLIT_GENERIC_VERIFY", self.result())
        result = self.result()
        result["_fused_kernel_calls"] = 0
        with self.assertRaisesRegex(RuntimeError, "fused kernel"):
            validate_execution("MTPMIXFUSED_UNSPLIT_GENERIC_VERIFY", result)

    def test_plain_split_requires_split_counter(self):
        result = self.result()
        with self.assertRaisesRegex(RuntimeError, "split calls"):
            validate_execution("MTPMIX_SPLIT_UNSPLIT_CONTROL", result)
        result["_fused_split_calls"] = 1
        validate_execution("MTPMIX_SPLIT_UNSPLIT_CONTROL", result)

    def test_missing_mixed_and_requests_rejected(self):
        result = self.result()
        result["_mixed_spec_lines"] = []
        with self.assertRaisesRegex(RuntimeError, "mixed steps"):
            validate_execution("MTPMIXFUSED_UNSPLIT_GENERIC_VERIFY", result)
        result = self.result()
        result.pop("request0")
        with self.assertRaisesRegex(RuntimeError, "requests"):
            validate_execution("MTPMIXFUSED_UNSPLIT_GENERIC_VERIFY", result)

    def test_error_rejected(self):
        result = self.result()
        result["_tracebacks"] = 1
        with self.assertRaisesRegex(RuntimeError, "tracebacks"):
            validate_execution("MTPMIXFUSED_UNSPLIT_GENERIC_VERIFY", result)


if __name__ == "__main__":
    unittest.main(verbosity=2)

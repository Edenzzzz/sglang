set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi HF_HOME=/dev/shm/w/hf
export MODEL=/dev/shm/w/qwen7b TRACE_PATH=/dev/shm/w/workloads/tracelab/syfi_coding_trace.jsonl.gz CHAT_DATASET=/dev/shm/w/datasets/ShareGPT.original.json
export FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=64,32,16 FUSED_CONST_PERS_PARAMS=1 FUSED_FA2_REG_REALLOC=1 FLASHINFER_FUSED_BACKFILL=1 FUSED_FA2_KV_CHUNK=1024
export SGLANG_FUSED_FA2_MMA_KV=2 SGLANG_FUSED_FA2_QSPLIT=0 FA3_STAGES=2 FA3_CTA_Q=128 SGLANG_FUSED_FA3_CONSUMER_REGS=0
export DISABLE_CUDA_GRAPH=0 BENCH_CHUNK=512 SGLANG_FUSED_DECODE_GUARD=0 SGLANG_FUSED_SPLIT_VERIFY=1
export BENCH_TAG=integration_head_checks_not_performance SGLANG_FUSED_FAILURE_DUMP=/dev/shm/w/mixed_trace_integration/failure.pt
/dev/shm/w/venv/bin/python -u /dev/shm/w/validated_upstream/tasks/realistic_workload_analysis/run_mixed_workloads.py --scenario loadsweep_min --methods MTPMIXFUSED --outdir /dev/shm/w/mixed_trace_integration
echo TRACE_MIX_INTEGRATION_PASS

#include <cassert>
#include <cstdio>
#include <limits>
#include <numeric>
#include <vector>

#include <flashinfer/attention/fused_plan.cuh>

int main() {
  int cases = 0;
  for (uint32_t tile : {64u, 96u, 128u}) {
    for (uint32_t page : {1u, 128u, 256u}) {
      const int alignment = std::lcm(std::lcm(128, int(tile)), int(page));
      assert(flashinfer::FusedAlignFa3KvChunk(0, tile, page) == 0);
      for (int chunk = 1; chunk <= 20000; chunk += 37) {
        const int aligned = flashinfer::FusedAlignFa3KvChunk(chunk, tile, page);
        assert(aligned >= chunk && aligned - chunk < alignment);
        assert(aligned % 128 == 0 && aligned % tile == 0 && aligned % page == 0);
        assert(flashinfer::FusedAlignFa3KvChunk(aligned, tile, page) == aligned);
        if (tile == 128 && page <= 128) assert(aligned == (chunk + 127) / 128 * 128);
        ++cases;
      }
    }
  }
  for (int invalid : {-1, std::numeric_limits<int32_t>::max()}) {
    bool rejected = false;
    try {
      flashinfer::FusedAlignFa3KvChunk(invalid, 96, 128);
    } catch (const std::exception&) {
      rejected = true;
    }
    assert(rejected);
  }
  for (const auto invalid : {std::pair<uint32_t, uint32_t>{0, 128}, {95, 128}, {96, 0}}) {
    bool rejected = false;
    try {
      flashinfer::FusedAlignFa3KvChunk(1024, invalid.first, invalid.second);
    } catch (const std::exception&) {
      rejected = true;
    }
    assert(rejected);
  }
  const int32_t queries[] = {17, 32, 257};
  const int32_t lengths[] = {32769, 65537, 4097};
  const bool roles[] = {true, true, true};
  std::vector<flashinfer::FusedWorkItem> work[4];
  int32_t maximum_splits = 0;
  std::vector<int32_t> requests;
  const int chunk = flashinfer::FusedAlignFa3KvChunk(513, 96, 128);
  flashinfer::EnumerateFusedWorkItems(queries, lengths, roles, 3, 7, 4, 128, chunk,
                                    work, &maximum_splits, &requests);
  assert(chunk == 768 && maximum_splits == (65537 + chunk - 1) / chunk);
  assert(!work[3].empty());
  for (const auto& item : work[3]) {
    assert(item.kv_start % 96 == 0 && item.kv_start % 128 == 0);
    assert(item.kv_end > item.kv_start && item.kv_end <= lengths[item.batch_idx]);
    assert(item.kv_end - item.kv_start <= chunk);
  }
  std::printf("FA3 alignment: %d rounded cases, disabled/invalid bounds and split seams PASS\n", cases);
}

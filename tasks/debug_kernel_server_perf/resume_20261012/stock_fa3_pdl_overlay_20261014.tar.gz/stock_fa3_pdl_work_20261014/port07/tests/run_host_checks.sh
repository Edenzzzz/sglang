#!/bin/bash
# Host-only checks for the 0.7 port overlay. No GPU, no CUDA toolkit: FusedPlanInfo is a plain
# struct over std::vector, so a host compiler validates its syntax AND its serialisation
# round-trip. Catches exactly what fuzzy patching broke silently on scheduler.cuh, where the
# struct and ToVector carried 11 per-task fields while NUM_TASK_ARGS said 10 and FromVector read
# 10 -- a mismatch invisible in the diff and fatal at runtime.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$HERE/../include"
WHEEL_INC="${1:-}"
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/flashinfer/attention"
cp "$ROOT/flashinfer/attention/fused_plan.cuh" "$TMP/flashinfer/attention/"
if [ -n "$WHEEL_INC" ] && [ -f "$WHEEL_INC/flashinfer/exception.h" ]; then
  cp "$WHEEL_INC/flashinfer/exception.h" "$TMP/flashinfer/"
else
  python3 - "$TMP" <<'PY'
import sys, glob, zipfile
out = sys.argv[1]
whl = glob.glob('/tmp/fi07/*.whl') + glob.glob('*.whl')
if not whl:
    raise SystemExit("no flashinfer wheel found; pass the wheel's include dir as $1")
z = zipfile.ZipFile(whl[0])
n = [x for x in z.namelist() if x.endswith('include/flashinfer/exception.h')][0]
open(out + '/flashinfer/exception.h', 'wb').write(z.read(n))
PY
fi
g++ -std=c++17 -I"$TMP" "$HERE/test_fused_plan_roundtrip.cpp" -o "$TMP/t"
"$TMP/t"
echo "host checks PASS"

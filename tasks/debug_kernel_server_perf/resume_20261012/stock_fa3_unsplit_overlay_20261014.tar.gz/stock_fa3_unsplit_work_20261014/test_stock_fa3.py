import math
import unittest

import torch


def make_case(query_lengths, kv_lengths, splits=1, heads=28, kv_heads=4):
    query = torch.randn(
        sum(query_lengths), heads, 128, device="cuda", dtype=torch.bfloat16
    )
    key = torch.randn(
        sum(kv_lengths), kv_heads, 128, device="cuda", dtype=torch.bfloat16
    )
    value = torch.randn_like(key)
    output = torch.empty_like(query)
    query_indptr = torch.tensor(
        [0, *torch.tensor(query_lengths).cumsum(0).tolist()],
        device="cuda",
        dtype=torch.int32,
    )
    lengths = torch.tensor(kv_lengths, device="cuda", dtype=torch.int32)
    pages = torch.full(
        (len(kv_lengths), max(kv_lengths)), -1, device="cuda", dtype=torch.int32
    )
    begin = 0
    for row, length in enumerate(kv_lengths):
        pages[row, :length] = torch.arange(
            begin, begin + length, device="cuda", dtype=torch.int32
        )
        begin += length
    lse = torch.empty((heads, query.shape[0]), device="cuda", dtype=torch.float32)
    partial = torch.empty(
        (splits, heads, query.shape[0], 128), device="cuda", dtype=torch.float32
    )
    partial_lse = torch.empty(
        (splits, heads, query.shape[0]), device="cuda", dtype=torch.float32
    )
    split_counts = torch.full(
        (len(kv_lengths),), splits, device="cuda", dtype=torch.int32
    )
    counter = torch.zeros(1, device="cuda", dtype=torch.int32)
    arguments = (
        query,
        key,
        value,
        output,
        lse,
        query_indptr,
        lengths,
        pages,
        partial,
        partial_lse,
        split_counts,
        counter,
        splits,
        max(query_lengths),
        112,
        1 / math.sqrt(128),
    )
    return arguments


def reference(arguments):
    query, key, value = arguments[:3]
    query_indptr, lengths, pages = arguments[5:8]
    output = torch.empty_like(query, dtype=torch.float32)
    heads = query.shape[1]
    group = heads // key.shape[1]
    boundaries = query_indptr.cpu().tolist()
    for request, length in enumerate(lengths.cpu().tolist()):
        begin, end = boundaries[request : request + 2]
        request_query = query[begin:end].float().transpose(0, 1)
        request_key = (
            key[pages[request, :length].long()]
            .float()
            .transpose(0, 1)
            .repeat_interleave(group, dim=0)
        )
        request_value = (
            value[pages[request, :length].long()]
            .float()
            .transpose(0, 1)
            .repeat_interleave(group, dim=0)
        )
        logits = request_query @ request_key.transpose(1, 2) / math.sqrt(128)
        masked = (
            torch.arange(length, device="cuda")[None, :]
            > length - (end - begin) + torch.arange(end - begin, device="cuda")[:, None]
        )
        logits.masked_fill_(masked, -float("inf"))
        output[begin:end] = (logits.softmax(-1) @ request_value).transpose(0, 1)
    return output


def assert_numerical(actual, expected):
    assert torch.isfinite(actual).all()
    difference = (actual.float() - expected).norm(dim=-1)
    scale = expected.norm(dim=-1).clamp_min(1e-3)
    worst = float((difference / scale).max())
    assert worst < 0.02, worst


@unittest.skipUnless(torch.cuda.is_available(), "requires CUDA")
class TestStockFA3(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from load_stock_fa3 import build

        torch.backends.cuda.matmul.allow_tf32 = False
        build()
        cls.operation = torch.ops.stock_fa3_pdl.run
        cls.empty_timeline = torch.empty(0, device="cuda", dtype=torch.int64)

    def execute(self, arguments, phase):
        self.operation(*arguments, phase, self.empty_timeline)
        self.operation(*arguments, 3, self.empty_timeline)

    def test_varlen_split_and_head_ratios(self):
        torch.manual_seed(2718)
        for heads in (16, 28):
            for splits in (1, 4, 7):
                arguments = make_case([4, 17, 129], [65, 513, 2048], splits, heads)
                expected = reference(arguments)
                for phase in (0, 1, 2):
                    with self.subTest(heads=heads, splits=splits, phase=phase):
                        arguments[3].fill_(float("nan"))
                        arguments[8].fill_(float("nan"))
                        arguments[9].fill_(float("nan"))
                        self.execute(arguments, phase)
                        torch.cuda.synchronize()
                        assert_numerical(arguments[3], expected)

    def test_graph_replay_changes_query(self):
        torch.manual_seed(3141)
        for splits in (1, 4):
            arguments = make_case([32, 129], [2048, 8192], splits)
            self.execute(arguments, 2)
            torch.cuda.synchronize()
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                self.execute(arguments, 2)
            for iteration in range(4):
                arguments[0].normal_()
                arguments[3].fill_(float("nan"))
                arguments[8].fill_(float("nan"))
                arguments[9].fill_(float("nan"))
                graph.replay()
                torch.cuda.synchronize()
                assert_numerical(arguments[3], reference(arguments))

    def test_shape_guards(self):
        arguments = make_case([4], [32])
        invalid = list(arguments)
        invalid[7] = invalid[7].long()
        with self.assertRaisesRegex(RuntimeError, "int32"):
            self.execute(invalid, 2)
        invalid = list(arguments)
        invalid[8] = invalid[8].flatten()[:1]
        with self.assertRaisesRegex(RuntimeError, "workspace"):
            self.execute(invalid, 2)
        with self.assertRaisesRegex(RuntimeError, "phase"):
            self.operation(*arguments, 7, self.empty_timeline)


if __name__ == "__main__":
    unittest.main(verbosity=2)

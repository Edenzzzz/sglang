import importlib.util
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch


specification = importlib.util.spec_from_file_location(
    "paged_correctness_driver", Path(__file__).parent / "srv_correctness.py")
driver = importlib.util.module_from_spec(specification)
specification.loader.exec_module(driver)


class StopLaunch(Exception):
    pass


class PagedDriverTest(unittest.TestCase):
    def launch_arguments(self, setting):
        captured = []

        def launch(arguments, **keywords):
            captured.append(arguments)
            keywords["stdout"].close()
            raise StopLaunch()

        environment = {} if setting is None else {"BENCH_PAGE_SIZE": setting}
        with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ, environment, clear=True):
            with patch.object(driver, "prompts", return_value=([], [])), patch.object(driver.subprocess, "Popen", side_effect=launch):
                with self.assertRaises(StopLaunch):
                    driver.run_arm("MTPMIXFUSED_PAGED", directory)
        return captured[0]

    def test_page128_reaches_server_cli(self):
        arguments = self.launch_arguments("128")
        self.assertEqual(arguments[arguments.index("--page-size") + 1], "128")
        self.assertEqual(arguments[arguments.index("--speculative-num-draft-tokens") + 1], "4")

    def test_default_cli_is_unchanged(self):
        self.assertNotIn("--page-size", self.launch_arguments(None))

    def test_unsupported_page_size_rejects_before_launch(self):
        with patch.dict(os.environ, {"BENCH_PAGE_SIZE": "64"}, clear=True), patch.object(driver.subprocess, "Popen") as launch:
            with self.assertRaises(ValueError):
                driver.run_arm("MTPMIXFUSED_PAGED", "/unused")
            launch.assert_not_called()


if __name__ == "__main__":
    unittest.main()

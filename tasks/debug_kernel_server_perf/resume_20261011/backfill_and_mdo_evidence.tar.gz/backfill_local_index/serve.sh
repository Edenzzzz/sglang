set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi HF_HOME=/dev/shm/w/hf
export HEADS=28,4 SM_SPLIT=64 FUSED_REFERENCE_WORKSPACE_BYTES=16 FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=64,32,16 FUSED_CONST_PERS_PARAMS=1 FLASHINFER_FUSED_BACKFILL=1
DISABLE_CUDA_GRAPH=1 BENCH_CHUNK=512 CORRECTNESS_DECODE_TOKENS=1200 SGLANG_FUSED_DECODE_GUARD=0 SGLANG_FUSED_SPLIT_VERIFY=1 SGLANG_FUSED_FAILURE_DUMP=/dev/shm/w/backfill_local_index/failure.pt /dev/shm/w/venv/bin/python -u /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py MTPMIXFUSED /dev/shm/w/backfill_local_index
for backfill in 0 1 1 0; do
 FLASHINFER_FUSED_BACKFILL=$backfill MODE=mixed_verify TIME_AB=1 TIME_ITERS=100 /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/backfill_local_index/timing_${backfill}_$(date +%s).log 2>&1
done
echo BACKFILL_SERVING_AND_AB_PASS

import asyncio
import gzip
import json
import random
import sys
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from sglang.benchmark.datasets.common import DatasetRow
from sglang.benchmark.datasets.tracelab import TraceLabClaudeDataset
from sglang.benchmark.session_replay import replay_sessions, wait_for_benchmark_start


class ToyTokenizer:
    def __init__(self, reverse=False):
        self.reverse = reverse

    def get_vocab(self):
        tokens = list(range(1000))
        if self.reverse:
            tokens.reverse()
        return {str(token): token for token in tokens}

    def encode(self, text, add_special_tokens=False):
        return list(range(len(text.split())))


class TraceLabDatasetTest(unittest.TestCase):
    def records(self):
        return [
            {
                "provider": "claude",
                "session_id": session,
                "round_index": turn,
                "input_tokens_total": 16 + turn * 8,
                "prefix_tokens": 12 + turn * 8,
                "newly_append_tokens": 4,
                "output_tokens": 3 + turn,
                "timing_events": [
                    {"timestamp": f"2026-10-11T00:00:{turn * 10:02d}Z"},
                    {"timestamp": f"2026-10-11T00:00:{turn * 10 + 2:02d}Z"},
                ],
            }
            for session in ("first", "second")
            for turn in range(2)
        ]

    def load(self, records, tokenizer, groups=2):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory, "trace.jsonl.gz")
            with gzip.open(path, "wt") as output:
                for record in records:
                    output.write(json.dumps(record) + "\n")
            dataset = TraceLabClaudeDataset(str(path), 4, groups, 1, 100, 1)
            return dataset.load(tokenizer)

    def test_lengths_prefixes_and_disjoint_warmup(self):
        random.seed(9)
        rows = self.load(self.records(), ToyTokenizer())
        warmups = [row for row in rows if row.warmup_only]
        measured = [row for row in rows if not row.warmup_only]
        self.assertEqual(len(warmups), 2)
        self.assertEqual(len(measured), 4)
        for session in ("first", "second"):
            rounds = [row for row in measured if row.session_id == session]
            self.assertEqual([row.prompt_len for row in rounds], [16, 24])
            self.assertEqual([len(row.prompt) for row in rounds], [16, 24])
            self.assertEqual([row.output_len for row in rounds], [3, 4])
            self.assertEqual(rounds[0].prompt, rounds[1].prompt[:16])
            self.assertEqual(rounds[1].inter_round_delay_s, 8)
            warmup = next(row for row in warmups if row.session_id == session)
            self.assertNotEqual(warmup.prompt, rounds[0].prompt[:12])

    def test_vocabulary_iteration_order_does_not_change_requests(self):
        random.seed(17)
        first = self.load(self.records(), ToyTokenizer())
        random.seed(17)
        second = self.load(self.records(), ToyTokenizer(reverse=True))
        self.assertEqual(first, second)

    def test_invalid_lengths_and_insufficient_sessions_fail(self):
        records = self.records()
        records[0]["input_tokens_total"] += 1
        with self.assertRaisesRegex(ValueError, "prefix plus append"):
            self.load(records, ToyTokenizer())
        with self.assertRaisesRegex(ValueError, "sufficiently long sessions"):
            self.load(self.records(), ToyTokenizer(), groups=3)

    def test_text_retokenization_is_not_silent(self):
        with self.assertRaisesRegex(ValueError, "tokenize-prompt"):
            TraceLabClaudeDataset.from_args(SimpleNamespace(tokenize_prompt=False))


class SessionReplayTest(unittest.IsolatedAsyncioTestCase):
    def request(self, session, turn):
        return DatasetRow(
            prompt=[turn], prompt_len=1, output_len=1,
            session_id=session, round_index=turn, inter_round_delay_s=1000,
        )

    async def test_rounds_are_ordered_without_timestamp_replay(self):
        requests = [self.request("first", 1), self.request("second", 0), self.request("first", 0)]
        active = set()
        completed = []

        async def send(request):
            self.assertNotIn(request.session_id, active)
            active.add(request.session_id)
            await asyncio.sleep(0)
            active.remove(request.session_id)
            completed.append((request.session_id, request.round_index))
            return SimpleNamespace(success=True, request=request)

        outputs = await asyncio.wait_for(
            replay_sessions(requests, send, float("inf")), timeout=2
        )
        self.assertEqual([output.request for output in outputs], requests)
        self.assertLess(completed.index(("first", 0)), completed.index(("first", 1)))

    async def test_failed_round_does_not_issue_dependent_round(self):
        sent = []

        async def send(request):
            sent.append(request.round_index)
            return SimpleNamespace(success=False)

        with self.assertRaisesRegex(RuntimeError, "dependent rounds"):
            await replay_sessions(
                [self.request("first", 0), self.request("first", 1)], send, float("inf")
            )
        self.assertEqual(sent, [0])

    async def test_start_barrier_and_timeout(self):
        with tempfile.TemporaryDirectory() as directory:
            waiter = asyncio.create_task(wait_for_benchmark_start(directory, timeout_s=2))
            await asyncio.sleep(0.03)
            self.assertFalse(waiter.done())
            self.assertEqual(len(list(Path(directory).glob("ready_*"))), 1)
            Path(directory, "go").touch()
            await waiter
            self.assertEqual(list(Path(directory).glob("ready_*")), [])
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(TimeoutError):
                await wait_for_benchmark_start(directory, timeout_s=0.01)

    async def test_benchmark_wiring_excludes_warmups_and_serializes_rounds(self):
        from sglang.benchmark import serving

        sent = []

        async def send(request_func_input, pbar):
            sent.append(list(request_func_input.prompt))
            await asyncio.sleep(0)
            output = serving.RequestFuncOutput.init_new(request_func_input)
            output.success = True
            output.output_len = request_func_input.output_len
            output.generated_text = " ".join(["token"] * output.output_len)
            output.latency = 0.02
            output.ttft = 0.01
            output.itl = [0.01 / max(1, output.output_len - 1)] * (output.output_len - 1)
            output.start_time = time.perf_counter()
            return output

        with tempfile.TemporaryDirectory() as directory:
            destination = str(Path(directory, "result.jsonl"))
            argv = [
                "bench", "--dataset-name", "tracelab-claude", "--tokenize-prompt",
                "--num-prompts", "2", "--tracelab-num-groups", "1",
                "--output-file", destination,
            ]
            with patch.object(sys, "argv", argv), patch.object(serving, "run_benchmark") as run:
                serving.cli_main()
                arguments = run.call_args.args[0]
            warmup = DatasetRow([9, 9], 2, 1, warmup_only=True)
            requests = [warmup, self.request("first", 1), self.request("first", 0)]
            requests[1].output_len = 3
            requests[2].output_len = 2
            with (
                patch.object(serving, "args", arguments, create=True),
                patch.dict(serving.ASYNC_REQUEST_FUNCS, {"unit": send}),
                patch.object(serving.requests, "get", return_value=SimpleNamespace(status_code=404)),
            ):
                await serving.benchmark(
                    backend="unit", base_url="http://unused", api_url="http://unused/generate",
                    model_id="toy", tokenizer=ToyTokenizer(), input_requests=requests,
                    request_rate=float("inf"), max_concurrency=None, disable_tqdm=True,
                    lora_names=[], lora_request_distribution="uniform", lora_zipf_alpha=1.0,
                    extra_request_body={}, profile=False, warmup_requests=1,
                )
            result = json.loads(Path(destination).read_text().splitlines()[0])
            self.assertEqual(result["completed"], 2)
            self.assertEqual(result["total_input_tokens"], 2)
            self.assertEqual(result["total_output_tokens"], 5)
            self.assertEqual(sent, [[9, 9], [0], [1]])


if __name__ == "__main__":
    unittest.main()

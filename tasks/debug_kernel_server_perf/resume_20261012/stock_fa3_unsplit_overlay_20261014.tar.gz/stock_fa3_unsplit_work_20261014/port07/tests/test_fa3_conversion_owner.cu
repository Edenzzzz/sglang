#include <cstdio>
#include <type_traits>
#include <utility>

#include "flashinfer/attention/hopper/utils.cuh"

template <int Elements>
__global__ void check_owner() {
  using Layout = cute::Layout<cute::Shape<cute::Int<Elements>>>;
  using Input = decltype(cute::make_tensor<float>(Layout{}));
  using Converted = decltype(flashinfer::convert_type<cutlass::bfloat16_t>(std::declval<Input const&>()));
  using Expected = decltype(cute::make_tensor<cutlass::bfloat16_t>(Layout{}));
  static_assert(std::is_same_v<Converted, Expected>);
  static_assert(sizeof(Converted) >= Elements * sizeof(cutlass::bfloat16_t));
}

template __global__ void check_owner<32>();
template __global__ void check_owner<48>();
template __global__ void check_owner<64>();

int main() {
  std::puts("device conversion ownership assertions for 32/48/64 elements: compiled");
}

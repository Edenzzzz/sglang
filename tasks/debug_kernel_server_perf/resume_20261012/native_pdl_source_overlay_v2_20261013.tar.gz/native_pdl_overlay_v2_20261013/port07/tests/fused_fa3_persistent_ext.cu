// Torch extension that drives the fused FA3 + FA2 SM-pre-assignment kernel from
// two already-planned workspaces (flashinfer's FA3 wrapper and BatchAttention).
// Compile FA3's mainloop without its warpgroup register protocol in THIS
// translation unit. See prefill_sm90.cuh: the protocol balances exactly at the
// 168-register baseline, and this kernel's body cannot hold to it because the
// FA2 mainloop is compiled into the same allocation and spills.
#define FLASHINFER_FUSED_NO_SETMAXNREG 1
// Default 1. Was hard-coded false while the FA2 runners use MaskMode::kCausal, so the two roles
// disagreed on masking. Settable to 0 to A/B the flag.
// MEASURED: 1 is WORSE. With CAUSAL=true, MODE=fa3_1chunk raises cudaErrorIllegalInstruction --
// a new failure mode, and one this project has seen before on the backfill path, where a CTA
// reaches a call on a warpgroup whose register budget FA3 raised to 240 via setmaxnreg while the
// ABI frame assumes 168. The residuals barely moved (fa3 45.41 -> 45.94, mixed 45.46 -> 45.19),
// so the masking flag is not the FA3 bug. Default stays 0; the flag exists to A/B it.
#ifndef FLASHINFER_FUSED_FA3_CAUSAL
#define FLASHINFER_FUSED_FA3_CAUSAL 0
#endif

#include <torch/all.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAGuard.h>
#include "native_prefill_bridge.cuh"

#include "batch_attention_config.inc"
// The plan is ours, not flashinfer's HolisticPlanInfo -- 0.7 removed the group tables the
// JIT-reduction rendezvous read, so the two no longer have the same shape.
#include <flashinfer/attention/fused_plan.cuh>
#include <flashinfer/attention/persistent_fa3_fused.cuh>
#include <flashinfer/attention/hopper/default_params.cuh>
#include <flashinfer/attention/hopper/variants.cuh>
#include <flashinfer/attention/scheduler.cuh>

using namespace flashinfer;
using FDT = cutlass::bfloat16_t;   // FA3 side
using PDT = __nv_bfloat16;         // persistent side
using IdT = int32_t;

using FA3Params = BatchPrefillPagedParams<FDT, FDT, FDT, IdT>;
// FA3's K/V pipeline depth. Two stages cost 128 KB of the 163920-byte
// SharedStorage; one brings FA3 near 96 KB, which is what makes room to give
// the FA2 mainloop a DISJOINT shared-memory region instead of letting it
// reinterpret FA3's (see FLASHINFER_FUSED_DISJOINT_SMEM).
#ifndef FUSED_FA3_STAGES
#define FUSED_FA3_STAGES 1
#endif
// Tile shape, configurable so the second K/V pipeline stage can be bought by shrinking a tile.
// FA3_STAGES=2 cannot launch at CTA_Q=CTA_KV=128 (the SharedStorage exceeds the smem max), and a
// single-stage pipeline has NO prefetch overlap at all -- the leading remaining suspect for the
// measured 4x gap against flashinfer's own 2-stage FA3.
//
// CONSTRAINT: the planner rounds kv chunks up to kTileKV = 128 (fused_plan.cuh), so CTA_KV must
// DIVIDE 128 or chunks stop aligning to kv tiles and a partial tile at a chunk seam gets masked
// twice. 64 and 128 are safe; 96 is not.
#ifndef FUSED_FA3_CTA_Q
#define FUSED_FA3_CTA_Q 128
#endif
#ifndef FUSED_FA3_CTA_KV
#define FUSED_FA3_CTA_KV 128
#endif
static_assert(128 % FUSED_FA3_CTA_KV == 0,
              "CTA_KV must divide the planner's kTileKV of 128, or kv chunks stop aligning to "
              "kv tiles and a seam tile is masked twice");
// PARAMETER ORDER, read off kernel_traits.cuh rather than inferred:
//   <USE_TMA_LOAD_KV, HEAD_DIM_QK, HEAD_DIM_VO, CTA_Q, CTA_KV, NUM_STAGES, ...>
// The original line was <false, 128, 128, 128, 128, STAGES, ...> -- all four identical, so the
// order was unverifiable from the call site. My first attempt put CTA_KV in position 3 and so set
// HEAD_DIM_VO=64, which failed `static_assert(HEAD_DIM_QK == HEAD_DIM_VO)`. Same hazard as the
// positional aggregate initialisers elsewhere in this port: identical values hide the ordering
// until one of them changes.
using FA3Traits = AttentionKernelTraits<false, 128, 128, FUSED_FA3_CTA_Q, FUSED_FA3_CTA_KV,
                                        FUSED_FA3_STAGES, FDT, FDT,
                                        FDT, IdT, DefaultAttentionSm90<false>>;
// FLASHINFER_FA2_QSPLIT=1 splits the FA2 role's q tile over 8 warps with
// num_mma_q=1 instead of 4 warps with num_mma_q=2. Both cover the same 128 q rows
// (8*1*16 == 4*2*16), but each warp then owns 16 rows rather than 32, which halves
// the per-thread O accumulator -- and that accumulator, not the softmax, is what
// makes the FA2 role spill at this kernel's 384-thread geometry. Measured in
// isolation: 1 136 B of spill at 4x1/num_mma_q=2 against 88 B here, while raising
// num_warps_kv to 3 to occupy all 384 threads was slightly WORSE (1 276 B) because
// every KV-warp still holds a full accumulator.
#ifndef FLASHINFER_FA2_QSPLIT
#define FLASHINFER_FA2_QSPLIT 0
#endif
// All three runners must come out at the SAME warp count, because the fused kernel
// gates one thread region and then dispatches to whichever runner the work item's
// tile class selects -- a narrower runner would leave threads sitting inside its
// barriers. The kernel static_asserts this.
//
// At kFa2Warps = 8 (256 threads) the assignment is forced:
//   tile 128: 8 warps_q x 1 warp_kv, num_mma_q = 128/(8*16) = 1   <- 16 q rows/warp
//   tile  64: 4 warps_q x 2 warps_kv, num_mma_q =  64/(4*16) = 1   (8 warps_q would
//             need num_mma_q = 0.5)
//   tile  16: 1 warp_q  x 8 warps_kv, num_mma_q =  16/(1*16) = 1
// Only tile 128 actually changes shape; 64 and 16 already had 16 q rows per warp and
// just gain KV warps to reach the common width.
constexpr uint32_t kFa2Warps = FLASHINFER_FA2_QSPLIT ? 8u : 4u;
// A2. The two REAL constraints are
//     warps_q * warps_kv  == kFa2Warps      (every runner must use all the threads)
//     warps_q * num_mma_q * 16 == CTA_TILE_Q (q rows per warp is a multiple of 16)
// and nothing requires warps_q == CTA_TILE_Q/16: num_mma_q absorbs the leftover factor. The old
// helper returned min(kFa2Warps, CTA_TILE_Q/16), which for tile 48 gives warps_q=3 and then
// kFa2Warps/3 TRUNCATES to 2, yielding 6 warps against the required 8 -- a silently wrong layout.
// That truncation, not the hardware, is what the doc recorded as "tile 48 requires a 6- or 12-warp
// layout". Picking the largest DIVISOR of kFa2Warps whose q-width divides CTA_TILE_Q makes
// {16, 32, 48, 64, 96, 128} all expressible at the existing 8 warps:
//     16: 1q x 8kv, mma_q 1    48: 1q x 8kv, mma_q 3    96: 2q x 4kv, mma_q 3
//     32: 2q x 4kv, mma_q 1    64: 4q x 2kv, mma_q 1   128: 8q x 1kv, mma_q 1
// This is what unblocks the user's {16,32,48} hypothesis without touching FusedPlanInfo<4>: the
// three widths fit the three FA2 task slots exactly.
template <uint32_t CTA_TILE_Q>
constexpr uint32_t fa2_warps_q() {
  uint32_t best = 0;
  for (uint32_t w = 1; w <= kFa2Warps; ++w) {
    if (kFa2Warps % w != 0u) continue;        // must divide the warp budget exactly
    if (CTA_TILE_Q % (w * 16u) != 0u) continue;  // must give an integral num_mma_q
    best = w;                                  // keep the largest such w
  }
  return best;  // 0 means CTA_TILE_Q is not expressible; static_assert below catches it
}
template <uint32_t CTA_TILE_Q>
constexpr uint32_t fa2_warps_kv() {
  return kFa2Warps / fa2_warps_q<CTA_TILE_Q>();
}
template <uint32_t CTA_TILE_Q>
constexpr uint32_t fa2_mma_q() {
  return CTA_TILE_Q / (fa2_warps_q<CTA_TILE_Q>() * 16u);
}
// The layout is derived, so assert the invariants rather than trusting the derivation.
template <uint32_t CTA_TILE_Q>
struct fa2_layout_check {
  static_assert(fa2_warps_q<CTA_TILE_Q>() != 0u,
                "CTA_TILE_Q not expressible at kFa2Warps: needs warps_q dividing kFa2Warps with "
                "warps_q*16 dividing CTA_TILE_Q");
  static_assert(fa2_warps_q<CTA_TILE_Q>() * fa2_warps_kv<CTA_TILE_Q>() == kFa2Warps,
                "FA2 runner would not use the full warp budget");
  static_assert(fa2_warps_q<CTA_TILE_Q>() * fa2_mma_q<CTA_TILE_Q>() * 16u == CTA_TILE_Q,
                "FA2 q-tile width does not match warps_q * num_mma_q * 16");
  static constexpr bool ok = true;
};
template <uint32_t CTA_TILE_Q, uint32_t NUM_MMA_KV>
using PKT = FusedWarpgroupTraits<
    // kCausal, not kNone. All three persistent q-tile runners instantiate through PKT, so a
    // kNone trait left every FA2 work item unmasked: the harness showed token 63 of 64 as the
    // only correct token on a 64-token row. Recovered from the task doc after the pod this was
    // first fixed on was destroyed without the change being committed.
    KernelTraits<MaskMode::kCausal, CTA_TILE_Q, fa2_mma_q<CTA_TILE_Q>(), NUM_MMA_KV, 8, 8,
                 fa2_warps_q<CTA_TILE_Q>(), fa2_warps_kv<CTA_TILE_Q>(),
                 PosEncodingMode::kNone, PDT, PDT, PDT, float, IdT, StandardAttention<false>>>;
// One runner per FA2 q-tile class of the FusedPlanInfo<4> plan. R128 used to be
// missing, on the belief that the plan's task 0 was FA3's work; it is not --
// the persistent plan is built over the FA2 sub-batch after the FA3 rows have
// been removed, so task 0 is ordinary FA2 work for every row whose
// packed_qo_len exceeds 64, and nothing else was executing it.
// FA2's KV-pipelining depth, the direct analogue of the FA3 executor's stage count --
// NUM_MMA_KV sets how many 16-wide KV tiles a warp keeps in flight, so raising it deepens
// the K/V pipeline exactly as stages=2 does for upstream FA3 (measured 6.0% there). The
// same optimisation has to be tested on BOTH executors, not just the one being ported.
//
// It costs shared memory and registers: the s_frag accumulator is
// [NUM_MMA_Q][NUM_MMA_KV][8] floats per thread, so this trades the per-thread register
// budget for pipeline depth and will not monotonically improve.
#ifndef FLASHINFER_FA2_MMA_KV
#define FLASHINFER_FA2_MMA_KV 2
#endif
// A2. The three FA2 class WIDTHS are compile-time, so they come from macros rather than the
// planner's env var: FUSED_FA2_TILES only reorders which rows land in which task slot, and a
// width the runners were not built for would route rows to a tile that does not exist. Keep the
// two in step -- the host-side planner reads FUSED_FA2_TILES, these three must match it.
// Defaults {128, 64, 16} reproduce the previous behaviour exactly.
#ifndef FUSED_FA2_W0
#define FUSED_FA2_W0 128
#endif
#ifndef FUSED_FA2_W1
#define FUSED_FA2_W1 64
#endif
#ifndef FUSED_FA2_W2
#define FUSED_FA2_W2 16
#endif
static_assert(fa2_layout_check<FUSED_FA2_W0>::ok && fa2_layout_check<FUSED_FA2_W1>::ok &&
                  fa2_layout_check<FUSED_FA2_W2>::ok,
              "one of the configured FA2 tile widths has no valid warp layout");
using R128 =
    BlockBatchPagedAttentionPersistent<PKT<FUSED_FA2_W0, FLASHINFER_FA2_MMA_KV>, PersistentParams>;
using R64 =
    BlockBatchPagedAttentionPersistent<PKT<FUSED_FA2_W1, FLASHINFER_FA2_MMA_KV>, PersistentParams>;
using R16 =
    BlockBatchPagedAttentionPersistent<PKT<FUSED_FA2_W2, FLASHINFER_FA2_MMA_KV>, PersistentParams>;

// The KV cache does not have one fixed rank, and assuming it does was a real
// bug. The standalone harness slices a [pages, 2, page_size, H, D] buffer and so
// hands this a RANK-4 [pages, page_size, H, D] tensor; sglang's paged pool hands
// it a RANK-3 [tokens, H, D] tensor (page_size 1). Reading stride(1) as the
// token stride and stride(2) as the head stride is right for the first and
// wrong for the second: on a measured server batch with k_stride [512, 128, 1]
// it produced k_stride_n = 128 and k_stride_h = 1, so all four KV heads aliased
// one head's memory and get_gmem_layout built a degenerate layout. The resulting
// tensor map made cudaLaunchKernel itself fail with "misaligned address" -- the
// kernel never started -- which then poisoned the context and took the next
// (ordinary, unrelated) attention call down with it.
//
// The invariant the kernel needs is:
//   page_step == vector_sparse_ratio * stride_n   and   stride_h == head stride
struct KvStrides {
  int64_t page, n, h;
};
static inline KvStrides kv_strides(const at::Tensor& t) {
  const int64_t d = t.dim();
  TORCH_CHECK(d == 3 || d == 4, "fused KV cache must be rank 3 [tokens, H, D] or "
                                "rank 4 [pages, page_size, H, D], got rank ", d);
  if (d == 4) return {t.stride(0), t.stride(1), t.stride(2)};
  // rank 3: one token per page, so the token step is the page step
  return {t.stride(0), t.stride(0), t.stride(1)};
}

void fused_run_impl(at::Tensor q, at::Tensor k_cache, at::Tensor v_cache, at::Tensor kv_indices,
               at::Tensor o, at::Tensor fa3_int_ws, std::vector<int64_t> fa3_plan,
               at::Tensor pers_int_ws, at::Tensor pers_float_ws, std::vector<int64_t> pers_plan,
               int64_t num_qo_heads, int64_t num_kv_heads, int64_t page_size, double sm_scale,
               int64_t sm_split, int64_t pers_row_offset, int64_t fa3_num_ctas,
               int64_t pers_kv_page_offset, at::Tensor fa3_kv_indices,
               at::Tensor pers_o, int64_t num_requests, int64_t max_pages_per_seq,
               int64_t max_seqlen_q, at::Tensor kv_lens_per_req,
               at::Tensor q_indptr_per_req, at::Tensor kv_indptr_per_req,
               bool native_fa2, at::Tensor timeline) {
  const c10::cuda::OptionalCUDAGuard g(q.device());
  cudaStream_t stream = c10::cuda::getCurrentCUDAStream();
  void* fa3_ib = fa3_int_ws.data_ptr();
  void* pers_ib = pers_int_ws.data_ptr();
  void* pers_fb = pers_float_ws.data_ptr();

  PrefillPlanSM90Info fp; fp.FromVector(fa3_plan);
  // Four tasks: 0/1/2 are the FA2 tile classes the persistent runners execute,
  // 3 is the wgmma class whose work items FA3's mainloop pulls through
  // UnifiedWgmmaTileScheduler. The loop below deliberately stays at 3.
  //
  // FusedPlanInfo, not flashinfer's HolisticPlanInfo: 0.7 removed the group tables that the
  // JIT-reduction rendezvous read (group_id / group_nchunks / group_row_begin / group_nrows /
  // group_kv_head / group_counter) and went to a scheduled merge over per-task partial_indptr
  // plus shared merge_indptr / merge_o_indices. Our plan carries that layout and the fused
  // additions, so the two no longer have the same shape and the plan must be ours.
  //
  // The task count is NOT negotiable at run time: FromVector walks the vector by
  // the count baked into the type, so handing a 3-task plan to FusedPlanInfo<4>
  // would read a task's worth of fields past the end and
  // silently take the shared fields -- partial_o, merge_indptr, merge_o_indices
  // -- from the wrong offsets. Check the length instead of trusting the caller.
  // Lengths come from ToVector itself, not from NUM_TASK_ARGS/NUM_SHARED_ARGS
  // arithmetic. That formula gives 51 and 62 while the real vectors are 49 and
  // 60, because NUM_SHARED_ARGS (16) is larger than the 14 shared fields
  // ToVector actually pushes -- so the arithmetic version of this guard rejected
  // every valid plan, including the default path's.
  const size_t kPlan3 = FusedPlanInfo<3>{}.ToVector().size();
  const size_t kPlan4 = FusedPlanInfo<4>{}.ToVector().size();
#ifdef FLASHINFER_FUSED_UNIFIED_WGMMA
  TORCH_CHECK(pers_plan.size() == kPlan4,
              "the unified wgmma path needs a 4-task plan (", kPlan4, " entries), got ",
              pers_plan.size(), "; build the plan with FusedPlanInfo<4>");
  FusedPlanInfo<4> pp; pp.FromVector(pers_plan);
#else
  TORCH_CHECK(pers_plan.size() == kPlan3 || pers_plan.size() == kPlan4,
              "persistent plan has ", pers_plan.size(), " entries, expected ", kPlan3, " or ",
              kPlan4);
  FusedPlanInfo<3> pp; pp.FromVector(pers_plan);
#endif

  if (native_fa2) {
    const char* colaunch = std::getenv("FLASHINFER_FUSED_COLAUNCH");
    const char* symmetric = std::getenv("FLASHINFER_FUSED_SYMMETRIC");
    TORCH_CHECK(colaunch != nullptr && std::atoi(colaunch) != 0 &&
                (symmetric == nullptr || std::atoi(symmetric) == 0),
                "native FA2 primary requires asymmetric co-launch mode");
    TORCH_CHECK(pp.max_splits_fa3 == 1,
                "native FA2 primary requires unsplit FA3; deferred reduction is not implemented");
  }

  // ---- FA3 params (mirrors csrc/batch_prefill_sm90.cu)
  //
  // FLASHINFER_FUSED_UNIFIED_WGMMA selects the unified plan for the wgmma role:
  // its work list, its KV chunking and its JIT-reduction group all come from
  // task 3 of the same plan the FA2 runners use, instead of from a second
  // PrefillSM90Plan that has neither GQA packing nor split-KV. Left switchable
  // so the two can be A/B'd on the same batch.
#ifdef FLASHINFER_FUSED_UNIFIED_WGMMA
  using FA3ParamsSel = UnifiedWgmmaParams<FA3Params, IdT>;
  constexpr bool kUnifiedWgmma = true;
#else
  using FA3ParamsSel = FA3Params;
  constexpr bool kUnifiedWgmma = false;
#endif
  FA3ParamsSel fa3{};
  fa3.q_ptr = static_cast<FDT*>(q.data_ptr());
  fa3.k_ptr = static_cast<FDT*>(k_cache.data_ptr());
  fa3.v_ptr = static_cast<FDT*>(v_cache.data_ptr());
  fa3.o_ptr = static_cast<FDT*>(o.data_ptr());
  fa3.lse_ptr = nullptr;  // set below on the upstream path, which requires one
  fa3.q_stride_n = q.stride(0);  fa3.q_stride_h = q.stride(1);
  fa3.o_stride_n = o.stride(0);  fa3.o_stride_h = o.stride(1);
  const KvStrides ks = kv_strides(k_cache), vs = kv_strides(v_cache);
  fa3.k_stride_n = ks.n; fa3.k_stride_h = ks.h;
  fa3.v_stride_n = vs.n; fa3.v_stride_h = vs.h;
  // ROOT CAUSE of the FA3 arm's failure (K1n, 2026-10-10). These two were NEVER assigned, and
  // `FA3ParamsSel fa3{}` zero-initialises them. 0.7's sparse_mainloop computes
  //     my_kv_offset = page_idx * k_page_stride + entry_idx * k_stride_n;
  // so with k_page_stride == 0 every page resolves to offset 0 and, at page_size=1 (entry_idx
  // always 0), EVERY key reads page 0. Under bottom-right causal row 0 attends to key 0 alone, so
  // row 0 came back exact and all 127 others wrong -- measured as rel 11.8, 127/128, and as a
  // PASS at 2.372e-07 the moment every kv page was made identical (KVCONST=1), which is what
  // localised it. These are the same fields 0.7 inserted mid-struct, and the FA2 persistent
  // params below already set their equivalents (k_stride_page / v_stride_page); only this
  // selection-params block was missed.
  fa3.k_page_stride = ks.page;
  fa3.v_page_stride = vs.page;
  fa3.nnz_qo = q.size(0);
  fa3.num_qo_heads = num_qo_heads; fa3.num_kv_heads = num_kv_heads;
  fa3.group_size = num_qo_heads / num_kv_heads;
  fa3.page_size = page_size; fa3.window_left = -1; fa3.causal = false;
  fa3.qo_tile_indices = GetPtrFromBaseOffset<IdT>(fa3_ib, fp.qo_tile_indices_offset);
  fa3.qo_indptr      = GetPtrFromBaseOffset<IdT>(fa3_ib, fp.qo_indptr_offset);
  fa3.kv_indptr      = GetPtrFromBaseOffset<IdT>(fa3_ib, fp.kv_indptr_offset);
  fa3.qo_lens        = GetPtrFromBaseOffset<IdT>(fa3_ib, fp.qo_len_offset);
  fa3.kv_lens        = GetPtrFromBaseOffset<IdT>(fa3_ib, fp.kv_len_offset);
  fa3.head_indices   = GetPtrFromBaseOffset<IdT>(fa3_ib, fp.head_indices_offset);
  fa3.work_indptr    = GetPtrFromBaseOffset<IdT>(fa3_ib, fp.work_indptr_offset);
  fa3.batch_indices  = GetPtrFromBaseOffset<IdT>(fa3_ib, fp.batch_indices_offset);
  // Index convention, and it CHANGED between 0.3.1 and 0.7. 0.3.1's fa3 multiplied the index by
  // k_stride_n, so flashinfer ran block_sparse_indices_to_vector_sparse_offsets first and passed
  // vector-sparse offsets; passing the raw page array there left the FA3 rows wrong by ~60% of
  // the output magnitude while the same kernel standalone was exact. 0.7 instead computes
  // `page_idx * k_page_stride + entry_idx * k_stride_n`, i.e. it wants RAW PAGE IDS plus the page
  // stride now assigned above.
  //
  // At page_size=1 the two conventions coincide (vector-sparse ratio 1, entry_idx always 0), which
  // is why this fixture passes with vector-sparse offsets. TODO before any page_size>1 arm: feed
  // raw page ids here and let entry_idx carry the within-page offset, or the >1 case will be wrong
  // in a way this fixture cannot see.
  fa3.kv_indices     = static_cast<IdT*>(fa3_kv_indices.data_ptr());
  fa3.additional_params.sm_scale = float(sm_scale);
#ifdef FLASHINFER_FUSED_UNIFIED_WGMMA
  // Upstream-port workspace. Only allocated when that path is compiled in, so the
  // default path pays nothing.
  //
  // num_splits comes from the PLAN (max_splits_fa3), not from a guess. The
  // partials scale as total_q * num_splits, so a loose bound is not affordable: the
  // obvious conservative choice -- pages per sequence -- would ask for
  // 8192 * 32 * 8192 * 4 bytes of LSE alone. The planner knows the exact figure
  // because it is the num_kv_tiles it just chose, so it now exports it.
  float* up_partial_o = nullptr;
  float* up_partial_lse = nullptr;
  IdT* up_page_table = nullptr;
  at::Tensor up_po, up_plse, up_pt, up_lse, up_nsd;
  float* up_lse_ptr = nullptr;
  int32_t* up_nsd_ptr = nullptr;
#if FLASHINFER_FA3_UPSTREAM
  {
    const int64_t nsplits = std::max<int64_t>(pp.max_splits_fa3, 1);
    const int64_t total_q = q.size(0);
    const auto fopt = at::TensorOptions().dtype(at::kFloat).device(q.device());
    const auto iopt = at::TensorOptions().dtype(at::kInt).device(q.device());
    // Sized from the SAME helpers the strides come from, so the allocation cannot
    // drift from the layout. Upstream's varlen layout is
    // out_accum[num_splits, num_heads, total_q, head_dim], i.e. split outermost.
    UpstreamFA3Plan shape_only{};
    shape_only.total_q = int(total_q);
    shape_only.head_dim = HEAD_DIM_VO;
    shape_only.num_qo_heads = int(num_qo_heads);
    shape_only.num_splits = int(nsplits);
    up_po = at::empty({UpstreamPartialOElems(shape_only)}, fopt);
    up_plse = at::empty({UpstreamPartialLSEElems(shape_only)}, fopt);
    // A real final-LSE buffer. This path leaves fa3.lse_ptr null because
    // flashinfer's FA3 epilogue skips LSE when it is null; upstream's does not --
    // it writes the final LSE unconditionally, so a null pointer is a device-side
    // null store, which is one of the three faults behind the first launch's
    // illegal access.
    up_lse = at::empty({total_q * num_qo_heads}, fopt);
    // -1, not 0: 0 is a valid page id, so zero padding would make every short
    // sequence read page 0 for its tail blocks instead of being masked off.
    up_pt = at::full({num_requests * max_pages_per_seq}, -1, iopt);
    up_partial_o = up_po.data_ptr<float>();
    up_partial_lse = up_plse.data_ptr<float>();
    up_page_table = up_pt.data_ptr<int32_t>();
    up_lse_ptr = up_lse.data_ptr<float>();
    fa3.lse_ptr = up_lse_ptr;
    // Per-request split counts for the combine pass; filled on device each launch.
    up_nsd = at::empty({num_requests}, iopt);
    up_nsd_ptr = up_nsd.data_ptr<int32_t>();
  }
#endif
  {
    const auto& t3 = pp.tasks[3];
    auto P = [&](int64_t off) { return GetPtrFromBaseOffset<IdT>(pers_ib, off); };
    fa3.wgmma_plan = UnifiedWgmmaPlanPtrs<IdT>{
        P(t3.work_indptr_offset), P(t3.q_indptr_offset),   P(t3.kv_indptr_offset),
        P(t3.q_len_offset),       P(t3.kv_len_offset),     P(t3.q_start_offset),
        P(t3.kv_start_offset),    P(t3.kv_end_offset),     P(t3.kv_head_idx_offset),
        P(t3.partial_indptr_offset),
        // No group_id: FusedPlanInfo dropped the plan's per-item group_id with K1a's
        // JIT-reduction rendezvous, and the scheduler now DERIVES the only thing it was still
        // used for -- whether this row needs a merge -- as (num_kv_chunks > 1). Deleting the
        // initialiser without also removing the field is what shifted this whole aggregate by
        // one and produced six type errors three fields later.
        P(t3.batch_idx_offset),
        // Task 3's element of the per-task len_kv_chunk array; the scheduler reads
        // it as [0] to derive each item's chunk index for the strided partial slab.
        GetPtrFromBaseOffset<IdT>(pers_ib, pp.len_kv_chunk_offset) + 3,
        // Upstream-port workspace. Null until the dispatch allocates it; the
        // positions matter because this is aggregate initialisation, and adding
        // fields mid-struct without updating here would silently assign
        // num_qo_heads to a float* -- the same class of bug as the plan's
        // ToVector/FromVector ordering scramble.
        up_partial_o, up_partial_lse, up_page_table,
        int(max_pages_per_seq), int(q.size(0)),
        int(num_requests), int(k_cache.size(0)), int(max_seqlen_q),
        // RAW page ids. fa3.kv_indices is the VECTOR-SPARSE array, which upstream
        // must not see: its paged path treats the entry as a page number.
        static_cast<IdT*>(kv_indices.data_ptr()),
        up_nsd_ptr, static_cast<IdT*>(kv_lens_per_req.data_ptr()),
        static_cast<IdT*>(q_indptr_per_req.data_ptr()),
        static_cast<IdT*>(kv_indptr_per_req.data_ptr()),
        P(pp.fa3_batch_list_offset), int(pp.num_fa3_requests),
        int(std::max<int64_t>(pp.max_splits_fa3, 1)),
        // cta_tile_q: MUST equal FA3Traits' CTA_Q and the planner's kFa3TileQ. Was a bare 128u.
        uint32_t(num_qo_heads), uint32_t(num_kv_heads), uint32_t(FUSED_FA3_CTA_Q)};
  }
#endif

  // ---- persistent params for all three q-tile tasks (mirrors csrc/batch_attention.cu)
  PersistentParams pr[3]{};  // zero-init: every field not set below must read as 0,
                             // not as whatever was on the stack
  IdT* len_kv_chunk = GetPtrFromBaseOffset<IdT>(pers_ib, pp.len_kv_chunk_offset);
  for (int i = 0; i < 3; ++i) {  // tasks 0 (tile 128), 1 (tile 64), 2 (tile 16)
    auto& P = pr[i];
    // The two sides were planned independently, so both their q_indptr and
    // o indices start at 0; the persistent rows actually live after the FA3
    // rows in q/o, so its base pointers are advanced by that many rows.
    P.q = static_cast<PDT*>(q.data_ptr()) + pers_row_offset * q.stride(0);
    P.k = static_cast<PDT*>(k_cache.data_ptr());
    P.v = static_cast<PDT*>(v_cache.data_ptr());
    P.q_indptr       = GetPtrFromBaseOffset<IdT>(pers_ib, pp.tasks[i].q_indptr_offset);
    P.kv_indptr      = GetPtrFromBaseOffset<IdT>(pers_ib, pp.tasks[i].kv_indptr_offset);
    P.partial_indptr = GetPtrFromBaseOffset<IdT>(pers_ib, pp.tasks[i].partial_indptr_offset);
    // The two sides are planned independently, so the persistent plan's
    // kv_indptr restarts at 0 while its pages actually begin after the FA3
    // rows' pages. Without this rebase it reads the FA3 rows' KV and produces
    // plausible-looking but wrong output -- measured 1.52 relative error against
    // an fp32 reference, where the same kernel on a rebased index is at 0.0044.
    P.kv_indices     = static_cast<int*>(kv_indices.data_ptr()) + pers_kv_page_offset;
    P.q_len          = GetPtrFromBaseOffset<IdT>(pers_ib, pp.tasks[i].q_len_offset);
    P.kv_len         = GetPtrFromBaseOffset<IdT>(pers_ib, pp.tasks[i].kv_len_offset);
    P.q_start        = GetPtrFromBaseOffset<IdT>(pers_ib, pp.tasks[i].q_start_offset);
    P.kv_start       = GetPtrFromBaseOffset<IdT>(pers_ib, pp.tasks[i].kv_start_offset);
    P.kv_end         = GetPtrFromBaseOffset<IdT>(pers_ib, pp.tasks[i].kv_end_offset);
    P.kv_head_idx_arr= GetPtrFromBaseOffset<IdT>(pers_ib, pp.tasks[i].kv_head_idx_offset);
    P.work_indptr    = GetPtrFromBaseOffset<IdT>(pers_ib, pp.tasks[i].work_indptr_offset);
    P.len_kv_chunk   = len_kv_chunk + i;
    // Normally the same tensor as FA3's output, offset past the FA3 rows.
    // Passing a separate tensor isolates whether the FA2 role writes outside
    // its own row range.
    P.final_o   = static_cast<PDT*>(pers_o.data_ptr()) + pers_row_offset * pers_o.stride(0);
    P.final_lse = nullptr;
    P.partial_o   = GetPtrFromBaseOffset<PDT>(pers_fb, pp.partial_o_offset);
    P.partial_lse = GetPtrFromBaseOffset<float>(pers_fb, pp.partial_lse_offset);
    P.merge_indptr      = GetPtrFromBaseOffset<IdT>(pers_ib, pp.merge_indptr_offset);
    P.merge_o_indices   = GetPtrFromBaseOffset<IdT>(pers_ib, pp.merge_o_indices_offset);
    P.num_packed_qo_len = GetPtrFromBaseOffset<IdT>(pers_ib, pp.num_qo_len_offset);
    // No group_* wiring here. Those six params fed the in-kernel JIT-reduction rendezvous,
    // which 0.7 does not have: split rows are combined by the scheduled merge over
    // partial_indptr / merge_indptr / merge_o_indices set above. The FLASHINFER_NO_JIT_REDUCE
    // bisect flag went with them -- there is no longer a rendezvous for it to disable.
    P.num_kv_heads = num_kv_heads;
    P.gqa_group_size = uint_fastdiv(num_qo_heads / num_kv_heads);
    P.page_size = uint_fastdiv(page_size);
    P.q_stride_n = q.stride(0); P.q_stride_h = q.stride(1);
    P.k_stride_page = ks.page; P.k_stride_h = ks.h; P.k_stride_n = ks.n;
    P.v_stride_page = vs.page; P.v_stride_h = vs.h; P.v_stride_n = vs.n;
    P.sm_scale = float(sm_scale); P.v_scale = 1.f;
  }

  // The cross-role backfill queue, passed as its own argument rather than as PersistentParams
  // fields. Upstream generates that struct from batch_attention_customize_config.jinja, so
  // carrying these there meant patching a template inside the installed wheel; only our kernel
  // reads them. Omitting them left cluster_cursor pointing at uninitialised stack
  // (cudaPointerGetAttributes reported cudaMemoryTypeUnregistered, device -2) and
  // num_pers_clusters garbage, so the drain loop compared its slot against a nonsense bound.
  FusedQueueParams queue;
  queue.cluster_cursor = GetPtrFromBaseOffset<IdT>(pers_ib, pp.cluster_cursor_offset);
  queue.num_pers_clusters = uint32_t(pp.num_pers_clusters);
  if (timeline.defined() && timeline.numel() != 0) {
    TORCH_CHECK(timeline.is_cuda() && timeline.device() == q.device() &&
                timeline.scalar_type() == at::kLong && timeline.numel() == 4 && timeline.is_contiguous(),
                "PDL timeline must contain four CUDA int64 values");
    queue.pdl_timeline = reinterpret_cast<unsigned long long*>(timeline.data_ptr<int64_t>());
  }

  auto status =
      // Template args: <KernelTraits, LEFT_SLIDING_WINDOW, CAUSAL, SAME_SCHEDULE_FOR_ALL_HEADS,
      // ...>. CAUSAL is now driven by FLASHINFER_FUSED_FA3_CAUSAL (default 1) instead of being
      // hard-false. It was hard-false while the FA2 runners are instantiated with
      // MaskMode::kCausal, so the two roles disagreed on masking -- flagged early in K1n and
      // never tested, because the reference was invalid at the time.
      FusedFA3PersistentDispatched<FA3Traits, false,
                                   (FLASHINFER_FUSED_FA3_CAUSAL != 0), false, FA3ParamsSel,
                                   R128, R64, R16, false, kUnifiedWgmma>(
                                          fa3, pr[0], pr[1], pr[2], uint32_t(sm_split),
                                          uint32_t(fa3_num_ctas), queue, stream, !native_fa2);
  TORCH_CHECK(status == cudaSuccess, "fused kernel failed: ", cudaGetErrorString(status));
  if (native_fa2) return;

  // Reduce the split-KV partials the grid just wrote. Separate launch, not a fourth role: 0.7
  // runs its reduction inside a COOPERATIVE kernel, and a cooperative launch caps the grid at
  // what fits co-resident -- the very quantity sm_split manipulates.
  //
  // num_merge_rows is the plan's COMPACTED split-row count. Passing the batch's row count
  // instead would make the merge visit unsplit rows, whose num_index_sets of 0 fills their
  // output with ZEROS over the direct write -- so the rows that need no merge would be the ones
  // destroyed by it.
  auto rstatus = FusedLaunchStateReduction<128, PDT, IdT>(
      GetPtrFromBaseOffset<PDT>(pers_fb, pp.partial_o_offset),
      GetPtrFromBaseOffset<float>(pers_fb, pp.partial_lse_offset),
      // v_merged is `o`, NOT pers_o advanced by pers_row_offset. The rows that split are FA3's,
      // which live at the START of o, and merge_o_indices are ABSOLUTE token rows -- so handing
      // the merge a base already advanced past FA3's rows makes it write o_indices rows beyond
      // the end of the FA2 region. Observed as a 16 B out-of-bounds write from the reduction's
      // own grid (x=0, blocks along Y), which a bisect with FLASHINFER_FUSED_NO_MERGE=1 showed
      // to be the only faulting launch.
      static_cast<PDT*>(o.data_ptr()),
      /*lse=*/nullptr,
      GetPtrFromBaseOffset<IdT>(pers_ib, pp.merge_indptr_offset),
      GetPtrFromBaseOffset<IdT>(pers_ib, pp.merge_o_indices_offset),
      int64_t(pp.num_merge_rows), uint32_t(num_kv_heads),
      uint32_t(num_qo_heads / num_kv_heads), stream);
  TORCH_CHECK(rstatus == cudaSuccess, "fused state reduction failed: ",
              cudaGetErrorString(rstatus));
}

void fused_run(at::Tensor q, at::Tensor k_cache, at::Tensor v_cache, at::Tensor kv_indices,
               at::Tensor o, at::Tensor fa3_int_ws, std::vector<int64_t> fa3_plan,
               at::Tensor pers_int_ws, at::Tensor pers_float_ws, std::vector<int64_t> pers_plan,
               int64_t num_qo_heads, int64_t num_kv_heads, int64_t page_size, double sm_scale,
               int64_t sm_split, int64_t pers_row_offset, int64_t fa3_num_ctas,
               int64_t pers_kv_page_offset, at::Tensor fa3_kv_indices,
               at::Tensor pers_o, int64_t num_requests, int64_t max_pages_per_seq,
               int64_t max_seqlen_q, at::Tensor kv_lens_per_req,
               at::Tensor q_indptr_per_req, at::Tensor kv_indptr_per_req) {
  fused_run_impl(q, k_cache, v_cache, kv_indices, o, fa3_int_ws, fa3_plan, pers_int_ws, pers_float_ws, pers_plan, num_qo_heads, num_kv_heads, page_size, sm_scale, sm_split, pers_row_offset, fa3_num_ctas, pers_kv_page_offset, fa3_kv_indices, pers_o, num_requests, max_pages_per_seq, max_seqlen_q, kv_lens_per_req, q_indptr_per_req, kv_indptr_per_req, false, at::Tensor());
}

void fused_primary_run(at::Tensor q, at::Tensor k_cache, at::Tensor v_cache, at::Tensor kv_indices,
               at::Tensor o, at::Tensor fa3_int_ws, std::vector<int64_t> fa3_plan,
               at::Tensor pers_int_ws, at::Tensor pers_float_ws, std::vector<int64_t> pers_plan,
               int64_t num_qo_heads, int64_t num_kv_heads, int64_t page_size, double sm_scale,
               int64_t sm_split, int64_t pers_row_offset, int64_t fa3_num_ctas,
               int64_t pers_kv_page_offset, at::Tensor fa3_kv_indices,
               at::Tensor pers_o, int64_t num_requests, int64_t max_pages_per_seq,
               int64_t max_seqlen_q, at::Tensor kv_lens_per_req,
               at::Tensor q_indptr_per_req, at::Tensor kv_indptr_per_req, at::Tensor timeline) {
  fused_run_impl(q, k_cache, v_cache, kv_indices, o, fa3_int_ws, fa3_plan, pers_int_ws, pers_float_ws, pers_plan, num_qo_heads, num_kv_heads, page_size, sm_scale, sm_split, pers_row_offset, fa3_num_ctas, pers_kv_page_offset, fa3_kv_indices, pers_o, num_requests, max_pages_per_seq, max_seqlen_q, kv_lens_per_req, q_indptr_per_req, kv_indptr_per_req, true, timeline);
}

#if FLASHINFER_FA3_UPSTREAM
// TWO-EXECUTOR PATH, FA3 half.
//
// Launches flash-attention's own FA3 kernel on UPSTREAM'S own scheduler over just the
// requests the planner routed to the wgmma queue. There is no FA2 half to write: that
// executor is flashinfer's persistent LPT kernel, unmodified, which is already correct and
// is the very baseline the fused kernel was measured against. The caller runs
// BatchAttention.run() for it.
//
// Why this exists at all: the fused kernel cannot give both roles their native register
// allocation (33 676 B of spill for FA3 co-compiled against 52 B alone) and its shared
// memory is over the opt-in limit by 1 120 B. Both are co-residency artifacts. Separate
// launches remove both, and the baseline is FA2 doing ALL the work while this split gives
// it strictly less.
void fa3_only_run(at::Tensor q, at::Tensor k_cache, at::Tensor v_cache, at::Tensor o,
                  at::Tensor lse, at::Tensor page_indices, at::Tensor kv_indptr_per_req,
                  at::Tensor q_indptr_per_req, at::Tensor kv_lens_per_req,
                  at::Tensor fa3_batch_list, int64_t num_qo_heads, int64_t num_kv_heads,
                  int64_t page_size, double sm_scale, int64_t max_seqlen_q,
                  int64_t max_pages_per_seq, int64_t num_splits,
                  // CALLER-OWNED scratch. These were allocated per call, which is five
                  // allocations plus a page-table scatter launch for every attention layer
                  // of every step -- about 140 allocations per forward at 28 layers. The
                  // kernel-level harness never saw it because it calls this in a tight loop
                  // on a warm allocator; serving did: TTFT 64.6 -> 89.7 ms and ITL
                  // 7.04 -> 8.42 ms, a regression from a 1.21x faster kernel.
                  //
                  // page_table_scratch is filled by the caller ONCE PER STEP, not per layer:
                  // every layer of a step shares one KV layout, so the scatter is identical
                  // across them.
                  at::Tensor page_table_scratch, at::Tensor partial_o_scratch,
                  at::Tensor partial_lse_scratch, at::Tensor nsd_scratch,
                  at::Tensor sem_scratch, bool fill_page_table) {
  const c10::cuda::OptionalCUDAGuard g(q.device());
  cudaStream_t stream = c10::cuda::getCurrentCUDAStream();
  const int n_fa3 = int(fa3_batch_list.numel());
  if (n_fa3 == 0) return;


  UpstreamFA3Plan up{};
  up.q_ptr = static_cast<cutlass::bfloat16_t const*>(q.data_ptr());
  up.k_ptr = static_cast<cutlass::bfloat16_t*>(k_cache.data_ptr());
  up.v_ptr = static_cast<cutlass::bfloat16_t*>(v_cache.data_ptr());
  up.cu_seqlens_q = static_cast<int const*>(q_indptr_per_req.data_ptr());
  up.seqused_k = static_cast<int const*>(kv_lens_per_req.data_ptr());
  up.total_q = int(q.size(0));
  up.num_pages = int(k_cache.size(0));
  up.page_size = int(page_size);
  up.num_qo_heads = int(num_qo_heads);
  up.num_kv_heads = int(num_kv_heads);
  up.head_dim = HEAD_DIM_VO;
  up.q_stride_tok = q.stride(0);
  up.q_stride_head = q.stride(1);
  const KvStrides ks = kv_strides(k_cache);
  up.kv_stride_page = ks.page;   // stride over PAGES; a 0 here aliases every page onto 0
  up.kv_stride_tok = ks.n;
  up.kv_stride_head = ks.h;
  up.o_stride_tok = o.stride(0);
  up.o_stride_head = o.stride(1);
  up.softmax_scale = float(sm_scale);
  // num_splits is a SCALAR here, not the per-request array. Under Prepared=false the varlen
  // scheduler reads params.nsplits_divmod.divisor (tile_scheduler.hpp:632) and never looks
  // at num_splits_dynamic_ptr, which is only consulted under Prepared=true. Passing 1 here
  // is what disabled split-KV entirely: a 16392-token row then runs on 4 CTAs of 132 and
  // walks its 129 KV blocks serially -- measured 17.4 ms, 1604x off roofline. That is the
  // dominant cost in the agentic ultra-long-context regime this kernel exists for.
  up.num_splits = int(num_splits > 0 ? num_splits : 1);
  up.num_requests_for_combine = n_fa3;
  up.max_seqlen_q = int(max_seqlen_q);
  up.num_fa3_requests = n_fa3;
  up.fa3_batch_list = static_cast<int const*>(fa3_batch_list.data_ptr());

  // Dense [batch, max_pages] page table, scattered from the ragged page ids using
  // PER-REQUEST page offsets. -1 padding is safe: paged_kv.h:148 substitutes page 0 past
  // seqlen_k rather than reading the table.
  at::Tensor pt = page_table_scratch;
  up.page_table = static_cast<int const*>(pt.data_ptr());
  if (fill_page_table) FLASHINFER_CHECK(LaunchScatterRaggedPageTable<int32_t>(
                       static_cast<int32_t const*>(kv_indptr_per_req.data_ptr()),
                       static_cast<int32_t const*>(page_indices.data_ptr()),
                       static_cast<int32_t*>(pt.data_ptr()),
                       int(q_indptr_per_req.numel() - 1), int(max_pages_per_seq),
                       stream) == cudaSuccess,
                   "page table scatter failed");

  // Split partials in upstream's own varlen layout, and the scheduler's tile counter.
  at::Tensor po = partial_o_scratch, plse = partial_lse_scratch, nsd = nsd_scratch;
  at::Tensor sem = sem_scratch;
  // The tile counter must start at zero each launch; the scheduler consumes it.
  sem.zero_();
  up.num_splits_dynamic = static_cast<int const*>(nsd.data_ptr());

  auto sched = MakeUpstreamOwnSchedArgs(up, static_cast<int*>(sem.data_ptr()));
  int dev = 0, nsm = 0;
  cudaGetDevice(&dev);
  cudaDeviceGetAttribute(&nsm, cudaDevAttrMultiProcessorCount, dev);
  // FA3_SM_BUDGET caps the SM count upstream's scheduler sizes its persistent grid from,
  // so the FA3 executor occupies at most that many SMs and leaves the rest to the FA2
  // executor. This is the admission control the overlap needs: concurrent streams alone
  // measured WORSE than sequential (111.3 vs 73.5 us) because two full persistent grids
  // contend for every SM, which is the same problem the fused kernel's sm_split existed to
  // solve -- only here it costs nothing, since neither kernel gives up its own geometry.
  if (const char* e = std::getenv("FA3_SM_BUDGET")) {
    const int b = std::atoi(e);
    if (b > 0 && b < nsm) nsm = b;
  }
  auto st = LaunchUpstreamFA3OwnSched<HEAD_DIM_VO>(
      MakeUpstreamMainloopArgs<HEAD_DIM_VO>(up, static_cast<int const*>(pt.data_ptr()),
                                            int(max_pages_per_seq),
                                            int(q_indptr_per_req.numel() - 1)),
      MakeUpstreamEpilogueArgs<HEAD_DIM_VO>(up, static_cast<cutlass::bfloat16_t*>(o.data_ptr()),
                                            po.data_ptr<float>(), lse.data_ptr<float>(),
                                            plse.data_ptr<float>()),
      sched, nsm, stream);
  TORCH_CHECK(st == cudaSuccess, "fa3_only launch failed: ", cudaGetErrorString(st));

  // With num_splits > 1 the epilogue takes its is_split branch and writes partials rather
  // than final O (epilogue_fwd.hpp:232), so the reduction must run or the rows stay
  // unwritten. Upstream pays this same second launch; replacing it with the smem-handoff
  // JIT reduction is the contribution, measurable only once splits actually engage.
  if (up.num_splits > 1) {
    up.num_fa3_requests = n_fa3;
    // The combine scheduler needs the FA3 subset's token extent, not the whole batch's.
    // The FA3 rows are the first n_fa3 requests, so cu_seqlens_q[n_fa3] is their token
    // count. Read host-side only on this branch: the combine runs only when splits engage,
    // so the sync never touches the num_splits == 1 path that serving uses.
    up.fa3_total_q = q_indptr_per_req.index({n_fa3}).item<int>();
    auto cs = LaunchUpstreamCombine<HEAD_DIM_VO>(
        up, static_cast<cutlass::bfloat16_t*>(o.data_ptr()), lse.data_ptr<float>(),
        po.data_ptr<float>(), plse.data_ptr<float>(), stream);
    TORCH_CHECK(cs == cudaSuccess, "combine failed: ", cudaGetErrorString(cs));
  }
}
#endif

// Expose FusedFourTaskPlan to Python. Without this there is no way to produce the `pers_plan`
// that fused_run takes, so the kernel cannot be driven from a test at all -- flashinfer's own
// plan functions build HolisticPlanInfo, which K1a replaced for this path.
//
// Returns the plan vector; the caller owns the two workspaces and passes the same ones to
// fused_run, because the plan's offsets are into them.
std::vector<int64_t> build_fused_plan(at::Tensor int_ws, at::Tensor pinned_int_ws,
                                      at::Tensor float_ws, at::Tensor qo_indptr,
                                      at::Tensor kv_indptr, at::Tensor kv_len,
                                      at::Tensor fa3_row_mask, int64_t num_qo_heads,
                                      int64_t num_kv_heads, int64_t head_dim_qk,
                                      int64_t head_dim_vo, int64_t page_size, int64_t sm_split,
                                      int64_t num_sm, bool causal) {
  const c10::cuda::OptionalCUDAGuard g(int_ws.device());
  cudaStream_t stream = c10::cuda::getCurrentCUDAStream();
  TORCH_CHECK(qo_indptr.is_cpu() && kv_indptr.is_cpu() && kv_len.is_cpu() &&
                  fa3_row_mask.is_cpu(),
              "plan inputs are read on the host; pass CPU tensors");
  const uint32_t batch = uint32_t(kv_len.numel());
  // bool on the host side: at::kBool stores one byte per element, which is what the planner's
  // `const bool*` expects. Passing an int32 mask here would read 4x the elements.
  TORCH_CHECK(fa3_row_mask.scalar_type() == at::kBool && uint32_t(fa3_row_mask.numel()) == batch,
              "fa3_row_mask must be a bool tensor of length batch");
  FusedPlanInfo<4> plan;
  size_t required_float_bytes = 0;
  cudaError_t st = FusedFourTaskPlan<4, IdT>(
      float_ws.data_ptr(), size_t(float_ws.numel()) * float_ws.element_size(), int_ws.data_ptr(),
      pinned_int_ws.data_ptr(), size_t(int_ws.numel()) * int_ws.element_size(), plan,
      qo_indptr.data_ptr<IdT>(), kv_indptr.data_ptr<IdT>(), kv_len.data_ptr<IdT>(),
      fa3_row_mask.data_ptr<bool>(), batch, uint32_t(num_qo_heads), uint32_t(num_kv_heads),
      uint32_t(head_dim_qk), uint32_t(head_dim_vo), uint32_t(page_size), uint32_t(sm_split),
      uint32_t(num_sm), causal, stream, &required_float_bytes);
  TORCH_CHECK(st == cudaSuccess, "FusedFourTaskPlan failed: ", cudaGetErrorString(st));
  if (required_float_bytes > size_t(float_ws.numel()) * float_ws.element_size()) {
    float_ws.resize_({int64_t((required_float_bytes + float_ws.element_size() - 1) /
                            float_ws.element_size())});
  }
  return plan.ToVector();
}

#ifndef FUSED_OP_NAMESPACE
#define FUSED_OP_NAMESPACE fused_fa3
#endif
#define FUSED_TORCH_LIBRARY_EXPAND(ns, m) TORCH_LIBRARY(ns, m)

FUSED_TORCH_LIBRARY_EXPAND(FUSED_OP_NAMESPACE, m) {
  m.def("fused_run", &fused_run);
  m.def("fused_primary_run", &fused_primary_run);
  m.def("native_fa2_run", &native_fa2_run);
  m.def("build_fused_plan", &build_fused_plan);
#if FLASHINFER_FA3_UPSTREAM
  m.def("fa3_only_run", &fa3_only_run);
#endif
}
#undef FUSED_TORCH_LIBRARY_EXPAND

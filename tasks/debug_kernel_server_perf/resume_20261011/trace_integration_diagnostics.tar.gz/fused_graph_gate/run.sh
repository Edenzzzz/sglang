set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi HF_HOME=/dev/shm/w/hf
export HEADS=28,4 SM_SPLIT=64 FUSED_REFERENCE_WORKSPACE_BYTES=16 FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=64,32,16 FUSED_CONST_PERS_PARAMS=1 FUSED_FA2_REG_REALLOC=1 FLASHINFER_FUSED_BACKFILL=1 FUSED_FA2_KV_CHUNK=1024
export SGLANG_FUSED_FA2_MMA_KV=2 SGLANG_FUSED_FA2_QSPLIT=0 FA3_STAGES=2 FA3_CTA_Q=128 SGLANG_FUSED_FA3_CONSUMER_REGS=0
for prefill_context in 512 32768; do
 PREFILL_QO=512 PREFILL_KV=$prefill_context VERIFY_ROWS=12 VERIFY_KV=32768 MODE=mixed_verify TIME_AB=1 TIME_CUDA_GRAPH=1 TIME_ITERS=100 /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fused_graph_gate/long_${prefill_context}.log 2>&1
done
echo LONG_CONTEXT_HEAD_REFERENCE_PASS
export CORRECTNESS_SYNTHETIC=0 CORRECTNESS_DATASET=/dev/shm/w/datasets/ShareGPT.original.json
export DISABLE_CUDA_GRAPH=0 BENCH_CHUNK=512 CORRECTNESS_DECODE_TOKENS=1200 SGLANG_FUSED_DECODE_GUARD=0 SGLANG_FUSED_SPLIT_VERIFY=1
for arm in MTP_LPT MTPMIXFUSED; do
 /dev/shm/w/venv/bin/python -u /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py $arm /dev/shm/w/fused_graph_gate
done
/dev/shm/w/venv/bin/python /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py --compare /dev/shm/w/fused_graph_gate MTP_LPT MTPMIXFUSED
echo GRAPH_SERVING_GATE_PASS

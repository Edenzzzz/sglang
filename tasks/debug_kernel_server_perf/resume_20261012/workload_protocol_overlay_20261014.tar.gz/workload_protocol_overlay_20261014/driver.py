#!/usr/bin/env python3
"""Multi-tenant serving benchmarks for the prefill/decode-overlap kernel.

One node, several concurrent tenant streams, as a production cluster actually
sees. Each scenario is chosen from the measured kernel cost surface
(tasks/debug_kernel_server_perf.md): the persistent overlap kernel wins when a
mixed batch holds *few long-context decode rows* (which starve BatchPrefill of
query tiles, leaving most SMs idle while each streams its whole KV) and the
arriving prefill chunk attends a *short prefix*. Both conditions have to come
from the workload, and in practice they come from different tenants:

  * a coding-agent tenant supplies the long-context decode pool (KV capacity
    caps it near ten concurrent sessions, which is exactly the starved regime),
  * a chat tenant supplies frequent fresh, zero-prefix prefill chunks.

Neither tenant produces the win alone, which is why single-workload replays
measured parity.

Usage:
  python run_mixed_workloads.py --scenario agent_plus_shortchat
  python run_mixed_workloads.py --list
"""

import argparse
import json
import os
import shutil
import signal
import socket
import re
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
VENV_PY = os.environ.get("BENCH_PYTHON", sys.executable)
MODEL = os.environ.get("MODEL", "/opt/tiger/models/Qwen2.5-7B-Instruct")
TRACE = os.environ.get("TRACE_PATH", str(REPO / "workloads/tracelab/syfi_coding_trace.jsonl.gz"))
CHAT_DS = os.environ.get(
    "CHAT_DATASET", str(REPO / "workloads/ShareGPT_V3_unfiltered_cleaned_split.json")
)
PORT = int(os.environ.get("BENCH_PORT", "30013"))


def codex(n, groups=12, min_ctx=32768, max_ctx=49152, min_out=512, rate="inf"):
    """Coding-agent tenant: causal session replay with tool-result appends.

    Rounds are issued back to back (recorded think/tool gaps are not replayed).
    A real cluster runs far more sessions than KV capacity allows to be
    resident, so one session's think gap is filled by another's work; with the
    dozen sessions that fit here, replaying gaps would instead leave the node
    idle 88% of the time and measure nothing. Causal ordering and cumulative
    prefix growth within each session are preserved.
    """
    return [
        "--dataset-name", "tracelab-claude", "--dataset-path", TRACE,
        "--tokenize-prompt",
        "--tracelab-num-groups", str(groups),
        "--tracelab-min-context-len", str(min_ctx),
        "--tracelab-max-context-len", str(max_ctx),
        "--tracelab-min-output-len", str(min_out),
        "--request-rate", str(rate), "--num-prompts", str(n),
    ]


def chat(n, rate, inp, out):
    """Chat tenant: fresh prompts, no shared prefix, so chunks have prefix 0."""
    return [
        "--dataset-name", "random", "--dataset-path", CHAT_DS,
        "--random-input", str(inp), "--random-output", str(out),
        "--random-range-ratio", "0.5",
        "--request-rate", str(rate), "--num-prompts", str(n),
    ]


def multiturn(n, rate, groups, sys_len, q_len, out):
    """Follow-up-turn tenant: each request attends a cached shared prefix of
    sys_len tokens with a fresh q_len-token turn. This is the overlap kernel's
    balanced band (chunk compute ~ decode-pool memory time), where the
    measured 1.2-1.26x temporal-overlap gain and the analytic cost model's
    overlap discount both apply."""
    return [
        "--dataset-name", "generated-shared-prefix",
        "--gsp-num-groups", str(groups), "--gsp-prompts-per-group", str(n // groups),
        "--gsp-system-prompt-len", str(sys_len), "--gsp-question-len", str(q_len),
        "--gsp-output-len", str(out),
        "--request-rate", str(rate), "--num-prompts", str(n),
    ]


def _env(name, default):
    return os.environ.get(name, default)


def standalone(kind, n, rate):
    """One standard standalone workload (S3), selected by STANDALONE:
    sharegpt | sharegpt:<json> | mooncake_toolagent | mooncake_conversation | longbench_v2 |
    speed_bench:<jsonl>[:<category>] | custom:<jsonl>."""
    rate_args = ["--request-rate", str(rate), "--num-prompts", str(n)]
    if kind == "sharegpt":
        return ["--dataset-name", "sharegpt", "--dataset-path", CHAT_DS] + rate_args
    if kind.startswith("sharegpt:"):
        # ShareGPT-format conversions (prep_standalone.py: gsm8k, math500, humaneval,
        # codefeedback); each request's output length is its reference answer's length.
        return ["--dataset-name", "sharegpt", "--dataset-path", kind.split(":", 1)[1]] + rate_args
    if kind.startswith("mooncake_"):
        # Mooncake replays its recorded timestamps; load is set by the slowdown factor, not the rate.
        return ["--dataset-name", "mooncake", "--mooncake-workload", kind.split("_", 1)[1],
                "--mooncake-slowdown-factor", _env("MOONCAKE_SLOWDOWN", "1.0")] + rate_args
    if kind == "longbench_v2":
        # Drop documents that do not fit the served window instead of failing them.
        return ["--dataset-name", "longbench_v2",
                "--sharegpt-context-len", _env("CONTEXT_LEN", "131072")] + rate_args
    if kind.startswith("speed_bench:"):
        parts = kind.split(":")
        args = ["--dataset-name", "speed-bench", "--dataset-path", parts[1]]
        if len(parts) > 2:
            args += ["--speed-bench-category", parts[2]]
        return args + rate_args
    if kind.startswith("custom:"):
        return ["--dataset-name", "custom", "--dataset-path", kind.split(":", 1)[1]] + rate_args
    raise ValueError(f"unknown STANDALONE workload {kind!r}")


SCENARIOS = {
    # S1/S2 evaluation matrix: agent + short chat with every axis from the environment, so one
    # driver sweeps request rate and context range. CHAT_SECONDS sizes the chat stream to the
    # offered rate, so every rate point runs for about the same wall time.
    "mix_env": {
        "desc": "agent + short chat; context range, rates and counts from the environment",
        "streams": {
            "codex": codex(int(_env("CODEX_N", "36")), groups=int(_env("CODEX_GROUPS", "8")),
                           min_ctx=int(_env("CODEX_MIN_CTX", "32768")),
                           max_ctx=int(_env("CODEX_MAX_CTX", "49152")),
                           rate=float(_env("CODEX_RATE", "0.1"))),
            "chat": chat(max(1, int(float(_env("CHAT_SECONDS", "200")) * float(_env("CHAT_RATE", "8")))),
                         float(_env("CHAT_RATE", "8")), int(_env("CHAT_IN", "512")),
                         int(_env("CHAT_OUT", "96"))),
        },
    },
    # Full-length TraceLab: the release as it is -- both providers, every context length up to the
    # served window, first rounds included, sessions picked in proportion to their rounds so the
    # replayed rounds follow the release's round-level context distribution. Chat is optional
    # (CHAT_RATE=0 drops it). Needs YARN_FACTOR=32 CONTEXT_LEN=1048576 for the >256K tail.
    "tracelab_full_env": {
        "desc": "full-length TraceLab (claude+codex, all lengths, round-weighted) [+ short chat]",
        "streams": {
            "agent": codex(int(_env("AGENT_N", "360")), groups=int(_env("AGENT_GROUPS", "120")),
                           min_ctx=0,
                           max_ctx=int(_env("AGENT_MAX_CTX", "1040000")),
                           min_out=1, rate=float(_env("AGENT_RATE", "0.2")))
                     + ["--tracelab-providers", _env("AGENT_PROVIDERS", "claude,codex"),
                        "--tracelab-allow-empty-prefix", "--tracelab-session-weighting", "rounds"]
                     + (["--tracelab-selection-seed", _env("AGENT_SEED", "")] if _env("AGENT_SEED", "") else []),
            **({"chat": chat(max(1, int(float(_env("CHAT_SECONDS", "600")) * float(_env("CHAT_RATE", "0")))),
                             float(_env("CHAT_RATE", "0")), 512, 96)}
               if float(_env("CHAT_RATE", "0")) > 0 else {}),
        },
    },
    # S3: one standard standalone workload at STANDALONE_RATE for STANDALONE_N requests.
    "standalone_env": {
        "desc": "one standard standalone workload (STANDALONE), rate-swept",
        "streams": {"main": standalone(_env("STANDALONE", "sharegpt"),
                                       int(_env("STANDALONE_N", "1000")),
                                       _env("STANDALONE_RATE", "8"))},
    },
    # Primary: long-context agent sessions beside high-rate short-answer chat.
    # Short outputs keep chat from accumulating decode rows, which would push
    # BatchPrefill back into its efficient many-tile regime; the arrivals still
    # make a third of all forwards mixed.
    # Load sweep for workload capture: same co-tenancy shape at four offered
    # loads, high to low. Used to record the realized mixed-batch composition
    # distribution (tasks/debug_kernel_server_perf/wgmma + gate resampling),
    # not as a performance comparison.
    # Pure session replay: every chunk continues a session whose prefix is
    # already in the radix cache, so prefill rows should be ~100% cache hits.
    # The co-tenancy scenarios mix in a fresh-prompt chat tenant, which has no
    # reusable prefix by construction and dominates the prefill ROW population.
    "codex_only": {
        "desc": "coding-agent session replay only (near-100% prefix cache hits)",
        "streams": {"codex": codex(80, groups=16)},
    },
    "loadsweep_hi": {
        "desc": "co-tenancy at high offered load (chat 16/s, 12 sessions)",
        "streams": {"codex": codex(60, groups=12), "chat": chat(2400, 16, 512, 96)},
    },
    "loadsweep_med": {
        "desc": "co-tenancy at medium offered load (chat 8/s, 8 sessions)",
        "streams": {"codex": codex(40, groups=8), "chat": chat(1200, 8, 512, 96)},
    },
    "loadsweep_lo": {
        "desc": "co-tenancy at low offered load (chat 4/s, 6 sessions)",
        "streams": {"codex": codex(24, groups=6), "chat": chat(600, 4, 512, 96)},
    },
    "loadsweep_min": {
        "desc": "co-tenancy at minimal offered load (chat 1.5/s, 4 sessions)",
        "streams": {"codex": codex(12, groups=4), "chat": chat(260, 1.5, 512, 96)},
    },
    "agent_plus_shortchat": {
        "desc": "coding agent + high-rate short-answer chat (routing/classification traffic)",
        "streams": {"codex": codex(60), "chat": chat(2400, 12, 512, 96)},
    },
    # The user-facing version: chat contributes long decodes as well as prefills.
    "agent_plus_chat": {
        "desc": "coding agent + conversational chat (long decodes, moderate arrival rate)",
        "streams": {"codex": codex(60), "chat": chat(600, 3, 1024, 512)},
    },
    # Single tenant. Decode KV grows from generated tokens, so a long-CoT pool
    # reaches the starved regime on its own while prompts stay fresh.
    "long_cot": {
        "desc": "long chain-of-thought reasoning, fresh prompts (single tenant)",
        "streams": {"reason": chat(160, 1.2, 1024, 8192)},
    },
    # Fresh long prompts (cache miss) chunked into several pieces: many mixed
    # steps whose early chunks still have small prefixes.
    "rag_plus_agent": {
        "desc": "cache-miss document/RAG traffic + coding agent",
        "streams": {"codex": codex(60), "rag": chat(300, 2, 12288, 256)},
    },
    # In-band overlap scenario: follow-up turns (2K fresh tokens on an 8K
    # cached prefix) arriving into the coding pool put mixed batches in the
    # balanced band T_p ~ T_d, where temporal overlap itself is the dominant
    # win and SLO-aware chunking has real slack to spend.
    "agent_plus_multiturn": {
        "desc": "coding agent + multi-turn follow-ups (2K turns on 8K shared prefixes)",
        "streams": {"codex": codex(60), "turns": multiturn(600, 4, 60, 8192, 2048, 256)},
    },
    # Same composition at SLO-feasible load: attainment-vs-throughput is only
    # meaningful when the baseline is not queue-dominated (the saturated
    # variant above has 18-77 s TTFTs in every arm).
    "agent_plus_multiturn_feasible": {
        "desc": "in-band multi-turn at SLO-feasible load",
        "streams": {"codex": codex(36, groups=8), "turns": multiturn(300, 1.5, 60, 8192, 2048, 256)},
    },
    # Clean SLO experiment: BOTH streams rate-limited. With any infinite-
    # backlog tenant present, FCFS admission ordering (not compute) dominates
    # the other tenant's latency, so attainment comparisons are confounded.
    # Codex sessions arrive as a finite Poisson process; rounds within a
    # session stay causal and back-to-back.
    "multiturn_slo_clean": {
        "desc": "in-band multi-turn, both tenants rate-limited (clean SLO A/B)",
        "streams": {"codex": codex(36, groups=8, rate=0.06),
                    "turns": multiturn(300, 1.5, 60, 8192, 2048, 256)},
    },
    # Load sweep: the same agent + short-chat mix with BOTH tenants rate-limited, the chat
    # rate set by CHAT_RATE (env). Latency comparisons are only fair below every arm's
    # saturation point. agent_plus_shortchat fires all codex sessions at once and runs chat at
    # 12/s, which pushed stock MTP past its capacity (chat throughput 748.6 < 858 offered).
    "agent_chat_rated": {
        "desc": "agent + short chat, both rate-limited; chat rate from CHAT_RATE",
        "streams": {"codex": codex(36, groups=8, rate=float(os.environ.get("CODEX_RATE", "0.1"))),
                    "chat": chat(int(200 * float(os.environ.get("CHAT_RATE", "8"))),
                                 float(os.environ.get("CHAT_RATE", "8")), 512, 96)},
    },
    # Capacity: BOTH tenants submit everything at once (closed loop to the server's queue), so
    # served throughput IS the capacity. A rate-limited sweep cannot show a throughput gain
    # until the baseline saturates, and then only up to the offered rate.
    "agent_chat_saturate": {
        "desc": "capacity: agent + short chat, both tenants at infinite rate",
        "streams": {"codex": codex(36, groups=8), "chat": chat(3200, "inf", 512, 96)},
    },
    # Long context (>64K): the codex sessions start at 64K and run to 96K, where attention is
    # 61-73% of a decode step at 8 concurrent requests (debug_kernel_server_perf_4_mode.md,
    # context share), so attention-kernel and scheduling gains reach end to end.
    "long_agent_chat": {
        "desc": "long-context agent (64-96K sessions) + short chat, both rate-limited",
        "streams": {"codex": codex(24, groups=8, min_ctx=65536, max_ctx=98304,
                                   rate=float(os.environ.get("CODEX_RATE", "0.1"))),
                    "chat": chat(int(200 * float(os.environ.get("CHAT_RATE", "8"))),
                                 float(os.environ.get("CHAT_RATE", "8")), 512, 96)},
    },
    # Control: the measured parity region. Many short rows give BatchPrefill
    # plenty of query tiles, so the gate should decline persistent throughout.
    "shortchat_only": {
        "desc": "CONTROL: high-concurrency short-context chat only (expect parity)",
        "streams": {"chat": chat(3000, 16, 512, 256)},
    },
}


def wait_health(proc, timeout=900):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if proc.poll() is not None:
            return False
        r = subprocess.run(
            ["curl", "-sf", f"http://127.0.0.1:{PORT}/health"],
            capture_output=True,
        )
        if r.returncode == 0:
            return True
        time.sleep(5)
    return False


def stop_owned_process(process):
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait(timeout=30)


def run_method(method, scenario, outdir):
    log = outdir / f"server_{method}.log"
    env = dict(os.environ)
    env["SGLANG_ALLOW_OVERWRITE_LONGER_CONTEXT_LEN"] = "1"
    # Capture every mixed batch's real composition (per-row decode KV, chunk
    # tokens, true attended prefix, gate decision) so kernel sweeps can be
    # resampled from the realized distribution instead of a Cartesian grid.
    # Only the persistent path calls the gate, so only those methods capture.
    env["SGLANG_LOG_MIXED_COMPOSITION"] = str(outdir / f"composition_{method}.jsonl")
    if method == "SPLIT":
        # Two-executor split: flash-attention's FA3 on its own scheduler over the wgmma
        # requests, flashinfer's persistent LPT over the rest. This is the kernel under
        # test; the fused single-kernel design is closed (it cannot reach per-role parity,
        # being denied native registers and smem by co-residency).
        #
        # SGLANG_TWO_EXEC must be in the env BEFORE the extension loads: it selects
        # -DFLASHINFER_FA3_UPSTREAM=1, without which fa3_only_run is compiled out and every
        # forward silently falls back -- which invalidated two serving A/Bs.
        env["SGLANG_FLASHINFER_USE_PERSISTENT"] = "1"
        env["SGLANG_MIXED_ATTENTION_KERNEL"] = "persistent"
        env["SGLANG_TWO_EXEC"] = "1"
        env["SGLANG_FUSED_FA3_SM_SPLIT"] = "1"
        env["FLASHINFER_SM_PARTITION"] = "1"
        env["UP_STAGES"] = "2"
        env["SGLANG_FUSED_FA3_SRC"] = "/dev/shm/w/fi/tests/fused_fa3_persistent_ext.cu"
    elif method == "LPT":
        env["SGLANG_FLASHINFER_USE_PERSISTENT"] = "1"
    elif method.startswith("MTP"):
        # MTP-style speculative decoding (EAGLE3 chain draft, 4 verify tokens).
        #   MTP_LPT       stock sglang: prefill chunks and verify rows never share a step
        #   MTPMIX_LPT    the 4-mode step (prefill + verify in one target forward), FA2 only
        #   MTPMIX_SPLIT  the 4-mode step on the two-executor split
        env["SGLANG_FLASHINFER_USE_PERSISTENT"] = "1"
        if method.startswith("MTPMIX"):
            env["SGLANG_ALLOW_MIXED_CHUNK_SPEC"] = "1"
            env["SGLANG_MIXED_SPEC"] = "1"
        if "SPLIT" in method or "FUSED" in method:
            env["SGLANG_MIXED_ATTENTION_KERNEL"] = "persistent"
            env["SGLANG_TWO_EXEC"] = "1"
            env["SGLANG_FUSED_FA3_SM_SPLIT"] = "1"
            env["FLASHINFER_SM_PARTITION"] = "1"
            env["UP_STAGES"] = "2"
            env["SGLANG_FUSED_FA3_SRC"] = "/dev/shm/w/fi/tests/fused_fa3_persistent_ext.cu"
        if "FUSED" in method:
            env["SGLANG_FUSED_KERNEL_EXEC"] = "1"
        if "_EDF" in method:
            # EDF + SLO chunk control on the speculative server, step model fit from its own
            # STEPTRACE (tasks/perf_model/fit_mtp_step.py). The suffix picks the tokens/step
            # estimate that scales the per-step ITL budget: EDF0 a=1, EDFG global EWMA,
            # EDFR per-request EWMA.
            env["SGLANG_EDF_SCHEDULING"] = "1"
            env["SGLANG_EDF_LATENCY_MODEL"] = "linear:" + os.environ["MTP_STEP_MODEL"]
            env["SGLANG_TTFT_SLO_MS"] = os.environ.get("TTFT_SLO_MS", "5000")
            env["SGLANG_ITL_SLO_MS"] = os.environ.get("ITL_SLO_MS", "100")
            env["SGLANG_EDF_PLAN_OVERHEAD_MS"] = "0"
            # Ablations: EDFP = deadline priority only (no latency model, so no chunk control);
            # EDFGC = global-EWMA chunk control with FCFS admission (no priority scheduling);
            # EDFGQ = global EWMA, quantile-aware chunk control (edf_scheduler.ITL_QUANTILE).
            suf = method.split("_")[-1]
            env["SGLANG_EDF_ACCEPT_MODE"] = {"EDF0": "none", "EDFG": "global", "EDFR": "req",
                                             "EDFP": "none", "EDFGC": "global",
                                             "EDFGQ": "global"}[suf]
            if suf == "EDFGQ":
                # chunk control only for requests past their P90 slow-step allowance
                env["SGLANG_EDF_ITL_QUANTILE"] = "0.9"
            if suf == "EDFP":
                env["SGLANG_EDF_LATENCY_MODEL"] = ""
    elif method == "LPT_EDF":
        # Gated persistent kernel + SLO-aware chunk control driven by the
        # closed-form overlap cost model. Same EDF policy as the MLP path;
        # only the predictor differs (no checkpoints, no training).
        env["SGLANG_FLASHINFER_USE_PERSISTENT"] = "1"
        env["SGLANG_EDF_SCHEDULING"] = "1"
        env["SGLANG_EDF_LATENCY_MODEL"] = "analytic"
        env["SGLANG_TTFT_SLO_MS"] = os.environ.get("TTFT_SLO_MS", "5000")
        env["SGLANG_ITL_SLO_MS"] = os.environ.get("ITL_SLO_MS", "100")
        # The analytic model already carries all fixed overheads in c0; the
        # adaptive planner guard was tuned before the plan-sync fix and would
        # double-count 5-10 ms per step, over-throttling chunks.
        env["SGLANG_EDF_PLAN_OVERHEAD_MS"] = "0"
    elif method == "LPT_FORCE_BP":
        # Ablation: the whole persistent host path (sync-free plan, reused
        # out/lse buffers, gate evaluation) but every mixed batch routed to
        # BatchPrefill. Should be indistinguishable from DMC_CG; any gap is
        # host-side overhead rather than the kernel.
        env["SGLANG_FLASHINFER_USE_PERSISTENT"] = "1"
        env["SGLANG_MIXED_ATTENTION_KERNEL"] = "batch_prefill"
    else:
        # Defaults to 1; a true BatchPrefill baseline must disable it.
        env["SGLANG_FLASHINFER_USE_PERSISTENT"] = "0"
        env["SGLANG_DISABLE_MIXED_CG"] = "1"

    with socket.socket() as probe:
        probe.settimeout(1)
        if probe.connect_ex(("127.0.0.1", PORT)) == 0:
            raise RuntimeError(f"Port {PORT} is occupied; refusing to kill an unowned server")
    with open(log, "w") as lf:
        args_srv = [VENV_PY, "-m", "sglang.launch_server", "--model", MODEL,
                    "--attention-backend", "flashinfer", "--enable-mixed-chunk",
                    "--mem-fraction-static", "0.85", "--port", str(PORT),
                    "--host", "127.0.0.1", "--max-running-requests", "48",
                    # YARN_FACTOR / CONTEXT_LEN raise the window past 131072 for the >128K
                    # mixtures (factor 8 -> 262144); defaults reproduce every earlier run.
                    "--context-length", os.environ.get("CONTEXT_LEN", "131072"),
                    "--json-model-override-args",
                    json.dumps({"rope_scaling": {"factor": float(os.environ.get("YARN_FACTOR", "4.0")),
                                                 "original_max_position_embeddings": 32768,
                                                 "type": "yarn"}}),
                    "--watchdog-timeout", "600"]
        if os.environ.get("BENCH_CHUNK"):
            # Chunked-prefill size sweep; unset keeps sglang's default (8192 here).
            args_srv += ["--chunked-prefill-size", os.environ["BENCH_CHUNK"]]
        if os.environ.get("DISABLE_CUDA_GRAPH") == "1":
            args_srv.append("--disable-cuda-graph")
        # Extra server flags for diagnostics (e.g. --disable-overlap-schedule); empty by default.
        args_srv += os.environ.get("SERVER_EXTRA_ARGS", "").split()
        if method.startswith("MTP"):
            draft_tokens = int(os.environ.get("MTP_DRAFT_TOKENS", "4"))
            draft_steps = int(os.environ.get("MTP_SPEC_STEPS", "3"))
            if draft_tokens <= 0:
                raise ValueError("MTP_DRAFT_TOKENS must be positive")
            if draft_steps <= 0:
                raise ValueError("MTP_SPEC_STEPS must be positive")
            args_srv += ["--speculative-algorithm", "EAGLE3",
                         "--speculative-draft-model-path", "/dev/shm/w/qwen7b_eagle3_sgl",
                         "--speculative-num-steps", str(draft_steps), "--speculative-eagle-topk", "1",
                         "--speculative-num-draft-tokens", str(draft_tokens)]
        if method == "LPT_EDF" or ("_EDF" in method and not method.endswith("_EDFGC")):
            args_srv += ["--enable-priority-scheduling",
                         "--schedule-low-priority-values-first",
                         "--priority-scheduling-preemption-threshold", "999999"]
        server = subprocess.Popen(
            args_srv, stdout=lf, stderr=subprocess.STDOUT, env=env, start_new_session=True
        )
    try:
        return run_clients(method, scenario, outdir, env, server, log)
    finally:
        stop_owned_process(server)


def run_clients(method, scenario, outdir, env, server, log):
    if not wait_health(server):
        print(f"  server failed to start for {method}; see {log}", file=sys.stderr)
        return False
    subprocess.run(["curl", "-sf", f"http://127.0.0.1:{PORT}/flush_cache"],
                   capture_output=True)

    procs = {}
    # Start barrier (bench_serving reads BENCH_BARRIER_DIR): every stream tokenises and warms
    # up first, then all are released together, so stream start offsets no longer depend on
    # how long each one took to tokenise. Set BENCH_NO_BARRIER=1 to reproduce the old race.
    barrier = outdir / "barrier"
    shutil.rmtree(barrier, ignore_errors=True)
    if not os.environ.get("BENCH_NO_BARRIER"):
        env["BENCH_BARRIER_DIR"] = str(barrier)
    try:
        for sname, sargs in scenario["streams"].items():
            out = outdir / f"{method}_{sname}.json"
            if out.exists():
                out.rename(out.with_suffix(f".previous.{time.time_ns()}.json"))
            blog = open(outdir / f"bench_{method}_{sname}.log", "w")
            procs[sname] = (subprocess.Popen(
                [VENV_PY, "-m", "sglang.benchmark.serving", "--backend", "sglang",
                 "--host", "127.0.0.1", "--port", str(PORT), "--model", MODEL,
                 *sargs, *(["--max-concurrency", env["BENCH_MAX_CONCURRENCY"]] if env.get("BENCH_MAX_CONCURRENCY") else []),
                 "--warmup-requests", "4", "--output-file", str(out),
                 "--output-details", "--cache-report", "--disable-tqdm",
                 "--tag", env.get("BENCH_TAG", "")],
                stdout=blog, stderr=subprocess.STDOUT, env=env, start_new_session=True), blog)
        if env.get("BENCH_BARRIER_DIR"):
            started = time.monotonic()
            while True:
                failed = [name for name, (process, _) in procs.items() if process.poll() is not None]
                if failed:
                    raise RuntimeError(f"Clients exited before start barrier: {failed}")
                ready = len(list(barrier.glob("ready_*"))) if barrier.exists() else 0
                if ready == len(procs):
                    break
                if time.monotonic() - started >= 1800:
                    raise TimeoutError(f"Only {ready}/{len(procs)} clients reached the start barrier")
                if server.poll() is not None:
                    raise RuntimeError("Server exited while clients were warming up")
                time.sleep(0.2)
            (barrier / "go").touch()
            print(f"  barrier: {ready}/{len(procs)} streams ready; released", flush=True)
        for name, (process, _) in procs.items():
            if process.wait() != 0:
                raise RuntimeError(f"Benchmark client {name} failed; see its log")
            records = (outdir / f"{method}_{name}.json").read_text().splitlines()
            if len(records) != 1:
                raise RuntimeError(f"Expected one result record for {name}, got {len(records)}")
            result = json.loads(records[0])
            arguments = scenario["streams"][name]
            expected = int(arguments[arguments.index("--num-prompts") + 1])
            if result.get("completed") != expected or any(result.get("errors", [])):
                raise RuntimeError(f"Client {name} did not complete all {expected} requests")
        text = Path(log).read_text()
        fallbacks = text.lower().count("fallback")
        tracebacks = text.count("Traceback")
        fused_calls = max([int(count) for count in re.findall(r"FUSED_KERNEL_CALLS (\d+)", text)], default=0)
        mixed_steps = max([int(count) for count in re.findall(r"MIXEDSPEC_STEPS (\d+)", text)], default=0)
        print(f"  {method}: fallbacks={fallbacks} tracebacks={tracebacks} "
              f"fused_calls>={fused_calls} mixed_steps>={mixed_steps}", flush=True)
        if fallbacks or tracebacks or ("FUSED" in method and not fused_calls):
            raise RuntimeError("Server failed the workload execution gate")
        report = {"completed": True, "fallbacks": fallbacks, "tracebacks": tracebacks,
                  "fused_kernel_calls": fused_calls, "mixed_steps": mixed_steps}
        (outdir / f"{method}_validation.json").write_text(json.dumps(report, indent=2))
        return True
    finally:
        for process, blog in procs.values():
            stop_owned_process(process)
            blog.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", default="agent_plus_shortchat")
    ap.add_argument("--methods", default="DMC_CG,LPT")
    ap.add_argument("--outdir", default=None)
    ap.add_argument("--list", action="store_true")
    args = ap.parse_args()

    if args.list:
        for k, v in SCENARIOS.items():
            print(f"{k:24} {v['desc']}")
            for s, a in v["streams"].items():
                print(f"    {s:8} {' '.join(a[:6])} ...")
        return

    sc = SCENARIOS[args.scenario]
    if _env("STREAMS", ""):
        # One tenant alone (e.g. the unloaded reference that relative SLOs are scaled from).
        keep = _env("STREAMS", "").split(",")
        sc = {**sc, "streams": {k: v for k, v in sc["streams"].items() if k in keep}}
        if not sc["streams"]:
            sys.exit(f"STREAMS={keep} matches none of {list(SCENARIOS[args.scenario]['streams'])}")
    outdir = Path(args.outdir or (Path(__file__).parent / f"h800_mw_{args.scenario}"))
    outdir.mkdir(parents=True, exist_ok=True)
    print(f"scenario: {args.scenario} — {sc['desc']}")
    for method in args.methods.split(","):
        validation = outdir / f"{method}_validation.json"
        if validation.exists() and json.loads(validation.read_text()).get("completed") and all(
            (outdir / f"{method}_{stream}.json").exists() for stream in sc["streams"]
        ):
            print(f"  {method}: cached")
            continue
        print(f"  running {method} ...")
        if not run_method(method, sc, outdir):
            sys.exit(1)
    print(f"results in {outdir}")


if __name__ == "__main__":
    main()

import copy
import unittest

import torch

from sglang.srt.sampling.sampling_batch_info import SamplingBatchInfo


class MixedSamplingMergeTest(unittest.TestCase):
    def sampling(self, size):
        return SamplingBatchInfo(
            temperatures=torch.ones(size, 1), top_ps=torch.ones(size),
            top_ks=torch.ones(size, dtype=torch.int32), min_ps=torch.zeros(size),
            is_all_greedy=True, is_any_greedy=True, need_top_p_sampling=False,
            need_top_k_sampling=False, need_min_p_sampling=False, vocab_size=8,
            device="cpu",
        )

    def test_forward_merge_preserves_source_rows_and_penalties(self):
        prefill = self.sampling(1)
        running = self.sampling(2)
        prefill.acc_additive_penalties = torch.full((1, 8), 2.0)
        running.acc_scaling_penalties = torch.full((2, 8), 1.25)
        merged = copy.copy(prefill)
        merged.merge_batch(running)
        self.assertEqual(len(prefill), 1)
        self.assertEqual(len(running), 2)
        self.assertEqual(len(merged), 3)
        torch.testing.assert_close(merged.acc_additive_penalties[0], torch.full((8,), 2.0))
        torch.testing.assert_close(merged.acc_additive_penalties[1:], torch.zeros(2, 8))
        torch.testing.assert_close(merged.acc_scaling_penalties[0], torch.ones(8))
        torch.testing.assert_close(merged.acc_scaling_penalties[1:], torch.full((2, 8), 1.25))
        self.assertIsNone(prefill.acc_scaling_penalties)
        self.assertIsNone(running.acc_additive_penalties)

    def test_mixed_ownership_is_rejected_before_mutating_sampling(self):
        prefill = self.sampling(1)
        running = self.sampling(2)
        running.penalizer_orchestrator = object()
        with self.assertRaisesRegex(ValueError, "forward-only sampling state"):
            prefill.merge_batch(running)
        self.assertEqual(len(prefill), 1)


if __name__ == "__main__":
    unittest.main()

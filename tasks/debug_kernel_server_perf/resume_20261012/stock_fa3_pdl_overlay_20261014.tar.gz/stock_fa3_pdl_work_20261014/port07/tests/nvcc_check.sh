#!/bin/bash
# First real compile of the overlay. nvcc must parse our headers against 0.7's tree.
#
# Builds a MERGED include tree rather than relying on -I ordering. Both 0.7's headers and ours
# use RELATIVE includes ("../cp_async.cuh", "../exception.h"), which resolve relative to the
# including file -- so a partial overlay that mirrors only flashinfer/attention/ breaks every one
# of them regardless of include order. Copying 0.7's tree and laying our files on top gives each
# header the siblings it expects, and is what the real extension build must do too.
set -u
W=${W:-/dev/shm/w}
OVL=$W/port07/include
DATA=$($W/venv/bin/python -c "import flashinfer,os;print(os.path.join(os.path.dirname(flashinfer.__file__),'data'))")
# Asked of flashinfer, not globbed: 0.7 inserts an arch segment and sglang redirects the
# cache base at import time, so the 0.3.1-era path is wrong on both counts. sglang is
# imported first on purpose -- it applies that redirect, and the real build runs inside
# the sglang process, so reading the env without it points at a directory nothing writes.
GEN=$(PYTHONPATH=$W/up/python $W/venv/bin/python -c "import sglang; from flashinfer.jit import env as e; import glob; d=glob.glob(str(e.FLASHINFER_GEN_SRC_DIR)+'/batch_attention_with*'); print(d[0] if d else '')" 2>/dev/null)
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
MERGED=$TMP/inc
mkdir -p "$MERGED"
cp -r "$DATA/include/." "$MERGED/"          # 0.7's full tree
cp -r "$OVL/." "$MERGED/"                   # our overlay on top
echo "merged tree: $MERGED"
echo "overridden:"; (cd "$OVL" && find . -name '*.cuh' | sed 's|^\./|  |')
# Two TUs: a narrow one that must always parse, and the full fused kernel. Keeping them
# separate means a regression in the base files is distinguishable from one in the kernel.
cat > "$TMP/tu.cu" <<'CU'
#include <flashinfer/attention/fused_plan.cuh>
#include <flashinfer/attention/persistent.cuh>
int main() { return 0; }
CU
cat > "$TMP/tu_fused.cu" <<'CU'
#include <flashinfer/attention/fused_plan.cuh>
#include <flashinfer/attention/persistent_fa3_fused.cuh>
int main() { return 0; }
CU
INC="-I$MERGED -I$DATA/csrc -I$DATA/cutlass/include -I$DATA/cutlass/tools/util/include -I$DATA/spdlog/include"
[ -n "${GEN:-}" ] && INC="$INC -I$GEN"
/usr/local/cuda/bin/nvcc -std=c++20 --expt-relaxed-constexpr -arch=sm_90a \
  -DFLASHINFER_FUSED_PLAN_WITH_CUDA -c "$TMP/tu.cu" -o "$TMP/tu.o" $INC 2>&1 \
  | grep -E "error|warning: .*(undefined|not declared)" | head -30
if [ -f "$TMP/tu.o" ]; then echo "NVCC_BASE_OK"; else echo "NVCC_BASE_FAILED"; fi
echo "--- full fused TU ---"
/usr/local/cuda/bin/nvcc -std=c++20 --expt-relaxed-constexpr -arch=sm_90a \
  -DFLASHINFER_FUSED_PLAN_WITH_CUDA -DFLASHINFER_SM90_SUPPRESS_UNSUFFIXED_NAMES=1 \
  -c "$TMP/tu_fused.cu" -o "$TMP/tu_fused.o" $INC 2>&1 \
  | grep -E "error" | head -25
if [ -f "$TMP/tu_fused.o" ]; then echo "NVCC_FUSED_OK"; else echo "NVCC_FUSED_FAILED"; fi

# The TU that actually INSTANTIATES the kernel. The two TUs above only parse headers: a template
# is type-checked where it is instantiated, and `cuobjdump -elf` on their object reports ZERO
# device kernels, so an OK there says almost nothing about the kernel body. This one is the real
# gate, and it is also what the loader compiles at runtime.
echo "--- instantiating TU (fused_fa3_persistent_ext.cu) ---"
EXT=$W/port07/tests/fused_fa3_persistent_ext.cu
TORCH=$($W/venv/bin/python -c "import torch,os;print(os.path.dirname(torch.__file__))" 2>/dev/null)
TINC="-I$TORCH/include -I$TORCH/include/torch/csrc/api/include"
/usr/local/cuda/bin/nvcc -std=c++20 --expt-relaxed-constexpr -arch=sm_90a \
  -DFLASHINFER_FUSED_PLAN_WITH_CUDA -DFLASHINFER_SM90_SUPPRESS_UNSUFFIXED_NAMES=1 \
  -c "$EXT" -o "$TMP/ext.o" $INC $TINC 2>&1 \
  | grep -E "error" | head -40
if [ -f "$TMP/ext.o" ]; then
  echo "device kernels: $(cuobjdump -elf "$TMP/ext.o" 2>/dev/null | grep -c '\.text\.')"
  echo "NVCC_EXT_OK"
else
  echo "NVCC_EXT_FAILED"
fi

# The unified-wgmma path, which is the ONLY one that instantiates store_partial. The default TU
# compiles with fa3_has_split_kv false, so its `if constexpr` branch is discarded and an OK there
# says nothing about that function -- three green lights in this port have already meant less
# than they looked. This step also runs a NULL CASE: it injects a type error inside
# store_partial and requires the compile to FAIL, so a gate that has stopped covering the
# function is reported as such instead of passing quietly.
echo "--- unified-wgmma TU (instantiates store_partial) ---"
UWFLAGS="-DFLASHINFER_FUSED_PLAN_WITH_CUDA -DFLASHINFER_SM90_SUPPRESS_UNSUFFIXED_NAMES=1 -DFLASHINFER_FUSED_UNIFIED_WGMMA=1"
/usr/local/cuda/bin/nvcc -std=c++20 --expt-relaxed-constexpr -arch=sm_90a $UWFLAGS \
  -c "$EXT" -o "$TMP/uw.o" $INC $TINC 2>&1 | grep -E "error" | head -25
if [ -f "$TMP/uw.o" ]; then
  echo "device kernels: $(cuobjdump -elf "$TMP/uw.o" 2>/dev/null | grep -c '\.text\.')"
  echo "NVCC_UNIFIED_OK"
else
  echo "NVCC_UNIFIED_FAILED"
fi

echo "--- null case: store_partial must actually be compiled ---"
POISON="$MERGED/flashinfer/attention/hopper/epilogue.cuh"
python3 - "$POISON" <<'PY'
import sys
p = sys.argv[1]
s = open(p).read()
a = '    const int chunks = num_kv_chunks > 0 ? num_kv_chunks : 1;'
assert a in s, 'anchor gone -- update the null case'
open(p, 'w').write(s.replace(a, a + '\n    { int* np_ = num_kv_chunks; (void)np_; }', 1))
PY
/usr/local/cuda/bin/nvcc -std=c++20 --expt-relaxed-constexpr -arch=sm_90a $UWFLAGS \
  -c "$EXT" -o "$TMP/uwp.o" $INC $TINC > /dev/null 2>&1
if [ -f "$TMP/uwp.o" ]; then
  echo "NULL_CASE_FAILED: the poisoned store_partial still compiled, so it is being discarded"
else
  echo "NULL_CASE_OK: the gate does cover store_partial"
fi

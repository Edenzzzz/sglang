import math
import re
from types import SimpleNamespace
import unittest

import torch


def make_case(query_lengths, kv_lengths, heads=28, kv_heads=4, page_size=1, split_size=None, strided=False):
    import flashinfer

    if len(query_lengths) != len(kv_lengths) or any(query > length for query, length in zip(query_lengths, kv_lengths)):
        raise ValueError("Invalid causal fixture lengths")
    page_counts = [(length + page_size - 1) // page_size for length in kv_lengths]
    query_indptr = torch.tensor([0, *torch.tensor(query_lengths).cumsum(0).tolist()], dtype=torch.int32, device="cuda")
    kv_indptr = torch.tensor([0, *torch.tensor(page_counts).cumsum(0).tolist()], dtype=torch.int32, device="cuda")
    page_indices = torch.randperm(sum(page_counts), device="cuda", dtype=torch.int64).to(torch.int32)
    last_page = torch.tensor([(length - 1) % page_size + 1 for length in kv_lengths], dtype=torch.int32, device="cuda")
    query = torch.randn(sum(query_lengths) * (2 if strided else 1), heads, 128, device="cuda", dtype=torch.bfloat16)
    if strided:
        query = query[::2]
    key = torch.randn(sum(page_counts), page_size, kv_heads, 128, device="cuda", dtype=torch.bfloat16)
    value = torch.randn(sum(page_counts) * (2 if strided else 1), page_size, kv_heads, 128, device="cuda", dtype=torch.bfloat16)
    if strided:
        value = value[::2]
    workspace = torch.empty(128 << 20, dtype=torch.uint8, device="cuda")
    wrapper = flashinfer.BatchPrefillWithPagedKVCacheWrapper(workspace, kv_layout="NHD", backend="fa2")
    options = {"fixed_split_size": split_size} if split_size is not None else {}
    wrapper.plan(query_indptr, kv_indptr, page_indices, last_page, heads, kv_heads, 128,
                 page_size, causal=True, q_data_type=torch.bfloat16, kv_data_type=torch.bfloat16, **options)
    output = torch.empty(query.shape, device="cuda", dtype=torch.bfloat16)
    empty_lse = torch.empty(0, device="cuda", dtype=torch.float32)
    timeline = torch.empty(0, device="cuda", dtype=torch.int64)
    arguments = (
        query, key, value, wrapper._qo_indptr_buf, wrapper._paged_kv_indptr_buf,
        wrapper._paged_kv_indices_buf, wrapper._paged_kv_last_page_len_buf,
        output, empty_lse, wrapper._float_workspace_buffer, wrapper._int_workspace_buffer,
        list(wrapper._plan_info), 1 / math.sqrt(128),
    )
    return SimpleNamespace(query=query, key=key, value=value, output=output, wrapper=wrapper,
                           arguments=arguments, timeline=timeline, maximum_query=max(query_lengths),
                           query_lengths=query_lengths, kv_lengths=kv_lengths, page_counts=page_counts,
                           page_indices=page_indices, kv_heads=kv_heads, heads=heads)


def execute(case, tile=32, pdl=False):
    torch.ops.native_fa2_q32.run(*case.arguments, pdl, pdl, case.timeline, tile, case.maximum_query)


def reference(case):
    output = torch.empty(case.query.shape, device="cuda", dtype=torch.float32)
    query_begin = page_begin = 0
    group = case.heads // case.kv_heads
    for query_length, kv_length, pages in zip(case.query_lengths, case.kv_lengths, case.page_counts, strict=True):
        indices = case.page_indices[page_begin:page_begin + pages].long()
        key = case.key[indices].reshape(-1, case.kv_heads, 128)[:kv_length].float()
        value = case.value[indices].reshape(-1, case.kv_heads, 128)[:kv_length].float()
        query = case.query[query_begin:query_begin + query_length].float().reshape(query_length, case.kv_heads, group, 128)
        logits = torch.einsum("thgd,khd->hgtk", query, key) / math.sqrt(128)
        mask = torch.arange(kv_length, device="cuda")[None, :] > kv_length - query_length + torch.arange(query_length, device="cuda")[:, None]
        logits.masked_fill_(mask, -float("inf"))
        output[query_begin:query_begin + query_length] = torch.einsum("hgtk,khd->thgd", logits.softmax(-1), value).reshape(query_length, case.heads, 128)
        query_begin += query_length
        page_begin += pages
    return output


def assert_numerical(actual, expected):
    if not torch.isfinite(actual).all():
        raise AssertionError("Nonfinite attention output")
    relative = (actual.float() - expected.float()).norm(dim=-1) / expected.float().norm(dim=-1).clamp_min(1e-6)
    worst = float(relative.max())
    if worst >= 0.02:
        raise AssertionError(f"Worst per-head relative error {worst}")
    return worst


@unittest.skipUnless(torch.cuda.is_available(), "requires CUDA")
class TestNativeQ32(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from load_native_q32 import build

        torch.backends.cuda.matmul.allow_tf32 = False
        build()

    def test_varlen_and_physical_layouts(self):
        torch.manual_seed(20261015)
        fixtures = (
            ([4, 3], [65, 257], 28, 1, None, False),
            ([1, 4], [1, 8192], 28, 1, 512, False),
            ([5, 8], [65, 513], 16, 1, 128, False),
            ([3, 4], [511, 2048], 28, 128, 2, False),
            ([4, 4], [257, 1024], 28, 1, 256, True),
        )
        for query, lengths, heads, page, split, strided in fixtures:
            with self.subTest(query=query, kv=lengths, page=page, strided=strided):
                case = make_case(query, lengths, heads=heads, page_size=page, split_size=split, strided=strided)
                self.assertEqual(case.wrapper._plan_info[3], 64)
                expected = reference(case)
                public = case.wrapper.run(case.query, (case.key, case.value)).clone()
                assert_numerical(public, expected)
                for tile in (0, 32):
                    for pdl in (False, True):
                        case.output.fill_(float("nan"))
                        execute(case, tile, pdl)
                        torch.cuda.synchronize()
                        assert_numerical(case.output, expected)
                        if tile == 0:
                            torch.testing.assert_close(case.output, public, rtol=0, atol=0)

    def test_changed_input_graph_and_consumer(self):
        torch.manual_seed(1701)
        case = make_case([3, 4], [513, 4096], split_size=256)
        projection = torch.randn(case.heads * 128, 64, device="cuda", dtype=torch.bfloat16)
        for warmup in range(3):
            execute(case, 32, True)
            case.output.flatten(1) @ projection
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            execute(case, 32, True)
            projected = case.output.flatten(1) @ projection
        for iteration in range(4):
            case.query.normal_()
            case.key.normal_()
            case.value.normal_()
            case.output.fill_(float("nan"))
            graph.replay()
            snapshot = case.output.clone()
            consumer = projected.clone()
            torch.cuda.synchronize()
            assert_numerical(snapshot, reference(case))
            execute(case, 32, False)
            torch.cuda.synchronize()
            torch.testing.assert_close(case.output, snapshot, rtol=0, atol=0)
            torch.testing.assert_close(consumer, snapshot.flatten(1) @ projection, rtol=0, atol=0)

    def test_host_proof_guards(self):
        case = make_case([8], [128])
        with self.assertRaisesRegex(RuntimeError, "packed query"):
            execute(case)
        case = make_case([2], [128])
        with self.assertRaisesRegex(RuntimeError, "original64"):
            execute(case)
        case = make_case([4], [128])
        with self.assertRaisesRegex(RuntimeError, "override"):
            execute(case, tile=16)
        case.maximum_query = 0
        with self.assertRaisesRegex(RuntimeError, "packed query"):
            execute(case)

    def test_executed_geometry(self):
        case = make_case([4] * 8, [4096] * 8)
        execute(case)
        torch.cuda.synchronize()
        with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CUDA]) as profile:
            execute(case)
            torch.cuda.synchronize()
        geometries = []
        for event in profile.events():
            if "BatchPrefillWithPagedKVCacheKernel" not in event.name or "KernelTraits<" not in event.name:
                continue
            parameters = event.name.split("KernelTraits<", 1)[1].split(",")[1:8]
            values = [re.fullmatch(r"\s*(\d+)u?\s*", value) for value in parameters]
            self.assertTrue(all(values), event.name)
            geometry = [int(value.group(1)) for value in values]
            self.assertEqual(geometry[:2], [32, 1])
            self.assertEqual(geometry[3:], [8, 8, 2, 2])
            geometries.append(geometry)
        self.assertTrue(geometries)
        print("NATIVE_Q32_EXECUTED_GEOMETRY", geometries, flush=True)


if __name__ == "__main__":
    unittest.main(verbosity=2)

import importlib.util
import os
from pathlib import Path

from torch.utils.cpp_extension import load


def build():
    root = Path(__file__).resolve().parent
    merged = Path(
        os.environ.get("STOCK_FA3_MERGED", "/tmp/stock_fa3_unsplit_merged_20261014")
    )
    source = Path(os.environ.get("STOCK_FLASH_ATTENTION", root / "flash-attention"))
    loader_path = (
        root / "up_racefix/python/sglang/srt/layers/attention/fused_fa3_loader.py"
    )
    specification = importlib.util.spec_from_file_location(
        "stock_fa3_header_loader", loader_path
    )
    loader = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(loader)
    os.environ["SGLANG_FUSED_MERGED_DIR"] = str(merged)
    merged.mkdir(parents=True, exist_ok=True)
    link = merged / "flash-attention"
    if not link.exists():
        link.symlink_to(source, target_is_directory=True)
    elif link.resolve() != source.resolve():
        raise ValueError("stock FlashAttention source link points to a different tree")
    data = loader.fi_data_dir()
    includes = loader._merged_include_tree(data, str(root / "port07"))
    return load(
        name="stock_fa3_pdl",
        sources=[str(root / "stock_fa3_pdl.cu")],
        extra_include_paths=[
            includes,
            str(Path(data) / "cutlass/include"),
            str(Path(data) / "cutlass/tools/util/include"),
            str(Path(data) / "cccl/libcudacxx/include"),
            str(Path(data) / "cccl/thrust"),
            str(Path(data) / "cccl/cub"),
            str(source / "hopper"),
        ],
        extra_cuda_cflags=[
            "-std=c++20",
            "-O3",
            "-arch=sm_90a",
            "--expt-relaxed-constexpr",
            "--expt-extended-lambda",
            "--use_fast_math",
            "-DNDEBUG",
            "-DCUTE_SM90_EXTENDED_MMA_SHAPES_ENABLED",
            "-DCUTLASS_ENABLE_GDC_FOR_SM90",
            "-DCUTLASS_DEBUG_TRACE_LEVEL=0",
            "-DSTOCK_FA3_UNSPLIT_SPECIALIZE=" + os.environ.get("STOCK_FA3_UNSPLIT_SPECIALIZE", "0"),
            "--threads",
            "8",
        ],
        extra_cflags=["-std=c++20", "-O3", "-DNDEBUG"],
        is_python_module=False,
        verbose=True,
    )


if __name__ == "__main__":
    print(build(), flush=True)

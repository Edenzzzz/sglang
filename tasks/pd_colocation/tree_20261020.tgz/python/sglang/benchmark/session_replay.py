import asyncio
import json
import os
import time
from pathlib import Path

import numpy as np


async def wait_for_benchmark_start(directory=None, timeout_s=1800):
    directory = directory or os.environ.get("BENCH_BARRIER_DIR")
    if not directory:
        return
    barrier = Path(directory)
    barrier.mkdir(parents=True, exist_ok=True)
    ready = barrier / f"ready_{os.getpid()}"
    ready.touch()
    deadline = time.monotonic() + timeout_s
    try:
        while not (barrier / "go").exists():
            if time.monotonic() >= deadline:
                raise TimeoutError(f"Benchmark start barrier timed out: {barrier}")
            await asyncio.sleep(0.02)
    finally:
        ready.unlink(missing_ok=True)


async def replay_sessions(
    requests, send_request, request_rate, replay_timestamps=False, slowdown_factor=1.0
):
    """Serialize each session regardless of whether recorded think times are replayed."""
    concurrency = os.environ.get("BENCH_SESSION_CONCURRENCY")
    if concurrency is not None:
        if request_rate != float("inf"):
            raise ValueError("program-concurrency replay requires request-rate inf")
        path = os.environ.get("BENCH_SESSION_AUDIT_FILE")
        if not path:
            raise ValueError("program-concurrency replay requires an audit output path")
        from sglang.benchmark.session_concurrency import replay_concurrent_sessions

        outputs, report = await replay_concurrent_sessions(
            requests,
            send_request,
            int(concurrency),
            replay_delays=replay_timestamps,
            delay_scale=slowdown_factor,
        )
        Path(path).write_text(json.dumps(report, indent=2) + "\n")
        print("PROGRAM_CONCURRENCY", json.dumps({key: value for key, value in report.items() if key not in ("events", "session_rounds")}), flush=True)
        return outputs
    if request_rate <= 0 or slowdown_factor < 0:
        raise ValueError("Session arrival rate must be positive and slowdown nonnegative")
    sessions = {}
    for index, request in enumerate(requests):
        if request.session_id is None or request.round_index is None:
            raise ValueError("Session replay requires session_id and round_index")
        sessions.setdefault(request.session_id, []).append((index, request))
    for records in sessions.values():
        records.sort(key=lambda item: item[1].round_index)
    outputs = [None] * len(requests)

    async def replay_one(records, start_delay):
        if start_delay:
            await asyncio.sleep(start_delay)
        for position, (index, request) in enumerate(records):
            if position and replay_timestamps and request.inter_round_delay_s:
                await asyncio.sleep(request.inter_round_delay_s * slowdown_factor)
            output = await send_request(request)
            if not output.success:
                raise RuntimeError(
                    f"Session {request.session_id} round {request.round_index} failed; "
                    "dependent rounds were not issued"
                )
            outputs[index] = output

    tasks = []
    start_delay = 0.0
    for records in sessions.values():
        tasks.append(asyncio.create_task(replay_one(records, start_delay)))
        if request_rate != float("inf"):
            start_delay += float(np.random.exponential(1.0 / request_rate))
    try:
        await asyncio.gather(*tasks)
    finally:
        for task in tasks:
            if not task.done():
                task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
    return outputs

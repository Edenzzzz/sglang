from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _first_argmax(values, indices, valid):
    first_nan = tl.min(tl.where(valid & (values != values), indices, 2147483647), 0)
    maximum = tl.max(tl.where(valid & (values == values), values, -float("inf")), 0)
    first_max = tl.min(tl.where(valid & (values == maximum), indices, 2147483647), 0)
    return tl.where(first_nan != 2147483647, first_nan, first_max), tl.where(
        first_nan != 2147483647, float("nan"), maximum
    )


@triton.jit
def _verify_partial_argmax(
    logits,
    partial_values,
    partial_indices,
    predictions,
    row_stride,
    VOCAB: tl.constexpr,
    SPLITS: tl.constexpr,
    BLOCK: tl.constexpr,
):
    row = tl.program_id(0).to(tl.int64)
    split = tl.program_id(1)
    columns = split * BLOCK + tl.arange(0, BLOCK)
    valid = columns < VOCAB
    values = tl.load(logits + row * row_stride + columns, valid, other=-float("inf"))
    index, maximum = _first_argmax(values.to(tl.float32), columns, valid)
    tl.store(partial_values + row * SPLITS + split, maximum)
    tl.store(partial_indices + row * SPLITS + split, index)
    if split == 0:
        tl.store(predictions + row, 0)


@triton.jit
def _verify_target_token(partial_values, partial_indices, row, SPLITS: tl.constexpr,
                         BLOCK: tl.constexpr):
    splits = tl.arange(0, BLOCK)
    offsets = row.to(tl.int64) * SPLITS + splits
    values = tl.load(partial_values + offsets, splits < SPLITS, other=-float("inf"))
    indices = tl.load(partial_indices + offsets, splits < SPLITS, other=2147483647)
    token, maximum = _first_argmax(values, indices, splits < SPLITS)
    return token


@triton.jit
def _verify_finalize(
    partial_values,
    partial_indices,
    candidates,
    retrieve_index,
    retrieve_next_token,
    retrieve_next_sibling,
    predictions,
    accepted_lengths,
    accepted_indices,
    DRAFT_TOKENS: tl.constexpr,
    MAX_DEPTH: tl.constexpr,
    SPLITS: tl.constexpr,
    BLOCK_SPLITS: tl.constexpr,
    BLOCK_DEPTH: tl.constexpr,
):
    request = tl.program_id(0)
    base = request * DRAFT_TOKENS
    depth_offsets = tl.arange(0, BLOCK_DEPTH)
    current_node = tl.full((), 0, tl.int32)
    last_row = tl.load(retrieve_index + base).to(tl.int32)
    result_indices = tl.where(depth_offsets == 0, last_row, -1)
    accepted = tl.full((), 0, tl.int32)
    active = tl.full((), True, tl.int1)
    target = _verify_target_token(
        partial_values, partial_indices, last_row, SPLITS, BLOCK_SPLITS
    )
    for depth in range(1, MAX_DEPTH):
        if active:
            child = tl.load(retrieve_next_token + base + current_node).to(tl.int32)
            matched = tl.full((), False, tl.int1)
            for sibling_visit in range(DRAFT_TOKENS):
                if (child != -1) & ~matched:
                    draft = tl.load(candidates + base + child)
                    if draft == target:
                        tl.store(predictions + last_row, target)
                        current_node = child
                        last_row = tl.load(retrieve_index + base + child).to(tl.int32)
                        accepted += 1
                        result_indices = tl.where(depth_offsets == accepted, last_row, result_indices)
                        matched = True
                    else:
                        child = tl.load(retrieve_next_sibling + base + child).to(tl.int32)
            active = matched
            if matched:
                target = _verify_target_token(
                    partial_values, partial_indices, last_row, SPLITS, BLOCK_SPLITS
                )
    tl.store(predictions + last_row, target)
    tl.store(accepted_lengths + request, accepted + 1)
    tl.store(accepted_indices + request * MAX_DEPTH + depth_offsets,
             result_indices, depth_offsets < MAX_DEPTH)


def fused_greedy_verify(
    logits: torch.Tensor,
    candidates: torch.Tensor,
    retrieve_index: torch.Tensor,
    retrieve_next_token: torch.Tensor,
    retrieve_next_sibling: torch.Tensor,
    max_tree_depth: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Return predictions, accepted lengths (including bonus), and accepted indices."""
    if logits.ndim != 2 or logits.stride(1) != 1 or not logits.is_cuda:
        raise ValueError("logits must be a CUDA matrix contiguous along vocabulary")
    if logits.dtype not in (torch.float16, torch.bfloat16, torch.float32):
        raise ValueError("logits must have float16, bfloat16 or float32 dtype")
    if candidates.ndim != 2:
        raise ValueError("candidates must have shape [batch, draft_tokens]")
    batch_size, draft_tokens = candidates.shape
    if logits.shape[0] != batch_size * draft_tokens or logits.shape[1] == 0:
        raise ValueError("logit rows must match candidates and vocabulary must be nonempty")
    if not 1 <= max_tree_depth <= draft_tokens:
        raise ValueError("max_tree_depth must be between 1 and draft_tokens")
    for tensor in (candidates, retrieve_index, retrieve_next_token, retrieve_next_sibling):
        if (tensor.shape != candidates.shape or tensor.device != logits.device
                or not tensor.is_contiguous() or tensor.dtype not in (torch.int32, torch.int64)):
            raise ValueError("tree tensors must be contiguous integer matrices matching candidates")
    predictions = torch.empty(logits.shape[0], dtype=torch.int32, device=logits.device)
    accepted_lengths = torch.empty(batch_size, dtype=torch.int32, device=logits.device)
    accepted_indices = torch.empty((batch_size, max_tree_depth), dtype=torch.int32, device=logits.device)
    if batch_size == 0:
        return predictions, accepted_lengths, accepted_indices
    block = 4096
    splits = triton.cdiv(logits.shape[1], block)
    partial_values = torch.empty((logits.shape[0], splits), dtype=torch.float32, device=logits.device)
    partial_indices = torch.empty_like(partial_values, dtype=torch.int32)
    _verify_partial_argmax[(logits.shape[0], splits)](
        logits, partial_values, partial_indices, predictions, logits.stride(0),
        VOCAB=logits.shape[1], SPLITS=splits, BLOCK=block, num_warps=4,
    )
    _verify_finalize[(batch_size,)](
        partial_values, partial_indices, candidates, retrieve_index,
        retrieve_next_token, retrieve_next_sibling, predictions, accepted_lengths,
        accepted_indices, DRAFT_TOKENS=draft_tokens, MAX_DEPTH=max_tree_depth,
        SPLITS=splits, BLOCK_SPLITS=triton.next_power_of_2(splits),
        BLOCK_DEPTH=triton.next_power_of_2(max_tree_depth), num_warps=4,
    )
    return predictions, accepted_lengths, accepted_indices

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Callable

from sglang.srt.disaggregation.utils import DisaggregationMode
from sglang.srt.managers.load_snapshot import (
    DisaggregationMetrics,
    LoadSnapshot,
    LoRAMetrics,
    MemoryMetrics,
    QueueMetrics,
    SpeculativeMetrics,
)
from sglang.srt.runtime_context import get_lora, get_parallel

if TYPE_CHECKING:
    from sglang.srt.managers.scheduler_components.pool_stats_observer import (
        SchedulerPoolStatsObserver,
    )
    from sglang.srt.managers.tp_worker import BaseTpWorker
    from sglang.srt.mem_cache.allocator import BaseTokenToKVPoolAllocator
    from sglang.srt.server_args import ServerArgs
    from sglang.srt.speculative.spec_info import SpeculativeAlgorithm


logger = logging.getLogger(__name__)


# Per-inquirer decode-step EWMA state (the dataclass is frozen): last (count, step_us) totals and the EWMA.
_DECODE_STEP_STATE: dict = {}


@dataclass(kw_only=True, slots=True, frozen=True)
class SchedulerLoadInquirer:
    disaggregation_mode: DisaggregationMode
    server_args: ServerArgs
    max_total_num_tokens: int
    max_running_requests: int
    pool_stats_observer: SchedulerPoolStatsObserver
    tp_worker: BaseTpWorker
    token_to_kv_pool_allocator: BaseTokenToKVPoolAllocator
    spec_algorithm: SpeculativeAlgorithm
    get_running_batch: Callable
    get_waiting_queue: Callable
    waiting_queue_prefix_matched: Callable
    get_recent_cache_hit_rate: Callable
    get_stats: Callable
    get_chunked_req: Callable
    get_disagg_prefill_bootstrap_queue: Callable
    get_disagg_prefill_inflight_queue: Callable
    get_disagg_decode_prealloc_queue: Callable
    get_disagg_decode_transfer_queue: Callable
    get_spec_total_num_accept_tokens: Callable
    get_spec_total_num_forward_ct: Callable
    get_total_prefill_uncached_tokens: Callable
    get_total_prefill_busy_us: Callable
    get_decode_moment_totals: Callable

    def _get_num_pending_tokens(self, chunk_deduct: int = 0) -> int:
        """Get the total number of tokens pending prefill.

        This includes tokens from waiting queue requests plus remaining tokens
        from the currently chunked request.

        Args:
            chunk_deduct: extra tokens to subtract from the chunked request's
                remaining count. At batch-scheduling time the current chunk
                has been planned but ``prefix_len`` does not yet include it,
                so callers pass ``extend_input_len`` here. At load-reporting
                time ``prefix_len`` is already up-to-date, so the default
                0 is correct.
        """
        num_pending_tokens = sum(req.seqlen for req in self.get_waiting_queue())
        if self.get_chunked_req() is not None:
            req = self.get_chunked_req()
            num_pending_tokens += req.seqlen - req.prefix_len - chunk_deduct
        return num_pending_tokens

    def get_num_waiting_uncached_tokens(self) -> int:
        """Estimate input tokens waiting for prefill compute."""
        if self.disaggregation_mode == DisaggregationMode.DECODE:
            return 0
        waiting_queue_prefix_matched = self.waiting_queue_prefix_matched()
        cache_miss_rate = 1.0 - self.get_recent_cache_hit_rate()
        num_tokens = 0
        for req in self.get_waiting_queue():
            if waiting_queue_prefix_matched:
                num_tokens += max(0, req.seqlen - req.num_matched_prefix_tokens)
            else:
                num_tokens += int(req.seqlen * cache_miss_rate)
        cr = self.get_chunked_req()
        if cr is not None:
            num_tokens += max(0, cr.seqlen - cr.prefix_len)
        return num_tokens

    def _decode_step_ms(self) -> float:
        tot = self.get_decode_moment_totals()
        st = _DECODE_STEP_STATE.setdefault(id(self), {"last": None, "ewma": 0.0})
        last = st["last"]
        if last is not None and tot[0] > last[0]:
            ms = (tot[2] - last[1]) / (tot[0] - last[0]) / 1000.0
            st["ewma"] = ms if st["ewma"] == 0.0 else 0.8 * st["ewma"] + 0.2 * ms
        st["last"] = (tot[0], tot[2])
        return round(st["ewma"], 3)

    def get_loads(self) -> LoadSnapshot:
        """Build the per-DP-rank load snapshot for DP balancing and /v1/loads."""
        stats = self.get_stats()
        num_running_reqs = len(self.get_running_batch().reqs)

        waiting_queues = [self.get_waiting_queue()]
        pending_token_queues = [self.get_waiting_queue()]
        awaiting_kv_tokens = 0
        if self.disaggregation_mode == DisaggregationMode.PREFILL:
            prefill_bootstrap_queue = self.get_disagg_prefill_bootstrap_queue().queue
            waiting_queues.append(prefill_bootstrap_queue)
            pending_token_queues.append(prefill_bootstrap_queue)
        elif self.disaggregation_mode == DisaggregationMode.DECODE:
            decode_prealloc_queue = self.get_disagg_decode_prealloc_queue().queue
            decode_transfer_queue = self.get_disagg_decode_transfer_queue().queue
            decode_retracted_queue = (
                self.get_disagg_decode_prealloc_queue().retracted_queue
            )
            waiting_queues.append(decode_prealloc_queue)
            waiting_queues.append(decode_transfer_queue)
            waiting_queues.append(decode_retracted_queue)
            # In disaggregated decode, transfer-queue requests and transferred
            # waiting-queue requests have already pre-allocated decode-side KV
            # slots, so they are already included in num_used_tokens.
            pending_token_queues = [decode_prealloc_queue, decode_retracted_queue]
            # KV not yet arrived from the prefill side.
            awaiting_kv_tokens = sum(
                req.seqlen
                for queue in (decode_prealloc_queue, decode_transfer_queue)
                for req in queue
            )

        num_waiting_reqs = sum(len(queue) for queue in waiting_queues)
        num_used_tokens, kv_token_usage = (
            self.pool_stats_observer.get_pool_stats().get_kv_token_stats()
        )
        num_total_tokens = num_used_tokens + sum(
            req.seqlen for queue in pending_token_queues for req in queue
        )
        num_active_tokens = max(0, num_total_tokens - awaiting_kv_tokens)

        memory = None
        try:
            memory = MemoryMetrics(
                weight_gb=round(self.tp_worker.model_runner.weight_load_mem_usage, 3),
                kv_cache_gb=round(
                    self.token_to_kv_pool_allocator.get_kvcache().mem_usage, 3
                ),
                graph_gb=round(sum(self.tp_worker.graph_memory_usage.values()), 3),
                token_capacity=int(self.max_total_num_tokens),
            )
        except (AttributeError, TypeError) as e:
            logger.debug(f"Memory metrics not available: {e}")

        speculative = None
        if (
            not self.spec_algorithm.is_none()
            and self.get_spec_total_num_forward_ct() > 0
        ):
            speculative = SpeculativeMetrics(
                accept_length=(
                    self.get_spec_total_num_accept_tokens()
                    / self.get_spec_total_num_forward_ct()
                ),
                accept_rate=stats.spec_accept_rate,
            )

        lora = None
        if get_lora().enable_lora:
            lora = LoRAMetrics(
                slots_used=stats.lora_pool_slots_used,
                slots_total=stats.lora_pool_slots_total,
                utilization=stats.lora_pool_utilization,
            )

        mode_str = "null"
        prefill_bootstrap = prefill_inflight = 0
        decode_prealloc = decode_transfer = decode_retracted = 0
        decode_prealloc_ready = 0
        num_prealloc_ready_tokens = 0
        if self.disaggregation_mode == DisaggregationMode.PREFILL:
            mode_str = "prefill"
            prefill_bootstrap = len(self.get_disagg_prefill_bootstrap_queue().queue)
            prefill_inflight = len(self.get_disagg_prefill_inflight_queue())
        elif self.disaggregation_mode == DisaggregationMode.DECODE:
            mode_str = "decode"
            decode_prealloc = len(self.get_disagg_decode_prealloc_queue().queue)
            decode_transfer = len(self.get_disagg_decode_transfer_queue().queue)
            decode_retracted = len(
                self.get_disagg_decode_prealloc_queue().retracted_queue
            )
            ready_reqs = [
                decode_req.req
                for decode_req in self.get_disagg_decode_prealloc_queue().queue
                if decode_req.waiting_for_input
            ]
            decode_prealloc_ready = len(ready_reqs)
            num_prealloc_ready_tokens = sum(req.seqlen for req in ready_reqs)
        disaggregation = DisaggregationMetrics(
            mode=mode_str,
            prefill_bootstrap_queue_reqs=prefill_bootstrap,
            prefill_inflight_queue_reqs=prefill_inflight,
            decode_prealloc_queue_reqs=decode_prealloc,
            decode_transfer_queue_reqs=decode_transfer,
            decode_retracted_queue_reqs=decode_retracted,
            kv_transfer_speed_gb_s=stats.kv_transfer_speed_gb_s,
            kv_transfer_latency_ms=stats.kv_transfer_latency_ms,
        )

        queues = QueueMetrics(
            waiting=len(self.get_waiting_queue()),
            grammar=stats.num_grammar_queue_reqs,
            paused=stats.num_paused_reqs,
            retracted=stats.num_retracted_reqs,
            prealloc_ready=decode_prealloc_ready,
        )

        totals = self.get_decode_moment_totals()
        decode_moments = list(totals) if totals[0] > 0 else None

        running_reqs = self.get_running_batch().reqs
        decode_kv_tokens = sum(len(r.origin_input_ids) + len(r.output_ids) for r in running_reqs)
        accept_len = 1.0
        if not self.spec_algorithm.is_none() and self.get_spec_total_num_forward_ct() > 0:
            accept_len = self.get_spec_total_num_accept_tokens() / self.get_spec_total_num_forward_ct()
        now = time.monotonic()
        entries = []
        cr = self.get_chunked_req()
        if cr is not None:
            entries.append([cr.priority, max(0, cr.seqlen - cr.prefix_len), cr.prefix_len])
        for r in self.get_waiting_queue():
            cached = getattr(r, "_edf_cached_len", 0)
            entries.append([r.priority, max(0, len(r.origin_input_ids) - cached), cached])
        entries.sort(key=lambda e: float("inf") if e[0] is None else e[0])
        prefill_queue = [
            [1e9 if pr is None else round((pr - now) * 1000.0, 1), int(u), int(pf)]
            for pr, u, pf in entries[:64]
        ]

        return LoadSnapshot(
            dp_rank=int(get_parallel().dp_rank)
            if get_parallel().dp_rank is not None
            else 0,
            timestamp=time.time(),
            num_running_reqs=num_running_reqs,
            num_waiting_reqs=num_waiting_reqs,
            num_waiting_uncached_tokens=self.get_num_waiting_uncached_tokens(),
            num_used_tokens=num_used_tokens,
            num_total_tokens=num_total_tokens,
            num_active_tokens=num_active_tokens,
            num_prealloc_ready_tokens=num_prealloc_ready_tokens,
            max_total_num_tokens=self.max_total_num_tokens,
            max_running_requests=self.max_running_requests,
            token_usage=round(kv_token_usage, 4),
            gen_throughput=round(stats.gen_throughput, 2),
            cache_hit_rate=round(stats.cache_hit_rate, 4),
            utilization=round(stats.utilization, 4),
            memory=memory,
            speculative=speculative,
            lora=lora,
            disaggregation=disaggregation,
            queues=queues,
            total_prefill_uncached_tokens=self.get_total_prefill_uncached_tokens(),
            total_prefill_busy_us=self.get_total_prefill_busy_us(),
            decode_moments=decode_moments,
            num_decode_rows=len(running_reqs),
            decode_kv_tokens=decode_kv_tokens,
            accept_len=round(accept_len, 4),
            prefill_queue=prefill_queue,
            decode_step_ms=self._decode_step_ms(),
        )

set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi
export HEADS=28,4 FUSED_REFERENCE_WORKSPACE_BYTES=16 FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=64,32,16 FUSED_CONST_PERS_PARAMS=1 FUSED_FA2_REG_REALLOC=1 FLASHINFER_FUSED_BACKFILL=1
export MODE=mixed_verify TIME_AB=1 TIME_ITERS=100 TIME_CUDA_GRAPH=1
for configuration in 64:1024 96:512 112:512 120:512 128:512 112:256 96:256 64:1024; do
 split=${configuration%:*}
 chunk=${configuration#*:}
 SM_SPLIT=$split FUSED_FA2_KV_CHUNK=$chunk /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fa2_sm_sweep/${split}_${chunk}_$(date +%s).log 2>&1
done
echo FA2_SM_SWEEP_PASS

/*!
 * \brief Named-barrier ids for the fused FA3+FA2 kernel.
 */
#ifndef FLASHINFER_ATTENTION_FUSED_BARRIERS_CUH_
#define FLASHINFER_ATTENTION_FUSED_BARRIERS_CUH_

#include <cutlass/arch/barrier.h>
#include <type_traits>

namespace flashinfer {

template <typename Traits, typename = void>
struct FusedNamedBarrier : std::false_type {};

template <typename Traits>
struct FusedNamedBarrier<Traits, std::void_t<decltype(Traits::NAMED_BARRIER_SYNC)>>
    : std::integral_constant<bool, Traits::NAMED_BARRIER_SYNC> {};

static constexpr int kPersistentMainloopBarrier = 2;
static constexpr int kFusedQueueBarrier = 5;
static_assert(kFusedQueueBarrier + 2 <
              static_cast<int>(cutlass::arch::ReservedNamedBarriers::FirstUserBarrier));
// The two values the cross-role backfill queue needs: the device-side cursor blocks pull
// persistent cluster indices from, and how many there are.
//
// These are deliberately NOT fields of PersistentParams. That struct is generated from
// upstream's csrc/batch_attention_customize_config.jinja, so carrying them there means
// patching a template inside the installed wheel -- unreproducible, and a hard blocker for
// upstreaming, since every stock BatchAttention build would have to grow two fields it never
// uses. The 0.3.1 tree did patch the jinja; 0.7 does not need to, because only our own kernel
// reads these and it can take them as an argument.
struct FusedQueueParams {
  int32_t* cluster_cursor = nullptr;
  uint32_t num_pers_clusters = 0;
  unsigned long long* pdl_timeline = nullptr;
};

}  // namespace flashinfer

#endif  // FLASHINFER_ATTENTION_FUSED_BARRIERS_CUH_

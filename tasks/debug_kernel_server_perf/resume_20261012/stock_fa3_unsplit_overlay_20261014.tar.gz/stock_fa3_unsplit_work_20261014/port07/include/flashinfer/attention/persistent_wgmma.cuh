/*
 * wgmma QK^T for the large-tile task of the persistent kernel.
 *
 * Why this is a drop-in rather than a port of FA3's mainloop: wgmma's
 * m64nNk16 accumulator is distributed across the warpgroup exactly the way the
 * m16n8 accumulator is distributed across a warp -- warp w of the warpgroup
 * owns rows 16w..16w+15, and within a warp each lane holds
 * (r, c), (r, c+1), (r+8, c), (r+8, c+1) per n8 group. So with NUM_MMA_Q == 1
 * the existing `s_frag[1][NUM_MMA_KV][8]` IS the wgmma D-register order for
 * N = NUM_MMA_KV * 16, and update_mdo_states / compute_sfm_v / normalize_d /
 * write_o_ keep working untouched. The large tile becomes 2 warpgroups of 64 q
 * rows (NUM_WARPS_Q = 8, 256 threads), each owning its own softmax state, so no
 * cross-warpgroup reduction is needed either.
 *
 * Only the QK^T GEMM moves to wgmma here. That is the one that scales with KV
 * length and therefore dominates on the long-prefix rows this task exists for;
 * P*V stays on mma.sync so the softmax epilogue is untouched.
 */
#ifndef FLASHINFER_ATTENTION_PERSISTENT_WGMMA_CUH_
#define FLASHINFER_ATTENTION_PERSISTENT_WGMMA_CUH_

#include "hopper.cuh"

namespace flashinfer {

template <typename KTraits>
__device__ __forceinline__ void compute_qk_wgmma(
    smem_t<KTraits::SWIZZLE_MODE_Q>* q_smem, smem_t<KTraits::SWIZZLE_MODE_KV>* k_smem,
    const uint32_t warpgroup_id,
    typename KTraits::DTypeQKAccum (*s_frag)[KTraits::NUM_MMA_KV][8]) {
  using DTypeQ = typename KTraits::DTypeQ;
  constexpr uint32_t HEAD_DIM = KTraits::HEAD_DIM_QK;
  constexpr uint32_t CTA_TILE_KV = KTraits::CTA_TILE_KV;
  constexpr uint32_t NUM_REGS = KTraits::NUM_MMA_KV * 8;
  using wgmma_op = WGMMA_ASYNC_SS<DTypeQ, float, 64, CTA_TILE_KV, 16, Major::K, Major::K,
                                  ScaleIn::One, ScaleIn::One>;

  // 16B leading offset = one k8 sub-block; stride = 8 rows of the head-dim.
  auto desc_q = make_smem_desc<KTraits::SWIZZLE_MODE_Q, /*leading=*/16,
                               /*stride=*/HEAD_DIM * 16, DTypeQ>(
      (DTypeQ*)q_smem->base + warpgroup_id * 64 * HEAD_DIM);
  auto desc_k = make_smem_desc<KTraits::SWIZZLE_MODE_KV, /*leading=*/16,
                               /*stride=*/HEAD_DIM * 16, DTypeQ>((DTypeQ*)k_smem->base);

  warpgroup_fence_frag<NUM_REGS>((float*)s_frag);
  warpgroup_arrive();
#pragma unroll
  for (uint32_t mma_d = 0; mma_d < KTraits::NUM_MMA_D_QK; ++mma_d) {
    if (mma_d == 0) {
      wgmma_op::template op</*init=*/true>(desc_q, desc_k, (float*)s_frag);
    } else {
      wgmma_op::template op</*init=*/false>(desc_q, desc_k, (float*)s_frag);
    }
    // advance 16 bytes along K; every 4 steps cross the 128B swizzle atom
    if ((mma_d + 1) % 4 == 0) {
      desc_q += 64 - 6;
      desc_k += 64 - 6;
    } else {
      desc_q += 2;
      desc_k += 2;
    }
  }
  warpgroup_commit_batch();
  warpgroup_wait<0>();
  warpgroup_fence_frag<NUM_REGS>((float*)s_frag);
}

}  // namespace flashinfer

#endif  // FLASHINFER_ATTENTION_PERSISTENT_WGMMA_CUH_

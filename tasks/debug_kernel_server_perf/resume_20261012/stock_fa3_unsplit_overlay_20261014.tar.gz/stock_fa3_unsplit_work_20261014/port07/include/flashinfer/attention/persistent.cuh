/*
 * Copyright (c) 2025 by FlashInfer team.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef FLASHINFER_PERSISTENT_CUH_
#define FLASHINFER_PERSISTENT_CUH_

#include "../cp_async.cuh"
#include "../math.cuh"
#include "../utils.cuh"
// jit_merge.cuh is deliberately NOT ported: K1a dropped the in-kernel JIT-reduction
// rendezvous after measuring its ceiling at 0.6% of GPU time (flashinfer's own
// PersistentVariableLengthMergeStatesKernel, 1682 launches / 10.66 ms in the B1b trace), so
// the scheduled merge via merge_indptr/merge_o_indices is used instead. The include survived
// the hunk-level port and only a compile caught it -- greps for MergeGroupJIT/s_merge_flag/
// group_counter all returned 0.
#include "mask.cuh"
#include "persistent_template.cuh"
#include "prefill.cuh"
#include <cutlass/arch/barrier.h>

#include "state.cuh"

// Barrier ids live in our own header rather than in prefill.cuh, which 0.7 rewrote from 2734
// to 4871 lines; overlaying it for two constants is not worth the maintenance.
#include "fused_barriers.cuh"

#include <type_traits>

namespace flashinfer {
// How many K/V ring stages this trait wants.
//
// NUM_KV_STAGES is OUR name: the staged wrapper below defines it as S. In 0.3.1 the runners
// instantiated directly over flashinfer's FA2 KernelTraits still found it, because 0.3.1's
// KernelTraits carried `NUM_KV_STAGES = 1` as a base default. 0.7 renamed its equivalent to
// NUM_STAGES, so those runners lost the default and nothing supplied a 1. Probing for the
// member keeps both spellings working instead of renaming one of them and having to keep the
// staged wrapper and upstream in agreement forever.
template <typename T, typename = void>
struct fa2_kv_stages : std::integral_constant<uint32_t, T::NUM_STAGES> {};
template <typename T>
struct fa2_kv_stages<T, std::void_t<decltype(T::NUM_KV_STAGES)>>
    : std::integral_constant<uint32_t, T::NUM_KV_STAGES> {};


// Fused-kernel named-barrier ids live in prefill.cuh, which this header
// includes, because the FA2 mainloop's helpers there need them too.


using cp_async::PrefetchMode;
using cp_async::SharedMemFillMode;

template <typename Params>
__device__ __forceinline__ auto get_block_coord(const Params& params, const uint32_t work_idx) {
  return std::tuple(params.q_indptr[work_idx], params.kv_indptr[work_idx],
                    params.partial_indptr[work_idx], params.q_len[work_idx],
                    params.kv_len[work_idx], params.q_start[work_idx], params.kv_start[work_idx],
                    params.kv_end[work_idx], params.kv_head_idx_arr[work_idx],
                    *params.len_kv_chunk);
}

template <typename KTraits>
__device__ __forceinline__ void prefetch_offest(
    const uint32_t packed_block_iter_base, const uint32_t packed_kv_bound,
    const uint32_t kv_head_idx, const uint32_t kv_stride_page, const uint32_t kv_stride_h,
    const uint32_t kv_stride_n, const uint_fastdiv& block_size, typename KTraits::IdType* indices,
    size_t* kv_offset, const uint32_t warp_idx, const uint32_t lane_idx) {
  using DTypeKV = typename KTraits::DTypeKV;
  constexpr uint32_t KV_THR_LAYOUT_ROW = KTraits::KV_THR_LAYOUT_ROW;
  constexpr uint32_t KV_THR_LAYOUT_COL = KTraits::KV_THR_LAYOUT_COL;
  constexpr uint32_t NUM_WARPS_Q = KTraits::NUM_WARPS_Q;
  constexpr uint32_t NUM_WARPS_KV = KTraits::NUM_WARPS_KV;
  constexpr uint32_t NUM_MMA_KV = KTraits::NUM_MMA_KV;
  constexpr SwizzleMode SWIZZLE_MODE_KV = KTraits::SWIZZLE_MODE_KV;

#pragma unroll
  for (uint32_t i = 0;
       i < NUM_MMA_KV * (SWIZZLE_MODE_KV == SwizzleMode::k128B ? 4 : 2) / NUM_WARPS_Q; ++i) {
    uint32_t page_iter, entry_idx;
    uint32_t packed_block_iter = packed_block_iter_base + warp_idx * KV_THR_LAYOUT_ROW +
                                 lane_idx / KV_THR_LAYOUT_COL +
                                 KV_THR_LAYOUT_ROW * NUM_WARPS_Q * NUM_WARPS_KV * i;
    block_size.divmod(packed_block_iter, page_iter, entry_idx);
    // FP4: GMEM is packed (2 FP4/byte), so the column byte offset is halved relative to fp8
    constexpr uint32_t fp4_pack_factor = is_fp4_type_v<DTypeKV> ? 2 : 1;
    kv_offset[i] = (packed_block_iter < packed_kv_bound ? indices[page_iter] : 0) * kv_stride_page +
                   entry_idx * kv_stride_n + kv_head_idx * kv_stride_h +
                   (lane_idx % KV_THR_LAYOUT_COL) * upcast_size<DTypeKV>() / fp4_pack_factor;
  }
}

template <typename KTraits>
__device__ __forceinline__ void write_o_(float (*o_frag)[KTraits::NUM_MMA_D_VO][8],
                                         smem_t<KTraits::SWIZZLE_MODE_Q>* o_smem,
                                         typename KTraits::DTypeO* o_ptr_base,
                                         const uint32_t o_packed_idx_base_warp,
                                         const uint32_t o_packed_idx_base_cta,
                                         const uint32_t qo_upper_bound, const uint32_t o_stride_n,
                                         const uint_fastdiv group_size, const uint32_t warp_idx,
                                         const uint32_t lane_idx, const dim3 tid) {
  using DTypeO = typename KTraits::DTypeO;
  constexpr uint32_t UPCAST_STRIDE_O = KTraits::UPCAST_STRIDE_O;
  const uint32_t warp_idx_x = get_warp_idx_q<KTraits>(tid.y),
                 warp_idx_z = get_warp_idx_kv<KTraits>(tid.z);

  static_assert(sizeof(DTypeO) == 2);
  if (warp_idx_z == 0) {
#pragma unroll
    for (uint32_t mma_q = 0; mma_q < KTraits::NUM_MMA_Q; ++mma_q) {
#pragma unroll
      for (uint32_t mma_d = 0; mma_d < KTraits::NUM_MMA_D_VO; ++mma_d) {
        uint32_t o_frag_f16[8 / 2];
        vec_cast<DTypeO, float>::cast<8>((DTypeO*)o_frag_f16, o_frag[mma_q][mma_d]);

#ifdef FLASHINFER_STMATRIX_M8N8X4_ENABLED
        uint32_t o_smem_offset_w = o_smem->get_permuted_offset<UPCAST_STRIDE_O>(
            (warp_idx_x * KTraits::NUM_MMA_Q + mma_q) * 16 + lane_idx % 16,
            mma_d * 2 + lane_idx / 16);
        o_smem->stmatrix_m8n8x4(o_smem_offset_w, o_frag_f16);
#else
        uint32_t o_smem_offset_w = o_smem->get_permuted_offset<UPCAST_STRIDE_O>(
            (warp_idx_x * KTraits::NUM_MMA_Q + mma_q) * 16 + lane_idx / 4, mma_d * 2);
        ((uint32_t*)(o_smem->base + o_smem_offset_w))[lane_idx % 4] = o_frag_f16[0];
        ((uint32_t*)(o_smem->base + o_smem_offset_w + 8 * UPCAST_STRIDE_O))[lane_idx % 4] =
            o_frag_f16[1];
        ((uint32_t*)(o_smem->base + (o_smem_offset_w ^ 0x1)))[lane_idx % 4] = o_frag_f16[2];
        ((uint32_t*)(o_smem->base + (o_smem_offset_w ^ 0x1) + 8 * UPCAST_STRIDE_O))[lane_idx % 4] =
            o_frag_f16[3];
#endif
      }
    }

    uint32_t o_smem_offset_w = o_smem->get_permuted_offset<UPCAST_STRIDE_O>(
        warp_idx_x * KTraits::NUM_MMA_Q * 16 + lane_idx / 8, lane_idx % 8);

#pragma unroll
    for (uint32_t mma_q = 0; mma_q < KTraits::NUM_MMA_Q; ++mma_q) {
#pragma unroll
      for (uint32_t j = 0; j < 2 * 2; ++j) {
        uint32_t q, r;
        const uint32_t o_packed_idx = o_packed_idx_base_warp + lane_idx / 8 + mma_q * 16 + j * 4;
        group_size.divmod(o_packed_idx, q, r);

        const uint32_t o_idx = q;
        DTypeO* o_ptr = o_ptr_base + (o_packed_idx - o_packed_idx_base_cta) * o_stride_n +
                        (lane_idx % 8) * upcast_size<DTypeO>();
#pragma unroll
        for (uint32_t mma_do = 0; mma_do < KTraits::NUM_MMA_D_VO / 4; ++mma_do) {
          if (o_idx < qo_upper_bound) {
            o_smem->store_128b(o_smem_offset_w, o_ptr);
          }
          o_ptr += 8 * upcast_size<DTypeO>();
          o_smem_offset_w = o_smem->template advance_offset_by_column<8>(o_smem_offset_w, mma_do);
        }
        o_smem_offset_w =
            o_smem->template advance_offset_by_row<4, UPCAST_STRIDE_O>(o_smem_offset_w) -
            2 * KTraits::NUM_MMA_D_VO;
      }
    }
  }
}

template <typename KTraits>
__device__ __forceinline__ void normalize_d(float (*o_frag)[KTraits::NUM_MMA_D_VO][8],
                                            typename KTraits::DTypeQKAccum (*m)[2], float (*d)[2],
                                            float v_scale = 1.0f) {
  using AttentionVariant = typename KTraits::AttentionVariant;
  if constexpr (AttentionVariant::use_softmax) {
    float d_rcp[KTraits::NUM_MMA_Q][2];
    // compute reciprocal of d
#pragma unroll
    for (uint32_t mma_q = 0; mma_q < KTraits::NUM_MMA_Q; ++mma_q) {
#pragma unroll
      for (uint32_t j = 0; j < 2; ++j) {
        d_rcp[mma_q][j] = (m[mma_q][j] != typename KTraits::DTypeQKAccum(-math::inf))
                              ? math::ptx_rcp(d[mma_q][j])
                              : 0.f;
      }
    }

#pragma unroll
    for (uint32_t mma_q = 0; mma_q < KTraits::NUM_MMA_Q; ++mma_q) {
#pragma unroll
      for (uint32_t mma_d = 0; mma_d < KTraits::NUM_MMA_D_VO; ++mma_d) {
#pragma unroll
        for (uint32_t reg_id = 0; reg_id < 8; ++reg_id) {
          o_frag[mma_q][mma_d][reg_id] =
              o_frag[mma_q][mma_d][reg_id] * d_rcp[mma_q][(reg_id >> 1) & 1];
          if (v_scale != 1.0f) {
            o_frag[mma_q][mma_d][reg_id] *= v_scale;
          }
        }
      }
    }
  }
}

// When the persistent mainloop runs inside the FUSED kernel it occupies only
// warpgroup 0 of a 384-thread CTA (the other warpgroups either run FA3 on a
// different SM or have exited), so a plain __syncthreads() would wait for
// threads that will never arrive. A named barrier with an explicit count of 128
// synchronises exactly the live warpgroup. Outside the fused kernel this is a
// plain __syncthreads().
// In the fused FA3+FA2 kernel the grid is one-dimensional (FA3's tile scheduler
// indexes blockIdx.x), so the persistent mainloop takes its cluster index from
// blockIdx.x there instead of blockIdx.y, and cluster_size is pinned to 1.
template <typename KTraits>
__device__ __forceinline__ uint32_t persistent_cluster_idx() {
  return KTraits::FUSED_GRID ? blockIdx.x : blockIdx.y;
}

template <typename KTraits>
__device__ __forceinline__ uint32_t persistent_cluster_slot() {
  return KTraits::FUSED_GRID ? 0u : blockIdx.x;
}

template <typename KTraits>
// Barrier 0 is the one __syncthreads() uses. In the fused kernel FA3's body
// calls __syncthreads() across all 384 threads while this mainloop syncs 128,
// so the mainloop gets its own id rather than sharing 0.
__device__ __forceinline__ void persistent_block_sync(uint32_t wg = 0) {
  if constexpr (KTraits::NAMED_BARRIER_SYNC) {
    // Per-warpgroup id, like threadblock_sync_mdo_states. With one shared id and
    // a count of 128, three warpgroups draining at once satisfy each other's
    // sync -- the deadlock recorded in prefill.cuh:1120. Sharing the warpgroup's
    // mdo id is safe because both are full-warpgroup rendezvous reached in
    // program order.
    cutlass::arch::NamedBarrier::sync(
        KTraits::NUM_THREADS,
        static_cast<cutlass::arch::ReservedNamedBarriers>(kPersistentMainloopBarrier + int(wg)));
  } else {
    __syncthreads();
  }
}


template <typename KTraits_, typename Params_>
struct BlockBatchPagedAttentionPersistent {
  using KTraits = KTraits_;
  using Params = Params_;

  // `cluster_override` lets the fused kernel's dynamic scheduler hand this invocation a
  // specific queue slot instead of deriving one from blockIdx, so a block that has finished its
  // own role can backfill another SM's work. This is the cross-role backfill mechanism; without
  // it the split is static and an SM that finishes FA3 idles.
  static constexpr uint32_t kNoClusterOverride = 0xFFFFFFFFu;

  // `tid_base` lets this mainloop run on a warpgroup other than warpgroup 0, which the fused
  // kernel needs: when a CTA that just finished FA3 backfills into the persistent queue, the
  // warpgroup free to do the work is a CONSUMER, not the producer. The producer deliberately
  // gave its registers away (warpgroup_reg_dealloc<24>) and a returning warp issues no matching
  // setmaxnreg.dec, so its quota stays charged to the CTA -- a producer-side
  // warpgroup_reg_alloc<160> then has nothing to take and blocks forever. A consumer warpgroup
  // already holds ~240 registers and needs no setmaxnreg at all.
  static __device__ __forceinline__ void Run(const Params& params,
                                             typename KTraits::SharedStorage* smem_storage,
                                             uint32_t cluster_override = kNoClusterOverride,
                                             uint32_t tid_base = 0
                                                 PROFILER_CLOSURE_FUNC_PARAMS) {
    using DTypeQ = typename Params::DTypeQ;
    using DTypeKV = typename Params::DTypeKV;
    using DTypeO = typename Params::DTypeO;
    using IdType = typename Params::IdType;
    using DTypeQKAccum = typename KTraits::DTypeQKAccum;
    using AttentionVariant = typename KTraits::AttentionVariant;
    [[maybe_unused]] constexpr uint32_t NUM_MMA_Q = KTraits::NUM_MMA_Q;
    [[maybe_unused]] constexpr uint32_t NUM_MMA_KV = KTraits::NUM_MMA_KV;
    [[maybe_unused]] constexpr uint32_t NUM_MMA_D_QK = KTraits::NUM_MMA_D_QK;
    [[maybe_unused]] constexpr uint32_t NUM_MMA_D_VO = KTraits::NUM_MMA_D_VO;
    [[maybe_unused]] constexpr uint32_t HEAD_DIM_QK = KTraits::HEAD_DIM_QK;
    [[maybe_unused]] constexpr uint32_t HEAD_DIM_VO = KTraits::HEAD_DIM_VO;
    [[maybe_unused]] constexpr uint32_t UPCAST_STRIDE_Q = KTraits::UPCAST_STRIDE_Q;
    [[maybe_unused]] constexpr uint32_t UPCAST_STRIDE_K = KTraits::UPCAST_STRIDE_K;
    [[maybe_unused]] constexpr uint32_t UPCAST_STRIDE_V = KTraits::UPCAST_STRIDE_V;
    [[maybe_unused]] constexpr uint32_t UPCAST_STRIDE_O = KTraits::UPCAST_STRIDE_O;
    [[maybe_unused]] constexpr uint32_t NUM_WARPS_Q = KTraits::NUM_WARPS_Q;
    [[maybe_unused]] constexpr uint32_t NUM_WARPS_KV = KTraits::NUM_WARPS_KV;
    [[maybe_unused]] constexpr SwizzleMode SWIZZLE_MODE_Q = KTraits::SWIZZLE_MODE_Q;
    [[maybe_unused]] constexpr SwizzleMode SWIZZLE_MODE_KV = KTraits::SWIZZLE_MODE_KV;
    [[maybe_unused]] constexpr uint32_t CTA_TILE_Q = KTraits::CTA_TILE_Q;
    [[maybe_unused]] constexpr uint32_t CTA_TILE_KV = KTraits::CTA_TILE_KV;
    [[maybe_unused]] constexpr bool CAUSAL = KTraits::MASK_MODE == MaskMode::kCausal;
    [[maybe_unused]] constexpr uint32_t NUM_STAGES = KTraits::NUM_STAGES;

    DTypeQ* q = params.q;
    DTypeKV* k = params.k;
    DTypeKV* v = params.v;
    IdType* kv_indices = params.kv_indices;
    uint8_t* maybe_k_cache_sf = nullptr;
    if constexpr (has_maybe_k_cache_sf_v<Params>) {
      maybe_k_cache_sf = params.maybe_k_cache_sf;
    }
    uint8_t* maybe_v_cache_sf = nullptr;
    if constexpr (has_maybe_v_cache_sf_v<Params>) {
      maybe_v_cache_sf = params.maybe_v_cache_sf;
    }
    float* partial_lse = params.partial_lse;
    IdType* work_indptr = params.work_indptr;

    float s_frag[NUM_MMA_Q][NUM_MMA_KV][8];
    alignas(16) float o_frag[NUM_MMA_Q][NUM_MMA_D_VO][8];
    float m[NUM_MMA_Q][2];
    float d[NUM_MMA_Q][2];

    const uint_fastdiv& gqa_group_size = params.gqa_group_size;
    const uint32_t num_kv_heads = params.num_kv_heads;
    const uint_fastdiv& block_size = params.page_size;
    const uint32_t q_stride_n = params.q_stride_n;
    const uint32_t q_stride_h = params.q_stride_h;
    const uint32_t k_stride_page = params.k_stride_page;
    const uint32_t k_stride_h = params.k_stride_h;
    const uint32_t k_stride_n = params.k_stride_n;
    const uint32_t v_stride_page = params.v_stride_page;
    const uint32_t v_stride_h = params.v_stride_h;
    const uint32_t v_stride_n = params.v_stride_n;
    // Under FUSED_GRID the grid's x dimension indexes ROLES, not q tiles, so gridDim.x
    // overstates the cluster's q extent and the causal bound derived from it lets work items
    // read past their row. Guarded rather than removed because the non-fused path still needs
    // gridDim.x. Recovered from the task doc: this fix lived only on the destroyed pod.
    const uint32_t cluster_tile_q = (KTraits::FUSED_GRID ? 1u : gridDim.x) * CTA_TILE_Q;
    smem_t<SWIZZLE_MODE_Q> q_smem(smem_storage->q_smem);

    AttentionVariant variant(params, /*batch_idx=*/0, nullptr);

    const uint32_t ltid = threadIdx.x - tid_base;
    const uint32_t lane_idx = ltid % 32;
    const uint32_t warp_idx = ltid / 32;

    // threadIdx: [32, NUM_WARPS_Q, NUM_WARPS_KV]
    // remap to utilize tool function in FA2 prefill
    const dim3 tid = dim3(lane_idx, warp_idx % NUM_WARPS_Q, warp_idx / NUM_WARPS_Q);

    uint32_t q_smem_offset_r = get_permuted_offset<SWIZZLE_MODE_Q, UPCAST_STRIDE_Q>(
        get_warp_idx_q<KTraits>(tid.y) * NUM_MMA_Q * 16 + lane_idx % 16, lane_idx / 16);
    uint32_t k_smem_offset_r = get_permuted_offset<SWIZZLE_MODE_KV, UPCAST_STRIDE_K>(
                 get_warp_idx_kv<KTraits>(tid.z) * NUM_MMA_KV * 16 + 8 * (lane_idx / 16) +
                     lane_idx % 8,
                 (lane_idx % 16) / 8),
             v_smem_offset_r = get_permuted_offset<SWIZZLE_MODE_KV, UPCAST_STRIDE_V>(
                 get_warp_idx_kv<KTraits>(tid.z) * NUM_MMA_KV * 16 + lane_idx % 16, lane_idx / 16);
    uint32_t k_smem_offset_w = get_permuted_offset<SWIZZLE_MODE_KV, UPCAST_STRIDE_K>(
                 warp_idx * KTraits::KV_THR_LAYOUT_ROW + lane_idx / KTraits::KV_THR_LAYOUT_COL,
                 lane_idx % KTraits::KV_THR_LAYOUT_COL),
             v_smem_offset_w = get_permuted_offset<SWIZZLE_MODE_KV, UPCAST_STRIDE_V>(
                 warp_idx * KTraits::KV_THR_LAYOUT_ROW + lane_idx / KTraits::KV_THR_LAYOUT_COL,
                 lane_idx % KTraits::KV_THR_LAYOUT_COL);
    size_t
        thr_local_kv_offset_k[NUM_MMA_KV * KTraits::KV_THR_LAYOUT_COL / 2 / KTraits::NUM_WARPS_Q];
    size_t
        thr_local_kv_offset_v[NUM_MMA_KV * KTraits::KV_THR_LAYOUT_COL / 2 / KTraits::NUM_WARPS_Q];

    const uint32_t cluster_idx = (cluster_override != kNoClusterOverride)
                                     ? cluster_override
                                     : persistent_cluster_idx<KTraits>();
#pragma unroll 1
    for (IdType work_idx = work_indptr[cluster_idx]; work_idx < work_indptr[cluster_idx + 1];
         ++work_idx) {
      // profile log
      if constexpr (CTA_TILE_Q > 64) {
        PROFILER_EVENT_START(profiler_closure, PersistentProfileEventType::kRunner1);
      } else {
        PROFILER_EVENT_START(profiler_closure, PersistentProfileEventType::kRunner2);
      }

      const auto [q_indptr, kv_indptr, o_indptr, q_len, kv_len, packed_qo_start, kv_start, kv_end,
                  kv_head_idx, len_kv_chunk] = get_block_coord(params, work_idx);

      const uint32_t kv_chunk_idx = kv_start / len_kv_chunk;
      const uint32_t num_kv_chunks =
          ceil_div(KTraits::FUSED_GRID
                       ? kv_len
                       : (CAUSAL ? min((kv_len - q_len) +
                                           ceil_div(packed_qo_start + cluster_tile_q, gqa_group_size),
                                       kv_len)
                                 : kv_len),
                   len_kv_chunk);
      // TRACE (FLASHINFER_TRACE_WORK=1): both sanitizers are clean, so the damaging store is
      // in bounds and not racing -- i.e. a correct-looking write to the WRONG rows, with an
      // index that varies run to run. The plan is known good and identical between runs, so
      // what must be checked is which coordinates each CTA ACTUALLY executed. One line per
      // work item; the reproducer has ~120, so device printf is affordable here.
#if 0  // trace off; flip to 1 AND clear cached_ops to re-enable
      if (threadIdx.x == 0) {
        printf("[TRACE] blk=%d work=%d q_indptr=%d q_len=%d packed_qo_start=%d kv_indptr=%d "
               "kv_len=%d kv_start=%d kv_end=%d kvh=%d chunk=%d nchunks=%d "
               "o_indptr=%d len_kv_chunk=%d\n",
               int(blockIdx.x), int(work_idx), int(q_indptr), int(q_len), int(packed_qo_start),
               int(kv_indptr), int(kv_len), int(kv_start), int(kv_end), int(kv_head_idx),
               int(kv_chunk_idx), int(num_kv_chunks), int(o_indptr), int(len_kv_chunk));
      }
#endif
      // Base of THIS CTA's q tile. partial_o indexes rows relative to it
      // (write_o_'s o_packed_idx_base_cta), and the plan captures partial_indptr once per
      // TILE, so tile-relative is the layout the merge expects.
      const uint32_t qo_packed_idx_base_cta =
          packed_qo_start + persistent_cluster_slot<KTraits>() * CTA_TILE_Q;
      const uint32_t qo_packed_idx_base = qo_packed_idx_base_cta +
                                          get_warp_idx_q<KTraits>(tid.y) * NUM_MMA_Q * 16;
      const uint32_t qo_upperbound =
          min(q_len, ceil_div(qo_packed_idx_base + CTA_TILE_Q, gqa_group_size));

      init_states<KTraits>(variant, o_frag, m, d);

      DTypeQ* q_ptr_base = q + q_indptr * q_stride_n + (kv_head_idx * gqa_group_size) * q_stride_h;

      // load_q
      load_q_global_smem<KTraits>(qo_packed_idx_base, qo_upperbound, q_ptr_base, q_stride_n,
                                  q_stride_h, gqa_group_size, &q_smem, tid);

      smem_t<SWIZZLE_MODE_KV> k_smem(smem_storage->k_smem), v_smem(smem_storage->v_smem);
      int kv_tile_idx =
          ceil_div((CAUSAL ? min(kv_end,
                                 kv_len - q_len +
                                     ceil_div((packed_qo_start + cluster_tile_q), gqa_group_size))
                           : kv_end),
                   CTA_TILE_KV) -
          1 - (kv_start / CTA_TILE_KV);

      int mask_tile_idx =
          (CAUSAL ? min(kv_end, kv_len - q_len + ceil_div(packed_qo_start, gqa_group_size))
                  : kv_end) /
              CTA_TILE_KV -
          (kv_start / CTA_TILE_KV);

      uint32_t block_iter_base = kv_indptr * block_size + kv_start;
      // last kv tile
      persistent_block_sync<KTraits>(tid_base / 128u);
      uint32_t packed_kv_bound = kv_indptr * block_size + kv_len;

      if (kv_tile_idx >= 0) {
      if constexpr (fa2_kv_stages<KTraits>::value > 1) {
        // S-slot K/V ring: tile t lives in slot (kv_tile_idx - t) % S, and tile t - S is
        // issued into it as soon as PV(t) has finished reading. Every iteration commits
        // exactly two groups (K, V; empty past the last tile) so the wait counts are fixed.
        constexpr uint32_t S = fa2_kv_stages<KTraits>::value;
        constexpr uint32_t K_SLOT = CTA_TILE_KV * UPCAST_STRIDE_K;
        constexpr uint32_t V_SLOT = CTA_TILE_KV * UPCAST_STRIDE_V;
        auto issue = [&](const int t, const uint32_t slot) {
          if (t >= 0) {
            // K and V get SEPARATE offset arrays, each prefetched with its own strides. 0.7
            // split `thr_local_kv_offset` into `_k` and `_v` for this reason, and the 0.3.1
            // version of this lambda had a latent bug: it computed offsets from K's strides
            // (k_stride_page/h/n) and reused them for the V produce, which only happens to work
            // while the V strides equal the K strides. Mirrors 0.7's own pattern of two
            // prefetch_offest calls.
            prefetch_offest<KTraits>(block_iter_base + t * CTA_TILE_KV, packed_kv_bound,
                                     kv_head_idx, k_stride_page, k_stride_h, k_stride_n,
                                     block_size, kv_indices, thr_local_kv_offset_k, warp_idx, lane_idx);
            prefetch_offest<KTraits>(block_iter_base + t * CTA_TILE_KV, packed_kv_bound,
                                     kv_head_idx, v_stride_page, v_stride_h, v_stride_n,
                                     block_size, kv_indices, thr_local_kv_offset_v, warp_idx, lane_idx);
            uint32_t kw = k_smem_offset_w + slot * K_SLOT;
            page_produce_kv<false, KTraits>(smem_storage, &kw, k, kv_start + t * CTA_TILE_KV,
                                            thr_local_kv_offset_k, kv_end, warp_idx, lane_idx);
            cp_async::commit_group();
            uint32_t vw = v_smem_offset_w + slot * V_SLOT;
            page_produce_kv<true, KTraits>(smem_storage, &vw, v, kv_start + t * CTA_TILE_KV,
                                           thr_local_kv_offset_v, kv_end, warp_idx, lane_idx);
            cp_async::commit_group();
          } else {
            cp_async::commit_group();
            cp_async::commit_group();
          }
        };
#pragma unroll
        for (uint32_t s = 0; s < S; ++s) issue(kv_tile_idx - int(s), s);

        uint32_t slot = 0;
#pragma unroll 1
        for (; kv_tile_idx >= 0; --kv_tile_idx) {
          cp_async::wait_group<2 * S - 1>();
          persistent_block_sync<KTraits>(tid_base / 128u);
          uint32_t kr = k_smem_offset_r + slot * K_SLOT;
          compute_qk<KTraits>(&q_smem, &q_smem_offset_r, &k_smem, &kr, s_frag);
          const uint32_t kv_idx_base =
              kv_start +
              (kv_tile_idx * NUM_WARPS_KV + get_warp_idx_kv<KTraits>(tid.z)) * NUM_MMA_KV * 16;
          if constexpr (AttentionVariant::use_logits_soft_cap) {
            logits_transform<KTraits>(params, variant, /*batch_idx=*/0, qo_packed_idx_base,
                                      kv_idx_base, q_len, kv_len, gqa_group_size, s_frag, tid,
                                      kv_head_idx);
          }
          if (kv_tile_idx >= mask_tile_idx || kv_tile_idx == 0) {
            logits_mask<KTraits>(params, variant, /*batch_idx=*/0, qo_packed_idx_base,
                                 kv_idx_base, q_len, kv_len, kv_end, gqa_group_size, s_frag, tid,
                                 kv_head_idx);
          }
          update_mdo_states<KTraits>(variant, s_frag, o_frag, m, d);

          cp_async::wait_group<2 * S - 2>();
          persistent_block_sync<KTraits>(tid_base / 128u);
          uint32_t vr = v_smem_offset_r + slot * V_SLOT;
          compute_sfm_v<KTraits>(&v_smem, &vr, s_frag, o_frag, d);
          persistent_block_sync<KTraits>(tid_base / 128u);

          issue(kv_tile_idx - int(S), slot);
          slot = (slot + 1 == S) ? 0 : slot + 1;
        }
        cp_async::wait_group<0>();
        persistent_block_sync<KTraits>(tid_base / 128u);
      } else {
      prefetch_offest<KTraits>(block_iter_base + kv_tile_idx * CTA_TILE_KV, packed_kv_bound,
                               kv_head_idx, k_stride_page, k_stride_h, k_stride_n, block_size,
                               kv_indices, thr_local_kv_offset_k, warp_idx, lane_idx);
      prefetch_offest<KTraits>(block_iter_base + kv_tile_idx * CTA_TILE_KV, packed_kv_bound,
                               kv_head_idx, v_stride_page, v_stride_h, v_stride_n, block_size,
                               kv_indices, thr_local_kv_offset_v, warp_idx, lane_idx);
      page_produce_kv<false, KTraits>(smem_storage, &k_smem_offset_w, k,
                                      kv_start + kv_tile_idx * CTA_TILE_KV, thr_local_kv_offset_k,
                                      kv_end, warp_idx, lane_idx);
      page_produce_kv_sf<false, KTraits>(
          smem_storage, maybe_k_cache_sf, block_iter_base + kv_tile_idx * CTA_TILE_KV,
          packed_kv_bound, kv_head_idx, params.k_sf_stride_page, params.k_sf_stride_h,
          params.k_sf_stride_n, block_size, kv_indices, kv_start + kv_tile_idx * CTA_TILE_KV,
          kv_end, warp_idx, lane_idx);
      cp_async::commit_group();
      page_produce_kv<true, KTraits>(smem_storage, &v_smem_offset_w, v,
                                     kv_start + kv_tile_idx * CTA_TILE_KV, thr_local_kv_offset_v,
                                     kv_end, warp_idx, lane_idx);
      page_produce_kv_sf<true, KTraits>(
          smem_storage, maybe_v_cache_sf, block_iter_base + kv_tile_idx * CTA_TILE_KV,
          packed_kv_bound, kv_head_idx, params.v_sf_stride_page, params.v_sf_stride_h,
          params.v_sf_stride_n, block_size, kv_indices, kv_start + kv_tile_idx * CTA_TILE_KV,
          kv_end, warp_idx, lane_idx);
      cp_async::commit_group();

      // loop with mask
      LOOP_SPLIT_MASK(
          kv_tile_idx, kv_tile_idx >= mask_tile_idx && kv_tile_idx > 0,
          kv_tile_idx + 1 > int(NUM_STAGES), {
            prefetch_offest<KTraits>(block_iter_base + (kv_tile_idx - 1) * CTA_TILE_KV,
                                     packed_kv_bound, kv_head_idx, k_stride_page, k_stride_h,
                                     k_stride_n, block_size, kv_indices, thr_local_kv_offset_k,
                                     warp_idx, lane_idx);
            prefetch_offest<KTraits>(block_iter_base + (kv_tile_idx - 1) * CTA_TILE_KV,
                                     packed_kv_bound, kv_head_idx, v_stride_page, v_stride_h,
                                     v_stride_n, block_size, kv_indices, thr_local_kv_offset_v,
                                     warp_idx, lane_idx);
            cp_async::wait_group<1>();
            persistent_block_sync<KTraits>(tid_base / 128u);

            compute_qk<KTraits>(
                &q_smem, &q_smem_offset_r, &k_smem, &k_smem_offset_r,
                smem_storage->k_sf_smem_ptr(get_warp_idx_kv<KTraits>(tid.z) * KTraits::NUM_MMA_KV *
                                            16 * KTraits::NUM_MMA_D_QK),
                lane_idx, s_frag);
            if constexpr (AttentionVariant::use_logits_soft_cap) {
              logits_transform<KTraits>(
                  params, variant, /*batch_idx=*/0, qo_packed_idx_base,
                  kv_start + (kv_tile_idx * NUM_WARPS_KV + get_warp_idx_kv<KTraits>(tid.z)) *
                                 NUM_MMA_KV * 16,
                  q_len, kv_len, kv_end, gqa_group_size, s_frag, tid, kv_head_idx);
            }
            if constexpr (WITH_MASK) {
              logits_mask<KTraits>(
                  params, variant, /*batch_idx=*/0, qo_packed_idx_base,
                  kv_start + (kv_tile_idx * NUM_WARPS_KV + get_warp_idx_kv<KTraits>(tid.z)) *
                                 NUM_MMA_KV * 16,
                  q_len, kv_len, kv_end, gqa_group_size, s_frag, tid, kv_head_idx);
            }
            update_mdo_states<KTraits>(variant, s_frag, o_frag, m, d);

            __syncthreads();
            page_produce_kv<false, KTraits>(smem_storage, &k_smem_offset_w, k,
                                            kv_start + (kv_tile_idx - 1) * CTA_TILE_KV,
                                            thr_local_kv_offset_k, kv_end, warp_idx, lane_idx);
            page_produce_kv_sf<false, KTraits>(
                smem_storage, maybe_k_cache_sf, block_iter_base + (kv_tile_idx - 1) * CTA_TILE_KV,
                packed_kv_bound, kv_head_idx, params.k_sf_stride_page, params.k_sf_stride_h,
                params.k_sf_stride_n, block_size, kv_indices,
                kv_start + (kv_tile_idx - 1) * CTA_TILE_KV, kv_end, warp_idx, lane_idx);
            cp_async::commit_group();
            cp_async::wait_group<1>();

            __syncthreads();
            compute_sfm_v<KTraits>(
                &v_smem, &v_smem_offset_r,
                smem_storage->v_sf_smem_ptr(get_warp_idx_kv<KTraits>(tid.z) * KTraits::NUM_MMA_KV *
                                            16 * KTraits::NUM_MMA_D_VO),
                lane_idx, s_frag, o_frag, d);
            __syncthreads();

            page_produce_kv<true, KTraits>(smem_storage, &v_smem_offset_w, v,
                                           kv_start + (kv_tile_idx - 1) * CTA_TILE_KV,
                                           thr_local_kv_offset_v, kv_end, warp_idx, lane_idx);
            page_produce_kv_sf<true, KTraits>(
                smem_storage, maybe_v_cache_sf, block_iter_base + (kv_tile_idx - 1) * CTA_TILE_KV,
                packed_kv_bound, kv_head_idx, params.v_sf_stride_page, params.v_sf_stride_h,
                params.v_sf_stride_n, block_size, kv_indices,
                kv_start + (kv_tile_idx - 1) * CTA_TILE_KV, kv_end, warp_idx, lane_idx);
            cp_async::commit_group();
          });
      cp_async::wait_group<0>();
      persistent_block_sync<KTraits>(tid_base / 128u);

#pragma unroll
      for (; kv_tile_idx >= 0; --kv_tile_idx) {
        compute_qk<KTraits>(
            &q_smem, &q_smem_offset_r, &k_smem, &k_smem_offset_r,
            smem_storage->k_sf_smem_ptr(get_warp_idx_kv<KTraits>(tid.z) * KTraits::NUM_MMA_KV * 16 *
                                        KTraits::NUM_MMA_D_QK),
            lane_idx, s_frag);
        if constexpr (AttentionVariant::use_logits_soft_cap) {
          logits_transform<KTraits>(
              params, variant, /*batch_idx=*/0, qo_packed_idx_base,
              kv_start +
                  (kv_tile_idx * NUM_WARPS_KV + get_warp_idx_kv<KTraits>(tid.z)) * NUM_MMA_KV * 16,
              q_len, kv_len, kv_end, gqa_group_size, s_frag, tid, kv_head_idx);
        }
        logits_mask<KTraits>(
            params, variant, /*batch_idx=*/0, qo_packed_idx_base,
            kv_start +
                (kv_tile_idx * NUM_WARPS_KV + get_warp_idx_kv<KTraits>(tid.z)) * NUM_MMA_KV * 16,
            q_len, kv_len, kv_end, gqa_group_size, s_frag, tid, kv_head_idx);
        update_mdo_states<KTraits>(variant, s_frag, o_frag, m, d);
        compute_sfm_v<KTraits>(
            &v_smem, &v_smem_offset_r,
            smem_storage->v_sf_smem_ptr(get_warp_idx_kv<KTraits>(tid.z) * KTraits::NUM_MMA_KV * 16 *
                                        KTraits::NUM_MMA_D_VO),
            lane_idx, s_frag, o_frag, d);
      }
      }

      } else {
        cp_async::commit_group();
        cp_async::wait_group<0>();
      }
      persistent_block_sync<KTraits>(tid_base / 128u);

      finalize_m<KTraits>(variant, m);

      // threadblock synchronization
      threadblock_sync_mdo_states<KTraits>(o_frag, smem_storage, m, d, warp_idx, lane_idx, tid,
                                          kPersistentMainloopBarrier + int(tid_base / 128u));
      if constexpr (NUM_WARPS_KV > 1) {
        persistent_block_sync<KTraits>(tid_base / 128u);
      }

      // normalize d
      normalize_d<KTraits>(o_frag, m, d, params.v_scale);

      // write back to global memory
      // o_indptr (partial_o): [packed_qo_len * num_kv_chunks, num_kv_heads, head_dim]
      // q_indpt (final_o): [qo_len, num_kv_heads, gqa_group_size, head_dim]
#if FLASHINFER_FUSED_TRACE_WRITE
      // BEFORE the branch, so this print is its own null case: if it does not appear the trace
      // is not compiled in or the site is not reached, and NEITHER branch's silence can be read
      // as "that branch was not taken" -- the inference that produced two retractions.
      // 999 is a sentinel for "every block": the question is WHICH q tiles appear across the
      // whole grid, which one block cannot answer.
      if ((threadIdx.x & 127u) == 0u &&
          (FLASHINFER_FUSED_TRACE_WRITE == 999 ||
           blockIdx.x == FLASHINFER_FUSED_TRACE_WRITE - 1)) {
        printf(
            "[fa2 epi] blk=%u tid=%u work=%u chunks=%u len_kv_chunk=%d q_len=%d kv_len=%d "
            "packed_start=%u qtile=%u kv=[%d,%d) o_indptr=%d q_indptr=%d chunk_idx=%u causal=%d\n",
            blockIdx.x, threadIdx.x, work_idx, unsigned(num_kv_chunks), int(len_kv_chunk),
            int(q_len), int(kv_len), unsigned(packed_qo_start),
            unsigned(packed_qo_start / CTA_TILE_Q), int(kv_start), int(kv_end),
            int(o_indptr), int(q_indptr), unsigned(kv_chunk_idx), int(CAUSAL));
      }
#endif
      if (num_kv_chunks > 1) {
        DTypeO* o_ptr_base = params.partial_o +
                             ((o_indptr + kv_chunk_idx) * num_kv_heads + kv_head_idx) * HEAD_DIM_VO;
#if FLASHINFER_FUSED_TRACE_WRITE
        // The SPLIT branch. In MODE=fa2 the plan allocates no partials at all, so reaching here
        // is itself the bug -- print the inputs the kernel ACTUALLY read, rather than
        // re-deriving them, so the disagreeing one is identified instead of guessed.
        // NOT tid.x == 0: the FA2 runners execute at a non-zero tid_base (128/256), so the
        // warpgroup-local id is never 0 for them and a trace gated on it never fires. That
        // silence was read as "this branch was not taken" and produced a wrong conclusion.
        // Keyed off the hardware thread id, one lane per warpgroup.
        if ((threadIdx.x & 127u) == 0u && blockIdx.x == FLASHINFER_FUSED_TRACE_WRITE - 1) {
          printf(
              "[fa2 SPLIT] blk=%u work=%u chunks=%u len_kv_chunk=%d q_len=%d kv_len=%d "
              "packed_start=%u cta_tile_q=%u kv=[%d,%d) o_indptr=%d chunk_idx=%u causal=%d "
              "p_off=%lld\n",
              blockIdx.x, work_idx, unsigned(num_kv_chunks), int(len_kv_chunk), int(q_len),
              int(kv_len), unsigned(packed_qo_start), unsigned(cluster_tile_q), int(kv_start),
              int(kv_end), int(o_indptr), unsigned(kv_chunk_idx), int(CAUSAL),
              (long long)(o_ptr_base - params.partial_o));
        }
#endif
        write_o_<KTraits>(o_frag, &q_smem, o_ptr_base, qo_packed_idx_base, packed_qo_start,
                          qo_upperbound, num_kv_chunks * num_kv_heads * HEAD_DIM_VO, gqa_group_size,
                          warp_idx, lane_idx, tid);
      } else {
        // write through
        // o_stride_n = num_qo_heads* head_dim
        const uint32_t o_stride_n = num_kv_heads * gqa_group_size * HEAD_DIM_VO,
                       o_stride_h = HEAD_DIM_VO;
        DTypeO* o_ptr_base =
            params.final_o + q_indptr * o_stride_n + (kv_head_idx * gqa_group_size) * o_stride_h;
#if FLASHINFER_FUSED_TRACE_WRITE
        // What the FA2 role ACTUALLY read, and the element offset it is about to write. The one
        // source of truth not reachable by reading either side's source.
        // NOT tid.x == 0: the FA2 runners execute at a non-zero tid_base (128/256), so the
        // warpgroup-local id is never 0 for them and a trace gated on it never fires. That
        // silence was read as "this branch was not taken" and produced a wrong conclusion.
        // Keyed off the hardware thread id, one lane per warpgroup.
        if ((threadIdx.x & 127u) == 0u && blockIdx.x == FLASHINFER_FUSED_TRACE_WRITE - 1) {
          printf(
              "[fa2 write] blk=%u work=%u q_indptr=%d q_len=%d q_start=%d packed_base=%u "
              "kv=[%d,%d) kv_len=%d kvh=%u chunks=%u o_off=%lld stride_n=%u\n",
              blockIdx.x, work_idx, int(q_indptr), int(q_len), int(packed_qo_start),
              unsigned(qo_packed_idx_base), int(kv_start), int(kv_end), int(kv_len),
              unsigned(kv_head_idx), unsigned(num_kv_chunks),
              (long long)(o_ptr_base - params.final_o), unsigned(o_stride_n));
        }
#endif
        write_o_reg_gmem<KTraits>(o_frag, &q_smem, o_ptr_base, qo_packed_idx_base, q_len,
                                  o_stride_n, o_stride_h, gqa_group_size, tid);
      }

      if constexpr (variant.use_softmax) {
        if (get_warp_idx_kv<KTraits>(tid.z) == 0) {
#pragma unroll
          for (uint32_t mma_q = 0; mma_q < NUM_MMA_Q; ++mma_q) {
#pragma unroll
            for (uint32_t j = 0; j < 2; ++j) {
              uint32_t q, r;
              const uint32_t packed_qo_idx = qo_packed_idx_base + lane_idx / 4 + j * 8 + mma_q * 16;
              gqa_group_size.divmod(packed_qo_idx, q, r);
              if (q < qo_upperbound) {
                if (num_kv_chunks > 1) {
                  // partial_lse was indexed relative to the ROW's start (packed_qo_start)
                  // while partial_o is indexed relative to the CTA TILE's base. Those
                  // coincide only for a row's FIRST q tile and diverge by the tile offset
                  // for every later one, so a row spanning several q tiles wrote its LSE
                  // partials to different rows than its O partials and the merge combined
                  // mismatched pairs. LSE_TILE_REL=0 restores the old expression for A/B.
#ifndef FLASHINFER_PARTIAL_LSE_TILE_REL
// NOTE: the FA2 path runs flashinfer's JIT module, which never receives our -D flags, so
// A/B-ing this requires editing THIS DEFAULT and clearing ~/.cache/flashinfer/90a/cached_ops.
// Passing -DFLASHINFER_PARTIAL_LSE_TILE_REL only affects the extension's TU, which does not
// execute the FA2 rows -- that is why the first A/B of this switch measured nothing.
#define FLASHINFER_PARTIAL_LSE_TILE_REL 1
#endif
                  const uint32_t lse_row_base =
#if FLASHINFER_PARTIAL_LSE_TILE_REL
                      qo_packed_idx_base_cta;
#else
                      packed_qo_start;
#endif
                  partial_lse[(o_indptr + (packed_qo_idx - lse_row_base) * num_kv_chunks +
                               kv_chunk_idx) *
                                  num_kv_heads +
                              kv_head_idx] = math::ptx_log2(d[mma_q][j]) + float(m[mma_q][j]);
                } else if (params.final_lse != nullptr) {
                  // write through
                  const uint32_t qo_head_idx = kv_head_idx * gqa_group_size + r;
                  params.final_lse[(q_indptr + q) * num_kv_heads * gqa_group_size + qo_head_idx] =
                      math::ptx_log2(d[mma_q][j]) + float(m[mma_q][j]);
                }
              }
            }
          }
        }
      }

      persistent_block_sync<KTraits>(tid_base / 128u);

      // profile
      if constexpr (CTA_TILE_Q > 64) {
        PROFILER_EVENT_END(profiler_closure, PersistentProfileEventType::kRunner1);
      } else {
        PROFILER_EVENT_END(profiler_closure, PersistentProfileEventType::kRunner2);
      }
    }
  }
};

template <uint32_t HEAD_DIM_VO_, uint32_t NUM_SMEM_STAGES_, uint32_t NUM_THREADS_,
          typename DTypeIn_, typename DTypeO_, typename IdType_>
struct StateReductionKernelTraits {
  using DTypeIn = DTypeIn_;
  using DTypeO = DTypeO_;
  using IdType = IdType_;

  static constexpr uint32_t HEAD_DIM_VO = HEAD_DIM_VO_;
  static constexpr uint32_t NUM_SMEM_STAGES = NUM_SMEM_STAGES_;
  static constexpr uint32_t NUM_THREADS = NUM_THREADS_;
  static constexpr uint32_t NUM_WARPS = NUM_THREADS / 32;

  static constexpr uint32_t vec_size =
      std::max<uint32_t>(16U / static_cast<uint32_t>(sizeof(DTypeIn)), HEAD_DIM_VO / 32U);
  static constexpr uint32_t bdx = HEAD_DIM_VO / vec_size;

  // gridDim is accessed by runtime variable and should be set by core attention
  // workload layout [bdx, bdy, num_warps]
  static_assert(NUM_THREADS % bdx == 0);
  static constexpr uint32_t bdy = 32 / bdx;

  // pipeline load & reduction
  static constexpr size_t SMEM_SIZE =
      NUM_WARPS * NUM_SMEM_STAGES * bdy * HEAD_DIM_VO * sizeof(DTypeIn) +
      NUM_THREADS * sizeof(float);
};

template <typename KTraits_>
struct BlockBatchReductionPersistent {
  using KTraits = KTraits_;

  static __device__ __forceinline__ void Run(
      typename KTraits::DTypeIn* __restrict__ V, typename KTraits::DTypeO* __restrict__ v_merged,
      float* __restrict__ S, float* __restrict__ s_merged,
      const typename KTraits::IdType num_packed_qo_len, const uint_fastdiv gqa_group_size,
      const uint32_t num_kv_heads, const typename KTraits::IdType* indptr,
      const typename KTraits::IdType* o_indices, uint8_t* smem PROFILER_CLOSURE_FUNC_PARAMS) {
    __syncthreads();  // NOTE(Zihao): required for guarantee correctness on blackwell
    using DTypeIn = typename KTraits::DTypeIn;
    using DTypeO = typename KTraits::DTypeO;
    using IdType = typename KTraits::IdType;

    [[maybe_unused]] constexpr uint32_t bdx = KTraits::bdx;
    [[maybe_unused]] constexpr uint32_t bdy = KTraits::bdy;
    [[maybe_unused]] constexpr uint32_t num_warps = KTraits::NUM_WARPS;

    [[maybe_unused]] constexpr uint32_t vec_size = KTraits::vec_size;
    [[maybe_unused]] constexpr uint32_t head_dim = KTraits::HEAD_DIM_VO;
    [[maybe_unused]] constexpr uint32_t num_smem_stages = KTraits::NUM_SMEM_STAGES;
    [[maybe_unused]] constexpr uint32_t vec_bits = sizeof(DTypeIn) * vec_size * 8;

    // control flow metadata
    const uint32_t warp_idx = threadIdx.x / 32;
    const uint32_t tx = (threadIdx.x % 32) % bdx, ty = (threadIdx.x % 32) / bdx;

    const uint32_t worker_id = blockIdx.y * num_warps + warp_idx;
    const uint32_t num_workers = gridDim.x * gridDim.y * gridDim.z * num_warps;

    DTypeIn* v_smem = (DTypeIn*)smem + warp_idx * num_smem_stages * bdy * head_dim;
    // FIXME: fix the offset calculation
    float* s_smem = (float*)(smem + num_warps * num_smem_stages * bdy * head_dim * sizeof(DTypeIn) +
                             warp_idx * 32 * sizeof(float));

    // V: [num_packed_qo_len x num_kv_tiles, num_kv_heads, head_dim]
    // v_merged: [qo_len, num_kv_heads, gqa_group_size, head_dim]
#pragma unroll 1
    for (uint32_t i = worker_id; i < num_packed_qo_len * num_kv_heads; i += num_workers) {
      PROFILER_EVENT_START(profiler_closure, PersistentProfileEventType::kReduction);
      __syncwarp();  // avoid data hazard due to reordering st.cast_store
      // remap workload
      uint32_t packed_qo_idx = i / num_kv_heads;
      uint32_t kv_head_idx = i % num_kv_heads;
      const uint32_t num_index_sets = indptr[packed_qo_idx + 1] - indptr[packed_qo_idx];
      if (num_index_sets == 0 || num_index_sets == 1) {
        // already write through, bypass
        PROFILER_EVENT_END(profiler_closure, PersistentProfileEventType::kReduction);
        continue;
      }

      // index calculation
      auto partial_idx_to_offset = [&](uint32_t off) {
        return (indptr[packed_qo_idx] + off) * num_kv_heads + kv_head_idx;
      };
      auto merge_idx_to_offset = [&]() {
        // NOTE (Yilong): qo_head_idx has been calculated in schedule.plan
        return o_indices[packed_qo_idx] + kv_head_idx * gqa_group_size;
      };

      state_t<vec_size> st;

#pragma unroll
      for (uint32_t iter = 0; iter < num_smem_stages; ++iter) {
        cp_async::pred_load<vec_bits, PrefetchMode::kPrefetch, SharedMemFillMode::kNoFill>(
            v_smem + (iter * bdy + ty) * head_dim + tx * vec_size,
            V + partial_idx_to_offset(iter * bdy + ty) * head_dim + tx * vec_size,
            (iter * bdy + ty) < num_index_sets);
        cp_async::commit_group();
      }
#pragma unroll 4
      for (uint32_t iter = 0; iter < ceil_div(num_index_sets, bdy); ++iter) {
        if (iter % bdx == 0) {
          s_smem[ty * bdx + tx] = iter * bdy + (ty * bdx + tx) < num_index_sets
                                      ? S[partial_idx_to_offset(iter * bdy + ty * bdx + tx)]
                                      : 0.f;
          __syncwarp();
        }
        cp_async::wait_group<num_smem_stages - 1>();
        __syncwarp();
        vec_t<float, vec_size> v;
        v.cast_load(v_smem + ((iter % num_smem_stages) * bdy + ty) * head_dim + tx * vec_size);
        if (iter * bdy + ty < num_index_sets) {
          float s = s_smem[(iter % bdx) * bdy + ty];
          st.merge(v, s, 1);
        }
        __syncwarp();
        cp_async::pred_load<vec_bits, PrefetchMode::kPrefetch, SharedMemFillMode::kNoFill>(
            v_smem + ((iter % num_smem_stages) * bdy + ty) * head_dim + tx * vec_size,
            V + partial_idx_to_offset((iter + num_smem_stages) * bdy + ty) * head_dim +
                tx * vec_size,
            (iter + num_smem_stages) * bdy + ty < num_index_sets);
        cp_async::commit_group();
      }
      cp_async::wait_group<0>();
      __syncwarp();

      st.normalize();
      if constexpr (bdy > 1) {
        warp_sync_state<bdx, bdy, vec_size>(st, v_smem, s_smem, tx, ty);
        st.normalize();
      }

      st.o.cast_store(v_merged + merge_idx_to_offset() * head_dim + tx * vec_size);
      if (s_merged != nullptr) {
        s_merged[merge_idx_to_offset()] = st.get_lse();
      }
      PROFILER_EVENT_END(profiler_closure, PersistentProfileEventType::kReduction);
    }
  }
};

// KVStagedTraits and its tuning macros live at NAMESPACE scope. The fuzzy patch placed this
// block inside the struct template below, where C++ forbids template declarations -- nvcc
// reported only "a template declaration is not allowed here", naming neither the template nor
// the enclosing scope. Second structural corruption from fuzzy patching on these files.
#ifndef FLASHINFER_FA2_KV_STAGES_1
#define FLASHINFER_FA2_KV_STAGES_1 2
#endif
#ifndef FLASHINFER_FA2_KV_STAGES_2
#define FLASHINFER_FA2_KV_STAGES_2 3
#endif
#ifndef FLASHINFER_FA2_KV_STAGES_3
#define FLASHINFER_FA2_KV_STAGES_3 1
#endif
#ifndef FLASHINFER_FA2_NUM_MMA_KV_3
#define FLASHINFER_FA2_NUM_MMA_KV_3 2
#endif

template <typename Base, uint32_t S>
struct KVStagedTraits : Base {
  static_assert(S >= 1);
  static constexpr uint32_t NUM_KV_STAGES = S;
  // S tiles stacked along the row axis: a slot boundary is a multiple of 8 rows, so the
  // 128B swizzle (row % 8) is the same in every slot.
  using SharedStorage =
      SharedStorageQKVO<Base::NUM_WARPS_KV, Base::CTA_TILE_Q, Base::CTA_TILE_KV * S,
                        Base::HEAD_DIM_QK, Base::HEAD_DIM_VO, typename Base::DTypeQ,
                        typename Base::DTypeKV, typename Base::DTypeO>;
};

template <uint32_t CTA_TILE_Q_1, uint32_t CTA_TILE_Q_2, uint32_t HEAD_DIM_QK, uint32_t HEAD_DIM_VO,
          MaskMode MASK_MODE, typename AttentionVariant, typename Params>
cudaError_t BatchPagedAttentionPersistent(const Params params_1, const Params params_2,
                                          const uint32_t num_blks_x, const uint32_t num_blks_y,
                                          const cudaStream_t stream) {
  static_assert(HEAD_DIM_VO <= 256 && HEAD_DIM_QK <= 256,
                "BatchAttention (holistic persistent) kernel does not support "
                "head_dim > 256; use the FA2 prefill/decode path for large head dims.");
  using DTypeQ = typename Params::DTypeQ;
  using DTypeKV = typename Params::DTypeKV;
  using DTypeO = typename Params::DTypeO;
  using IdType = typename Params::IdType;
  constexpr uint32_t NUM_WARPS_Q_1 = get_num_warps_q(CTA_TILE_Q_1);
  constexpr uint32_t NUM_WARPS_KV_1 = get_num_warps_kv(CTA_TILE_Q_1);
  constexpr uint32_t NUM_MMA_Q_1 = get_num_mma_q(CTA_TILE_Q_1);
  constexpr uint32_t NUM_MMA_KV_1 = 4;
  constexpr uint32_t NUM_MMA_D_QK = HEAD_DIM_QK / 16;
  constexpr uint32_t NUM_MMA_D_VO = HEAD_DIM_VO / 16;
  using KTraits1 = KernelTraits<MASK_MODE, CTA_TILE_Q_1, NUM_MMA_Q_1, NUM_MMA_KV_1, NUM_MMA_D_QK,
                                NUM_MMA_D_VO, NUM_WARPS_Q_1, NUM_WARPS_KV_1, PosEncodingMode::kNone,
                                DTypeQ, DTypeKV, DTypeO, float, IdType, AttentionVariant>;
  constexpr uint32_t NUM_WARPS_Q_2 = get_num_warps_q(CTA_TILE_Q_2);
  constexpr uint32_t NUM_WARPS_KV_2 = get_num_warps_kv(CTA_TILE_Q_2);
  constexpr uint32_t NUM_MMA_Q_2 = get_num_mma_q(CTA_TILE_Q_2);
  constexpr uint32_t NUM_MMA_KV_2 = 2;
  using KTraits2 = KernelTraits<MASK_MODE, CTA_TILE_Q_2, NUM_MMA_Q_2, NUM_MMA_KV_2, NUM_MMA_D_QK,
                                NUM_MMA_D_VO, NUM_WARPS_Q_2, NUM_WARPS_KV_2, PosEncodingMode::kNone,
                                DTypeQ, DTypeKV, DTypeO, float, IdType, AttentionVariant>;

  // Attention state reduction kernel
// K/V smem ring depth per tile class (128 / 64 / 16 q rows). The FA2 plan puts two CTAs on
// every SM, so a class's SharedStorage must stay under ~113 KB: at head_dim 128 that allows
// 2 stages for the 128 tile (96 KB) and up to 4 for the 64 tile, but the 16 tile's 128-row KV
// tile already costs 68 KB at depth 1. Defaults measured 2026-10-07 (fa2_stage_bench.py):
// 2/3/1 is -7.4% on MTP-verify rows, -10.3% at 64-128K, -2.0% on appends; the 16 tile is
// at ~80% of HBM bandwidth already and loses 2-5% to the smaller KV tile depth 2 needs.

  constexpr uint32_t NUM_THREADS =
      KTraits1::NUM_THREADS > KTraits2::NUM_THREADS ? KTraits1::NUM_THREADS : KTraits2::NUM_THREADS;
  using ReductionKTraits =
      StateReductionKernelTraits<HEAD_DIM_VO, 4, NUM_THREADS, DTypeO, DTypeO, IdType>;
  size_t smem_size =
      max(sizeof(typename KTraits1::SharedStorage), sizeof(typename KTraits2::SharedStorage));
  smem_size = max(smem_size, ReductionKTraits::SMEM_SIZE);

  // Launch persistent kernel
  auto kernel = PersistentKernelTemplate<BlockBatchPagedAttentionPersistent<KTraits1, Params>,
                                         BlockBatchPagedAttentionPersistent<KTraits2, Params>,
                                         BlockBatchReductionPersistent<ReductionKTraits>>;
  FLASHINFER_CUDA_CALL(
      cudaFuncSetAttribute(kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, smem_size));
  dim3 nblks(num_blks_x, num_blks_y);
  dim3 nthrs(NUM_THREADS);
  void* args[] = {(void*)&params_1, (void*)&params_2};
  FLASHINFER_CUDA_CALL(
      cudaLaunchCooperativeKernel((void*)kernel, nblks, nthrs, args, smem_size, stream));
  return cudaSuccess;
}

};  // namespace flashinfer

#endif  // FLASHINFER_PERSISTENT_CUH_

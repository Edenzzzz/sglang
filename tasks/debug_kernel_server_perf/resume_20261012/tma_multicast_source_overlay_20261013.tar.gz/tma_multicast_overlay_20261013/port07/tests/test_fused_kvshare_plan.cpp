#include <cassert>
#include <cstdio>
#include <map>
#include <tuple>
#include <vector>

#include <flashinfer/attention/fused_plan.cuh>

int main() {
  for (uint32_t cta_count : {2u, 4u, 8u, 16u}) {
    for (int32_t count = 0; count <= 257; ++count) {
      std::vector<flashinfer::FusedWorkItem> items;
      for (int32_t index = 0; index < count; ++index) {
        items.push_back({index, 0, 128, 0, 1024, 0});
      }
      const auto offsets = flashinfer::FusedPairFa3WorkItems(items, cta_count);
      assert(offsets.size() == cta_count + 1 && offsets.front() == 0 && offsets.back() == count);
      std::vector<int> seen(count, 0);
      for (uint32_t cta = 0; cta < cta_count; ++cta) {
        assert(offsets[cta] <= offsets[cta + 1]);
        for (int32_t index = offsets[cta]; index < offsets[cta + 1]; ++index) {
          assert(items[index].batch_idx >= 0 && items[index].batch_idx < count);
          ++seen[items[index].batch_idx];
        }
      }
      for (int frequency : seen) assert(frequency == 1);
      for (uint32_t cta = 0; cta < cta_count; cta += 2) {
        const int32_t left_count = offsets[cta + 1] - offsets[cta];
        const int32_t right_count = offsets[cta + 2] - offsets[cta + 1];
        assert(left_count == right_count || left_count == right_count + 1);
        for (int32_t slot = 0; slot < right_count; ++slot) {
          const auto& left = items[offsets[cta] + slot];
          const auto& right = items[offsets[cta + 1] + slot];
          assert(left.batch_idx % 2 == 0 && right.batch_idx == left.batch_idx + 1);
        }
      }
    }
  }
  for (uint32_t cta_count : {0u, 1u, 3u}) {
    std::vector<flashinfer::FusedWorkItem> items;
    bool rejected = false;
    try {
      flashinfer::FusedPairFa3WorkItems(items, cta_count);
    } catch (const std::exception&) {
      rejected = true;
    }
    assert(rejected);
  }
  int32_t queries[] = {257, 512};
  int32_t context[] = {1025, 4096};
  int32_t query_offsets[] = {0, 257, 769};
  bool mask[] = {true, true};
  std::vector<flashinfer::FusedWorkItem> items[4];
  int32_t max_splits = 0;
  std::vector<int32_t> requests;
  flashinfer::EnumerateFusedWorkItems(queries, context, mask, 2, 7, 4, 128, 256,
                                    items, &max_splits, &requests);
  flashinfer::FusedMergeLayout original_merge;
  flashinfer::BuildFusedMergeLayout(items, context, 2, 4, query_offsets, 7, &original_merge);
  using Key = std::tuple<int32_t, int32_t, int32_t, int32_t>;
  std::map<Key, int32_t> partials;
  for (size_t index = 0; index < items[3].size(); ++index) {
    const auto& item = items[3][index];
    partials[{item.batch_idx, item.q_start, item.kv_head_idx, item.kv_start}] =
        original_merge.partial_indptr[3][index];
  }
  flashinfer::FusedPairFa3WorkItems(items[3], 112);
  flashinfer::FusedMergeLayout paired_merge;
  flashinfer::BuildFusedMergeLayout(items, context, 2, 4, query_offsets, 7, &paired_merge);
  assert(original_merge.merge_indptr == paired_merge.merge_indptr);
  assert(original_merge.merge_o_indices == paired_merge.merge_o_indices);
  for (size_t index = 0; index < items[3].size(); ++index) {
    const auto& item = items[3][index];
    assert((partials.at({item.batch_idx, item.q_start, item.kv_head_idx, item.kv_start}) ==
            paired_merge.partial_indptr[3][index]));
  }
  std::puts("FA3 cluster-pair coverage, odd tails, and split-merge coordinates: PASS");
}

import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import torch

sys.path.insert(0, str(Path(__file__).parent / "candidate"))
from kernel_logit_audit import capture_mixed_logits


class TestInternalLogits(unittest.TestCase):
    def fixtures(self):
        prefill = SimpleNamespace(reqs=[SimpleNamespace(rid="l0", origin_input_ids=[1, 2, 3])], seq_lens=torch.tensor([3]))
        running = SimpleNamespace(reqs=[SimpleNamespace(rid="s1", origin_input_ids=[6, 7, 8])], seq_lens=torch.tensor([3]))
        verify = SimpleNamespace(draft_token_num=4, draft_token=torch.tensor([1, 2, 3, 4]))
        prefill_logits = torch.tensor([[0.0, 1.0, 3.0, 2.5, -2.0, -3.0]])
        verify_logits = prefill_logits.repeat(4, 1)
        return prefill, running, verify, prefill_logits, verify_logits

    def collect(self, fixtures, **environment):
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "logits.jsonl"
            with patch.dict(os.environ, {"SGLANG_KERNEL_LOGIT_AUDIT": str(destination), **environment}):
                capture_mixed_logits(*fixtures)
            return [json.loads(line) for line in destination.read_text().splitlines()] if destination.exists() else []

    def test_output_positions_and_proposal_history(self):
        fixtures = self.fixtures()
        original = fixtures[-1].clone()
        records = self.collect(fixtures)
        self.assertEqual([record["output_index"] for record in records], [0, 1, 2, 3, 4])
        self.assertEqual(records[2]["proposal_begin"], 0)
        self.assertEqual(records[2]["proposal_tokens"], [1, 2])
        self.assertEqual(records[0]["argmax"], 2)
        self.assertAlmostEqual(records[0]["top_logits"][0] - records[0]["top_logits"][1], 0.5)
        torch.testing.assert_close(fixtures[-1], original, rtol=0, atol=0)

    def test_partial_prefill_and_limits(self):
        fixtures = self.fixtures()
        fixtures[0].seq_lens[0] = 2
        records = self.collect(fixtures, SGLANG_KERNEL_LOGIT_AUDIT_TOKENS="2")
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["role"], "verify")
        self.assertEqual(records[0]["output_index"], 1)
        self.assertEqual(self.collect(fixtures, SGLANG_KERNEL_LOGIT_AUDIT_RIDS="absent"), [])

    def test_bad_extents_rejected(self):
        fixtures = list(self.fixtures())
        fixtures[-1] = fixtures[-1][:1]
        with self.assertRaisesRegex(ValueError, "row extent"):
            self.collect(fixtures)


if __name__ == "__main__":
    unittest.main(verbosity=2)

set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi
export FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=64,32,16 FUSED_CONST_PERS_PARAMS=1 FUSED_FA2_REG_REALLOC=1 FLASHINFER_FUSED_BACKFILL=1 FUSED_FA2_KV_CHUNK=1024
export SGLANG_FUSED_FA2_MMA_KV=2 SGLANG_FUSED_FA2_QSPLIT=0 FA3_STAGES=2 FA3_CTA_Q=128 SGLANG_FUSED_FA3_CONSUMER_REGS=0
/dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/replay_fused_failure.py /dev/shm/w/mixed_trace_integration/failure.pt --saved-plan --original-strides --physical-pages --poison-workspace --repeats 3

import argparse
import hashlib
import json
from pathlib import Path
import re


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--concurrency", type=int, required=True)
    parser.add_argument("--chain", type=int, choices=(0, 1), required=True)
    parser.add_argument("--verify", type=int, choices=(0, 1), required=True)
    parser.add_argument("--reference", type=Path)
    args = parser.parse_args()
    method = "MTPMIX_SPLIT"
    program_path = args.directory / f"{method}_agent_programs.json"
    programs = json.loads(program_path.read_text())
    assert programs["concurrency_limit"] == args.concurrency
    assert programs["sessions"] == 48 and programs["rounds"] == 96
    active = set()
    peak = 0
    for event in programs["events"]:
        session = event["session_id"]
        if event["event"] == "start":
            assert session not in active
            active.add(session)
        else:
            assert event["event"] == "end" and session in active
            active.remove(session)
        peak = max(peak, len(active))
        assert len(active) <= args.concurrency
    assert not active and peak == args.concurrency == programs["peak_active_programs"]
    server_path = args.directory / f"server_{method}.log"
    server = server_path.read_text()
    assert "Traceback" not in server and "fallback" not in server.lower()
    assert "cuda graph: True" in server and "EDF_RUNTIME_" not in server
    assert "FUSED_CHAIN_WARMUP batches=48 complete" in server
    split_counts = re.findall(r"FUSED_SPLIT_CALLS (\d+)", server)
    mixed_counts = re.findall(r"MIXEDSPEC_STEPS (\d+)", server)
    chain_counts = re.findall(r"FUSED_CHAIN_TREE calls=(\d+)", server)
    assert split_counts and int(split_counts[-1]) > 0
    assert mixed_counts and int(mixed_counts[-1]) > 0
    assert bool(chain_counts) == bool(args.chain)
    assert ("FUSED_VERIFY_EPILOGUE active" in server) == bool(args.verify)
    summary = {
        "program_limit": args.concurrency,
        "program_peak": peak,
        "program_mean": programs["mean_active_programs"],
        "delay_policy": programs["delay_policy"],
        "split_calls": int(split_counts[-1]),
        "mixed_steps": int(mixed_counts[-1]),
        "chain_calls": int(chain_counts[-1]) if chain_counts else 0,
        "verify_enabled": bool(args.verify),
        "server_sha256": hashlib.sha256(server_path.read_bytes()).hexdigest(),
        "streams": {},
    }
    for stream, count in (("agent", 96), ("chat", 2048)):
        path = args.directory / f"{method}_{stream}.json"
        result = json.loads(path.read_text())
        assert result["completed"] == count and not any(result["errors"])
        assert len(result["request_keys"]) == count
        assert len(result["token_events"]) == count
        if args.reference is not None:
            reference = json.loads((args.reference / path.name).read_text())
            assert result["request_keys"] == reference["request_keys"]
            assert result["requested_output_lens"] == reference["requested_output_lens"]
        summary["streams"][stream] = {
            key: value
            for key, value in result.items()
            if isinstance(value, (int, float, bool))
        }
        summary["streams"][stream]["first_request_start"] = min(
            result["request_start_times"]
        )
        summary["streams"][stream]["last_request_end"] = max(
            result["request_end_times"]
        )
        summary["streams"][stream]["result_sha256"] = hashlib.sha256(
            path.read_bytes()
        ).hexdigest()
    if args.reference is not None:
        prior = json.loads((args.reference / program_path.name).read_text())
        assert programs["session_rounds"] == prior["session_rounds"]
    agent, chat = summary["streams"]["agent"], summary["streams"]["chat"]
    overlap = max(
        0,
        min(agent["last_request_end"], chat["last_request_end"])
        - max(agent["first_request_start"], chat["first_request_start"]),
    )
    union = max(agent["last_request_end"], chat["last_request_end"]) - min(
        agent["first_request_start"], chat["first_request_start"]
    )
    summary["overlapping_stream_span_s"] = overlap
    summary["overlap_fraction_of_union"] = overlap / union if union else 0
    (args.directory / "kernel_concurrency_audit.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print("KERNEL_CONCURRENCY_PASS", json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()

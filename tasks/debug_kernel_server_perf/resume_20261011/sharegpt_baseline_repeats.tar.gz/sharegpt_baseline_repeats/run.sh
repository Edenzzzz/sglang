set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi HF_HOME=/dev/shm/w/hf
export CORRECTNESS_SYNTHETIC=0 CORRECTNESS_DATASET=/dev/shm/w/datasets/ShareGPT.original.json
export DISABLE_CUDA_GRAPH=1 BENCH_CHUNK=512 CORRECTNESS_DECODE_TOKENS=1200
cp /dev/shm/w/sharegpt_correctness/MTP_LPT.json /dev/shm/w/sharegpt_baseline_repeats/MTP_LPT.json
for arm in MTP_LPT_R2 MTP_LPT_R3; do
 /dev/shm/w/venv/bin/python -u /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py $arm /dev/shm/w/sharegpt_baseline_repeats
done
status=0
for arm in MTP_LPT_R2 MTP_LPT_R3; do
 if ! /dev/shm/w/venv/bin/python /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py --compare /dev/shm/w/sharegpt_baseline_repeats MTP_LPT $arm; then status=1; fi
done
echo BASELINE_REPEAT_GATES_STATUS=$status
exit $status

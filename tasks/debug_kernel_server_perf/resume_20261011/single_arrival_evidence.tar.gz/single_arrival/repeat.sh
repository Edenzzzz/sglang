set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi HF_HOME=/dev/shm/w/hf
export O_HANDSHAKE=1 Q_REUSE_FENCE=1 SPLIT_SMEM_O=1 DISABLE_CUDA_GRAPH=1 BENCH_CHUNK=512 CORRECTNESS_DECODE_TOKENS=1200 SGLANG_FUSED_DECODE_GUARD=0 SGLANG_FUSED_SPLIT_VERIFY=1
for repetition in 2 3; do
 output=/dev/shm/w/single_arrival_r$repetition
 mkdir -p "$output"
 SGLANG_FUSED_FAILURE_DUMP="$output/failure.pt" /dev/shm/w/venv/bin/python -u /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py MTPMIXFUSED "$output" > "$output/run.log" 2>&1
 echo "SINGLE_ARRIVAL_REPEAT_$repetition PASS"
done

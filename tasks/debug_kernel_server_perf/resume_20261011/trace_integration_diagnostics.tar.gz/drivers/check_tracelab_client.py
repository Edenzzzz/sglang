import random, hashlib, array, json
from transformers import AutoTokenizer
from sglang.benchmark.datasets.tracelab import TraceLabClaudeDataset
random.seed(0)
tokenizer=AutoTokenizer.from_pretrained('/dev/shm/w/qwen7b')
rows=TraceLabClaudeDataset('/dev/shm/w/workloads/tracelab/syfi_coding_trace.jsonl.gz',72,12,32768,49152,512).load(tokenizer)
measured=[row for row in rows if not row.warmup_only]
digest=hashlib.sha256()
for row in measured:
 digest.update(array.array('i',row.prompt).tobytes())
 digest.update(str(row.output_len).encode())
print(json.dumps({'requests':len(measured),'sessions':len(set(row.session_id for row in measured)),'warmups':len(rows)-len(measured),'input_min':min(row.prompt_len for row in measured),'input_max':max(row.prompt_len for row in measured),'input_mean':sum(row.prompt_len for row in measured)/len(measured),'output_min':min(row.output_len for row in measured),'output_max':max(row.output_len for row in measured),'output_mean':sum(row.output_len for row in measured)/len(measured),'payload_sha256':digest.hexdigest()}))

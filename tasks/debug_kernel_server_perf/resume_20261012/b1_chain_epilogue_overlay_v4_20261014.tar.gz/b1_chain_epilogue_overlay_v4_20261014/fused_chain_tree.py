import torch
import triton
import triton.language as tl


@triton.jit
def _fused_chain_tree_kernel(
    bonus,
    draft,
    lengths,
    mask,
    positions,
    retrieve,
    tokens,
    request_indices,
    request_table,
    cache_locations,
    mrope,
    BATCH: tl.constexpr,
    WIDTH: tl.constexpr,
    MODE: tl.constexpr,
    FILL_PREFIX: tl.constexpr,
    BONUS_STRIDE: tl.constexpr,
    DRAFT_ROW: tl.constexpr,
    DRAFT_COLUMN: tl.constexpr,
    LENGTH_STRIDE: tl.constexpr,
    REQUEST_STRIDE: tl.constexpr,
    TABLE_ROW: tl.constexpr,
    TABLE_COLUMN: tl.constexpr,
    WRITE_CACHE: tl.constexpr,
    WRITE_MROPE: tl.constexpr,
    REQUEST_BLOCK: tl.constexpr,
    TOKEN_BLOCK: tl.constexpr,
    TREE_BLOCK: tl.constexpr,
    MASK_BLOCK: tl.constexpr,
):
    request = tl.program_id(0).to(tl.int64)
    tile = tl.program_id(1)
    length = tl.load(lengths + request * LENGTH_STRIDE).to(tl.int64)
    base = request * WIDTH
    mask_base = request * WIDTH * WIDTH
    if MODE == 0:
        preceding = tl.arange(0, REQUEST_BLOCK)
        prior_lengths = tl.load(
            lengths + preceding * LENGTH_STRIDE, preceding < request, other=0
        ).to(tl.int64)
        mask_base += tl.sum(prior_lengths, 0) * WIDTH

    if tile == 0:
        column = tl.arange(0, TOKEN_BLOCK)
        valid = column < WIDTH
        first = tl.load(bonus + request * BONUS_STRIDE)
        rest = tl.load(
            draft + request * DRAFT_ROW + (column - 1) * DRAFT_COLUMN,
            valid & (column > 0),
            other=0,
        )
        tl.store(tokens + base + column, tl.where(column == 0, first, rest), valid)
        tl.store(positions + base + column, length + column, valid)
        tl.store(retrieve + base + column, base + column, valid)
        tl.store(
            retrieve + BATCH * WIDTH + base + column,
            tl.where(column + 1 < WIDTH, column + 1, -1),
            valid,
        )
        tl.store(retrieve + 2 * BATCH * WIDTH + base + column, -1, valid)
        if WRITE_CACHE:
            pool_row = tl.load(request_indices + request * REQUEST_STRIDE).to(tl.int64)
            location = tl.load(
                request_table + pool_row * TABLE_ROW + (length + column) * TABLE_COLUMN,
                valid,
                other=0,
            )
            tl.store(cache_locations + base + column, location, valid)
        if WRITE_MROPE:
            for axis in tl.static_range(3):
                tl.store(
                    mrope + axis * BATCH * WIDTH + base + column, length + column, valid
                )
        if MODE == 2:
            packed = (tl.full((TOKEN_BLOCK,), 1, tl.uint64) << (column + 1)) - 1
            tl.store(mask + base + column, packed, valid)
        else:
            tree_offset = tl.arange(0, TREE_BLOCK)
            tree_row = tree_offset // WIDTH
            tree_column = tree_offset % WIDTH
            if MODE == 0:
                destination = (
                    mask_base + tree_row * (length + WIDTH) + length + tree_column
                )
            else:
                destination = mask_base + tree_offset
            tl.store(
                mask + destination, tree_column <= tree_row, tree_offset < WIDTH * WIDTH
            )

    if MODE == 0 and FILL_PREFIX:
        row_width = length + WIDTH
        word_offsets = tl.arange(0, MASK_BLOCK // 4).to(tl.int64)
        edge_offsets = tl.arange(0, 4)
        for query in tl.static_range(WIDTH):
            prefix_base = mask_base + query * row_width
            head = tl.minimum((-prefix_base) & 3, length)
            words = (length - head) // 4
            aligned = (mask + prefix_base + head).to(tl.pointer_type(tl.uint32))
            for start in range(
                tile * (MASK_BLOCK // 4),
                words,
                tl.num_programs(1) * (MASK_BLOCK // 4),
            ):
                word = start + word_offsets
                tl.store(aligned + word, 0x01010101, word < words)
            if tile == 0:
                tl.store(mask + prefix_base + edge_offsets, True, edge_offsets < head)
                tail = head + words * 4 + edge_offsets
                tl.store(
                    mask + prefix_base + tail,
                    True,
                    tail < length,
                )


def build_fused_chain_tree(
    bonus_tokens,
    draft_tokens,
    seq_lens,
    seq_lens_sum,
    tree_mask_mode=0,
    tree_mask_buf=None,
    fill_prefix_mask=True,
    req_pool_indices=None,
    req_to_token=None,
    with_mrope=False,
):
    if draft_tokens.ndim != 2 or bonus_tokens.ndim != 1 or seq_lens.ndim != 1:
        raise ValueError("chain inputs must be a draft matrix and two vectors")
    batch_size, depth = draft_tokens.shape
    width = depth + 1
    mode = int(tree_mask_mode)
    if mode not in (0, 1, 2) or width > 32:
        raise ValueError("supported mask modes are 0/1/2 and chain width is at most 32")
    if bonus_tokens.numel() != batch_size or seq_lens.numel() != batch_size:
        raise ValueError("chain inputs must have matching batch dimensions")
    for tensor in (bonus_tokens, draft_tokens, seq_lens):
        if (
            tensor.dtype not in (torch.int32, torch.int64)
            or tensor.device != seq_lens.device
        ):
            raise ValueError("chain inputs must be same-device int32/int64 tensors")
    if not seq_lens.is_cuda or seq_lens_sum < 0:
        raise ValueError(
            "chain construction requires CUDA and a nonnegative length bound"
        )
    if (req_pool_indices is None) != (req_to_token is None):
        raise ValueError("request indices and cache table must be supplied together")
    if req_to_token is not None:
        if req_pool_indices.shape != (batch_size,) or req_to_token.ndim != 2:
            raise ValueError(
                "cache lookup requires one request index per sequence and a table"
            )
        for tensor in (req_pool_indices, req_to_token):
            if tensor.device != seq_lens.device or tensor.dtype not in (
                torch.int32,
                torch.int64,
            ):
                raise ValueError(
                    "cache lookup tensors must be same-device integer tensors"
                )
    mask_dtype = (
        torch.bool
        if mode != 2
        else (
            torch.uint8 if width <= 8 else torch.uint16 if width <= 16 else torch.uint32
        )
    )
    mask_size = batch_size * width if mode == 2 else batch_size * width * width
    if mode == 0:
        mask_size += seq_lens_sum * width
    mask = tree_mask_buf
    if mask is None:
        mask = torch.empty(mask_size, dtype=mask_dtype, device=seq_lens.device)
    if (
        mask.device != seq_lens.device
        or mask.dtype != mask_dtype
        or not mask.is_contiguous()
        or mask.numel() < mask_size
    ):
        raise ValueError(
            "mask buffer must have the required device, dtype and capacity"
        )
    positions = torch.empty(
        batch_size * width, dtype=torch.int64, device=seq_lens.device
    )
    retrieve = torch.empty(
        (3, batch_size, width), dtype=torch.int64, device=seq_lens.device
    )
    tokens = torch.empty(
        batch_size * width,
        dtype=torch.promote_types(bonus_tokens.dtype, draft_tokens.dtype),
        device=seq_lens.device,
    )
    cache_locations = torch.empty_like(positions) if req_to_token is not None else None
    mrope = (
        torch.empty((3, batch_size * width), dtype=torch.int64, device=seq_lens.device)
        if with_mrope
        else None
    )
    if batch_size:
        tiles = (
            min(64, max(1, triton.cdiv(mask_size, batch_size * 4096)))
            if mode == 0 and fill_prefix_mask
            else 1
        )
        _fused_chain_tree_kernel[(batch_size, tiles)](
            bonus_tokens,
            draft_tokens,
            seq_lens,
            mask,
            positions,
            retrieve,
            tokens,
            req_pool_indices,
            req_to_token,
            cache_locations,
            mrope,
            BATCH=batch_size,
            WIDTH=width,
            MODE=mode,
            FILL_PREFIX=fill_prefix_mask,
            BONUS_STRIDE=bonus_tokens.stride(0),
            DRAFT_ROW=draft_tokens.stride(0),
            DRAFT_COLUMN=draft_tokens.stride(1),
            LENGTH_STRIDE=seq_lens.stride(0),
            REQUEST_STRIDE=(
                req_pool_indices.stride(0) if req_pool_indices is not None else 0
            ),
            TABLE_ROW=req_to_token.stride(0) if req_to_token is not None else 0,
            TABLE_COLUMN=req_to_token.stride(1) if req_to_token is not None else 0,
            WRITE_CACHE=req_to_token is not None,
            WRITE_MROPE=with_mrope,
            REQUEST_BLOCK=triton.next_power_of_2(batch_size),
            TOKEN_BLOCK=triton.next_power_of_2(width),
            TREE_BLOCK=triton.next_power_of_2(width * width),
            MASK_BLOCK=1024,
            num_warps=4,
        )
    return (
        mask,
        positions,
        retrieve[0],
        retrieve[1],
        retrieve[2],
        tokens,
        cache_locations,
        mrope,
    )

import gzip
import json
import random
from typing import Optional
from dataclasses import dataclass
from datetime import datetime

from sglang.benchmark.datasets.common import (
    BaseDataset,
    DatasetRow,
    get_available_tokens,
)


@dataclass
class TraceLabClaudeDataset(BaseDataset):
    """Synthetic token contents with recorded TraceLab lengths and session ordering.

    This is a length/session trace replay, not a replay of original agent text.
    Selected request lengths are neither clipped nor retokenized.
    """

    dataset_path: str
    num_requests: int
    num_groups: int
    min_context_len: int
    max_context_len: int
    min_output_len: int
    # Full-release replay: which providers to keep, and whether a session's first round (empty
    # prefix) is replayable. Defaults reproduce every earlier Claude-only, prefix>0 run.
    providers: tuple = ("claude",)
    allow_empty_prefix: bool = False
    # "rounds" picks sessions with probability proportional to their eligible round count, so the
    # replayed rounds follow the release's ROUND-level context distribution (uniform session
    # picks under-sample long contexts, which live in long sessions: median 51K vs 124K).
    session_weighting: str = "uniform"
    # Seed for session and window selection only (token draws stay on the global RNG), so a
    # selection checked offline against the release's distribution replays unchanged.
    selection_seed: Optional[int] = None

    @classmethod
    def from_args(cls, args):
        if not args.tokenize_prompt:
            raise ValueError("tracelab-claude requires --tokenize-prompt to preserve lengths")
        return cls(
            args.dataset_path,
            args.num_prompts,
            args.tracelab_num_groups,
            args.tracelab_min_context_len,
            args.tracelab_max_context_len,
            args.tracelab_min_output_len,
            tuple(p for p in getattr(args, "tracelab_providers", "claude").split(",") if p),
            bool(getattr(args, "tracelab_allow_empty_prefix", False)),
            getattr(args, "tracelab_session_weighting", "uniform"),
            getattr(args, "tracelab_selection_seed", None),
        )

    def load(self, tokenizer, model_id=None):
        if not self.dataset_path:
            raise ValueError("--dataset-path must identify a TraceLab JSONL(.gz) file")
        if not 0 < self.num_groups <= self.num_requests:
            raise ValueError("--tracelab-num-groups must be in [1, num_prompts]")
        if self.min_context_len < 0 or self.max_context_len < self.min_context_len:
            raise ValueError("Invalid TraceLab context-length selection interval")
        opener = gzip.open if self.dataset_path.endswith(".gz") else open
        sessions = {}
        with opener(self.dataset_path, "rt") as source:
            for line in source:
                record = json.loads(line)
                if record.get("provider") not in self.providers:
                    continue
                context_length = int(record.get("input_tokens_total") or 0)
                output_length = int(record.get("output_tokens") or 0)
                prefix_length = int(record.get("prefix_tokens") or 0)
                append_length = int(record.get("newly_append_tokens") or 0)
                if not (
                    self.min_context_len <= context_length <= self.max_context_len
                    and output_length >= self.min_output_len
                    and (prefix_length > 0 or (self.allow_empty_prefix and prefix_length == 0))
                    and append_length > 0
                ):
                    continue
                if context_length != prefix_length + append_length:
                    raise ValueError("TraceLab input length differs from prefix plus append")
                session_id = record.get("session_id")
                if not isinstance(session_id, str) or not session_id:
                    raise ValueError("TraceLab rows require a nonempty session_id")
                sessions.setdefault(session_id, []).append(record)

        quotas = [
            (index + 1) * self.num_requests // self.num_groups
            - index * self.num_requests // self.num_groups
            for index in range(self.num_groups)
        ]
        eligible = [
            session_id for session_id, records in sessions.items()
            if len(records) >= max(quotas)
        ]
        if len(eligible) < self.num_groups:
            raise ValueError(
                f"TraceLab selection has {len(eligible)} sufficiently long sessions; "
                f"requested {self.num_groups}"
            )
        selector = random if self.selection_seed is None else random.Random(self.selection_seed)
        if self.session_weighting == "rounds":
            # Weighted sampling without replacement (Efraimidis-Spirakis keys), seeded like
            # the uniform path.
            keyed = sorted(
                eligible, key=lambda sid: selector.random() ** (1.0 / len(sessions[sid])), reverse=True
            )
            selected = keyed[: self.num_groups]
        else:
            selected = selector.sample(eligible, self.num_groups)
        vocabulary = get_available_tokens(tokenizer)
        if not vocabulary:
            raise ValueError("Tokenizer vocabulary is empty")

        requests = []
        warmups = []
        for session_id, quota in zip(selected, quotas):
            records = sorted(sessions[session_id], key=lambda record: record["round_index"])
            window_start = selector.randint(0, len(records) - quota)
            records = records[window_start : window_start + quota]
            first_prefix = int(records[0]["prefix_tokens"])
            prompt_ids = random.choices(vocabulary, k=first_prefix)
            if first_prefix > 0:
                warmup_rng = random.Random(f"tracelab-warmup:{session_id}:{first_prefix}")
                warmups.append(DatasetRow(
                    prompt=warmup_rng.choices(vocabulary, k=first_prefix),
                    prompt_len=first_prefix,
                    output_len=1,
                    session_id=session_id,
                    warmup_only=True,
                ))
            previous_end_ms = None
            for record in records:
                prefix_length = int(record["prefix_tokens"])
                append_length = int(record["newly_append_tokens"])
                if len(prompt_ids) < prefix_length:
                    prefix_ids = prompt_ids + random.choices(
                        vocabulary, k=prefix_length - len(prompt_ids)
                    )
                else:
                    prefix_ids = prompt_ids[:prefix_length]
                prompt_ids = prefix_ids + random.choices(vocabulary, k=append_length)
                event_times = [
                    datetime.fromisoformat(event["timestamp"].replace("Z", "+00:00"))
                    .timestamp() * 1000
                    for event in record.get("timing_events") or []
                    if event.get("timestamp")
                ]
                start_ms = min(event_times) if event_times else None
                end_ms = max(event_times) if event_times else None
                gap = (
                    max(0.0, (start_ms - previous_end_ms) / 1000)
                    if start_ms is not None and previous_end_ms is not None else 0.0
                )
                previous_end_ms = end_ms
                requests.append(DatasetRow(
                    prompt=prompt_ids,
                    prompt_len=len(prompt_ids),
                    output_len=int(record["output_tokens"]),
                    timestamp=start_ms,
                    session_id=session_id,
                    round_index=int(record["round_index"]),
                    inter_round_delay_s=gap,
                ))
        replayed = sorted(row.prompt_len for row in requests)
        if replayed:
            pick = lambda q: replayed[min(len(replayed) - 1, int(q * len(replayed)))]
            print(
                "TraceLab replayed context p10/p50/p90/p99: "
                f"{pick(0.1)}/{pick(0.5)}/{pick(0.9)}/{pick(0.99)}; providers={','.join(self.providers)}"
            )
        print(
            f"TraceLab length/session replay: {len(requests)} rounds, "
            f"{self.num_groups} sessions; synthetic token contents, "
            "recorded input/output lengths preserved"
        )
        return warmups + requests

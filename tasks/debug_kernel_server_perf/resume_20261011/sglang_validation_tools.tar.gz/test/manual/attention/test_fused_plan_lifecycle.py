import unittest
from types import SimpleNamespace
from unittest.mock import Mock

import torch

from sglang.srt.layers.attention.flashinfer_backend import FlashInferAttnBackend
from sglang.srt.model_executor.forward_batch_info import ForwardMode


class TestFusedPlanLifecycle(unittest.TestCase):
    def make_backend(self):
        backend = FlashInferAttnBackend.__new__(FlashInferAttnBackend)
        backend.fused_split_mask = object()
        backend.fused_split_plan = {"tok_total": 6145, "fused_kernel": {"stale": True}}
        backend.use_sliding_window_kv_pool = False
        backend.indices_updater_decode = Mock()
        backend.indices_updater_prefill = Mock()
        backend.decode_wrappers = []
        backend.prefill_wrappers_verify = []
        backend.decode_split_tile_size = None
        backend.decode_cuda_graph_metadata = {8: []}
        backend.prefill_cuda_graph_metadata = {8: []}
        backend.disable_cuda_graph_kv_split = False
        return backend

    def make_batch(self, mode):
        return SimpleNamespace(
            batch_size=8,
            forward_mode=mode,
            req_pool_indices=torch.arange(8),
            seq_lens=torch.full((8,), 2048),
            seq_lens_cpu=torch.full((8,), 2048),
            seq_lens_sum=16384,
            encoder_lens=None,
            spec_info=None,
            kv_loc_plan=None,
            out_cache_loc=None,
        )

    def test_prefill_plan_invalidated_before_verify_or_decode_planning(self):
        for mode in (ForwardMode.TARGET_VERIFY, ForwardMode.DECODE, ForwardMode.IDLE):
            for graph in (False, True):
                with self.subTest(mode=mode, graph=graph):
                    backend = self.make_backend()

                    def check_invalidated(*args, **kwargs):
                        self.assertIsNone(backend.fused_split_mask)
                        self.assertIsNone(backend.fused_split_plan)

                    backend.indices_updater_decode.update.side_effect = check_invalidated
                    backend.indices_updater_prefill.update.side_effect = check_invalidated
                    initialize = (
                        backend.init_forward_metadata_out_graph
                        if graph else backend.init_forward_metadata
                    )
                    initialize(self.make_batch(mode))
                    self.assertIsNone(backend.fused_split_plan)

    def test_mismatched_query_rejected_before_any_kernel_or_cache_access(self):
        backend = self.make_backend()
        query = torch.zeros(32, 28, 128)
        layer = SimpleNamespace(tp_q_head_num=28, head_dim=128, layer_id=0)
        with self.assertRaisesRegex(ValueError, "6145.*32"):
            backend._fused_split_dispatch(query, layer, None, True, 0)

    def test_invalidated_plan_does_not_dispatch(self):
        backend = self.make_backend()
        backend.init_forward_metadata(self.make_batch(ForwardMode.TARGET_VERIFY))
        self.assertIsNone(backend._fused_split_dispatch(None, None, None, True, 0))


if __name__ == "__main__":
    unittest.main()

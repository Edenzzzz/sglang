#include <array>
#include <cassert>
#include <cstdio>
#include <vector>

#include "flashinfer/attention/hopper/kernel_traits.cuh"

struct TestAttentionVariant {};
using Value = cutlass::bfloat16_t;
using Traits = flashinfer::AttentionKernelTraits<false, 128, 128, 128, 128, 2,
                                                 Value, Value, Value, int32_t, TestAttentionVariant>;
using CopyAtom = cute::Copy_Atom<cute::SM80_CP_ASYNC_CACHEGLOBAL_ZFILL<cute::uint128_t>, Value>;
using Copy = decltype(cutlass::gemm::collective::detail::make_simt_gmem_tiled_copy<
    CopyAtom, Traits::NUM_PRODUCER_THREADS, 8,
    cutlass::detail::TagToStrideB_t<cutlass::layout::ColumnMajor>, cute::Int<128>, cute::Int<128>>());

template <class Layout>
void check_layout(const char* name) {
  using namespace cute;
  alignas(1024) std::array<Value, cosize_v<Layout>> buffer;
  auto shared = make_tensor(make_smem_ptr(buffer.data()), Layout{});
  auto identity = make_identity_tensor(make_shape(Int<128>{}, Int<128>{}, Int<1>{}));
  for (int stage = 0; stage < 2; ++stage) {
    for (int valid_rows : {1, 17, 127, 128}) {
      std::fill(buffer.begin(), buffer.end(), Value(1.0f));
      std::vector<int> coverage(buffer.size(), 0);
      for (int producer = 0; producer < Traits::NUM_PRODUCER_THREADS; ++producer) {
        auto thread_copy = Copy{}.get_slice(producer);
        auto destination = thread_copy.partition_D(shared);
        auto coordinates = thread_copy.partition_S(identity);
        auto vectors = recast<cute::uint128_t>(flatten(destination(_, _, _, stage)));
        auto positions = flatten(coordinates(_, _, _, 0));
        for (int index = 0; index < size(vectors); ++index) {
          const int offset = reinterpret_cast<Value*>(&vectors(index)) - buffer.data();
          assert(offset >= 0 && offset + 8 <= int(buffer.size()) && offset % 8 == 0);
          for (int element = 0; element < 8; ++element) {
            ++coverage[offset + element];
            if (get<0>(positions(index * 8)) >= valid_rows) buffer[offset + element] = Value(0.0f);
          }
        }
      }
      for (int inspected_stage = 0; inspected_stage < 2; ++inspected_stage) {
        for (int row = 0; row < 128; ++row) {
          for (int dimension = 0; dimension < 128; ++dimension) {
            const int offset = &shared(row, dimension, inspected_stage) - buffer.data();
            const bool active_stage = inspected_stage == stage;
            assert(coverage[offset] == int(active_stage));
            const float expected = active_stage && row >= valid_rows ? 0.0f : 1.0f;
            assert(float(shared(row, dimension, inspected_stage)) == expected);
          }
        }
      }
    }
  }
  std::printf("%s producers=%d tail mapping: 8 cases PASS\n", name, Traits::NUM_PRODUCER_THREADS);
}

int main() {
  constexpr int physical_producers = Traits::NUM_THREADS - Traits::NUM_MMA_THREADS;
  constexpr int producer_registers = Traits::NUM_PRODUCER_THREADS == 32 ? 32 : 72;
  static_assert(physical_producers == 128 && Traits::NUM_MMA_THREADS == 256);
  static_assert(216 * Traits::NUM_MMA_THREADS + producer_registers * physical_producers <= 65536);
  static_assert((232 * Traits::NUM_MMA_THREADS + producer_registers * physical_producers <= 65536) ==
                (Traits::NUM_PRODUCER_THREADS == 32));
  static_assert(248 * Traits::NUM_MMA_THREADS + producer_registers * physical_producers > 65536);
  check_layout<typename Traits::SmemLayoutK>("K");
  check_layout<typename Traits::SmemLayoutV>("V");
}

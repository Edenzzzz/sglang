import importlib.util
import os
from pathlib import Path
import unittest
from unittest.mock import patch

from audit_stock_dispatch import route_evidence


class TestDispatchAudit(unittest.TestCase):
    def test_guard_records(self):
        for guard in (0, 1):
            rows = 15 if guard == 0 else 0
            record = f"KERNEL_DISPATCH_AUDIT guard={guard} plans=201 two_sided=25 long_mixed_rows={rows} selected_max_kv_tiles=512"
            self.assertEqual(route_evidence(record, guard)["long_mixed_planned_rows_max"], rows)
            with self.assertRaises(ValueError):
                route_evidence(record, 1 - guard)

    def test_missing_and_wrong_routing_rejected(self):
        for guard in (0, 1):
            with self.assertRaises(ValueError):
                route_evidence("", guard)
            rows = 0 if guard == 0 else 10
            record = f"KERNEL_DISPATCH_AUDIT guard={guard} plans=201 two_sided=25 long_mixed_rows={rows} selected_max_kv_tiles=512"
            with self.assertRaises(ValueError):
                route_evidence(record, guard)

    def test_long_context_prompt_sizes(self):
        path = Path(__file__).parent / "correctness.py"
        specification = importlib.util.spec_from_file_location("long_correctness", path)
        module = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(module)
        with patch.dict(os.environ, {"CORRECTNESS_SYNTHETIC": "1", "CORRECTNESS_LONG_TOKENS": "49152"}):
            short, long_prompts = module.prompts()
        self.assertEqual([len(prompt) for prompt in short], [2048] * 8)
        self.assertEqual([len(prompt) for prompt in long_prompts], [49152] * 4)
        with patch.dict(os.environ, {"CORRECTNESS_LONG_TOKENS": "50001"}):
            with self.assertRaises(ValueError):
                module.prompts()


if __name__ == "__main__":
    unittest.main(verbosity=2)

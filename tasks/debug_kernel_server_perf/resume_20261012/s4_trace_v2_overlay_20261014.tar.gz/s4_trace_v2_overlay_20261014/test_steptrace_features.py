import ast
import os
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "up_racefix/python/sglang/srt/managers/scheduler.py"
TREE = ast.parse(SOURCE.read_text())
METHOD = next(node for node in ast.walk(TREE) if isinstance(node, ast.FunctionDef) and node.name == "_steptrace_begin")
EVENT = SimpleNamespace(record=lambda: None)
NAMESPACE = {
    "os": os, "time": SimpleNamespace(perf_counter=lambda: 100.0),
    "torch": SimpleNamespace(cuda=SimpleNamespace(Event=lambda **kwargs: EVENT)),
    "ScheduleBatch": SimpleNamespace,
}
exec(compile(ast.Module(body=[METHOD], type_ignores=[]), str(SOURCE), "exec"), NAMESPACE)


class StepTraceFeaturesTest(unittest.TestCase):
    def batch(self, lengths, contexts, extend=True):
        return SimpleNamespace(
            forward_mode=SimpleNamespace(is_extend=lambda: extend, name="EXTEND" if extend else "DECODE"),
            reqs=[SimpleNamespace(extend_len=length) for length in lengths],
            seq_lens_cpu=SimpleNamespace(tolist=lambda: contexts), extend_lens=lengths,
            extend_num_tokens=sum(lengths), batch_size=lambda: len(lengths),
        )

    def trace(self, batch):
        scheduler = SimpleNamespace(metrics_reporter=SimpleNamespace(
            spec_total_num_accept_tokens=30, spec_total_num_forward_ct=10))
        with patch.dict(os.environ, {"SGLANG_STEP_TRACE": "1"}):
            NAMESPACE["_steptrace_begin"](scheduler, batch)
        return scheduler._steptrace[-1][0]

    def test_new_request_schema_does_not_zero_prefill(self):
        line = self.trace(self.batch([512], [33280]))
        self.assertIn("np=1 ptok=512 pf=32768 nd=0 dkv=0", line)

    def test_batch_metadata_wins_over_stale_request_attribute(self):
        batch = self.batch([128], [8320])
        batch.reqs[0].extend_input_len = 0
        self.assertIn("np=1 ptok=128 pf=8192", self.trace(batch))

    def test_mixed_verify_rows_keep_their_context(self):
        batch = self.batch([512, 128], [33280, 128])
        batch.mixed_spec_running = self.batch([1, 1], [8192, 16384], extend=False)
        line = self.trace(batch)
        self.assertIn("np=2 ptok=640 pf=32768 nd=2 dkv=24576", line)

    def test_decode_ignores_stale_extend_metadata(self):
        line = self.trace(self.batch([512, 128], [8192, 16384], extend=False))
        self.assertIn("np=0 ptok=0 pf=0 nd=2 dkv=24576", line)

    def test_missing_extend_metadata_fails_instead_of_fabricating_zeros(self):
        batch = self.batch([512], [512])
        batch.extend_lens = None
        with self.assertRaisesRegex(ValueError, "extend lengths"):
            self.trace(batch)


if __name__ == "__main__":
    unittest.main()

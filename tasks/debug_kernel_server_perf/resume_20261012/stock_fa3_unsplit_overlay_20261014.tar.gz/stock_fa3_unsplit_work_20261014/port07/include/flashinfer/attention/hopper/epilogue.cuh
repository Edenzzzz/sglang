/*
 * Copyright (c) 2024, Jay Shah, Ganesh Bikshandi, Ying Zhang, Vijay Thakkar, Pradeep Ramani, Tri
 * Dao. Licensed under the BSD 3-Clause.
 *
 * Modified by the FlashInfer team.
 */
#ifndef FLASHINFER_ATTENTION_HOPPER_EPILOGUE_CUH_
#define FLASHINFER_ATTENTION_HOPPER_EPILOGUE_CUH_

#include <cutlass/cutlass.h>

#include "../../math.cuh"
#include "cute/tensor.hpp"
#include "cutlass/gemm/collective/collective_builder.hpp"
#include "named_barrier.cuh"
#include "utils.cuh"

namespace flashinfer {

using namespace cute;

template <int NUM_COPY_THREADS, typename DTypeO, typename TiledCopyO, typename LayoutO,
          typename TileShapeO, typename SMemO>
__forceinline__ __device__ void write_tiled(DTypeO* O, const TiledCopyO& tiled_copy_O,
                                            const LayoutO& layout_O, const TileShapeO& tile_shape_O,
                                            const SMemO& sO, int thread_idx, int qo_tile_idx,
                                            int qo_head_idx, int qo_indptr, int64_t qo_len) {
  Tensor mO = make_tensor(make_gmem_ptr(O + qo_indptr * stride<0>(layout_O)), layout_O);
  Tensor gO =
      get_local_tile_tensor(mO, tile_shape_O, qo_head_idx, 0, qo_len)(_, _, qo_tile_idx);  // (O, D)
  Tensor cO = cute::make_identity_tensor(gO.shape());  // (O, D) -> (o_idx, d_idx)

  ThrCopy thr_copy_O = tiled_copy_O.get_slice(thread_idx);
  Tensor tOgO = thr_copy_O.partition_D(gO);  // (CPY, CPY_O, CPY_D)
  Tensor tOsO = thr_copy_O.partition_S(sO);  // (CPY, CPY_O, CPY_D)
  Tensor tOcO = thr_copy_O.partition_D(cO);  // (CPY, CPY_O, CPY_D)
  Tensor tOsOGroup = flatten_1(tOsO);        // (CPY, (CPY_O, CPY_D))
  Tensor tOgOGroup = flatten_1(tOgO);        // (CPY, (CPY_O, CPY_D))
  Tensor tOcOGroup = flatten_1(tOcO);        // (CPY, (CPY_O, CPY_D))

  const int qo_tile_size = get<0>(tile_shape_O);
  int valid_qo_tile_size = std::min<int>(qo_len - qo_tile_idx * qo_tile_size, qo_tile_size);
  if (valid_qo_tile_size == qo_tile_size) {
    copy(tiled_copy_O, tOsOGroup, tOgOGroup);
  } else {
    // copy if not out of bound
    auto predicate_fn = [&](auto coords) {
      auto s_coords = tOcOGroup(_0{}, coords);
      return elem_less(get<0>(s_coords), valid_qo_tile_size);
    };
    copy_if(tiled_copy_O, predicate_fn, tOsOGroup, tOgOGroup);
  }
}

// Packed-GQA store, the mirror of the packed Q load. A work item of the unified
// plan owns PACKED rows of one kv head's group, so row p of the tile belongs to
// token p / G and head kv_head * G + p % G. Writing it with write_tiled would put
// correct attention output on token-indexed rows, which is a silent wrong answer
// rather than a fault -- hence the same two helpers the load uses, so there is one
// mapping and tests/test_packed_gqa_layout.cu checks it.
//
// Correctness first, like the load: a per-row loop rather than a tiled copy.
template <typename DTypeO, typename LayoutO, typename TileShapeO, typename SMemO>
__forceinline__ __device__ void write_packed(DTypeO* O, const LayoutO& layout_O,
                                             const TileShapeO& tile_shape_O, const SMemO& sO,
                                             int thread_idx, int num_threads, int qo_tile_idx,
                                             int kv_head_idx, int group_size, int qo_indptr,
                                             int packed_qo_len) {
  Tensor mO = make_tensor(make_gmem_ptr(O), layout_O);
  // Exact token extent, no slack. packed_qo_len is qo_len * group_size, so
  // dividing gives the row's token count exactly; the earlier `+ 1` described a
  // layout one token past the row, and for the LAST row of a batch that is one
  // token past the tensor itself. Predication kept indices inside it, but a
  // layout that describes out-of-bounds memory is not something to leave in a
  // kernel that is being debugged for a fault.
  auto gOp = get_packed_gqa_tensor(mO, tile_shape_O, kv_head_idx, group_size, qo_indptr,
                                   packed_qo_len / group_size);
  const int tile_size = get<0>(tile_shape_O);
  const int tile_base = qo_tile_idx * tile_size;
  // Same asymmetry as the load: O's D axis has stride 1 in global memory so the
  // store is one 16-byte transaction per 8 bf16, while sO's swizzled layout is
  // read element-wise through its own indexing.
  constexpr int kVec = 16 / sizeof(DTypeO);
#if FLASHINFER_FA3_PARTIAL_PROBE
  // Diagnostic: have the kernel say what it is actually writing. Every hypothesis
  // about why task-3 rows come back unwritten has been wrong so far, so stop
  // inferring and read it off the device.
  if (thread_idx == 0) {
    // Print the ADDRESS the mapping actually produces for this tile's first row,
    // as an element offset from O. Expected for tile t, row 0, kv head h:
    //   ((qo_indptr + (t*128)/G) * num_qo_heads + h*G + (t*128)%G) * HEAD_DIM
    const int pr0 = tile_base;
    if (pr0 < packed_qo_len) {
      const DTypeO* a = &gOp(packed_coord(pr0, group_size), 0);
      // ALSO row 1 of the tile. The earlier "addresses exact for every tile" check printed only
      // pr0 = tile_base (r=0), so it was blind to the WITHIN-TILE stepping -- and row 0 is the one
      // row where every offset is zero, hence immune to a wrong row stride. Expected for packed
      // row pr: token pr/G, head kvh*G + pr%G, so pr=1 is the SAME token at the NEXT
      // head-in-group. If the kernel steps by a token instead, pr=1 is wrong while pr=0 stays
      // right -- exactly the 1-of-128 pattern.
      if (pr0 + 1 < packed_qo_len) {
        const DTypeO* a1 = &gOp(packed_coord(pr0 + 1, group_size), 0);
        printf("[wpk1] blk=%d tile=%d pr=1 tok=%d hig=%d off=%lld\n",
               int(blockIdx.x), qo_tile_idx, (pr0 + 1) / group_size, (pr0 + 1) % group_size,
               (long long)(a1 - O));
      }
      {
        int iters = 0;
        for (int ii = thread_idx; ii < tile_size; ii += num_threads) ++iters;
        // Folded into THIS printf because it is already known to fire (same gate as the line
        // below). A separate probe on a wider gate produced zero lines, which could not be told
        // apart from a stale build -- so this is its own null case: if the [wpk] line appears
        // without this one, the module is stale.
        // write_packed is a FREE function, not a CollectiveEpilogue member, so NUM_MMA_THREADS /
        // NUM_COPY_THREADS / NUM_WARPS are NOT in scope here -- adding them failed to compile.
        // What is in scope is enough: num_threads IS NUM_COPY_THREADS (measured 128), and
        // thread_idx was measured reaching 160, so thread_idx exceeds num_threads. The MMA thread
        // count must be read at the CALLER (store(), where the members are in scope) to tell
        // whether get_thread_slice(thread_idx) is in range.
        printf("[wsz] blk=%d tile=%d thread_idx=%d num_threads=%d tile_size=%d iters=%d\n",
               int(blockIdx.x), qo_tile_idx, thread_idx, num_threads, int(tile_size), iters);
      }
      printf("[wpk] blk=%d tile=%d base=%d packed_qo=%d qo_indptr=%d kvh=%d G=%d "
             "tok=%d r=%d off=%lld\n",
             int(blockIdx.x), qo_tile_idx, tile_base, packed_qo_len, qo_indptr, kv_head_idx,
             group_size, pr0 / group_size, pr0 % group_size, (long long)(a - O));
      // And what is actually being stored. The address math is confirmed exact, so
      // if these are NaN the fault is upstream in the compute, not in the write.
      printf("[wpk] blk=%d tile=%d sO[0,0..3]=%f %f %f %f\n", int(blockIdx.x), qo_tile_idx,
             float(sO(0, 0)), float(sO(0, 1)), float(sO(1, 0)), float(sO(2, 0)));
    }
  }
#endif
#if FLASHINFER_FA3_PARTIAL_PROBE
  // The three quantities the loop's coverage depends on, none of which had been printed.
  // EXPECTED, stated first: iters = ceil((tile_size - thread_idx)/num_threads) for thread_idx <
  // tile_size, else 0; full coverage needs tile_size distinct thread_idx values below tile_size.
  // Measured coverage is 32 of 128 rows, so either thread_idx spans fewer than 128 values here,
  // or num_threads is not what write_O passes.
  {
    int iters = 0;
    for (int i = thread_idx; i < tile_size; i += num_threads) ++iters;
    if (threadIdx.x % 32 == 0) {
      printf("[wstride] blk=%u tIdx.x=%u thread_idx=%d num_threads=%d tile_size=%d iters=%d\n",
             blockIdx.x, threadIdx.x, thread_idx, num_threads, int(tile_size), iters);
    }
  }
#endif
  for (int i = thread_idx; i < tile_size; i += num_threads) {
    const int pr = tile_base + i;
    if (pr >= packed_qo_len) continue;
    DTypeO* row = &gOp(packed_coord(pr, group_size), 0);
    for (int d = 0; d < get<1>(tile_shape_O); d += kVec) {
      DTypeO buf[kVec];
#pragma unroll
      for (int v = 0; v < kVec; ++v) buf[v] = sO(i, d + v);
      *reinterpret_cast<uint4*>(row + d) = *reinterpret_cast<const uint4*>(buf);
    }
  }
}

template <int NUM_COPY_THREADS, typename ElemO, typename TiledCopyO, typename LayoutO,
          typename TileShapeO, typename SMemO>
__forceinline__ __device__ void write_O(ElemO* O, const TiledCopyO& tiled_copy_O,
                                        const LayoutO& layout_O, const TileShapeO& tile_shape_O,
                                        const SMemO& sO, int thread_idx, int qo_tile_idx,
                                        int qo_head_idx, int qo_indptr, int qo_len,
                                        int write_warp_idx, int group_size = 1) {
// Independently gated from the Q gather (2026-10-10). Both were behind FLASHINFER_FUSED_PACKED_Q,
// which made it impossible to tell whether the multi-item-per-CTA corruption comes from the gather
// writing sQ or from write_packed reading sO -- stock paths are CLEAN at 129 requests (0/384) while
// ours are 116-144/384, and both Q-completion mechanisms (mbarrier arrive vs explicit cp.async
// drain) fail identically. FUSED_PACKED_O defaults to FLASHINFER_FUSED_PACKED_Q so behaviour is
// unchanged; setting it to 0 at G=1 uses the packed gather with the STOCK store, which isolates the
// two in one run.
#ifndef FUSED_PACKED_O
#if defined(FLASHINFER_FUSED_PACKED_Q)
#define FUSED_PACKED_O 1
#else
#define FUSED_PACKED_O 0
#endif
#endif
#if FUSED_PACKED_O
  // The unified scheduler sets qo_head_idx = kv_head * G, so the kv head is exact here and needs
  // no extra plumbing. qo_len is the PACKED extent on this path, matching what the scheduler
  // hands the mainloop -- and write_packed is what maps those packed rows back to
  // (token, head-in-group). Without this branch the epilogue clamps on the packed extent and
  // writes packed rows as if they were tokens: measured qo_len=1024 / rows_left=1024 against an
  // `o` of 256 token rows, residual 3.076e+06.
  write_packed(O, layout_O, tile_shape_O, sO, thread_idx, NUM_COPY_THREADS, qo_tile_idx,
               qo_head_idx / group_size, group_size, qo_indptr, qo_len);
#else
  write_tiled<NUM_COPY_THREADS>(O, tiled_copy_O, layout_O, tile_shape_O, sO, thread_idx,
                                qo_tile_idx, qo_head_idx, qo_indptr, qo_len);
#endif
}

template <typename Ktraits>
struct CollectiveEpilogue {
  using DTypeO = typename Ktraits::DTypeO;
  static constexpr int CTA_Q = Ktraits::CTA_Q;
  static constexpr int CTA_KV = Ktraits::CTA_KV;
  static constexpr int HEAD_DIM_VO = Ktraits::HEAD_DIM_VO;
  using TileShape_PDV = Shape<Int<CTA_Q>, Int<HEAD_DIM_VO>, Int<CTA_KV>>;

  static constexpr int NUM_WARPS = Ktraits::NUM_WARPS;
  static constexpr int NUM_THREADS = NUM_WARPS * cutlass::NumThreadsPerWarp;

  static constexpr int NUM_COPY_THREADS = cutlass::NumThreadsPerWarpGroup;
  static constexpr int NUM_MMA_THREADS = NUM_THREADS - NUM_COPY_THREADS;

  using SmemLayoutAtomO = decltype(cutlass::gemm::collective::detail::ss_smem_selector<
                                   GMMA::Major::K, DTypeO, decltype(cute::get<0>(TileShape_PDV{})),
                                   decltype(cute::get<1>(TileShape_PDV{}))>());
  using SmemLayoutO = decltype(tile_to_shape(SmemLayoutAtomO{}, select<0, 1>(TileShape_PDV{})));

  using SmemCopyAtomO = Copy_Atom<cute::SM90_U32x4_STSM_N, DTypeO>;
  using SharedStorage = cute::array_aligned<DTypeO, cute::cosize_v<SmemLayoutO>>;

  using ShapeT = cute::Shape<int32_t, int32_t, int32_t>;
  using StrideT = cute::Shape<int64_t, _1, int64_t>;
  using LayoutT = cute::Layout<ShapeT, StrideT>;

  using ShapeLseT = cute::Shape<int32_t, int32_t>;
  using StrideLseT = cute::Shape<_1, int64_t>;
  using LayoutLseT = cute::Layout<ShapeLseT, StrideLseT>;

  using GmemTiledCopyOTMA = cute::SM90_TMA_STORE;
  using TMA_O = decltype(make_tma_copy(
      GmemTiledCopyOTMA{},
      make_tensor(make_gmem_ptr(static_cast<DTypeO*>(nullptr)), ShapeT{}, StrideT{}), SmemLayoutO{},
      select<0, 1>(TileShape_PDV{}), _1{}));  // no mcast for O

  static constexpr int VEC_SIZE = cute::ceil_div(128, sizeof_bits_v<DTypeO>);
  static_assert(HEAD_DIM_VO % VEC_SIZE == 0);
  static constexpr int NUM_THREADS_PER_ROW = HEAD_DIM_VO / VEC_SIZE;
  static_assert(NUM_MMA_THREADS % NUM_THREADS_PER_ROW == 0);
  static constexpr int NUM_ROWS = NUM_MMA_THREADS / NUM_THREADS_PER_ROW;
  using TiledCopyOAtom = cute::Copy_Atom<cute::UniversalCopy<cutlass::uint128_t>, DTypeO>;
  using TiledCopyOThrLayout = decltype(cute::make_layout(
      cute::make_shape(Int<NUM_ROWS>{}, Int<NUM_THREADS_PER_ROW>{}), LayoutRight{}));
  using TiledCopyOValLayout =
      decltype(cute::make_layout(cute::make_shape(_1{}, Int<VEC_SIZE>{}), LayoutRight{}));
  using TiledCopyO =
      decltype(make_tiled_copy(TiledCopyOAtom{}, TiledCopyOThrLayout{},  // Thr layout
                               TiledCopyOValLayout{}                     // Val layout
                               ));

  // used for rmem -> smem O copy in fp8 kernel to undo column permutation
  using ThreadLayoutrO = Layout<Shape<_8, Int<CTA_Q / 16>, _4, _1>, Stride<_4, _32, _1, _0>>;
  using ValueLayoutrO = Layout<Shape<_1, _2, Shape<_2, _2>, Int<HEAD_DIM_VO / 16>>,
                               Stride<_0, _2, Stride<_4, _1>, _8>>;
  using TiledCopyrO = decltype(make_tiled_copy(Copy_Atom<UniversalCopy<uint16_t>, DTypeO>{},
                                               ThreadLayoutrO{}, ValueLayoutrO{}));
  using TiledCopyShaperO = Shape<_8, Int<CTA_Q / 8>, _16, Int<HEAD_DIM_VO / 16>>;
  using SmemLayoutrO = decltype(composition(SmemLayoutO{}, Layout<TiledCopyShaperO>{}));

  // Host side kernel arguments
  struct Arguments {
    DTypeO* O_ptr;
    LayoutT const layout_O;
    float* lse_ptr;
    LayoutLseT const layout_LSE;
    // --- split-KV partials for the unified reduction (ours; 0.7's epilogue has no split path)
    // The SAME buffers the FA2 roles use, not an FA3-specific pair, so they come straight off
    // the persistent params the one plan already filled. Defaulted and LAST so every existing
    // aggregate initialisation of this struct stays valid.
    //
    // The five group tables (group_row_begin / group_nrows / group_kv_head / group_nchunks /
    // group_counter) that 0.3.1 carried here are deliberately absent: K1a dropped the in-kernel
    // JIT-reduction rendezvous, and partials are reduced by 0.7's
    // PersistentVariableLengthMergeStatesKernel over merge_indptr / merge_o_indices instead.
    DTypeO* partial_o = nullptr;
    float* partial_lse = nullptr;
    int const* merge_indptr = nullptr;
    int const* merge_o_indices = nullptr;
    int num_kv_heads = 0;
    int gqa_group_size = 1;
  };

  // Device side kernel params
  struct Params {
    DTypeO* O_ptr;
    LayoutT const layout_O;
    float* lse_ptr;
    LayoutLseT const layout_LSE;
    // --- split-KV partials for the unified reduction (ours; 0.7's epilogue has no split path)
    // The SAME buffers the FA2 roles use, not an FA3-specific pair, so they come straight off
    // the persistent params the one plan already filled. Defaulted and LAST so every existing
    // aggregate initialisation of this struct stays valid.
    //
    // The five group tables (group_row_begin / group_nrows / group_kv_head / group_nchunks /
    // group_counter) that 0.3.1 carried here are deliberately absent: K1a dropped the in-kernel
    // JIT-reduction rendezvous, and partials are reduced by 0.7's
    // PersistentVariableLengthMergeStatesKernel over merge_indptr / merge_o_indices instead.
    DTypeO* partial_o = nullptr;
    float* partial_lse = nullptr;
    int const* merge_indptr = nullptr;
    int const* merge_o_indices = nullptr;
    int num_kv_heads = 0;
    int gqa_group_size = 1;
  };

  static Params to_underlying_arguments(Arguments const& args) {
    Tensor mO = make_tensor(make_gmem_ptr(args.O_ptr), args.layout_O);
    return {args.O_ptr,        args.layout_O,     args.lse_ptr,
            args.layout_LSE,     args.partial_o,    args.partial_lse,
            args.merge_indptr,   args.merge_o_indices,
            args.num_kv_heads,   args.gqa_group_size};
  }

  /// Issue Tma Descriptor Prefetch -- ideally from a single thread for best performance
  CUTLASS_DEVICE
  static void prefetch_tma_descriptors(Params const& epilogue_params) {}

  template <typename BlockCoord, typename SharedStorage, typename FrgTensorO, typename FrgTensorLSE,
            typename TiledMma>
  CUTLASS_DEVICE void store(Params const& epilogue_params, FrgTensorO const& tOrO,
                            FrgTensorLSE const& lse, SharedStorage& shared_storage,
                            TiledMma tiled_mma, int thread_idx, BlockCoord const& block_coord) {
    auto [qo_tile_idx, qo_head_idx, kv_head_idx, qo_indptr, kv_indptr, qo_len, kv_len, batch_idx] =
        block_coord;
    Tensor sO = make_tensor(make_smem_ptr(shared_storage.smem_o.data()), SmemLayoutO{});
    auto smem_tiled_copy_O = make_tiled_copy_C(SmemCopyAtomO{}, tiled_mma);
    auto smem_thr_copy_O = smem_tiled_copy_O.get_thread_slice(thread_idx);

#if FLASHINFER_FA3_PARTIAL_PROBE
    // The MMA ACCUMULATOR, before any conversion or staging. Everything downstream is verified,
    // and sO holds row 0 in rows 0/1/2, so if tOrO's own elements already coincide the PV MMA or
    // the attention_updater is producing one row and replicating it.
    if (threadIdx.x % 64 == 0) {
      printf("[acc] blk=%u tIdx.x=%u size(tOrO)=%d tOrO[0..5]=%f %f %f %f %f %f\n",
             blockIdx.x, threadIdx.x, int(size(tOrO)), float(tOrO(0)), float(tOrO(1)),
             float(tOrO(2)), float(tOrO(3)), float(tOrO(4)), float(tOrO(5)));
    }
#endif
    Tensor tOrO_out = convert_type<DTypeO>(tOrO);
    Tensor tOrO_retile = smem_thr_copy_O.retile_S(tOrO_out);  // ((Atom,AtomNum), MMA_M, MMA_N)
    Tensor tOsO = smem_thr_copy_O.partition_D(sO);            // ((Atom,AtomNum),PIPE_M,PIPE_N)
#if FLASHINFER_FA3_PARTIAL_PROBE
    // Read AT THE CALLER, where the members are in scope (write_packed is a free function and
    // cannot see them). The staging does get_thread_slice(thread_idx); if thread_idx is at or
    // beyond the TiledMma's thread count the slices alias, which is what row 0 appearing in every
    // sO row looks like. thread_idx was measured reaching 160 with NUM_COPY_THREADS = 128.
    if (threadIdx.x % 64 == 0) {
      printf("[stg] blk=%u tIdx.x=%u thread_idx=%d NUM_MMA_THREADS=%d NUM_COPY_THREADS=%d "
             "size(tiled_mma)=%d size(tOsO)=%d size<1>(tOsO)=%d\n",
             blockIdx.x, threadIdx.x, thread_idx, int(NUM_MMA_THREADS), int(NUM_COPY_THREADS),
             int(size(tiled_mma)), int(size(tOsO)), int(size<1>(tOsO)));
    }
#endif

    // Make sure all WGs have finished reading V
    cutlass::arch::NamedBarrier::sync(NUM_MMA_THREADS,
                                      /*id=*/static_cast<int>(NamedBarriers::kValueEmpty));
    cute::copy(smem_tiled_copy_O, tOrO_retile, tOsO);
    cutlass::arch::fence_view_async_shared();  // ensure smem writes are visible to TMA

    Tensor mLSE = make_tensor(make_gmem_ptr(epilogue_params.lse_ptr), epilogue_params.layout_LSE);
    Tensor gLSE = get_lse_local_tile_tensor(mLSE, Shape<Int<CTA_Q>>{}, qo_head_idx, qo_indptr,
                                            qo_len)(_, qo_tile_idx);
    Tensor cO = cute::make_identity_tensor(select<0, 1>(TileShape_PDV{}));
    auto thread_mma = tiled_mma.get_thread_slice(thread_idx);
    Tensor tOcO = thread_mma.partition_C(cO);  // (MMA,MMA_M,MMA_K)
    static_assert(decltype(size<0, 0>(tOcO))::value == 2);
    static_assert(decltype(size<0, 1>(tOcO))::value == 2);
    // tOcO has shape ((2, 2, V), MMA_M, MMA_K), we only take only the row indices.
    Tensor tOcO_row = tOcO(make_coord(_0{}, _, _0{}), _, _0{});
    CUTE_STATIC_ASSERT_V(size(lse) == size(tOcO_row));  // MMA_M
    if (epilogue_params.lse_ptr) {                      // don't write to LSE if it's nullptr
      if (get<1>(tOcO_row(_0{})) == 0) {
#pragma unroll
        for (int mi = 0; mi < size(lse); ++mi) {
          const int row = get<0>(tOcO_row(mi));
          if (row < qo_len - qo_tile_idx * CTA_Q) {
            gLSE(row) = lse(mi);
          }
        }
      }
    }

    int write_warp_idx = NUM_WARPS - 1;
#if FLASHINFER_FUSED_TRACE_WRITE
    // What the FA3 epilogue computes for its output rows, from every block. qo_len arrives as the
    // PACKED extent (the scheduler presents packed so the mainloop's tile check works), but `o`
    // is laid out [tokens, num_qo_heads, head_dim] -- so if the clamp below uses packed rows the
    // row mapping is wrong by the gqa factor for every tile. Printed before the store, so it is
    // its own null case.
    if (thread_idx == 0) {
      printf("[fa3 store] blk=%u qo_tile=%d qo_head=%d qo_indptr=%d qo_len=%d rows_left=%d "
             "CTA_Q=%d\n",
             blockIdx.x, int(qo_tile_idx), int(qo_head_idx), int(qo_indptr), int(qo_len),
             int(qo_len) - int(qo_tile_idx) * int(CTA_Q), int(CTA_Q));
    }
#endif
    // Make sure all MMA WGs finish STSM O
    cutlass::arch::NamedBarrier::sync(NUM_MMA_THREADS,
                                      cutlass::arch::ReservedNamedBarriers::EpilogueBarrier);
    TiledCopyO gmem_tiled_copy_O;
    write_O<NUM_COPY_THREADS>(epilogue_params.O_ptr, gmem_tiled_copy_O, epilogue_params.layout_O,
                              select<0, 1>(TileShape_PDV{}), sO, thread_idx, qo_tile_idx,
                              qo_head_idx, qo_indptr, qo_len, write_warp_idx,
                              epilogue_params.gqa_group_size);
  }

  // Split-KV partial write. 0.7's epilogue has no split path at all -- only store / store_tail /
  // store_zero -- so this is ours. It writes ONLY the partial O/LSE slabs; the reduction is
  // 0.7's own PersistentVariableLengthMergeStatesKernel over merge_indptr / merge_o_indices.
  // 0.3.1's version also carried the in-kernel JIT-reduction rendezvous (group_counter +
  // MergeGroupJIT); K1a dropped that after measuring its ceiling at 0.6% of GPU time, so the
  // group tables and the `group_id` argument are gone with it. `num_kv_chunks` takes their
  // place and comes from the scheduler, which derives it with the PLAN's formula.
  //
  template <typename BlockCoord, typename SharedStorage, typename FrgTensorO,
            typename FrgTensorLSE, typename TiledMma>
  CUTLASS_DEVICE void store_partial(Params const& epilogue_params, FrgTensorO const& tOrO,
                                    FrgTensorLSE const& lse, SharedStorage& shared_storage,
                                    TiledMma tiled_mma, int thread_idx,
                                    BlockCoord const& block_coord, int partial_indptr,
                                    int kv_chunk_idx, int num_kv_chunks) {
    auto [qo_tile_idx, qo_head_idx, kv_head_idx, qo_indptr, kv_indptr, qo_len, kv_len, batch_idx] =
        block_coord;
    constexpr int kHeadDim = get<1>(TileShape_PDV{});
    const int tail = qo_len - qo_tile_idx * int(CTA_Q);
    const int rows = tail < int(CTA_Q) ? tail : int(CTA_Q);
    const int chunks = num_kv_chunks > 0 ? num_kv_chunks : 1;

    // Stage O through smem exactly as store() does, barriers included: the epilogue hands O to
    // a designated writer across a named barrier, so the sequence may not be reordered.
    Tensor sO = make_tensor(make_smem_ptr(shared_storage.smem_o.data()), SmemLayoutO{});
    auto smem_tiled_copy_O = make_tiled_copy_C(SmemCopyAtomO{}, tiled_mma);
    auto smem_thr_copy_O = smem_tiled_copy_O.get_thread_slice(thread_idx);
    Tensor tOrO_out = convert_type<DTypeO>(tOrO);
    Tensor tOrO_retile = smem_thr_copy_O.retile_S(tOrO_out);
    Tensor tOsO = smem_thr_copy_O.partition_D(sO);
    cutlass::arch::NamedBarrier::sync(NUM_MMA_THREADS,
                                      /*id=*/static_cast<int>(NamedBarriers::kValueEmpty));
    cute::copy(smem_tiled_copy_O, tOrO_retile, tOsO);
    cutlass::arch::fence_view_async_shared();

    // LSE into the dense partial slab, same tOcO_row walk store() uses.
    Tensor cO = cute::make_identity_tensor(select<0, 1>(TileShape_PDV{}));
    auto thread_mma = tiled_mma.get_thread_slice(thread_idx);
    Tensor tOcO = thread_mma.partition_C(cO);
    Tensor tOcO_row = tOcO(make_coord(_0{}, _, _0{}), _, _0{});
    if (epilogue_params.partial_lse != nullptr && get<1>(tOcO_row(_0{})) == 0) {
#pragma unroll
      for (int mi = 0; mi < size(lse); ++mi) {
        const int row = get<0>(tOcO_row(mi));
        if (row < rows) {
          epilogue_params.partial_lse[size_t(partial_indptr + row * chunks + kv_chunk_idx) *
                                          size_t(epilogue_params.num_kv_heads) +
                                      size_t(kv_head_idx)] = lse(mi);
        }
      }
    }

    int write_warp_idx = NUM_WARPS - 1;
    cutlass::arch::NamedBarrier::sync(NUM_MMA_THREADS,
                                      cutlass::arch::ReservedNamedBarriers::EpilogueBarrier);
    // O: dense copy out of the same staged sO, vectorised 16 B stores.
    //
    // FA2's exact layout, from persistent.cuh --
    //   partial_o[((o_indptr + row * num_kv_chunks + kv_chunk_idx) * num_kv_heads
    //              + kv_head_idx) * HEAD_DIM]
    // Writing `partial_indptr + r` instead, as the first version did, drops BOTH the chunk
    // stride and the kv-head dimension: every chunk of a group then overwrites rows
    // [base, base+rows) and the merge reads locations nothing touched. That was fixture 2's
    // 511/512 unwritten rows.
    // REVERTED to a single warp (2026-10-10). Parallelising this across all NUM_MMA_THREADS
    // gave a 12% win on `mixed` (0.2470 -> 0.2183 ms) but took `MODE=fa3` from 1 failure in 20
    // runs to **8 failures in 10**, with 1-7 bad rows and rel 0.15-1.21. So the single-warp gate
    // is load-bearing for a reason I have not identified yet, and a 12% win is not worth an
    // 80%-failure kernel. Keep the gate until the reason is found.
    //
    // The measurement that motivated it still stands and the target is still right: the split
    // path is 78% of the fused kernel's time (MODE=fa3 0.2586 ms with splits vs 0.0578 ms with
    // FUSED_NOSPLIT=1, against a 0.0386 ms unfused baseline). One warp moving a 128x128 bf16 tile
    // is 32 KB through 32 threads. The fix needs to respect whatever the gate is protecting --
    // most likely the lifetime of sO, which is UNIONED with smem_v, so the producer warps may be
    // refilling it for the next work item while the consumer still reads it.
    if (epilogue_params.partial_o != nullptr &&
        cutlass::canonical_warp_idx_sync() == write_warp_idx) {
      constexpr int kVec = 16 / sizeof(DTypeO);
      const int lane = thread_idx % cutlass::NumThreadsPerWarp;
      for (int r = 0; r < rows; ++r) {
        const size_t slot = size_t(partial_indptr + r * chunks + kv_chunk_idx) *
                                size_t(epilogue_params.num_kv_heads) +
                            size_t(kv_head_idx);
        DTypeO* dst = epilogue_params.partial_o + slot * kHeadDim;
        for (int d = lane * kVec; d < kHeadDim; d += cutlass::NumThreadsPerWarp * kVec) {
          DTypeO tmp[kVec];
#pragma unroll
          for (int v = 0; v < kVec; ++v) tmp[v] = sO(r, d + v);
          *reinterpret_cast<uint4*>(dst + d) = *reinterpret_cast<uint4 const*>(tmp);
        }
      }
    }
  }

  // A split item whose chunk lies ENTIRELY beyond the causal diagonal still has a slot in the
  // partial slab, because EnumerateFusedWorkItems chunks uniformly with no causal adjustment --
  // deliberately, so the count matches what sized the slab and built merge_indptr. Such an item
  // produces no attention output, and `store_zero` is the wrong answer for it twice over: it
  // writes the FINAL O (not the partial slab), through a token-indexed mapping that is also wrong
  // on the packed path.
  //
  // Leaving the slot unwritten is what the race was: the merge counts the chunk regardless, reads
  // `partial_lse` at an untouched slot (0.0 in a freshly zeroed workspace, stale otherwise) and
  // folds in a zero O with weight 2^(0 - lse_true). At a true LSE near 6.6 that is a ~1%
  // dilution -- measured as rel 0.03311 on row 0, the row with the FEWEST keys under
  // bottom-right causal (token 0 sees 1793 of 2048) and so the one most likely to have a fully
  // masked chunk. Magnitudes up to 0.35 appeared as the number of masked chunks varied.
  //
  // -inf LSE is the identity for the merge: 2^(-inf - m) == 0, so the chunk contributes nothing.
  template <typename BlockCoord>
  CUTLASS_DEVICE void store_partial_zero(Params const& epilogue_params, int thread_idx,
                                         BlockCoord const& block_coord, int partial_indptr,
                                         int kv_chunk_idx, int num_kv_chunks) {
    auto [qo_tile_idx, qo_head_idx, kv_head_idx, qo_indptr, kv_indptr, qo_len, kv_len, batch_idx] =
        block_coord;
    constexpr int kHeadDim = get<1>(TileShape_PDV{});
    const int tail = qo_len - qo_tile_idx * int(CTA_Q);
    const int rows = tail < int(CTA_Q) ? tail : int(CTA_Q);
    const int chunks = num_kv_chunks > 0 ? num_kv_chunks : 1;
    if (partial_indptr < 0) return;
    const int nkvh = epilogue_params.num_kv_heads;
    for (int r = thread_idx; r < rows; r += NUM_MMA_THREADS) {
      const size_t slot =
          size_t(partial_indptr + r * chunks + kv_chunk_idx) * size_t(nkvh) + size_t(kv_head_idx);
      if (epilogue_params.partial_lse != nullptr) {
        epilogue_params.partial_lse[slot] = -cutlass::platform::numeric_limits<float>::infinity();
      }
      if (epilogue_params.partial_o != nullptr) {
        DTypeO* dst = epilogue_params.partial_o + slot * kHeadDim;
        // Vectorised: was element-at-a-time over 128 elements per row.
        constexpr int kVecZ = 16 / sizeof(DTypeO);
        DTypeO zed[kVecZ];
#pragma unroll
        for (int v = 0; v < kVecZ; ++v) zed[v] = DTypeO(0.f);
        for (int d = 0; d < kHeadDim; d += kVecZ) {
          *reinterpret_cast<uint4*>(dst + d) = *reinterpret_cast<uint4 const*>(zed);
        }
      }
    }
  }

  CUTLASS_DEVICE void store_tail() {
    // tma_store_wait<0>();
  }

  // Write 0 to output and -inf to LSE
  template <typename BlockCoord, typename SharedStorage>
  CUTLASS_DEVICE void store_zero(Params const& epilogue_params, SharedStorage& shared_storage,
                                 int thread_idx, BlockCoord const& block_coord) {
    auto [qo_tile_idx, qo_head_idx, kv_head_idx, qo_indptr, kv_indptr, qo_len, kv_len, batch_idx] =
        block_coord;
    Tensor mO = make_tensor(make_gmem_ptr(epilogue_params.O_ptr), epilogue_params.layout_O);
    Tensor gO = get_local_tile_tensor(mO, select<0, 1>(TileShape_PDV{}), qo_head_idx, qo_indptr,
                                      qo_len)(_, _, qo_tile_idx);  // (O, D)
    Tensor cO = cute::make_identity_tensor(gO.shape());            // (O, D) -> (o_idx, d_idx)
    Tensor mLSE = make_tensor(make_gmem_ptr(epilogue_params.lse_ptr), epilogue_params.layout_LSE);
    Tensor gLSE = get_lse_local_tile_tensor(mLSE, Shape<Int<CTA_Q>>{}, qo_head_idx, qo_indptr,
                                            qo_len)(_, qo_tile_idx);

    TiledCopyO tiled_copy_O;
    auto thr_copy_O = tiled_copy_O.get_thread_slice(thread_idx);
    Tensor tOgO = thr_copy_O.partition_D(gO);  // (CPY, CPY_O, CPY_D)
    Tensor tOrO = make_fragment_like(tOgO);    // (CPY, CPY_O, CPY_D)
    clear(tOrO);
    Tensor tOcO = thr_copy_O.partition_D(cO);  // (CPY, CPY_O, CPY_D)
    Tensor tOgOGroup = flatten_1(tOgO);        // (CPY, (CPY_O, CPY_D))
    Tensor tOrOGroup = flatten_1(tOrO);        // (CPY, (CPY_O, CPY_D))
    Tensor tOcOGroup = flatten_1(tOcO);        // (CPY, (CPY_O, CPY_D))

    const int qo_tile_size = get<0>(TileShape_PDV{});
    int valid_qo_tile_size = std::min<int>(qo_len - qo_tile_idx * qo_tile_size, qo_tile_size);
    if (valid_qo_tile_size == qo_tile_size) {
      copy(tiled_copy_O, tOrOGroup, tOgOGroup);
    } else {
      auto predicate_fn = [&](auto coords) {
        auto s_coords = tOcOGroup(_0{}, coords);
        return elem_less(get<0>(s_coords), valid_qo_tile_size);
      };
      copy_if(tiled_copy_O, predicate_fn, tOrOGroup, tOgOGroup);
    }

    static_assert(CTA_Q <= NUM_MMA_THREADS);
    if (epilogue_params.lse_ptr) {  // don't write to LSE if it's nullptr
      if (thread_idx < qo_len - qo_tile_idx * CTA_Q) {
        gLSE(thread_idx) = -math::inf;
      }
    }
  }
};

}  // namespace flashinfer

#endif  // FLASHINFER_ATTENTION_HOPPER_EPILOGUE_CUH_

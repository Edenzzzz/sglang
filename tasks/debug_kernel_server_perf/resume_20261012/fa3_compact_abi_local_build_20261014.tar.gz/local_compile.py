import importlib.util
import os
from pathlib import Path

root = Path("/dev/shm/fa3_compact_abi_work_20261014")
tile_kv = os.environ.get("FA3_CTA_KV", "128")
os.environ.update({
    "SGLANG_FUSED_FI_ROOT": str(root / "port07"),
    "SGLANG_FUSED_FI_DATA": "/tmp/kvshare_fi07_20261013/flashinfer/data",
    "SGLANG_FUSED_MERGED_DIR": "/tmp/fa3_compact_abi_merged_20261014",
    "TORCH_EXTENSIONS_DIR": "/tmp/fa3_compact_abi_extensions_20261014",
    "TORCH_CUDA_ARCH_LIST": "9.0a",
    "SGLANG_FUSED_FA2_TILES": "64,32,16",
    "FUSED_CLUSTER": "1",
    "FUSED_PAGED_TMA_BUILD": "0",
    "FA3_CTA_KV": tile_kv,
    "SGLANG_FUSED_FA3_CONSUMER_REGS": "216",
    "FUSED_PACKED_Q": "7",
    "FUSED_CONST_PERS_PARAMS": "1",
    "FUSED_FA2_FINE_TAIL": "1",
    "MAX_JOBS": "1",
})
loader_path = root / "up_racefix/python/sglang/srt/layers/attention/fused_fa3_loader.py"
spec = importlib.util.spec_from_file_location("native_pdl_loader", loader_path)
loader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(loader)
loader._ensure_generated_config = lambda: str(root / "generated_config")
print(loader.load_fused_fa3(verbose=True, cta_q=128), flush=True)

#include <torch/all.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/cuda/CUDAGuard.h>
#include "native_prefill_bridge.cuh"

TORCH_LIBRARY(native_fa2_q32, library) {
  library.def(
      "run(Tensor query, Tensor key_cache, Tensor value_cache, Tensor query_indptr, "
      "Tensor kv_indptr, Tensor kv_indices, Tensor last_page_len, Tensor(a!) output, "
      "Tensor(b!) lse, Tensor(c!) float_workspace, Tensor int_workspace, int[] plan_values, "
      "float sm_scale, bool enable_pdl, bool independent_pdl, Tensor(d!) timeline, "
      "int query_tile, int maximum_query) -> ()",
      &native_fa2_run);
}

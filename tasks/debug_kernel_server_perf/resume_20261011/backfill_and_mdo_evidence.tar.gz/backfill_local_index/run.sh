set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi
export HEADS=28,4 FUSED_REFERENCE_WORKSPACE_BYTES=16 FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=64,32,16 FUSED_CONST_PERS_PARAMS=1
SM_SPLIT=64 MODE=fa2 /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/backfill_local_index/fa2.log 2>&1
SM_SPLIT=64 MODE=mixed_verify /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/backfill_local_index/mixed.log 2>&1
echo BACKFILL_BASE_REFERENCE_PASS
SM_SPLIT=all FLASHINFER_FUSED_BACKFILL=1 MODE=mixed_verify /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/backfill_local_index/on.log 2>&1
echo CROSS_ROLE_BACKFILL_PASS
if SM_SPLIT=all FLASHINFER_FUSED_BACKFILL=0 MODE=mixed_verify /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/backfill_local_index/off.log 2>&1; then
 echo BACKFILL_NULL_UNEXPECTED_PASS
 exit 1
fi
echo BACKFILL_NULL_FAILED_AS_EXPECTED

import importlib.util
import os
from pathlib import Path

from torch.utils.cpp_extension import load


def build():
    root = Path(__file__).resolve().parent
    specification = importlib.util.spec_from_file_location("native_q32_loader", root / "base_loader.py")
    loader = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(loader)
    data = loader.fi_data_dir()
    if data is None:
        raise RuntimeError("Installed FlashInfer headers are required; set SGLANG_FUSED_FI_DATA")
    os.environ["SGLANG_FUSED_MERGED_DIR"] = os.environ.get("NATIVE_Q32_MERGED", "/tmp/native_q32_merged_20261015")
    includes = loader._merged_include_tree(data, str(root / "port07"))
    return load(
        name="native_fa2_q32",
        sources=[str(root / "native_fa2_q32.cu")],
        extra_include_paths=[
            includes, str(root), str(Path(data) / "cutlass/include"),
            str(Path(data) / "cutlass/tools/util/include"),
            str(Path(data) / "cccl/libcudacxx/include"),
            str(Path(data) / "cccl/thrust"), str(Path(data) / "cccl/cub"),
        ],
        extra_cuda_cflags=[
            "-std=c++20", "-O3", "-arch=sm_90a", "--expt-relaxed-constexpr",
            "--expt-extended-lambda", "--use_fast_math", "-DNDEBUG",
            "-DCUTLASS_ENABLE_GDC_FOR_SM90", "--threads", "8",
            "-U__CUDA_NO_HALF_OPERATORS__", "-U__CUDA_NO_HALF_CONVERSIONS__",
            "-U__CUDA_NO_HALF2_OPERATORS__", "-U__CUDA_NO_BFLOAT16_OPERATORS__",
            "-U__CUDA_NO_BFLOAT16_CONVERSIONS__", "-U__CUDA_NO_BFLOAT162_OPERATORS__",
        ],
        extra_cflags=["-std=c++20", "-O3", "-DNDEBUG"],
        is_python_module=False,
        verbose=True,
    )


if __name__ == "__main__":
    print(build(), flush=True)

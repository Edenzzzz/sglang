#include <cstdio>

#include "flashinfer/attention/hopper/kernel_traits.cuh"

template <int Tile>
int check_mapping() {
  using namespace cute;
  using Value = cutlass::bfloat16_t;
  using Atom = Copy_Atom<SM80_CP_ASYNC_CACHEGLOBAL_ZFILL<uint128_t>, Value>;
  using Copy = decltype(cutlass::gemm::collective::detail::make_simt_gmem_tiled_copy<
      Atom, 128, 8, cutlass::detail::TagToStrideB_t<cutlass::layout::ColumnMajor>,
      Int<Tile>, Int<128>>());
  auto identity = make_identity_tensor(make_shape(Int<Tile>{}, Int<128>{}, Int<1>{}));
  int bad = 0;
  int checked = 0;
  for (int producer = 0; producer < 128; ++producer) {
    auto coordinates = Copy{}.get_slice(producer).partition_S(identity);
    constexpr int iterations = decltype(size<1>(coordinates))::value;
    constexpr int stride = Tile / iterations;
    constexpr int threads_per_group = 128 / stride;
    auto flattened = flatten(coordinates(_, _, _, 0));
    for (int vector = 0; vector < size(flattened) / 8; ++vector) {
      const int row = get<0>(flattened(vector * 8));
      const int group = producer / threads_per_group;
      const int lane = (group * threads_per_group + row / stride) % 32;
      const int source = (producer / 32) * 32 + lane;
      const int loaded = source / threads_per_group + (source % threads_per_group) * stride;
      if (row != loaded || source % threads_per_group >= iterations) {
        if (bad < 4) std::printf("BAD tile=%d producer=%d row=%d source=%d loaded=%d\n",
                                 Tile, producer, row, source, loaded);
        ++bad;
      }
      ++checked;
    }
    if (producer == 0) std::printf("tile=%d iterations=%d stride=%d threads/group=%d\n",
                                   Tile, iterations, stride, threads_per_group);
  }
  std::printf("tile=%d mapping bad=%d/%d\n", Tile, bad, checked);
  return bad;
}

int main() {
  const int bad64 = check_mapping<64>();
  const int bad96 = check_mapping<96>();
  const int bad128 = check_mapping<128>();
  return bad64 + bad96 + bad128 != 0;
}

set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi
export HEADS=28,4 SM_SPLIT=64 FUSED_REFERENCE_WORKSPACE_BYTES=16 FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=64,32,16
for mode in fa2 fa3_1chunk mixed_verify; do
 MODE=$mode /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fa2_tile32/verify_$mode.log 2>&1
done
echo TILE32_REFERENCE_PASS
MODE=band1 BAND_SIDE=fa2 BAND_QO=4 BAND_ROWS=8 BAND_KV=2048 TIME_AB=1 TIME_ITERS=100 /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fa2_tile32/verify_timing.log 2>&1
MODE=mixed_verify TIME_AB=1 TIME_ITERS=100 /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fa2_tile32/mixed_timing.log 2>&1
echo TILE32_TIMINGS_DONE

import json
from sglang.srt.configs.model_config import ModelConfig
from sglang.srt.utils.hf_transformers.common import get_rope_config
ovr = '{"rope_scaling":{"factor":4.0,"original_max_position_embeddings":32768,"type":"yarn"}}'
for name, args in [("no_override", "{}"), ("yarn_override", ovr)]:
    mc = ModelConfig("/dev/shm/w/qwen7b", model_override_args=args, context_length=131072 if args != "{}" else None)
    cfg = mc.hf_text_config
    print(name, "rope_parameters=", getattr(cfg, "rope_parameters", None),
          "rope_scaling=", getattr(cfg, "rope_scaling", None),
          "-> get_rope_config:", get_rope_config(cfg), flush=True)

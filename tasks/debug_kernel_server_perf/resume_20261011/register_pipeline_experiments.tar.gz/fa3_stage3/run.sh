set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi HF_HOME=/dev/shm/w/hf
export HEADS=28,4 SM_SPLIT=64 FUSED_REFERENCE_WORKSPACE_BYTES=16 FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=64,32,16 FUSED_CONST_PERS_PARAMS=1 FUSED_FA2_REG_REALLOC=1 FLASHINFER_FUSED_BACKFILL=1 FUSED_FA2_KV_CHUNK=1024
export SGLANG_FUSED_FA2_MMA_KV=2 SGLANG_FUSED_FA2_QSPLIT=0 FA3_STAGES=3
for mode in fa2 fa2_2tile fa3_1chunk fa3_multitile mixed_verify; do
 chunk=1024
 if [ "$mode" = fa2_2tile ]; then chunk=128; fi
 FUSED_FA2_KV_CHUNK=$chunk MODE=$mode /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fa3_stage3/verify_$mode.log 2>&1
done
FUSED_WORK_BUDGET_SPLIT=0 PREFILL_QO=504 PREFILL_KV=504 MODE=mixed_verify /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fa3_stage3/fully_masked_fa3_chunks.log 2>&1
SM_SPLIT=all MODE=mixed_verify /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fa3_stage3/backfill_all.log 2>&1
if SM_SPLIT=all FLASHINFER_FUSED_BACKFILL=0 MODE=mixed_verify /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fa3_stage3/backfill_null.log 2>&1; then echo BACKFILL_NULL_UNEXPECTED_PASS; exit 1; fi
echo FA3_STAGE3_HEAD_REFERENCE_PASS
MODE=mixed_verify TIME_AB=1 TIME_CUDA_GRAPH=1 TIME_ITERS=100 /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/fa3_stage3/timing.log 2>&1
/usr/local/cuda/bin/cuobjdump --dump-resource-usage /home/tiger/.cache/torch_extensions/py312_cu130/fused_fa3/fused_fa3.so > /dev/shm/w/fa3_stage3/resources.log
CORRECTNESS_SYNTHETIC=0 CORRECTNESS_DATASET=/dev/shm/w/datasets/ShareGPT.original.json DISABLE_CUDA_GRAPH=1 BENCH_CHUNK=512 CORRECTNESS_DECODE_TOKENS=1200 SGLANG_FUSED_DECODE_GUARD=0 SGLANG_FUSED_SPLIT_VERIFY=1 /dev/shm/w/venv/bin/python -u /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py MTPMIXFUSED /dev/shm/w/fa3_stage3
cp /dev/shm/w/sharegpt_correctness/MTP_LPT.json /dev/shm/w/fa3_stage3/MTP_LPT.json
/dev/shm/w/venv/bin/python /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py --compare /dev/shm/w/fa3_stage3 MTP_LPT MTPMIXFUSED
echo FA3_STAGE3_SERVING_PASS

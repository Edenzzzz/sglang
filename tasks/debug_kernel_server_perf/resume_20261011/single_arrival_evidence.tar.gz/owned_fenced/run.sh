set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi HF_HOME=/dev/shm/w/hf
export O_HANDSHAKE=1 Q_REUSE_FENCE=1 SPLIT_SMEM_O=1 HEADS=28,4 SM_SPLIT=64 FUSED_REFERENCE_WORKSPACE_BYTES=16
for mode in fa2 fa3_1chunk mixed; do
 MODE=$mode /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/owned_fenced/$mode.log 2>&1
done
echo OWNED_FENCED_KERNEL_PASS
DISABLE_CUDA_GRAPH=1 BENCH_CHUNK=512 CORRECTNESS_DECODE_TOKENS=1200 SGLANG_FUSED_DECODE_GUARD=0 SGLANG_FUSED_SPLIT_VERIFY=1 SGLANG_FUSED_FAILURE_DUMP=/dev/shm/w/owned_fenced/failure.pt /dev/shm/w/venv/bin/python -u /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py MTPMIXFUSED /dev/shm/w/owned_fenced
echo OWNED_FENCED_SERVING_PASS

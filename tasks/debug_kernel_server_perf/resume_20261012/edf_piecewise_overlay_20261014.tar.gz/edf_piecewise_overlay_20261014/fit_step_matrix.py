"""Compare step predictors on audited serving runs without joining run boundaries."""

import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import re

import numpy as np
from scipy.optimize import nnls


FEATURES = ("et", "bs", "np", "ptok", "pf", "nd", "dkv", "kv", "mx")
COEFFICIENTS = ("c0", "c_tok", "c_attn", "c_bs", "c_kv")
NUMBER = r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?"
TRACE = re.compile(
    r"STEPTRACE (?P<mode>\w+) "
    + " ".join(rf"{name}=(?P<{name}>-?\d+)" for name in FEATURES)
    + rf"(?: acc=(?P<acc>{NUMBER}))? t=(?P<time>{NUMBER})"
    + rf"(?: gpu=(?P<gpu>{NUMBER}))?"
)


def parse_trace(text):
    rows = []
    for line in text.splitlines():
        if "STEPTRACE " not in line:
            continue
        match = TRACE.search(line)
        if match is None:
            raise ValueError(f"Malformed STEPTRACE: {line[:160]}")
        row = {name: int(match[name]) for name in FEATURES}
        row.update(mode=match["mode"], time=float(match["time"]))
        for name in ("acc", "gpu"):
            row[name] = float(match[name]) if match[name] is not None else None
        numbers = [value for value in row.values() if isinstance(value, (int, float))]
        if not all(np.isfinite(numbers)) or any(
            row[name] < 0 for name in ("np", "ptok", "pf", "nd", "dkv")
        ):
            raise ValueError("Invalid step features")
        if row["acc"] is not None and row["acc"] <= 0:
            raise ValueError("Acceptance must be positive")
        rows.append(row)
    return rows


def samples_from_run(rows, gap_ms=250.0):
    samples = []
    for current, following in zip(rows, rows[1:]):
        interval = (following["time"] - current["time"]) * 1000.0
        if interval <= 0:
            raise ValueError("Step timestamps must increase within each run")
        if interval < gap_ms:
            samples.append({**current, "launch_ms": interval})
    return samples


def design(rows, acceptance=False):
    matrix = []
    for row in rows:
        tokens = row["ptok"]
        count = row["np"]
        prefix = row["pf"] / count if count else 0.0
        features = [
            1.0,
            tokens,
            (tokens * prefix + 0.5 * tokens * tokens / max(count, 1)) / 1e6,
            row["nd"],
            row["dkv"] / 1e3,
        ]
        if acceptance:
            if row["acc"] is None:
                raise ValueError(
                    "Acceptance-aware fit requires acceptance in every row"
                )
            features.append(row["acc"])
        matrix.append(features)
    return np.asarray(matrix, dtype=np.float64)


def fit(matrix, targets):
    scale = np.sqrt(np.mean(matrix * matrix, axis=0))
    scale[scale == 0] = 1.0
    coefficients, _ = nnls(matrix / scale, targets, maxiter=10000)
    return coefficients / scale


def fit_piecewise(rows, target, acceptance=False):
    coefficients = {}
    for mode in ("decode", "extend"):
        selected = [row for row in rows if (row["ptok"] > 0) == (mode == "extend")]
        if len(selected) < 10:
            raise ValueError(f"Insufficient {mode} samples for piecewise fit")
        values = np.asarray([row[target] for row in selected], dtype=np.float64)
        coefficients[mode] = fit(
            design(selected, acceptance) / values[:, None], np.ones(len(values))
        )
    return coefficients


def predict_piecewise(rows, coefficients, acceptance=False):
    matrix = design(rows, acceptance)
    result = np.empty(len(rows), dtype=np.float64)
    for mode in ("decode", "extend"):
        selected = np.asarray([(row["ptok"] > 0) == (mode == "extend") for row in rows])
        result[selected] = matrix[selected] @ coefficients[mode]
    return result


def metrics(targets, predictions):
    error = predictions - targets
    relative = np.abs(error) / targets
    return {
        "n": len(targets),
        "mean_ms": float(np.mean(targets)),
        "mae_ms": float(np.mean(np.abs(error))),
        "mape": float(np.mean(relative)),
        "p90_ape": float(np.quantile(relative, 0.9)),
        "bias_ms": float(np.mean(error)),
        "underprediction_fraction": float(np.mean(error < 0)),
        "nonpositive_prediction_fraction": float(np.mean(predictions <= 0)),
    }


def evaluate(training, heldout, target, acceptance, strategy="global"):
    if len(training) < 10 or len(heldout) < 10:
        raise ValueError("Each fit needs at least ten training and ten held-out steps")
    train_values = np.asarray([row[target] for row in training], dtype=np.float64)
    test_values = np.asarray([row[target] for row in heldout], dtype=np.float64)
    if not np.all(train_values > 0) or not np.all(test_values > 0):
        raise ValueError("Targets must be positive")
    if strategy == "piecewise-relative":
        coefficients = fit_piecewise(training, target, acceptance)
        predictions = predict_piecewise(heldout, coefficients, acceptance)
    else:
        coefficients = fit(design(training, acceptance), train_values)
        predictions = design(heldout, acceptance) @ coefficients
    result = {
        "train_n": len(training),
        "heldout": metrics(test_values, predictions),
        "constant": metrics(test_values, np.full(len(heldout), np.mean(train_values))),
    }
    names = COEFFICIENTS + (("c_acc",) if acceptance else ())
    if strategy == "piecewise-relative":
        result["mode_coef"] = {
            mode: dict(zip(names, map(float, values)))
            for mode, values in coefficients.items()
        }
    else:
        result["coef"] = dict(zip(names, map(float, coefficients)))
    for field in ("mode", "mixture", "run"):
        result["by_" + field] = {}
        for value in sorted({row[field] for row in heldout}):
            selected = np.asarray([row[field] == value for row in heldout])
            result["by_" + field][value] = metrics(
                test_values[selected], predictions[selected]
            )
    return result


def load_runs(root):
    runs = defaultdict(list)
    for audit_path in sorted(root.glob("*/execution_audit.json")):
        audit = json.loads(audit_path.read_text())
        if (
            not audit.get("completed")
            or audit.get("fallbacks") != 0
            or audit.get("tracebacks") != 0
        ):
            raise ValueError(f"Invalid serving audit: {audit_path}")
        if audit.get("mixed_steps", 0) <= 0:
            raise ValueError(f"No mixed execution: {audit_path}")
        trace_path = audit_path.parent / "steptrace.log"
        trace = trace_path.read_bytes()
        rows = parse_trace(trace.decode())
        if len(rows) != audit["trace_rows"]:
            raise ValueError(f"Trace count differs from audit: {trace_path}")
        if not any(row["np"] > 0 and row["ptok"] > 0 and row["nd"] > 0 for row in rows):
            raise ValueError(
                f"Mixed serving trace has no prefill/decode feature rows: {trace_path}"
            )
        runs[audit["method"]].append(
            {
                "run": audit_path.parent.name,
                "mixture": audit["mixture"],
                "chat_rate": audit["chat_rate"],
                "rows": rows,
                "trace_sha256": hashlib.sha256(trace).hexdigest(),
                "server_sha256": audit["server_sha256"],
            }
        )
    if not runs:
        raise ValueError(f"No audited trace runs under {root}")
    return runs


def analyze(runs, gap_ms, strategy="global"):
    samples = []
    for run in runs:
        current = samples_from_run(run["rows"], gap_ms)
        midpoint = len(current) // 2
        if midpoint < 10:
            raise ValueError(f"Insufficient contiguous steps in {run['run']}")
        for index, row in enumerate(current):
            samples.append(
                {
                    **row,
                    "run": run["run"],
                    "mixture": run["mixture"],
                    "training": index < midpoint,
                }
            )
    report = {
        "runs": [
            {key: value for key, value in run.items() if key != "rows"} for run in runs
        ],
        "n_steps": len(samples),
        "fits": {},
    }
    for target in ("launch_ms", "gpu"):
        valid = [row for row in samples if row[target] is not None and row[target] > 0]
        if not valid:
            continue
        for acceptance in (False, True):
            if acceptance and any(row["acc"] is None for row in valid):
                continue
            name = target + ("_acceptance" if acceptance else "_base")
            result = evaluate(
                [row for row in valid if row["training"]],
                [row for row in valid if not row["training"]],
                target,
                acceptance,
                strategy,
            )
            result["leave_context_out"] = {}
            contexts = sorted({row["mixture"] for row in valid})
            if len(contexts) > 1:
                for context in contexts:
                    result["leave_context_out"][context] = evaluate(
                        [row for row in valid if row["mixture"] != context],
                        [row for row in valid if row["mixture"] == context],
                        target,
                        acceptance,
                        strategy,
                    )
            report["fits"][name] = result
    coefficients = fit(
        design(samples), np.asarray([row["launch_ms"] for row in samples])
    )
    model = {
        "coef": dict(zip(COEFFICIENTS, map(float, coefficients))),
        "n_steps": len(samples),
        "status": "unvalidated_serving_candidate",
        "target": "launch_to_launch_ms",
        "fit": "nonnegative_least_squares_all_runs",
        "heldout_mape": report["fits"]["launch_ms_base"]["heldout"]["mape"],
        "acceptance_feature": False,
    }
    if strategy == "piecewise-relative":
        mode_coefficients = fit_piecewise(samples, "launch_ms")
        model["mode_coef"] = {
            mode: dict(zip(COEFFICIENTS, map(float, values)))
            for mode, values in mode_coefficients.items()
        }
        model["coef"] = model["mode_coef"]["decode"]
        model["fit"] = "nonnegative_relative_least_squares_by_mode"
        model["requires_mode_aware_predictor"] = True
    return report, model


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--gap-ms", type=float, default=250.0)
    parser.add_argument(
        "--strategy", choices=("global", "piecewise-relative"), default="global"
    )
    parser.add_argument("--require-methods", default="MTPMIX_LPT,MTPMIX_SPLIT")
    parser.add_argument("--require-contexts", default="mix32,mix64,mix128")
    parser.add_argument("--require-runs", type=int, default=6)
    arguments = parser.parse_args()
    if arguments.gap_ms <= 0 or not np.isfinite(arguments.gap_ms):
        parser.error("--gap-ms must be finite and positive")
    runs = load_runs(arguments.root)
    if set(runs) != set(arguments.require_methods.split(",")):
        raise ValueError(f"Incomplete method comparison: {sorted(runs)}")
    required = set(arguments.require_contexts.split(","))
    reference_fixtures = None
    for method, method_runs in runs.items():
        contexts = {run["mixture"] for run in method_runs}
        if contexts != required or len(method_runs) != arguments.require_runs:
            raise ValueError(
                f"Incomplete matrix for {method}: {len(method_runs)} runs, {contexts}"
            )
        fixtures = {(run["mixture"], run["chat_rate"]) for run in method_runs}
        if len(fixtures) != len(method_runs):
            raise ValueError(f"Duplicate context/rate fixture for {method}")
        if reference_fixtures is not None and fixtures != reference_fixtures:
            raise ValueError("Methods must have matched context/rate fixtures")
        reference_fixtures = fixtures
    report = {
        "target_scope": "CPU launch intervals and asynchronous forward GPU durations",
        "validation": "chronological half within each run; leave-one-context-out separately",
        "acceptance_semantics": "pre-step cumulative server acceptance, not per-request EWMA",
        "deployment": "acceptance-free NNLS only; fresh EDF serving validation still required",
        "gap_ms": arguments.gap_ms,
        "strategy": arguments.strategy,
        "methods": {},
    }
    arguments.out.mkdir(parents=True, exist_ok=True)
    for method, method_runs in runs.items():
        result, model = analyze(method_runs, arguments.gap_ms, arguments.strategy)
        report["methods"][method] = result
        (arguments.out / (method + "_step_model.json")).write_text(
            json.dumps(model, indent=2) + "\n"
        )
        print(method, "steps", result["n_steps"], "heldout_mape", model["heldout_mape"])
    (arguments.out / "report.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()

# flashinfer 0.7 port overlay

Files here are OUR versions rebased onto **flashinfer 0.7.0.post1**, to be used as an include
overlay *in front of* the installed wheel's bundled headers
(`<site-packages>/flashinfer/data/include`). The build therefore takes 0.7's headers for
everything except the files present here.

Why an overlay rather than editing a checkout: the 0.3.1 source tree and the 0.7 wheel disagree
on the central plan struct (`HolisticPlanInfo` went from 3-4 tasks with group tables to 2 tasks
with `partial_indptr` + `merge_indptr`/`merge_o_indices`), so mixing the two trees on one include
path silently reintroduces the mismatch that made the kernel reject every plan
(`persistent plan has 28 entries, expected 56 or 68`).

## Status

| file | state | notes |
|---|---|---|
| `attention/persistent.cuh` | **ported** | 11 of our 16 hunks applied onto 0.7's copy; the 5 rejects were all JIT-reduction machinery and are dropped by design (K1a: measured ceiling 0.6% of GPU time). Carries `FUSED_GRID` role indexing and the recovered `cluster_tile_q` guard; zero residual `MergeGroupJIT`/`s_merge_flag`/`group_counter` references. |
| `attention/scheduler.cuh` | **NOT overlaid (by design)** | 0.7's copy is used unmodified. Our additions live in the private `attention/fused_plan.cuh` instead, so flashinfer's own `BatchAttention` keeps its 28-entry plan format and upgrades cannot silently change ours. |
| `attention/fused_plan.cuh` | **added (K1c1)** | `FusedPlanInfo<4>`: 0.7 fields + `batch_idx_offset` per task + 6 shared (cursor, cluster counts, `max_splits_fa3`, fa3 request list, `num_fa3_clusters` last). 11 / 14, verified self-consistent; 58 entries at 4 tasks. |
| `attention/persistent_fa3_fused.cuh` | todo (K1d) | +948, retarget to the 2-task layout and the scheduled merge |
| `attention/persistent_wgmma.cuh` | todo | +70, new file |
| `attention/unified_wgmma_scheduler.cuh` | todo | +281, new file |
| `attention/prefill.cuh` | todo | +65, onto a file 0.7 grew from 2734 to 4871 lines |
| `attention/jit_merge.cuh` | **dropped** | JIT reduction not ported; see K1a |


## CRITICAL CONSTRAINT: the plan format is shared with flashinfer's own compiled module

Extending `HolisticPlanInfo` changes the serialised length: with 11 per-task and 14 shared it is
**36 at `NUM_TASKS=2`** and 58 at 4, where stock 0.7 is 28 and 48.

`BatchAttention._plan_info` is produced by **flashinfer's own JIT-compiled module**, not by our
extension. So if our kernel is built against the overlay while `BatchAttention` is built against
the wheel's pristine headers, the two disagree on the format and the kernel rejects every plan --
the same class of failure as `persistent plan has 28 entries, expected 56 or 68`, just with
different numbers.

On the 0.3.1 tree this never arose: flashinfer was used as a **source tree** and its JIT compiled
`BatchAttention` from the same modified headers, so our struct changes were automatically in both.
With the 0.7 **wheel** that coupling is gone.

Two ways out, and the choice is a real decision rather than a detail:

1. **Feed the overlay to flashinfer's own JIT** so `BatchAttention` is compiled against the
   extended struct too. flashinfer 0.7's `jit/core.py` assembles include paths from its data dir;
   the overlay has to be prepended there. Keeps the harness's existing design (consume
   `BatchAttention`'s plan) and keeps one plan format in the process.
2. **Build the 4-task plan ourselves and never consume `BatchAttention._plan_info`.** The fused
   kernel then needs its own planner call, and `BatchAttention` is used only for its workspace
   buffers (or we allocate our own). Decouples us from flashinfer's build entirely, at the cost
   of duplicating `TwoStageHolisticPlan`.

Option 1 is less code; option 2 is more robust to future flashinfer releases, which have already
broken us twice (plan struct redesign, helper removal).

import torch, json
capture=torch.load('/dev/shm/w/mixed_trace_integration/failure.pt',map_location='cpu',weights_only=True)
print(json.dumps({key:capture.get(key) for key in ('layer_id','worst_query_row','worst_query_head','num_fa3_rows','sm_split','kv_chunk_size','kernel_environment')},default=str))
print('q_shape',list(capture['q'].shape),'q_lengths',torch.diff(capture['q_indptr']).tolist(),'kv_lengths',capture['kv_lens'].tolist())

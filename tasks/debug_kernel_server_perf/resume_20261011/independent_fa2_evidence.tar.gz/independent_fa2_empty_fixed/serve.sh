set -e
export PYTHONPATH=/dev/shm/w/validated_upstream/python SGLANG_FUSED_FI_ROOT=/dev/shm/w/fi HF_HOME=/dev/shm/w/hf
export HEADS=28,4 SM_SPLIT=64 FUSED_REFERENCE_WORKSPACE_BYTES=16 FUSED_WORK_BUDGET_SPLIT=1 SGLANG_FUSED_FA2_TILES=64,32,16 FUSED_CONST_PERS_PARAMS=1 FLASHINFER_FUSED_BACKFILL=1 FUSED_FA2_KV_CHUNK=1024
DISABLE_CUDA_GRAPH=1 BENCH_CHUNK=512 CORRECTNESS_DECODE_TOKENS=1200 SGLANG_FUSED_DECODE_GUARD=0 SGLANG_FUSED_SPLIT_VERIFY=1 SGLANG_FUSED_FAILURE_DUMP=/dev/shm/w/independent_fa2_empty_fixed/failure.pt /dev/shm/w/venv/bin/python -u /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py MTPMIXFUSED /dev/shm/w/independent_fa2_empty_fixed
/dev/shm/w/venv/bin/python /dev/shm/w/validated_upstream/tasks/fused_specdec_workload/drivers/srv_correctness.py --compare /dev/shm/w/independent_fa2_empty_fixed MTP_LPT MTPMIXFUSED
echo INDEPENDENT_FA2_SERVING_PASS
for capture in 0 1; do
 for chunk in 2048 1024 1024 2048; do
  FUSED_FA2_KV_CHUNK=$chunk TIME_CUDA_GRAPH=$capture MODE=mixed_verify TIME_AB=1 TIME_ITERS=100 /dev/shm/w/venv/bin/python -u /dev/shm/w/drivers/fused_reference.py > /dev/shm/w/independent_fa2_empty_fixed/repeat_${capture}_${chunk}_$(date +%s).log 2>&1
 done
done
echo INDEPENDENT_FA2_REPEATED_AB_PASS

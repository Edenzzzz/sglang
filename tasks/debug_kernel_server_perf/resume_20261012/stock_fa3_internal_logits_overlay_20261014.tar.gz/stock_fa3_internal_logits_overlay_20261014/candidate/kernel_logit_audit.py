import hashlib
import json
import os
from pathlib import Path

import torch


def capture_mixed_logits(prefill_batch, running_batch, verify_input, prefill_logits, verify_logits):
    destination = os.environ.get("SGLANG_KERNEL_LOGIT_AUDIT")
    if not destination:
        return
    requested = set(os.environ.get("SGLANG_KERNEL_LOGIT_AUDIT_RIDS", "l0,s1").split(","))
    limit = int(os.environ.get("SGLANG_KERNEL_LOGIT_AUDIT_TOKENS", "16"))
    width = int(verify_input.draft_token_num)
    if width < 1 or limit < 1:
        raise ValueError("Invalid logit-audit bounds")
    prefill_lengths = prefill_batch.seq_lens.tolist()
    running_lengths = running_batch.seq_lens.tolist()
    draft_tokens = verify_input.draft_token.reshape(-1, width)
    if len(prefill_lengths) != len(prefill_batch.reqs) or len(running_lengths) != len(running_batch.reqs):
        raise ValueError("Logit-audit batch metadata mismatch")
    if prefill_logits.shape[0] < len(prefill_lengths) or verify_logits.shape[0] < len(running_lengths) * width:
        raise ValueError("Logit-audit row extent mismatch")
    records = []
    selected = []
    for role, batch, lengths, logits in (
        ("prefill", prefill_batch, prefill_lengths, prefill_logits),
        ("verify", running_batch, running_lengths, verify_logits),
    ):
        for request_index, (request, sequence_length) in enumerate(zip(batch.reqs, lengths, strict=True)):
            if request.rid not in requested:
                continue
            prompt_length = len(request.origin_input_ids)
            first_output = sequence_length - prompt_length + (role == "verify")
            if role == "prefill" and first_output != 0:
                continue
            token_count = width if role == "verify" else 1
            if first_output >= limit or first_output + token_count <= 0:
                continue
            prompt_hash = hashlib.sha256(
                json.dumps(request.origin_input_ids, separators=(",", ":")).encode()
            ).hexdigest()
            proposal = draft_tokens[request_index].tolist() if role == "verify" else []
            for proposal_index in range(token_count):
                output_index = first_output + proposal_index
                if not 0 <= output_index < limit:
                    continue
                row = request_index * width + proposal_index if role == "verify" else request_index
                selected.append(logits[row].float())
                records.append({
                    "rid": request.rid,
                    "role": role,
                    "output_index": output_index,
                    "prompt_length": prompt_length,
                    "prompt_sha256": prompt_hash,
                    "sequence_length": sequence_length,
                    "proposal_begin": first_output - 1 if role == "verify" else None,
                    "proposal_tokens": proposal[:proposal_index + 1] if role == "verify" else [],
                })
    if not selected:
        return
    scores = torch.stack(selected)
    values, indices = scores.topk(min(5, scores.shape[1]), dim=-1)
    normalizers = scores.logsumexp(dim=-1)
    argmax_ids = scores.argmax(dim=-1).tolist()
    top_values = values.tolist()
    top_indices = indices.tolist()
    top_logprobs = (values - normalizers.unsqueeze(-1)).tolist()
    for record, argmax, logits, token_ids, logprobs in zip(
        records, argmax_ids, top_values, top_indices, top_logprobs, strict=True
    ):
        record.update(argmax=argmax, top_logits=logits, top_ids=token_ids, top_logprobs=logprobs)
    with Path(destination).open("a") as output:
        for record in records:
            output.write(json.dumps(record, allow_nan=False) + "\n")

import unittest

import torch

from tma_multicast_reference import PAGE_SIZE, build_fixture, parse_requests, reference_output


class TmaFixtureTest(unittest.TestCase):
    def test_request_validation(self):
        self.assertEqual(parse_requests("17:129,4:8193"), [(17, 129), (4, 8193)])
        self.assertEqual(parse_requests(""), [])
        for invalid in ("0:128", "4:3", "1:2:3", "-1:128"):
            with self.assertRaises(ValueError):
                parse_requests(invalid)

    def test_page_mapping_and_poison(self):
        fixture = build_fixture([(17, 129), (3, 256)], [(4, 257)], device="cpu")
        self.assertEqual(fixture["query_indptr"].tolist(), [0, 17, 20, 24])
        self.assertEqual(fixture["page_indptr"].tolist(), [0, 2, 4, 7])
        pages = fixture["indices_cpu"]
        self.assertEqual(sorted(pages.tolist()), list(range(7)))
        self.assertNotEqual(pages.tolist(), list(range(7)))
        for request, length in enumerate(fixture["kv_lengths"]):
            begin = int(fixture["page_indptr"][request])
            end = int(fixture["page_indptr"][request + 1])
            for name in ("key", "value"):
                dense = fixture[name][pages[begin:end]].flatten(0, 1)
                self.assertTrue(torch.isfinite(dense[:length]).all())
                self.assertTrue(torch.isnan(dense[length:]).all())
                self.assertEqual(dense.shape[0], (end - begin) * PAGE_SIZE)
        self.assertTrue(torch.isfinite(reference_output(fixture)).all())

    def test_single_token_oracle(self):
        fixture = build_fixture([(1, 1)], [], device="cpu")
        reference = reference_output(fixture)
        value = fixture["value"][int(fixture["indices_cpu"][0]), 0].float()
        expected = value.repeat_interleave(7, dim=0)
        self.assertTrue(torch.equal(reference[0], expected))

    def test_seed_reproducibility(self):
        first = build_fixture([(2, 129)], [(4, 256)], device="cpu")
        second = build_fixture([(2, 129)], [(4, 256)], device="cpu")
        for name in ("query", "indices_cpu"):
            self.assertTrue(torch.equal(first[name], second[name]))
        for name in ("key", "value"):
            torch.testing.assert_close(first[name], second[name], equal_nan=True)


if __name__ == "__main__":
    unittest.main()

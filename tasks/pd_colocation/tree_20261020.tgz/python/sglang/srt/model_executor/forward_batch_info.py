# Copyright 2023-2024 SGLang Team
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""
Store information about a forward batch.

The following is the flow of data structures for a batch:

ScheduleBatch -> ForwardBatch

- ScheduleBatch is managed by `scheduler.py::Scheduler`.
  It contains high-level scheduling data. Most of the data is on the CPU.
- ForwardBatch is managed by `model_runner.py::ModelRunner`.
  It contains low-level tensor data. Most of the data consists of GPU tensors.
  It is constructed directly from a ScheduleBatch by `ForwardBatch.init_new`.
"""

from __future__ import annotations

import hashlib
import warnings
from dataclasses import dataclass
from enum import IntEnum, auto
from functools import total_ordering
from typing import TYPE_CHECKING, Dict, List, Optional, Set, Tuple, Union

import torch

from sglang.kernels.ops.attention.clamp_position import clamp_position
from sglang.kernels.ops.attention.position import compute_position_triton
from sglang.srt.configs.hybrid_arch import mambaish_config
from sglang.srt.environ import envs
from sglang.srt.kv_canary.req_to_expected_token_ids_manager import (
    compute_req_all_ids_info,
)
from sglang.srt.layers.dp_attention import (
    DpPaddingMode,
    dp_slot_in,
    set_dp_buffer_len_from_batch,
    set_is_extend_in_batch,
    world_dp_gather_enabled,
)
from sglang.srt.model_executor.forward_batch_deepseek_mha_mixin import (
    ForwardBatchDeepSeekMHAMixin,
)
from sglang.srt.runtime_context import (
    get_exec,
    get_flags,
    get_lora,
    get_parallel,
    mamba_cache_chunk_size,
)
from sglang.srt.speculative.spec_info import SpecInputType
from sglang.srt.utils import (
    is_cpu,
    is_hip,
    is_npu,
    support_triton,
)
from sglang.srt.utils.common import ceil_align, is_pin_memory_available

if TYPE_CHECKING:
    from sglang.srt.configs.model_config import ModelConfig
    from sglang.srt.layers.cp.base import BaseContextParallelMetadata
    from sglang.srt.layers.dcp.metadata import DecodeContextParallelMetadata
    from sglang.srt.layers.layer_boundary.residual.stream import ResidualStream
    from sglang.srt.layers.logits_processor import LogitsProcessorOutput
    from sglang.srt.managers.schedule_batch import MultimodalInputs, ScheduleBatch
    from sglang.srt.mem_cache.kv_loc_plan import Cols, KVLocPlan
    from sglang.srt.model_executor.model_runner import ModelRunner
    from sglang.srt.sampling.sampling_batch_info import SamplingBatchInfo
    from sglang.srt.speculative.spec_info import SpecInput, SpeculativeAlgorithm

# Warn-once flag for the deprecated skip_attn_backend_init kwarg; see
# ForwardBatch.apply_deprecated_skip_attn_backend_init.
_skip_attn_backend_init_warned = False

_is_npu = is_npu()
_is_cpu = is_cpu()
_is_hip = is_hip()


def _build_forward_token_modalities(
    mm_inputs: Optional[List[MultimodalInputs]],
    extend_prefix_lens: Optional[List[int]],
    extend_seq_lens: Optional[List[int]],
    num_tokens: int,
    device: torch.device,
) -> Optional[torch.Tensor]:
    if not mm_inputs or extend_prefix_lens is None or extend_seq_lens is None:
        return None
    if not (len(mm_inputs) == len(extend_prefix_lens) == len(extend_seq_lens)):
        raise ValueError(
            "Multimodal metadata batch dimensions do not match: "
            f"mm_inputs={len(mm_inputs)}, prefixes={len(extend_prefix_lens)}, "
            f"extend_lens={len(extend_seq_lens)}"
        )

    modalities = []
    has_multimodal_tokens = False
    for mm_input, prefix_len, extend_len in zip(
        mm_inputs, extend_prefix_lens, extend_seq_lens
    ):
        if mm_input is None or mm_input.token_modalities is None:
            modalities.extend([0] * extend_len)
            continue
        end = prefix_len + extend_len
        request_modalities = mm_input.token_modalities[prefix_len:end]
        if len(request_modalities) != extend_len:
            raise ValueError(
                "Multimodal token metadata is shorter than the active forward span: "
                f"prefix_len={prefix_len}, extend_len={extend_len}, "
                f"metadata_len={len(mm_input.token_modalities)}"
            )
        has_multimodal_tokens |= any(request_modalities)
        modalities.extend(request_modalities)

    if len(modalities) != num_tokens:
        raise ValueError(
            "Multimodal token metadata does not match the forward batch: "
            f"metadata_tokens={len(modalities)}, forward_tokens={num_tokens}"
        )
    if not has_multimodal_tokens:
        return None
    return torch.tensor(
        modalities,
        dtype=torch.int8,
        pin_memory=is_pin_memory_available(device),
    ).to(device, non_blocking=True)


def _maybe_build_forward_token_modalities(
    model_config: ModelConfig,
    mm_inputs: Optional[List[MultimodalInputs]],
    extend_prefix_lens: Optional[List[int]],
    extend_seq_lens: Optional[List[int]],
    num_tokens: int,
    device: torch.device,
) -> Optional[torch.Tensor]:
    if not model_config.requires_mm_token_modalities:
        return None
    return _build_forward_token_modalities(
        mm_inputs,
        extend_prefix_lens,
        extend_seq_lens,
        num_tokens,
        device,
    )


def _mega_moe_materializes_idle_rank(batch: ForwardBatch) -> bool:
    """Whether aiter MegaMoE needs this idle rank to carry a token anyway.

    MegaMoE's dispatch is rank-synchronous: when the batch is globally a
    prefill, a rank with nothing to do still has to enter the collective, so it
    runs a fabricated one-token extend instead of sitting the forward out.
    """
    return bool(
        _is_hip
        and envs.SGLANG_AITER_MEGA_RANK_SYNC.get()
        and batch.is_extend_in_batch
        and batch.forward_mode.is_idle()
    )


def _elastic_should_preserve_local_token_counts(
    *,
    model_runner: ModelRunner,
    dp_padding_mode: DpPaddingMode,
    global_num_tokens: List[int],
) -> bool:
    if not getattr(model_runner, "enable_elastic_ep", False):
        return False
    if not world_dp_gather_enabled():
        return False
    if not dp_padding_mode.is_max_len():
        return False
    if len(global_num_tokens) <= 1:
        return False

    uneven_token_count = len(set(global_num_tokens)) > 1
    return uneven_token_count


class ForwardMode(IntEnum):
    # Extend a sequence. The KV cache of the beginning part of the sequence is already computed (e.g., system prompt).
    # It is also called "prefill" in common terminology.
    EXTEND = auto()
    # Decode one token.
    DECODE = auto()
    # Contains both EXTEND and DECODE when doing chunked prefill.
    MIXED = auto()
    # No sequence to forward. For data parallel attention, some workers will be IDLE if no sequence are allocated.
    IDLE = auto()

    # Used in speculative decoding: verify a batch in the target model.
    TARGET_VERIFY = auto()
    # Used in speculative decoding: extend a batch in the draft model.
    DRAFT_EXTEND_V2 = auto()

    # Used in disaggregated decode worker
    # Represent a batch of requests having their KV cache ready to start decoding
    PREBUILT = auto()

    # Split Prefill for PD multiplexing
    SPLIT_PREFILL = auto()

    # Used in dLLM
    DLLM_EXTEND = auto()

    def is_prefill(self, include_draft_extend_v2: bool = False):
        return self.is_extend(include_draft_extend_v2=include_draft_extend_v2)

    def is_extend(self, include_draft_extend_v2: bool = False):
        return (
            self == ForwardMode.EXTEND
            or self == ForwardMode.MIXED
            or (include_draft_extend_v2 and self == ForwardMode.DRAFT_EXTEND_V2)
            or self == ForwardMode.TARGET_VERIFY
            or self == ForwardMode.SPLIT_PREFILL
            or self == ForwardMode.DLLM_EXTEND
        )

    def is_context_parallel_extend(self, include_draft_extend_v2: bool = False):
        return (
            self == ForwardMode.EXTEND
            or self == ForwardMode.MIXED
            or (
                self == ForwardMode.DRAFT_EXTEND_V2
                if include_draft_extend_v2
                else False
            )
        )

    def is_decode(self):
        return self == ForwardMode.DECODE

    def is_mixed(self):
        return self == ForwardMode.MIXED

    def is_idle(self):
        return self == ForwardMode.IDLE

    def is_decode_or_idle(self):
        return self == ForwardMode.DECODE or self == ForwardMode.IDLE

    def is_target_verify(self):
        return self == ForwardMode.TARGET_VERIFY

    def is_draft_extend_v2(self):
        # For fixed shape logits output in eagle v2 worker
        return self == ForwardMode.DRAFT_EXTEND_V2

    def is_extend_or_draft_extend_or_mixed(self, include_draft_extend_v2: bool = False):
        return (
            self == ForwardMode.EXTEND
            or self == ForwardMode.MIXED
            or self == ForwardMode.SPLIT_PREFILL
            or (include_draft_extend_v2 and self == ForwardMode.DRAFT_EXTEND_V2)
        )

    def is_cuda_graph(self):
        return (
            self == ForwardMode.DECODE
            or self == ForwardMode.TARGET_VERIFY
            or self == ForwardMode.IDLE
            or self == ForwardMode.DLLM_EXTEND
        )

    def is_cpu_graph(self):
        return self == ForwardMode.DECODE

    def is_dllm_extend(self):
        return self == ForwardMode.DLLM_EXTEND

    def is_split_prefill(self):
        return self == ForwardMode.SPLIT_PREFILL

    def is_extend_without_speculative(self):
        return self.is_extend() and not self.is_target_verify()

    def is_prebuilt(self):
        return self == ForwardMode.PREBUILT

    def is_dllm_extend(self):
        return self == ForwardMode.DLLM_EXTEND


@total_ordering
class CaptureHiddenMode(IntEnum):
    # Do not capture anything.
    NULL = 0
    # Capture a hidden state of the last token.
    LAST = 1
    # Capture hidden states of all tokens.
    FULL = 2

    def need_capture(self):
        return self != CaptureHiddenMode.NULL

    def is_full(self):
        return self == CaptureHiddenMode.FULL

    def is_last(self):
        return self == CaptureHiddenMode.LAST

    def __lt__(self, other):
        return self.value < other.value


def get_server_return_hidden_states_mode() -> CaptureHiddenMode:
    features = get_exec().features
    mode = features.return_hidden_states_mode
    if mode == "last":
        return CaptureHiddenMode.LAST
    if mode == "full" or features.enable_return_hidden_states:
        return CaptureHiddenMode.FULL
    return CaptureHiddenMode.NULL


def get_required_capture_hidden_mode(
    capture_hidden_mode: CaptureHiddenMode,
    spec_info: Optional[SpecInput],
) -> CaptureHiddenMode:
    spec_capture_hidden_mode = (
        getattr(spec_info, "capture_hidden_mode", None) or CaptureHiddenMode.NULL
    )
    return max(capture_hidden_mode, spec_capture_hidden_mode)


def _attn_tp_local_shard_bounds(
    num_tokens_per_dp: int, *, sharded: bool
) -> Tuple[int, int]:
    """(tokens_per_rank, rank_offset) of this attn-TP rank's slice of the sequence.

    A replicated (non-sharded) forward keeps the full range on every rank.
    """
    if not sharded:
        return num_tokens_per_dp, 0
    parallel = get_parallel()
    tokens_per_rank = num_tokens_per_dp // parallel.attn_tp_size
    return tokens_per_rank, tokens_per_rank * parallel.attn_tp_rank


def compute_local_num_token_non_padded(
    global_num_token_non_padded: torch.Tensor,
    num_tokens_per_dp: int,
    *,
    sharded: bool,
) -> torch.Tensor:
    """Compute local non-padded token count for this attention-TP rank.

    Converts a global count (across all TP ranks) to a local count for this rank.
    The "global" scope is within the current DP rank; DP is handled via num_tokens_per_dp.

    ``num_tokens_per_dp`` is the padded bucket width for the DP group, so each rank
    owns a contiguous ``chunk = num_tokens_per_dp // attn_tp_size`` slice: the local
    count is ``clamp(global - chunk * attn_tp_rank, 0, chunk)``. The padded bucket
    (not ``ceil(real / attn_tp_size)``) sets the chunk, so a trailing rank can own
    zero real tokens. ``sharded`` False returns the global count unchanged
    (replicated).
    """
    tokens_per_rank, rank_offset = _attn_tp_local_shard_bounds(
        num_tokens_per_dp, sharded=sharded
    )
    return torch.clamp(
        global_num_token_non_padded - rank_offset,
        0,
        tokens_per_rank,
    )


def compute_local_num_token_non_padded_cpu(
    global_num_token_non_padded: int,
    num_tokens_per_dp: int,
    *,
    sharded: bool,
) -> int:
    """Int-scalar twin of ``compute_local_num_token_non_padded`` for replay-time
    hooks that hold the global count as a host int."""
    tokens_per_rank, rank_offset = _attn_tp_local_shard_bounds(
        num_tokens_per_dp, sharded=sharded
    )
    return min(max(global_num_token_non_padded - rank_offset, 0), tokens_per_rank)


def prefill_graph_tolerates_sum_len() -> bool:
    """Whether MegaMoE may replay prefill graphs with per-rank SUM_LEN buckets.

    The graph body is captured with MAX_LEN geometry, so a graph that recorded
    a DP gather/scatter only replays correctly when every rank uses one bucket.
    """
    from sglang.srt.layers.attention.dsa.utils import is_dsa_enable_prefill_cp
    from sglang.srt.layers.cp.utils import is_mla_cp_enabled
    from sglang.srt.layers.moe.utils import get_moe_a2a_backend

    if not get_moe_a2a_backend().is_megamoe():
        return False
    if get_flags().dp.prefill_graph_has_dp_gather:
        return False
    return not (is_dsa_enable_prefill_cp() or is_mla_cp_enabled())


@dataclass
class DSV4OutCacheLoc:
    """Per-forward-pass KV cache allocation for DeepSeek-V4 on NPU.

    Bundles slot indices for full/SWA pools and the two compressed-KV pools
    (C4/C128). Compressor state uses fixed ring storage and explicit
    ``state_loc`` metadata, so it is not part of the token-allocation bundle.
    Populated by the NPU V4 allocator (DSV4NPUTokenToKVPoolAllocator) when
    the model is DeepSeek-V4 on NPU; left as ``None`` on ForwardBatch
    otherwise.

    All fields are token-level slot ids in their respective pools (NOT page
    ids). Attention backends convert to page ids via ``// page_size`` when
    constructing PA_ND block tables.

    """

    out_full_loc: torch.Tensor
    out_swa_loc: torch.Tensor
    out_c4_loc: torch.Tensor
    out_c128_loc: torch.Tensor


@dataclass
class NgramEmbeddingInfo:
    """Ngram embedding state for LongCat models."""

    token_table: torch.Tensor
    column_starts: torch.Tensor
    req_lens: torch.Tensor
    out_column_starts: torch.Tensor
    out_req_lens: torch.Tensor
    # Mask marking chunked (not-yet-finished) prefill requests whose sampled
    # pseudo next-token must NOT be written into the token table.
    skip_token_table_update: Optional[torch.Tensor] = None

    @classmethod
    def create(
        cls,
        token_table: torch.Tensor,
        batch_size: int,
        device: torch.device,
        column_starts=None,
        req_lens=None,
        skip_token_table_update=None,
    ) -> NgramEmbeddingInfo:
        info = cls(
            token_table=token_table,
            column_starts=torch.empty(batch_size, dtype=torch.int32, device=device),
            req_lens=torch.empty(batch_size, dtype=torch.int32, device=device),
            out_column_starts=torch.empty(batch_size, dtype=torch.int32, device=device),
            out_req_lens=torch.empty(batch_size, dtype=torch.int32, device=device),
            skip_token_table_update=skip_token_table_update,
        )
        if column_starts is not None:
            info.column_starts[:] = column_starts
        if req_lens is not None:
            info.req_lens[:] = req_lens
        return info

    def slice(self, bs: int) -> NgramEmbeddingInfo:
        return NgramEmbeddingInfo(
            token_table=self.token_table,
            column_starts=self.column_starts[:bs],
            req_lens=self.req_lens[:bs],
            out_column_starts=self.out_column_starts[:bs],
            out_req_lens=self.out_req_lens[:bs],
            skip_token_table_update=(
                self.skip_token_table_update[:bs]
                if self.skip_token_table_update is not None
                else None
            ),
        )


@dataclass
class ForwardBatch(ForwardBatchDeepSeekMHAMixin):
    """Store all inputs of a forward pass."""

    # === Required core inputs (no default; input_ids / req_pool_indices / seq_lens / out_cache_loc are borrowed from ScheduleBatch) ===
    # The forward mode
    forward_mode: ForwardMode
    # The batch size
    batch_size: int
    # The input ids
    input_ids: torch.Tensor
    # The indices of requests in the req_to_token_pool
    req_pool_indices: torch.Tensor
    # The sequence length
    seq_lens: torch.Tensor
    # The indices of output tokens in the token_to_kv_pool
    out_cache_loc: torch.Tensor
    # The sum of all sequence lengths
    seq_lens_sum: int

    # Allocator-global output slots before NPU DCP localizes ``out_cache_loc``.
    # DSA's replicated indexer cache uses the global slot identity.
    origin_out_cache_loc: Optional[torch.Tensor] = None

    # === Borrowed from ScheduleBatch: GPU tensors (cross-stream; clone targets for stream isolation) ===
    # FIXME(lsyin): these are currently aliased by reference from ScheduleBatch. Once
    # they are cloned/relayed into FB-owned copies at the boundary, move them out of
    # "Borrowed" into a dedicated "Forward-resolved snapshot" group.
    # The original sequence length without being chunked. Qwen-1M related.
    orig_seq_lens: Optional[torch.Tensor] = None

    # This iteration's KV ids, translated once per sub-pool (`KVLocPlan`).
    # Every forward of the iteration holds the same plan; `out_cache_loc` is
    # its write window in the full-attention ids this runner's pool indexes,
    # and a backend that writes another sub-pool asks the plan for its ids
    # (`KVIndexTranslator.write_ids`).
    kv_loc_plan: Optional[KVLocPlan] = None
    # The part of the plan's window this forward writes (None: all of it).
    kv_loc_cols: Optional[Cols] = None
    # The same write ids in the virtual space when `out_cache_loc` holds
    # translated ones (None on a pool that indexes virtual ids), for the
    # scheduler's bookkeeping: lazy compaction's in-flight write set, TBO's
    # split, state capture.
    out_cache_loc_virtual: Optional[torch.Tensor] = None
    # DSV4-NPU only: per-pool slot bundle from DSV4NPUTokenToKVPoolAllocator,
    # consumed by the Ascend backend for PA_ND block tables. None elsewhere.
    out_cache_loc_dsv4: Optional[DSV4OutCacheLoc] = None
    # Whether `out_cache_loc` holds physical ids: set by `KVLocPlan.bind`.
    out_cache_loc_is_physical: bool = False
    # The indices to track mamba state with
    mamba_track_indices: Optional[torch.Tensor] = None  # shape: [b], int64
    # The mask to track mamba state if needed
    mamba_track_mask: Optional[torch.Tensor] = None  # shape: [b], bool
    # The seqlens to track mamba state if masked, prefill only.
    mamba_track_seqlens: Optional[torch.Tensor] = None  # shape: [b], int64
    mamba_prefill_track_mask_cpu: Optional[List[bool]] = None
    mamba_track_seqlens_cpu: Optional[List[int]] = None
    # Deferred mamba init ops: COW pairs and clear indices (performed on forward stream)
    mamba_cow_src_indices: Optional[torch.Tensor] = None
    mamba_cow_dst_indices: Optional[torch.Tensor] = None
    mamba_clear_indices: Optional[torch.Tensor] = None

    # For input embeddings
    input_embeds: Optional[torch.Tensor] = None
    dllm_input_preparation_state: Optional[torch.Tensor] = None
    # For token embedding overrides (sparse replacement at specific positions)
    replace_embeds: Optional[torch.Tensor] = None
    replace_positions: Optional[torch.Tensor] = None

    # For cross-encoder model
    token_type_ids: Optional[torch.Tensor] = None

    # Encoder-decoder device tensors
    encoder_lens: Optional[torch.Tensor] = None
    encoder_out_cache_loc: Optional[torch.Tensor] = None

    # === Borrowed from ScheduleBatch: config / flags (by-value) ===
    # For logprob
    return_logprob: bool = False
    # Whether this batch is prefill-only (no token generation needed)
    is_prefill_only: bool = False
    spec_algorithm: SpeculativeAlgorithm = None
    # For matryoshka embeddings
    dimensions: Optional[list[int]] = None
    # Whether to return pooled hidden states (pre-head transformer output)
    return_pooled_hidden_states: bool = False

    # For DP attention
    is_extend_in_batch: bool = False
    dp_spec_prefill_coordination_applied: bool = False
    can_run_decode_cuda_graph: bool = False
    # Draft-only companion to the generic DP decode graph vote.
    can_run_dp_draft_cuda_graph: bool = False
    can_run_dp_prefill_cuda_graph: bool = False
    dp_prefill_cuda_graph_max_prefix_len: int = 0
    global_forward_mode: Optional[ForwardMode] = None

    # Current layer-stack invocation; each TBO child owns a separate stream.
    residual_stream: Optional[ResidualStream] = None

    # For two-batch overlap
    tbo_split_seq_index: Optional[int] = None

    # === Borrowed from ScheduleBatch: host metadata (CPU lists / mirrors) ===
    # Optional seq_lens on cpu (CPU mirror of seq_lens)
    seq_lens_cpu: Optional[torch.Tensor] = None
    # Fresh only for non-speculative extend; speculative modes use device slots.
    req_pool_indices_cpu: Optional[torch.Tensor] = None

    # For logprob
    top_logprobs_nums: Optional[List[int]] = None
    token_ids_logprobs: Optional[List[List[int]]] = None

    # For multimodal
    mm_inputs: Optional[List[MultimodalInputs]] = None
    mm_token_modalities: Optional[torch.Tensor] = None
    multi_gate_indices: Optional[Tuple[torch.Tensor, torch.Tensor]] = None

    # Encoder-decoder host fields
    encoder_cached: Optional[List[bool]] = None
    encoder_lens_cpu: Optional[List[int]] = None

    # Pre-computed delimiter indices for multi-item scoring (CPU tensors, one per request)
    multi_item_delimiter_indices: Optional[List[torch.Tensor]] = None

    # Setwise pooling readout positions (CPU tensors, one per request)
    token_indices_to_pool: Optional[List[torch.Tensor]] = None

    # === Borrowed from ScheduleBatch: compound (carry their own device tensors) ===
    # Sampling info
    sampling_info: SamplingBatchInfo = None
    # Speculative decoding
    spec_info: Optional[SpecInput] = None

    # === Derived from ScheduleBatch.reqs ===
    # For LoRA
    lora_ids: Optional[List[str]] = None
    # For dumper: request IDs for cross-step sequence tracking
    rids: Optional[List[str]] = None

    # === Per-forward overrides passed explicitly to init_new ===
    capture_hidden_mode: CaptureHiddenMode = None
    # CUDA-graph runners may capture only the transformer body and execute the
    # logits processor eagerly after replay.
    defer_logits_to_eager: bool = False
    # For hidden states before normal
    return_hidden_states_before_norm: bool = False

    # Gate for reusing the first MTP draft step's indexer topk across steps;
    # the carried topk lives on spec_info (see EagleDraftInput.dsa_topk_indices).
    reuse_dsa_topk_indices: Optional[bool] = False

    minimax_m3_precached_sparse_layers: Optional[Set[int]] = None

    # === Forward-derived (built in init_new on the forward stream; FB-owned) ===
    # Position information
    positions: torch.Tensor = None

    # For extend
    extend_num_tokens: Optional[int] = None
    # 4-mode step: tokens contributed by VERIFY rows at the tail (see mix_with_verify).
    mixed_verify_tokens: int = 0
    extend_seq_lens: Optional[torch.Tensor] = None
    extend_prefix_lens: Optional[torch.Tensor] = None
    extend_start_loc: Optional[torch.Tensor] = None
    extend_prefix_lens_cpu: Optional[List[int]] = None
    extend_seq_lens_cpu: Optional[List[int]] = None
    extend_logprob_start_lens_cpu: Optional[List[int]] = None
    extend_input_logprob_token_ids_gpu: Optional[torch.Tensor] = None

    # For DP attention (MLP sync sizes)
    original_global_num_tokens_cpu: Optional[List[int]] = None
    _original_batch_size: Optional[int] = None
    _original_forward_mode: Optional[ForwardMode] = None
    _original_num_tokens: Optional[int] = None
    global_num_tokens_cpu: Optional[List[int]] = None
    global_num_tokens_gpu: Optional[torch.Tensor] = None
    # Has to be None when cuda graph is captured.
    global_num_tokens_for_logprob_cpu: Optional[List[int]] = None
    global_num_tokens_for_logprob_gpu: Optional[torch.Tensor] = None

    # Real (non-padding) token count, held at two scopes whose meaning never
    # changes once set:
    #   GLOBAL — the real-token count across the attn-TP group before sharding.
    #     global_num_token_non_padded      GPU int32 scalar. The invariant source
    #                                      the eager forward and the cuda-graph
    #                                      registry localize from on each forward /
    #                                      replay. Present only when
    #                                      enable_num_token_non_padded()
    #                                      (moe_ep_size > 1).
    #     global_num_token_non_padded_cpu  host int. Host-side attention/backend
    #                                      slices read it directly; the prefill
    #                                      graph registry derives its per-rank GPU
    #                                      scalar from it.
    #   LOCAL — this attn-TP rank's owned count after sharding.
    #     num_token_non_padded             GPU int32 scalar, derived from
    #                                      global_num_token_non_padded (see
    #                                      compute_local_num_token_non_padded). The
    #                                      MoE topk kernel masks padded rows with
    #                                      it; replicated forwards keep the full
    #                                      count. Left None until localized (eager
    #                                      prep / graph replay). Present only when
    #                                      enable_num_token_non_padded().
    global_num_token_non_padded: Optional[torch.Tensor] = None  # scalar, GLOBAL
    global_num_token_non_padded_cpu: int = None  # host int, GLOBAL
    num_token_non_padded: Optional[torch.Tensor] = None  # scalar, LOCAL (derived)

    # Whether this forward's sequence is sharded across the attn-TP group (SP on)
    # vs. replicated; stamped per forward, defaults to replicated.
    attn_tp_sequence_sharded: bool = False

    # === Runtime-filled (set during the forward pass / cuda graph / managers; not at construction) ===
    # Preallocated piecewise-graph attention output, set by RadixAttention.
    _attn_output: Optional[torch.Tensor] = None

    # Decode-graph-owned destination for AuxHiddenStatePacker; None when eager.
    aux_hidden_states_buffer: Optional[torch.Tensor] = None

    # Prefill body-CUDA-graph context limit. Attention backends that allocate
    # context-shaped metadata use this fixed maximum instead of deriving a
    # shape from the live batch. None preserves eager/default graph behavior.
    max_seq_len_override: Optional[int] = None

    # For logits and logprobs post processing
    next_token_logits_buffer: torch.Tensor = None
    temperature: torch.Tensor = None
    top_p: torch.Tensor = None

    # For split prefill
    # intermediate values for split prefill
    hidden_states: torch.Tensor = None
    residual: torch.Tensor = None
    model_specific_states: Dict[str, any] = None
    # current split index of layer
    split_index: int = 0

    # For multimodal
    mm_input_embeds: Optional[torch.Tensor] = None

    # Encoder-decoder cross-attention mask
    cross_attention_custom_mask: Optional[torch.Tensor] = None

    # For DP attention (padding / local info)
    dp_padding_mode: Optional[DpPaddingMode] = None
    # for extend, local start pos and num tokens is different in logits processor
    # this will be computed in get_dp_local_info
    # this will be recomputed in LogitsMetadata.from_forward_batch
    dp_local_start_pos: Optional[torch.Tensor] = None  # cached info at runtime
    dp_local_num_tokens: Optional[torch.Tensor] = None  # cached info at runtime
    global_dp_buffer_len: Optional[int] = None
    # global_num_tokens_cpu as published for the DP gather: attn-TP aligned and,
    # under MAX_LEN, padded to the max. None when the raw list already is.
    global_num_tokens_padded_cpu: Optional[List[int]] = None

    # For Qwen2-VL
    mrope_positions: torch.Tensor = None

    # For two-batch overlap
    tbo_parent_token_range: Optional[Tuple[int, int]] = None
    tbo_padded_len: Optional[int] = None
    tbo_children: Optional[List[ForwardBatch]] = None

    attn_cp_metadata: Optional[BaseContextParallelMetadata] = None

    # For decode context parallel.
    # NOTE: DecodeContextParallelMetadata is imported under TYPE_CHECKING only (see the
    # import block above) — available for annotations but NOT bound at runtime in this
    # module. Import it from sglang.srt.layers.dcp.metadata if a runtime use is added.
    attn_dcp_metadata: Optional[DecodeContextParallelMetadata] = None

    # Decode context parallel KV write mask.
    dcp_kv_mask: Optional[torch.Tensor] = None

    # For ngram embedding
    ngram_embedding_info: Optional[NgramEmbeddingInfo] = None
    encoder_swa_replay: bool = False

    # DeepSeek-V4.1 engram, extend only: the n - 1 tokens before each request's
    # first extend token, oldest first, [bs, n - 1] int32 (see EngramHasher).
    engram_history: Optional[torch.Tensor] = None

    # For dumper: int-hashed request / bootstrap-room IDs (derived from rids)
    rids_int: Optional[torch.Tensor] = None
    bootstrap_room_ids_int: Optional[torch.Tensor] = None

    # kv-canary token-id validator snapshot
    req_all_ids_flat: Optional[torch.Tensor] = None
    req_all_ids_lens: Optional[torch.Tensor] = None

    # Attention planning state. True iff attention metadata for this batch has
    # already been planned outside ModelRunner.forward (multi-step draft
    # pre-plan, plan-stream load_batch, hand-built spec batches), so the
    # forward path must not plan again. Only such pre-planners may set this —
    # ModelRunner / graph runners never mark after their own planning. The
    # marker is only valid for the planning regime (backend set) it was set
    # under; a fresh batch from init_new always starts unplanned.
    forward_metadata_ready: bool = False
    # Shapes the batch had when it was marked (plan record). Lets the
    # judgment predicate detect staleness when DP padding
    # (prepare_mlp_sync_batch) reshapes the batch after pre-planning.
    # Deliberately plain ints — no planner object ref on ForwardBatch
    # (runtime refs were removed from this dataclass on purpose).
    forward_metadata_planned_bs: Optional[int] = None
    forward_metadata_planned_num_tokens: Optional[int] = None
    # Whether the forward path may re-plan this batch when its shapes no
    # longer match the plan record. Only mark sites where the forward
    # path's own init_forward_metadata is equivalent to the pre-plan
    # (same backend object, no special context) may opt in; multi-step
    # wrapper plans and view-context plans must keep this False — a
    # forward-path re-plan would clobber their metadata.
    forward_metadata_replan_equivalent: bool = False

    def mark_forward_metadata_ready(self, replan_equivalent: bool = False):
        """Record that attention metadata was pre-planned for this batch.

        Call right next to the out-of-forward planning action
        (e.g. ``draft_attn_backend.init_forward_metadata(fb)`` or
        ``graph_runner.load_batch(fb)``). Records the batch shapes so
        staleness is detectable; pass ``replan_equivalent=True`` only when
        a forward-path re-plan is equivalent to the pre-plan (see field
        docs).
        """
        self.forward_metadata_ready = True
        self.forward_metadata_planned_bs = self.batch_size
        self.forward_metadata_planned_num_tokens = (
            self.input_ids.shape[0] if self.input_ids is not None else 0
        )
        self.forward_metadata_replan_equivalent = replan_equivalent

    def needs_forward_metadata_init(self) -> bool:
        """Single judgment point for whether the forward path must plan.

        A marked batch is treated as stale — and re-planned — when its
        shapes no longer match the plan record AND the mark site declared
        the re-plan safe (replan_equivalent). This runs after
        prepare_mlp_sync_batch in _forward_raw, so the re-plan sees the
        padded (final) shapes. Sites that cannot opt in (multi-step
        wrapper plans etc.) keep today's behavior: marked stays skipped,
        backends' defensive checks remain the backstop.
        """
        if not self.forward_metadata_ready:
            return True
        if not self.forward_metadata_replan_equivalent:
            return False
        num_tokens = self.input_ids.shape[0] if self.input_ids is not None else 0
        return (
            self.batch_size != self.forward_metadata_planned_bs
            or num_tokens != self.forward_metadata_planned_num_tokens
        )

    def apply_deprecated_skip_attn_backend_init(
        self, skip_attn_backend_init: Optional[bool]
    ) -> None:
        """Map the deprecated ``skip_attn_backend_init`` kwarg onto the marker.

        Mapped, not ignored: callers passing True relied on planning being
        skipped — ignoring the flag would silently re-plan and corrupt
        pre-planned multi-step draft metadata. Warns once per process (a
        module flag, not the warnings filter, so the hot decode loop never
        pays warnings.warn per forward).
        """
        if skip_attn_backend_init is None:
            return
        global _skip_attn_backend_init_warned
        if not _skip_attn_backend_init_warned:
            _skip_attn_backend_init_warned = True
            warnings.warn(
                "skip_attn_backend_init is deprecated and will be removed; "
                "pre-planners should call "
                "ForwardBatch.mark_forward_metadata_ready() after planning "
                "instead. The flag is mapped onto the marker for now.",
                DeprecationWarning,
                stacklevel=3,
            )
        if skip_attn_backend_init:
            self.mark_forward_metadata_ready()

    def init_mlp_sync_metadata(
        self,
        batch: ScheduleBatch,
        device: Union[str, torch.device],
        *,
        is_draft_worker: bool = False,
    ) -> None:
        """Populate per-rank token counts for DP-attention MLP synchronization."""
        self.dp_spec_prefill_coordination_applied = (
            batch.dp_spec_prefill_coordination_applied
        )
        global_num_tokens_source = batch.global_num_tokens
        global_num_tokens_for_logprob_source = batch.global_num_tokens_for_logprob
        # A DP spec/prefill coordination plan already wrote this phase's counts.
        if (
            is_draft_worker
            and batch.draft_global_num_tokens is not None
            and not batch.dp_spec_prefill_coordination_applied
        ):
            global_num_tokens_source = batch.draft_global_num_tokens
            global_num_tokens_for_logprob_source = (
                batch.draft_global_num_tokens_for_logprob
            )

        if global_num_tokens_source is None:
            return

        assert global_num_tokens_for_logprob_source is not None
        if (
            self.spec_info is not None
            and not batch.dp_spec_prefill_coordination_applied
        ):
            from sglang.srt.speculative.spec_info import spec_scale_global_num_tokens

            global_num_tokens, global_num_tokens_for_logprob = (
                spec_scale_global_num_tokens(
                    self.spec_info,
                    global_num_tokens_source,
                    global_num_tokens_for_logprob_source,
                )
            )
        else:
            global_num_tokens = global_num_tokens_source
            global_num_tokens_for_logprob = global_num_tokens_for_logprob_source

        self.original_global_num_tokens_cpu = global_num_tokens_source
        self.global_num_tokens_cpu = global_num_tokens
        pin_memory = is_pin_memory_available(device)
        self.global_num_tokens_gpu = torch.tensor(
            global_num_tokens, dtype=torch.int64, pin_memory=pin_memory
        ).to(device, non_blocking=True)
        self.global_num_tokens_for_logprob_cpu = global_num_tokens_for_logprob
        self.global_num_tokens_for_logprob_gpu = torch.tensor(
            global_num_tokens_for_logprob,
            dtype=torch.int64,
            pin_memory=pin_memory,
        ).to(device, non_blocking=True)
        self.can_run_decode_cuda_graph = batch.can_run_decode_cuda_graph
        self.can_run_dp_draft_cuda_graph = batch.can_run_dp_draft_cuda_graph

    @classmethod
    def init_new(
        cls,
        batch: ScheduleBatch,
        model_runner: ModelRunner,
        *,
        capture_hidden_mode: Optional[CaptureHiddenMode] = None,
        return_hidden_states_before_norm: bool,
        extend_position_info=None,
        spec_mrope_positions: Optional[torch.Tensor] = None,
        kv_loc_plan: Optional[KVLocPlan] = None,
        write_cols: Optional[Cols] = None,
    ):
        # init_new must not mutate the input ScheduleBatch; per-forward
        # overrides go through explicit keyword arguments.
        #
        # `kv_loc_plan`: the iteration's plan when this forward is one of
        # several over the same slots (a speculative iteration), `write_cols`
        # the columns of its window this forward writes. Without one, this
        # forward is its own iteration and builds the plan itself.

        # capture_hidden_mode=None means no override: capture the server's
        # configured maximum so lower-mode requests can share one graph.
        if capture_hidden_mode is None:
            request_capture_hidden_mode = (
                CaptureHiddenMode.NULL
                if model_runner.is_draft_worker
                else max(
                    batch.return_hidden_states_mode,
                    get_server_return_hidden_states_mode(),
                )
            )
            capture_hidden_mode = get_required_capture_hidden_mode(
                request_capture_hidden_mode,
                batch.spec_info,
            )

        # extend-mode-only fields are None on decode/idle
        if batch.forward_mode.is_decode_or_idle():
            extend_seq_lens = extend_prefix_lens = extend_logprob_start_lens = None
        else:
            extend_seq_lens = batch.extend_lens
            extend_prefix_lens = batch.prefix_lens
            extend_logprob_start_lens = batch.extend_logprob_start_lens

        # Mirror the grammars-population behavior previously done in
        # ScheduleBatch.get_model_worker_batch.
        if batch.sampling_info is not None:
            if batch.has_grammar:
                batch.sampling_info.grammars = [req.grammar for req in batch.reqs]
            else:
                batch.sampling_info.grammars = None

        # ScheduleBatch.sampling_info is already swapped to the forward-only
        # copy by Scheduler.run_batch under overlap mode (see save/restore
        # block there). Use it directly.
        seq_lens_cpu = batch.seq_lens_cpu

        # TODO(seq-lens-removal): the whole ScheduleBatch seq_lens family
        # (incl. seq_lens_sum) is slated for removal in favor of kv-committed
        # lengths, so this init_new-time backfill onto the ScheduleBatch is
        # tolerated for now despite the init_new-must-not-mutate-SB rule.
        if batch.seq_lens_sum is None and seq_lens_cpu is not None:
            batch.seq_lens_sum = int(seq_lens_cpu.sum())

        ret = cls(
            # Required core inputs
            forward_mode=batch.forward_mode,
            mixed_verify_tokens=getattr(batch, "mixed_verify_tokens", 0) or 0,
            batch_size=len(batch.seq_lens),
            input_ids=batch.input_ids,
            req_pool_indices=batch.req_pool_indices,
            seq_lens=batch.seq_lens,
            out_cache_loc=batch.out_cache_loc,
            seq_lens_sum=batch.seq_lens_sum,
            # Inputs aliased by reference from ScheduleBatch
            seq_lens_cpu=seq_lens_cpu,
            req_pool_indices_cpu=(
                getattr(batch, "req_pool_indices_cpu", None)
                if batch.forward_mode.is_extend_without_speculative()
                else None
            ),
            orig_seq_lens=batch.orig_seq_lens,
            out_cache_loc_dsv4=batch.out_cache_loc_dsv4,
            engram_history=batch.engram_history,
            mamba_track_indices=batch.mamba_track_indices,
            mamba_track_mask=batch.mamba_track_mask,
            mamba_track_seqlens=batch.mamba_track_seqlens,
            mamba_prefill_track_mask_cpu=(
                list(batch.mamba_prefill_track_mask_cpu)
                if batch.mamba_prefill_track_mask_cpu is not None
                else None
            ),
            mamba_track_seqlens_cpu=(
                list(batch.mamba_track_seqlens_cpu)
                if batch.mamba_track_seqlens_cpu is not None
                else None
            ),
            mamba_cow_src_indices=batch.mamba_cow_src_indices,
            mamba_cow_dst_indices=batch.mamba_cow_dst_indices,
            mamba_clear_indices=batch.mamba_clear_indices,
            encoder_lens=batch.encoder_lens,
            encoder_out_cache_loc=batch.encoder_out_cache_loc,
            input_embeds=batch.input_embeds,
            replace_embeds=batch.replace_embeds,
            replace_positions=batch.replace_positions,
            # Scalar config / flags
            return_logprob=batch.return_logprob,
            is_extend_in_batch=batch.is_extend_in_batch,
            can_run_decode_cuda_graph=batch.can_run_decode_cuda_graph,
            can_run_dp_draft_cuda_graph=batch.can_run_dp_draft_cuda_graph,
            can_run_dp_prefill_cuda_graph=batch.can_run_dp_prefill_cuda_graph,
            dp_prefill_cuda_graph_max_prefix_len=batch.dp_prefill_cuda_graph_max_prefix_len,
            global_forward_mode=batch.global_forward_mode,
            is_prefill_only=batch.is_prefill_only,
            spec_algorithm=batch.spec_algorithm,
            capture_hidden_mode=capture_hidden_mode,
            return_hidden_states_before_norm=return_hidden_states_before_norm,
            tbo_split_seq_index=batch.tbo_split_seq_index,
            # Host-side metadata
            top_logprobs_nums=batch.top_logprobs_nums,
            token_ids_logprobs=batch.token_ids_logprobs,
            mm_inputs=batch.multimodal_inputs,
            encoder_cached=batch.encoder_cached,
            encoder_lens_cpu=batch.encoder_lens_cpu,
            lora_ids=[req.lora_id for req in batch.reqs],
            rids=[req.rid for req in batch.reqs],
            # Compound (carry their own device tensors)
            sampling_info=batch.sampling_info,
            spec_info=batch.spec_info,
        )

        # ScheduleBatch and req_to_token keep allocator-global slot identities,
        # and so does the plan's window. An NPU DCP target writes rank-local
        # slots, which its translator maps the window to at `bind` below; keep
        # the global view for the consumers that read it.
        if _is_npu and get_parallel().dcp_enabled and not model_runner.is_draft_worker:
            ret.origin_out_cache_loc = ret.out_cache_loc
        ret._maybe_init_non_generation_fields(batch)

        device = model_runner.device

        ret.mm_token_modalities = _maybe_build_forward_token_modalities(
            model_runner.model_config,
            ret.mm_inputs,
            extend_prefix_lens if isinstance(extend_prefix_lens, list) else None,
            extend_seq_lens if isinstance(extend_seq_lens, list) else None,
            len(batch.input_ids) if batch.input_ids is not None else 0,
            device,
        )

        translator = model_runner.kv_index_translator
        if kv_loc_plan is None:
            kv_loc_plan = translator.own_plan(ret)
        kv_loc_plan.bind(ret, translator, cols=write_cols)

        if envs.SGLANG_KV_CANARY_ENABLE_TOKEN_ORACLE.get():
            hashed = _hash_rids_to_tensor(
                rids=[req.rid for req in batch.reqs],
                device=device,
            )
            bootstrap_room_ids = _bootstrap_rooms_to_tensor(
                bootstrap_rooms=[req.bootstrap_room for req in batch.reqs],
                device=device,
            )
            batch.sampling_info.rids_int = hashed
            batch.sampling_info.bootstrap_room_ids_int = bootstrap_room_ids
            ret.rids_int = hashed
            ret.bootstrap_room_ids_int = bootstrap_room_ids

        if envs.SGLANG_KV_CANARY_ENABLE_VERIFY_TOKEN_ASSERT.get():
            ret.req_all_ids_flat, ret.req_all_ids_lens = compute_req_all_ids_info(
                batch.reqs
            )

        if batch.extend_input_logprob_token_ids is not None:
            ret.extend_input_logprob_token_ids_gpu = (
                batch.extend_input_logprob_token_ids.to(device, non_blocking=True)
            )

        num_tokens = len(batch.input_ids) if batch.input_ids is not None else 0
        if enable_num_token_non_padded():
            ret.global_num_token_non_padded = torch.tensor(
                num_tokens,
                dtype=torch.int32,
                pin_memory=is_pin_memory_available(device),
            ).to(device, non_blocking=True)
        ret.global_num_token_non_padded_cpu = num_tokens

        ret.init_mlp_sync_metadata(
            batch, device, is_draft_worker=model_runner.is_draft_worker
        )

        if ret.forward_mode.is_idle():
            ret.positions = torch.empty((0,), dtype=torch.int64, device=device)
            if model_runner.lora_manager is not None:
                model_runner.lora_manager.reset_lora_batch()
            return ret

        # A dLLM denoise pass rewrites a fixed-size block in place. Context
        # encoding uses the ordinary EXTEND position path below.
        if batch.dllm_config is not None and ret.forward_mode.is_dllm_extend():
            block_size = batch.dllm_config.block_size
            positions_dtype = torch.int64 if is_hip() or _is_npu else torch.int32
            ret.positions = torch.tensor(
                [
                    i
                    for block_offset in (req.dllm_block_offset for req in batch.reqs)
                    for i in range(block_offset, block_offset + block_size)
                ],
                dtype=positions_dtype,
            ).to(device, non_blocking=True)
        elif (
            ret.spec_info is not None
            and getattr(ret.spec_info, "positions", None) is not None
        ):
            ret.positions = ret.spec_info.positions

        # Init position information
        if ret.forward_mode.is_decode() or ret.forward_mode.is_target_verify():
            if ret.positions is None:
                ret.positions = clamp_position(batch.seq_lens)
        else:
            if isinstance(extend_seq_lens, list):
                # Main path: H2D from host lists; populate *_cpu mirrors.
                assert isinstance(extend_prefix_lens, list)
                pin_memory = is_pin_memory_available(device)
                ret.extend_seq_lens = torch.tensor(
                    extend_seq_lens, dtype=torch.int32, pin_memory=pin_memory
                ).to(device, non_blocking=True)
                ret.extend_prefix_lens = torch.tensor(
                    extend_prefix_lens, dtype=torch.int32, pin_memory=pin_memory
                ).to(device, non_blocking=True)
                ret.extend_prefix_lens_cpu = list(extend_prefix_lens)
                ret.extend_seq_lens_cpu = list(extend_seq_lens)
            else:
                # gpu_only: device tensors handed in directly; leave *_cpu unset.
                assert isinstance(extend_seq_lens, torch.Tensor)
                ret.extend_seq_lens = extend_seq_lens
                ret.extend_prefix_lens = extend_prefix_lens
            ret.extend_num_tokens = batch.extend_num_tokens
            if extend_position_info is None:
                positions, ret.extend_start_loc = compute_position(
                    model_runner.prefill_attention_backend_str,
                    ret.extend_prefix_lens,
                    ret.extend_seq_lens,
                    ret.extend_num_tokens,
                )
            else:
                positions, ret.extend_start_loc, _ = extend_position_info
            if ret.positions is None:
                ret.positions = positions
            ret.extend_logprob_start_lens_cpu = extend_logprob_start_lens

        if model_runner.ngram_embedding_manager.enabled:
            ret._init_ngram_embedding_info(batch, device)

        if model_runner.model_config.model_is_mrope:
            if spec_mrope_positions is not None:
                ret.mrope_positions = spec_mrope_positions
            elif (
                extend_position_info is not None and extend_position_info[2] is not None
            ):
                ret.mrope_positions = extend_position_info[2]
            elif (
                ret.spec_info is not None
                and getattr(ret.spec_info, "positions", None) is not None
            ):
                ret.compute_spec_mrope_positions(model_runner, batch)
            elif ret.forward_mode.is_draft_extend_v2():
                # Draft-extend tokens are uniform text continuation; reuse the
                # spec mrope path with the input-consistent `ret.positions` rather
                # than the per-request rebuild (which mis-sizes mm requests).
                ret.compute_spec_mrope_positions(
                    model_runner, batch, seq_positions=ret.positions
                )
            else:
                ret._compute_mrope_positions(model_runner, batch)

        # Init lora information
        if (
            model_runner.lora_manager is not None
            and not model_runner.lora_manager.attn_dp_enabled
        ):
            # In the non-LoRA overlap loading case, we fetch LoRA adapters into the memory pool
            # as a batch, right before running the batch
            if not get_lora().enable_lora_overlap_loading:
                model_runner.lora_manager.fetch_new_loras(set(ret.lora_ids))

            model_runner.lora_manager.prepare_lora_batch(ret)

        parallel = get_parallel()
        if parallel.attn_dcp_size > 1 and ret.out_cache_loc is not None and is_hip():
            ret.dcp_kv_mask = (
                ret.positions % parallel.attn_dcp_size == parallel.attn_dcp_rank
            )

        return ret

    def _maybe_init_non_generation_fields(self, batch: ScheduleBatch):
        """Derive non-generation (max_new_tokens==0) forward fields from reqs.

        token_type_ids gates on presence, not is_prefill_only: a missing
        tensor makes bert/roberta silently fall back to zeros.
        """
        if self.is_prefill_only:
            if batch.model_config.is_matryoshka and any(
                r.dimensions is not None for r in batch.reqs
            ):
                self.dimensions = [
                    r.dimensions if r.dimensions else batch.model_config.hidden_size
                    for r in batch.reqs
                ]

            self.return_pooled_hidden_states = any(
                r.return_pooled_hidden_states for r in batch.reqs
            )

            # --enable-mis: every request must carry delimiter indices (the score
            # endpoint always produces MIS-structured requests; consumers index
            # without None-checking).
            if get_exec().features.enable_mis and any(
                r.multi_item_delimiter_indices is not None for r in batch.reqs
            ):
                assert all(
                    r.multi_item_delimiter_indices is not None for r in batch.reqs
                ), "MIS batch must have delimiter indices on every request"
                self.multi_item_delimiter_indices = [
                    torch.tensor(r.multi_item_delimiter_indices, dtype=torch.int64)
                    for r in batch.reqs
                ]

            # Setwise readout: pool the head AT token_indices_to_pool instead of
            # the last token. The scheduler keeps readout batches homogeneous
            # (get_new_batch_prefill), so build only when every request carries
            # the field and otherwise fall back to standard pooling.
            if batch.reqs and all(
                r.token_indices_to_pool is not None for r in batch.reqs
            ):
                self.token_indices_to_pool = [
                    torch.tensor(r.token_indices_to_pool, dtype=torch.int64)
                    for r in batch.reqs
                ]

        token_type_ids = [
            r.token_type_ids for r in batch.reqs if r.token_type_ids is not None
        ]
        if token_type_ids:
            self.token_type_ids = torch.tensor(
                sum(token_type_ids, []),
                dtype=torch.int64,
                pin_memory=is_pin_memory_available(batch.device),
            ).to(batch.device, non_blocking=True)

    def set_local_num_token_non_padded(self, *, sharded: bool) -> None:
        """Derive the LOCAL num_token_non_padded from the invariant GLOBAL scalar.

        A replicated (``sharded=False``) forward keeps the full DP-group count.
        """
        from sglang.srt.utils.common import require_mlp_tp_gather

        if self.global_num_tokens_cpu is not None:
            # DP / MLP-sync path: per-DP padded width.
            if require_mlp_tp_gather():
                num_tokens_per_dp = self.global_num_tokens_cpu[
                    dp_slot_in(self.global_num_tokens_cpu)
                ]
            else:
                num_tokens_per_dp = self.global_num_tokens_cpu[0]
        else:
            # Pure TP+SP: local input width.
            num_tokens_per_dp = self._forward_num_tokens()

        self.num_token_non_padded = compute_local_num_token_non_padded(
            global_num_token_non_padded=self.global_num_token_non_padded,
            num_tokens_per_dp=num_tokens_per_dp,
            sharded=sharded,
        )

    def moe_num_token_non_padded(self) -> Optional[torch.Tensor]:
        """Bound for masking a sparse MoE's padded rows, or None when the MoE
        input is a gathered buffer whose real rows are not a prefix of it."""
        from sglang.srt.layers.layer_boundary import batch_gathers_over_moe_cp
        from sglang.srt.layers.moe.utils import is_moe_input_scattered_across_dp_ranks

        if (
            is_moe_input_scattered_across_dp_ranks()
            and self.attn_cp_metadata is not None
            and self.forward_mode.is_context_parallel_extend()
        ):
            from sglang.srt.layers.cp.base import get_cp_strategy

            strategy = get_cp_strategy()
            if strategy is not None:
                return strategy.moe_num_token_non_padded(self)

        if self.num_token_non_padded is None:
            return None

        if is_moe_input_scattered_across_dp_ranks():
            # a2a dispatch, FP4 all-gather and dwdp all route the local shard.
            return self.num_token_non_padded
        if batch_gathers_over_moe_cp(self):
            return None
        # DSA / MLA CP all-gather across attention CP on a prefill, which leaves
        # the real rows zigzag-permuted rather than in a prefix.
        if get_parallel().attn_cp_size > 1 and self._moe_input_gathered_across_cp():
            return None
        if get_parallel().attn_dp_size != 1:
            # dp_gather concatenates one padded slot per attention-DP rank.
            return None
        # A single attention-DP group all-reduces instead of gathering, so the
        # buffer holds the whole sequence and the GLOBAL count bounds it.
        if not self.attn_tp_sequence_sharded:
            return self.num_token_non_padded
        # None under cuda-graph replay: its static batch carries no GLOBAL count.
        return self.global_num_token_non_padded

    def _moe_input_gathered_across_cp(self) -> bool:
        from sglang.srt.layers.attention.dsa.utils import dsa_use_prefill_cp
        from sglang.srt.layers.cp.utils import is_mla_cp_active

        return dsa_use_prefill_cp(self) or is_mla_cp_active(self)

    def mamba_track_aligned_lens(self) -> Optional[torch.Tensor]:
        """Tokens of this extend chunk covered by the tracked mamba state,
        floored to the mamba_cache_chunk_size boundary the scheduler snapshots at;
        the +1 that _force_track_h adds cancels under the floor.
        Sole home of this math: every side state snapshotting alongside mamba calls it.
        None means tracking is skipped for this forward:
        no mask, or a prefill CUDA-graph replay without mamba_track_seqlens.
        Masked-off rows hold garbage.
        """
        if (
            self.mamba_track_mask is None
            or self.mamba_track_seqlens is None
            or self.extend_prefix_lens is None
        ):
            return None

        chunk_size = mamba_cache_chunk_size()
        lens_to_track = self.mamba_track_seqlens - self.extend_prefix_lens
        return (lens_to_track // chunk_size) * chunk_size

    def contains_image_inputs(self) -> bool:
        if self.mm_inputs is None:
            return False
        return any(
            mm_input is not None and mm_input.contains_image_inputs()
            for mm_input in self.mm_inputs
        )

    def contains_audio_inputs(self) -> bool:
        if self.mm_inputs is None:
            return False
        return any(
            mm_input is not None and mm_input.contains_audio_inputs()
            for mm_input in self.mm_inputs
        )

    def contains_video_inputs(self) -> bool:
        if self.mm_inputs is None:
            return False
        return any(
            mm_input is not None and mm_input.contains_video_inputs()
            for mm_input in self.mm_inputs
        )

    def contains_mm_inputs(self) -> bool:
        return (
            self.contains_audio_inputs()
            or self.contains_video_inputs()
            or self.contains_image_inputs()
        )

    def _init_ngram_embedding_info(self, batch: ScheduleBatch, device: torch.device):
        if self.forward_mode.is_decode():
            column_starts, req_lens = self.seq_lens - 1, 1
        else:
            column_starts, req_lens = self.extend_prefix_lens, self.extend_seq_lens
        self.ngram_embedding_info = NgramEmbeddingInfo.create(
            batch.ne_token_table,
            self.batch_size,
            device,
            column_starts=column_starts,
            req_lens=req_lens,
            skip_token_table_update=batch.ne_skip_token_table_update,
        )

    def compute_spec_mrope_positions(
        self, model_runner: ModelRunner, batch: ScheduleBatch, seq_positions=None
    ):
        # TODO support batched deltas
        batch_size = self.seq_lens.shape[0]
        device = model_runner.device
        mm_inputs = batch.multimodal_inputs

        # target_verify / draft_decode read spec_info.positions; draft_extend
        # passes its own positions (uniform num_draft_tokens per request).
        if seq_positions is None:
            seq_positions = batch.spec_info.positions
        seq_positions = seq_positions.view(batch_size, -1)
        # Split text-only and mixed batches here because SpecV2 text-only batches can avoid an extra D2H.
        if all(mm_input is None for mm_input in mm_inputs):
            self.mrope_positions = (
                seq_positions.to(torch.int64).flatten().unsqueeze(0).repeat(3, 1)
            )
            return
        else:
            mrope_deltas = [
                (
                    torch.zeros(1, dtype=torch.int64)
                    if mm_inputs[i] is None
                    else mm_inputs[i].mrope_position_delta.squeeze(0)
                )
                for i in range(batch_size)
            ]
            mrope_delta_tensor = torch.stack(mrope_deltas, dim=0).to(device=device)
        next_input_positions = (
            (seq_positions + mrope_delta_tensor).flatten().unsqueeze(0).repeat(3, 1)
        )

        self.mrope_positions = next_input_positions

    def _expand_mrope_from_input(
        self,
        mm_input: MultimodalInputs,
        seq_len: int,
    ) -> torch.Tensor:
        # Some generation models precompute decode positions for future tokens.
        # For example, GLM-Image needs 2D spatial MRoPE positions instead of
        # sequential delta-based positions.
        # This is needed for image generation models (e.g. GlmImage) where
        # decode tokens require 2D spatial MRoPE positions, not sequential.
        if (
            mm_input.mrope_positions is not None
            and mm_input.mrope_positions.shape[1] >= seq_len
        ):
            pos = mm_input.mrope_positions[:, seq_len - 1 : seq_len]
            return pos

        # doing below compute on cpu to avoid frequent small kernels
        if mm_input.mrope_position_delta_repeated_cache is None:
            mm_input.mrope_position_delta_repeated_cache = (
                (mm_input.mrope_position_delta - 1).flatten().unsqueeze(0).repeat(3, 1)
            )
        mrope_positions = mm_input.mrope_position_delta_repeated_cache + seq_len
        return mrope_positions

    def _compute_mrope_positions(self, model_runner: ModelRunner, batch: ScheduleBatch):
        # mrope_positions shape: [3, total_seq_len]
        # The first dimension corresponds to temporal, height and width positions.
        forward_mode = self.forward_mode

        if forward_mode.is_decode():
            self._compute_mrope_positions_decode(model_runner, batch)
            return

        if not forward_mode.is_extend(include_draft_extend_v2=True):
            # Should not reach here: spec/draft_extend_v2 modes go through
            # compute_spec_mrope_positions in init_new.
            raise RuntimeError(
                f"_compute_mrope_positions called with unsupported forward_mode: {forward_mode}"
            )

        self._compute_mrope_positions_extend(model_runner, batch)

    def _compute_mrope_positions_decode(
        self, model_runner: ModelRunner, batch: ScheduleBatch
    ):
        seq_lens_cpu = self.seq_lens_cpu
        batch_size = seq_lens_cpu.shape[0]
        mm_inputs = batch.multimodal_inputs
        rl_on_policy_target = get_exec().deterministic.rl_on_policy_target
        seq_lens_int64 = self.seq_lens.to(torch.int64)

        # Some multimodal models (e.g. image generation models) provide
        # precomputed MRoPE positions. In this case, positions cannot be
        # reconstructed only from mrope_position_delta and need the original
        # per-request computation path.
        has_precomputed_mrope = any(
            mm is not None
            and mm.mrope_positions is not None
            and mm.mrope_positions.shape[1] >= seq_lens_cpu[i]
            for i, mm in enumerate(mm_inputs)
        )
        has_multimodal_input = any(mm is not None for mm in mm_inputs)

        if rl_on_policy_target is not None or not has_multimodal_input:
            # Text-only
            positions_1d = seq_lens_int64 - 1
            self.mrope_positions = positions_1d.unsqueeze(0).repeat(3, 1)
            return

        if not has_precomputed_mrope:
            # Compute all requests together to avoid per-request Python loops.
            deltas_list = [0] * batch_size
            for i, mm in enumerate(mm_inputs):
                deltas_list[i] = mm.mrope_position_delta.item() if mm is not None else 0
            deltas = torch.tensor(
                deltas_list, dtype=torch.int64, device=model_runner.device
            )
            positions_1d = (deltas - 1) + seq_lens_int64
            self.mrope_positions = positions_1d.unsqueeze(0).repeat(3, 1)
            return

        # Fallback path for models with precomputed spatial MRoPE positions.
        # These positions cannot be derived from mrope_position_delta.
        mrope_positions_list = [None] * batch_size
        for batch_idx in range(batch_size):
            mm_input = mm_inputs[batch_idx]
            if mm_input is None:
                # text only
                mrope_positions = torch.full(
                    (3, 1),
                    seq_lens_cpu[batch_idx] - 1,
                    dtype=torch.int64,
                )
            else:
                mrope_positions = self._expand_mrope_from_input(
                    mm_input, seq_lens_cpu[batch_idx]
                )
            mrope_positions_list[batch_idx] = mrope_positions

        self.mrope_positions = torch.cat(
            mrope_positions_list,
            dim=1,
        ).to(
            dtype=torch.int64,
            device=model_runner.device,
            non_blocking=True,
        )

    def _compute_mrope_positions_extend(
        self, model_runner: ModelRunner, batch: ScheduleBatch
    ):
        seq_lens_cpu = self.seq_lens_cpu
        batch_size = seq_lens_cpu.shape[0]
        mm_inputs = batch.multimodal_inputs
        rl_on_policy_target = get_exec().deterministic.rl_on_policy_target
        extend_lens = batch.extend_lens
        prefix_lens = batch.prefix_lens

        # Optimize text-only branch with torch.arange
        mrope_positions_list = [None] * batch_size
        for batch_idx in range(batch_size):
            mm_input = mm_inputs[batch_idx]
            extend_seq_len = extend_lens[batch_idx]
            extend_prefix_len = prefix_lens[batch_idx]
            if mm_input is None or rl_on_policy_target is not None:
                # text only
                mrope_positions = (
                    torch.arange(
                        extend_prefix_len,
                        extend_prefix_len + extend_seq_len,
                        dtype=torch.int64,
                    )
                    .unsqueeze(0)
                    .repeat(3, 1)
                )
            else:
                mrope_positions = mm_input.mrope_positions[
                    :,
                    extend_prefix_len : extend_prefix_len + extend_seq_len,
                ]
                if (
                    batch.reqs[batch_idx].session is not None
                    and mrope_positions.shape[1] < extend_seq_len
                ):
                    # Session history includes generated and appended text that
                    # is not covered by the saved prompt positions.
                    tail_len = extend_seq_len - mrope_positions.shape[1]
                    tail_start = extend_prefix_len + mrope_positions.shape[1]
                    text_positions = self._expand_mrope_from_input(
                        mm_input, tail_start + 1
                    ) + torch.arange(tail_len)
                    mrope_positions = torch.cat(
                        [mrope_positions, text_positions], dim=1
                    )
                elif mrope_positions.numel() == 0:
                    mrope_positions = self._expand_mrope_from_input(
                        mm_input, seq_lens_cpu[batch_idx]
                    )
            mrope_positions_list[batch_idx] = mrope_positions

        self.mrope_positions = torch.cat(
            mrope_positions_list,
            dim=1,
        ).to(dtype=torch.int64, device=model_runner.device, non_blocking=True)

    def _pad_tensor_to_size(self, tensor: torch.Tensor, size: int, *, value: int = 0):
        if value == 0:
            return torch.cat(
                [tensor, tensor.new_zeros(size - tensor.shape[0], *tensor.shape[1:])],
                dim=0,
            )
        else:
            return torch.cat(
                [
                    tensor,
                    tensor.new_full((size - tensor.shape[0], *tensor.shape[1:]), value),
                ],
                dim=0,
            )

    def prepare_mlp_sync_batch(self, model_runner: ModelRunner):
        from sglang.srt.batch_overlap.two_batch_overlap import TboForwardBatchPreparer

        assert self.global_num_tokens_cpu is not None
        assert self.global_num_tokens_for_logprob_cpu is not None

        self._original_batch_size = self.batch_size
        global_num_tokens = list(self.global_num_tokens_cpu)
        # MegaMoEv2 dispatch is rank-synchronous, so an idle rank still carries the
        # one row _run_mega_routed fabricates for it. HIP-only, False elsewhere.
        mega_moe_idle_materialize = _mega_moe_materializes_idle_rank(self)
        if mega_moe_idle_materialize:
            global_num_tokens = [1] * len(global_num_tokens)
        sync_group_size = len(global_num_tokens)
        attn_tp_size = get_parallel().attn_tp_size

        for i in range(sync_group_size):
            # make sure that the padded length is divisible by attn_tp_size because we may need reduce-scatter across attn_tp dim.
            # there is no reduce-scatter in LM logprob, so we do not need to adjust the padded length for logprob
            global_num_tokens[i] = ceil_align(global_num_tokens[i], attn_tp_size)

        dp_padding_mode = DpPaddingMode.get_dp_padding_mode(
            self.is_extend_in_batch, global_num_tokens
        )
        if _elastic_should_preserve_local_token_counts(
            model_runner=model_runner,
            dp_padding_mode=dp_padding_mode,
            global_num_tokens=global_num_tokens,
        ):
            # Joined ranks require real token counts instead of MAX_LEN padding.
            dp_padding_mode = DpPaddingMode.SUM_LEN
        # Prefill CUDA graphs require every DP rank to run the same captured
        # shape. Under SUM_LEN each rank pads to its own local token
        # count and can select a different capture bucket. This mismatches the
        # rank-coupled communication geometry: DP gather/combine uses
        # all_gather_into_tensor / reduce_scatter_tensor, while MoE backends may
        # use A2A dispatch/combine. Force MAX_LEN so every rank pads to the global
        # max and picks the same bucket.
        #
        # Larger prefills fall back to eager and keep the memory-efficient
        # SUM_LEN. global_num_tokens is identical across ranks (all-gathered),
        # so the decision is consistent cluster-wide.
        prefill_cg = get_exec().graph.cuda_graph_config.prefill
        if (
            self.can_run_dp_prefill_cuda_graph
            and self.is_extend_in_batch
            and prefill_cg.bs
            and max(global_num_tokens) <= max(prefill_cg.bs)
            and not prefill_graph_tolerates_sum_len()
        ):
            dp_padding_mode = DpPaddingMode.MAX_LEN
        if self.dp_spec_prefill_coordination_applied:
            # Preserve each rank's forward mode on coordinated steps.
            dp_padding_mode = DpPaddingMode.SUM_LEN
        self.dp_padding_mode = dp_padding_mode
        # Read once here, where dp_padding_mode is final: the idle-row branch
        # below runs after another arm may have rewritten self.forward_mode.
        materializes_dummy_extend = mega_moe_idle_materialize or (
            self.is_extend_in_batch and dp_padding_mode.is_max_len()
        )

        if dp_padding_mode.is_max_len():
            # when DP gather mode is all gather, we will use
            # all_gather_into_tensor to gather hidden states, where transferred
            # tokens should be padded to the same length. We will also use
            # reduce-scatter instead of all-reduce after MLP.
            max_num_tokens = max(global_num_tokens)
            global_num_tokens = [max_num_tokens] * sync_group_size
            buffer_len = max_num_tokens * sync_group_size
        else:
            buffer_len = sum(global_num_tokens)

        num_tokens = global_num_tokens[dp_slot_in(global_num_tokens)]

        self.attn_tp_sequence_sharded = model_runner.attn_tp_sequence_sharded(
            num_tokens
        )

        self.global_dp_buffer_len = buffer_len
        self.global_num_tokens_padded_cpu = global_num_tokens
        set_dp_buffer_len_from_batch(self)
        set_is_extend_in_batch(self.is_extend_in_batch)

        bs = self.batch_size

        if (
            self.forward_mode.is_decode()
            or self.forward_mode.is_target_verify()
            or self.forward_mode.is_draft_extend_v2()
            or self.forward_mode.is_idle()
        ):
            # TARGET_VERIFY counts as extend; hybrid-SSM verify batches keep their
            # verify layout. MTP draft workers ("*E", no mamba layer) count as hybrid.
            hybrid_ssm = mambaish_config(model_runner.model_config) is not None or (
                model_runner.is_draft_worker
                and getattr(
                    model_runner.model_config.hf_config,
                    "mtp_hybrid_override_pattern",
                    None,
                )
                is not None
            )
            if (
                hybrid_ssm
                and self.spec_info is not None
                and not self.spec_info.is_draft_input()
            ):
                if self.forward_mode.is_idle():
                    self._original_forward_mode = self.forward_mode
                    self.forward_mode = ForwardMode.TARGET_VERIFY
                # Invert the spec_scale_global_num_tokens scaling.
                bs = self.batch_size = num_tokens // self.spec_info.num_tokens_per_req
            elif materializes_dummy_extend:
                self._original_forward_mode = self.forward_mode
                self.forward_mode = ForwardMode.EXTEND
                # Fabricate a single dummy request covering num_tokens for an
                # empty (idle) rank. Ranks reach this once MAX_LEN is forced for
                # the prefill breakable CUDA graph (idle + prefill), which needs
                # every DP rank to run the same captured shape. The `else`
                # branch handles decode rows padded to a 1-token extend.
                if self.seq_lens.shape[0] == 0:
                    dev = self.seq_lens.device
                    self.extend_num_tokens = num_tokens
                    self.extend_seq_lens = torch.tensor(
                        [num_tokens], dtype=torch.int32, device=dev
                    )
                    self.extend_prefix_lens = torch.zeros(
                        1, dtype=self.seq_lens.dtype, device=dev
                    )
                    self.extend_start_loc = torch.zeros(
                        1, dtype=torch.int32, device=dev
                    )
                    self.seq_lens = torch.tensor(
                        [num_tokens], dtype=self.seq_lens.dtype, device=dev
                    )
                    # orig_seq_lens is not padded by _pad_inputs_to_size, so
                    # fabricate it to match the dummy request (the breakable
                    # prefill CUDA graph runner reads it).
                    self.orig_seq_lens = torch.tensor(
                        [num_tokens], dtype=self.orig_seq_lens.dtype, device=dev
                    )
                    self.seq_lens_sum = int(num_tokens)
                    if self.seq_lens_cpu is not None:
                        self.seq_lens_cpu = torch.tensor(
                            [num_tokens], dtype=self.seq_lens.dtype
                        )
                    self.extend_prefix_lens_cpu = [0]
                    self.extend_seq_lens_cpu = [int(num_tokens)]
                    self.extend_logprob_start_lens_cpu = [0]
                    bs = self.batch_size = 1
                    # Keep idle fabricated rows masked. Bump the GLOBAL scalar;
                    # the LOCAL count is derived from it downstream.
                    # (global_num_token_non_padded is None unless
                    # moe_ep_size > 1.)
                    if self._original_forward_mode.is_idle():
                        if self.global_num_token_non_padded is not None:
                            self.global_num_token_non_padded.fill_(0)
                        self.global_num_token_non_padded_cpu = 0
                    else:
                        if self.global_num_token_non_padded is not None:
                            self.global_num_token_non_padded.fill_(num_tokens)
                        self.global_num_token_non_padded_cpu = num_tokens
                else:
                    self.extend_num_tokens = bs
                    self.extend_seq_lens = torch.full_like(self.seq_lens, 1)
                    self.extend_prefix_lens = self.seq_lens - 1
                    self.extend_start_loc = torch.arange(
                        bs, dtype=torch.int32, device=self.seq_lens.device
                    )
                    self.extend_prefix_lens_cpu = self.extend_prefix_lens.cpu().tolist()
                    self.extend_seq_lens_cpu = self.extend_seq_lens.cpu().tolist()
                    self.extend_logprob_start_lens_cpu = self.extend_prefix_lens_cpu
            else:
                if self.spec_info is not None:
                    # Invert the spec_scale_global_num_tokens scaling.
                    bs = self.batch_size = (
                        num_tokens // self.spec_info.num_tokens_per_req
                    )
                else:
                    bs = self.batch_size = num_tokens
        elif self.forward_mode.is_extend():
            self.extend_num_tokens = num_tokens

        # padding
        self._pad_inputs_to_size(model_runner, num_tokens, bs)
        self.global_num_tokens_cpu = global_num_tokens
        self.use_pin_memory = not _is_cpu
        global_num_tokens_pinned = torch.tensor(
            global_num_tokens, pin_memory=self.use_pin_memory
        )
        self.global_num_tokens_gpu.copy_(
            global_num_tokens_pinned, non_blocking=self.use_pin_memory
        )

        TboForwardBatchPreparer.prepare(
            batch=self, is_draft_worker=model_runner.is_draft_worker
        )
        # TODO: The following is added to make sure sub-batch input_ids are padded
        # to the multiple of attn_tp_size. It can likely be removed after this
        # function is refactored and merged into the Scheduler.
        if self.tbo_children:
            for child in self.tbo_children:
                child._pad_inputs_to_size(
                    model_runner, child.tbo_padded_len, child.batch_size
                )

    def _pad_inputs_to_size(self, model_runner: ModelRunner, num_tokens, bs):
        # padding
        self._original_num_tokens = self.positions.shape[0]
        self.input_ids = self._pad_tensor_to_size(self.input_ids, num_tokens)
        if self.input_embeds is not None:
            # Keep token-aligned inputs consistent after padding.
            self.input_embeds = self._pad_tensor_to_size(self.input_embeds, num_tokens)
        if (
            self.mm_input_embeds is not None
            and self.mm_input_embeds.shape[0] < num_tokens
        ):
            # A draft reads the target's mm embeds in place of its input_ids.
            self.mm_input_embeds = self._pad_tensor_to_size(
                self.mm_input_embeds, num_tokens
            )
        self.req_pool_indices = self._pad_tensor_to_size(self.req_pool_indices, bs)
        if self.req_pool_indices_cpu is not None:
            self.req_pool_indices_cpu = self._pad_tensor_to_size(
                self.req_pool_indices_cpu, bs
            )
        if self.lora_ids is not None:
            self.lora_ids.extend((bs - len(self.lora_ids)) * [None])

        seq_len_fill_value = (
            model_runner.attn_backend.get_cpu_graph_seq_len_fill_value()
            if _is_cpu
            else model_runner.attn_backend.get_cuda_graph_seq_len_fill_value()
        )
        # Keep gpu_only batches sync-free: leave seq_lens_sum None and let the
        # attention backend over-allocate from an upper bound (see #26738).
        if self.seq_lens_sum is not None:
            self.seq_lens_sum = self.seq_lens_sum + seq_len_fill_value * (
                bs - self.seq_lens.shape[0]
            )
        self.seq_lens = self._pad_tensor_to_size(
            self.seq_lens, bs, value=seq_len_fill_value
        )
        if self.seq_lens_cpu is not None:
            self.seq_lens_cpu = self._pad_tensor_to_size(
                self.seq_lens_cpu, bs, value=seq_len_fill_value
            )

        self.out_cache_loc = self._pad_tensor_to_size(self.out_cache_loc, num_tokens)
        if self.origin_out_cache_loc is not None:
            self.origin_out_cache_loc = self._pad_tensor_to_size(
                self.origin_out_cache_loc, num_tokens
            )
        if self.encoder_lens is not None:
            self.encoder_lens = self._pad_tensor_to_size(self.encoder_lens, bs)
        self.positions = self._pad_tensor_to_size(self.positions, num_tokens)
        if self.mamba_track_indices is not None:
            self.mamba_track_indices = self._pad_tensor_to_size(
                self.mamba_track_indices, bs
            )
        if self.mamba_prefill_track_mask_cpu is not None:
            self.mamba_prefill_track_mask_cpu = self.mamba_prefill_track_mask_cpu + [
                False
            ] * (bs - len(self.mamba_prefill_track_mask_cpu))
        if self.mamba_track_seqlens_cpu is not None:
            self.mamba_track_seqlens_cpu = self.mamba_track_seqlens_cpu + [0] * (
                bs - len(self.mamba_track_seqlens_cpu)
            )
        if self.mamba_track_mask is not None:
            self.mamba_track_mask = self._pad_tensor_to_size(self.mamba_track_mask, bs)
        if self.mamba_track_seqlens is not None:
            self.mamba_track_seqlens = self._pad_tensor_to_size(
                self.mamba_track_seqlens, bs
            )

        if self.mrope_positions is not None:
            self.mrope_positions = torch.cat(
                [
                    self.mrope_positions,
                    self.mrope_positions.new_zeros(
                        3, num_tokens - self.mrope_positions.shape[1]
                    ),
                ],
                dim=1,
            )

        # Draft-extend padding uses the fixed per-request token width.
        dummy_extend_len = 0
        if (
            self.spec_info is not None
            and self.forward_mode.is_draft_extend_v2()
            and self.spec_info.num_tokens_per_req > 0
        ):
            dummy_extend_len = self.spec_info.num_tokens_per_req

        if self.extend_seq_lens is not None:
            self.extend_seq_lens = self._pad_tensor_to_size(
                self.extend_seq_lens, bs, value=dummy_extend_len
            )
        if self.extend_prefix_lens is not None:
            self.extend_prefix_lens = self._pad_tensor_to_size(
                self.extend_prefix_lens, bs
            )
        if self.extend_seq_lens_cpu is not None:
            self.extend_seq_lens_cpu.extend(
                [dummy_extend_len] * (bs - len(self.extend_seq_lens_cpu))
            )
        if self.extend_prefix_lens_cpu is not None:
            self.extend_prefix_lens_cpu.extend(
                [0] * (bs - len(self.extend_prefix_lens_cpu))
            )
        if self.extend_logprob_start_lens_cpu is not None:
            self.extend_logprob_start_lens_cpu.extend(
                [0] * (bs - len(self.extend_logprob_start_lens_cpu))
            )

        if self.rids_int is not None:
            self.rids_int = self._pad_tensor_to_size(self.rids_int, bs)
            if self.sampling_info is not None:
                self.sampling_info.rids_int = self.rids_int
        if self.bootstrap_room_ids_int is not None:
            self.bootstrap_room_ids_int = self._pad_tensor_to_size(
                self.bootstrap_room_ids_int, bs, value=-1
            )
            if self.sampling_info is not None:
                self.sampling_info.bootstrap_room_ids_int = self.bootstrap_room_ids_int

        if self.spec_info is not None and self.spec_info.is_draft_input():
            spec_info = self.spec_info
            self.output_cache_loc_backup = self.out_cache_loc
            self.hidden_states_backup = spec_info.hidden_states
            # Draft input types carry different subsets of the shared fields.
            if getattr(spec_info, "topk_p", None) is not None:
                spec_info.topk_p = self._pad_tensor_to_size(spec_info.topk_p, bs)
            if getattr(spec_info, "topk_index", None) is not None:
                spec_info.topk_index = self._pad_tensor_to_size(
                    spec_info.topk_index, bs
                )
            if spec_info.hidden_states is not None:
                spec_info.hidden_states = self._pad_tensor_to_size(
                    spec_info.hidden_states, num_tokens
                )
            spec_info.pad_batch(self._pad_tensor_to_size, bs)

    def _forward_num_tokens(self) -> int:
        """Token width of this forward (``input_embeds`` over ``input_ids``), as
        the model counts it for its SP gate."""
        if self.input_embeds is not None:
            return self.input_embeds.shape[0]
        return self.input_ids.shape[0]

    def prepare_attn_tp_scatter_input(self, model_runner: ModelRunner):
        from sglang.srt.layers.layer_boundary import get_attn_tp_context

        # Pure TP+SP has no MLP-sync pass, so stamp the decision here.
        self.attn_tp_sequence_sharded = model_runner.attn_tp_sequence_sharded(
            self._forward_num_tokens()
        )

        attn_tp_context = get_attn_tp_context()
        input_scattered = attn_tp_context.use_input_scattered(self)
        if not input_scattered:
            return
        assert self.forward_mode.is_extend()
        tokens = self.input_ids.shape[0]
        rank_size = get_parallel().tp_size
        tokens_padded = (tokens + rank_size - 1) // rank_size * rank_size
        self._pad_inputs_to_size(model_runner, tokens_padded, self.batch_size)

    def post_forward_mlp_sync_batch(self, logits_output: LogitsProcessorOutput):
        if self._original_forward_mode is not None:
            self.forward_mode = self._original_forward_mode
        if self._original_batch_size is not None:
            self.batch_size = self._original_batch_size
        bs = self.batch_size

        # MLP-sync padding appended dummy rows after the real ones; slice the
        # per-request tensors back so post-forward consumers (seeded sampling,
        # ngram token-table updates) never see the padding. The draft-decode
        # branch below does the same for speculative batches.
        if self.spec_info is None and self._original_num_tokens is not None:
            self.positions = self.positions[: self._original_num_tokens]
            self.seq_lens = self.seq_lens[:bs]
            self.req_pool_indices = self.req_pool_indices[:bs]
            if self.req_pool_indices_cpu is not None:
                self.req_pool_indices_cpu = self.req_pool_indices_cpu[:bs]
            if self.seq_lens_cpu is not None:
                self.seq_lens_cpu = self.seq_lens_cpu[:bs]

        if self.spec_info is not None:
            if self.forward_mode.is_decode():  # draft
                num_tokens = self.hidden_states_backup.shape[0]
                self.positions = self.positions[:num_tokens]
                self.seq_lens = self.seq_lens[:bs]
                self.req_pool_indices = self.req_pool_indices[:bs]
                if self.req_pool_indices_cpu is not None:
                    self.req_pool_indices_cpu = self.req_pool_indices_cpu[:bs]
                if self.seq_lens_cpu is not None:
                    self.seq_lens_cpu = self.seq_lens_cpu[:bs]
                if logits_output.next_token_logits is not None:
                    logits_output.next_token_logits = logits_output.next_token_logits[
                        :num_tokens
                    ]
                logits_output.hidden_states = logits_output.hidden_states[:num_tokens]
            elif self.forward_mode.is_target_verify():  # verify
                num_tokens = bs * self.spec_info.num_tokens_per_req
                if logits_output.next_token_logits is not None:
                    logits_output.next_token_logits = logits_output.next_token_logits[
                        :num_tokens
                    ]
                if logits_output.hidden_states is not None:
                    logits_output.hidden_states = logits_output.hidden_states[
                        :num_tokens
                    ]
            elif (
                self.spec_info.spec_input_type == SpecInputType.EAGLE_DRAFT_EXTEND
                and not self.forward_mode.is_draft_extend_v2()
            ):
                if self.spec_info.num_correct_drafts is not None:
                    self.spec_info.num_correct_drafts = (
                        self.spec_info.num_correct_drafts[:bs]
                    )
                if self.spec_info.num_accept_tokens is not None:
                    self.spec_info.num_accept_tokens = self.spec_info.num_accept_tokens[
                        :bs
                    ]
                if self.extend_seq_lens is not None:
                    self.extend_seq_lens = self.extend_seq_lens[:bs]
                if logits_output.next_token_logits is not None:
                    logits_output.next_token_logits = logits_output.next_token_logits[
                        :bs
                    ]
                if logits_output.hidden_states is not None:
                    logits_output.hidden_states = logits_output.hidden_states[:bs]
            elif self.forward_mode.is_draft_extend_v2():  # draft extend_v2
                bs = bs * self.spec_info.num_tokens_per_req
                if logits_output.next_token_logits is not None:
                    logits_output.next_token_logits = logits_output.next_token_logits[
                        :bs
                    ]
                logits_output.hidden_states = logits_output.hidden_states[:bs]
            elif self.forward_mode.is_extend() or self.forward_mode.is_idle():
                if self.forward_mode.is_idle():
                    self.positions = self.positions[:bs]
                    self.seq_lens = self.seq_lens[:bs]
                    self.req_pool_indices = self.req_pool_indices[:bs]
                    if self.seq_lens_cpu is not None:
                        self.seq_lens_cpu = self.seq_lens_cpu[:bs]
                if logits_output.next_token_logits is not None:
                    logits_output.next_token_logits = logits_output.next_token_logits[
                        :bs
                    ]
                logits_output.hidden_states = logits_output.hidden_states[:bs]

            if hasattr(self, "hidden_states_backup"):
                self.spec_info.hidden_states = self.hidden_states_backup
            if hasattr(self, "output_cache_loc_backup"):
                self.out_cache_loc = self.output_cache_loc_backup

        elif self.forward_mode.is_decode() or self.forward_mode.is_idle():
            logits_output.next_token_logits = logits_output.next_token_logits[:bs]
            if logits_output.hidden_states is not None:
                logits_output.hidden_states = logits_output.hidden_states[:bs]
        elif self.forward_mode.is_extend():
            num_tokens = self.seq_lens_sum
            logits_output.next_token_logits = logits_output.next_token_logits[
                :num_tokens
            ]
            if logits_output.hidden_states is not None:
                logits_output.hidden_states = logits_output.hidden_states[:num_tokens]

    @property
    def can_run_tbo(self):
        return self.tbo_split_seq_index is not None


def enable_num_token_non_padded():
    # Elastic joiners also need graph padding masked after joining WORLD.
    return get_parallel().moe_ep_size > 1 or world_dp_gather_enabled()


def build_inner_fb_view(
    forward_batch: ForwardBatch,
    *,
    bs: int,
    forward_mode: ForwardMode,
    encoder_lens: Optional[torch.Tensor] = None,
):
    """Build a ForwardBatch-like view for MultiStep draft wrapper dispatch.

    MultiStep draft wrappers (FlashInferMultiStepDraftBackend,
    AiterMultiStepDraftBackend, TritonMultiStepDraftBackend, etc.) need
    to dispatch to per-step inner backends'
    :py:meth:`AttentionBackend.init_forward_metadata_out_graph` with an
    overridden ``forward_mode`` (typically pinned to ``DECODE``) and
    sometimes overridden ``encoder_lens``. The result is a thin
    namespace mirroring just the fields backend init reads, avoiding
    the cost of allocating a real ``ForwardBatch``.

    ``actual_forward_mode`` carries the original runtime
    ``forward_batch.forward_mode`` (e.g., spec-decode draft) so backends
    that check it for IDLE substitution (DSV4) see the unaltered value.
    """
    from types import SimpleNamespace

    return SimpleNamespace(
        batch_size=bs,
        forward_mode=forward_mode,
        actual_forward_mode=forward_batch.forward_mode,
        input_ids=getattr(forward_batch, "input_ids", None),
        positions=getattr(forward_batch, "positions", None),
        req_pool_indices=forward_batch.req_pool_indices,
        seq_lens=forward_batch.seq_lens,
        seq_lens_sum=forward_batch.seq_lens_sum,
        seq_lens_cpu=forward_batch.seq_lens_cpu,
        encoder_lens=encoder_lens,
        out_cache_loc=getattr(forward_batch, "out_cache_loc", None),
        # A caller may hand in another view that does not carry this field.
        out_cache_loc_virtual=getattr(forward_batch, "out_cache_loc_virtual", None),
        kv_loc_plan=getattr(forward_batch, "kv_loc_plan", None),
        kv_loc_cols=getattr(forward_batch, "kv_loc_cols", None),
        origin_out_cache_loc=getattr(forward_batch, "origin_out_cache_loc", None),
        out_cache_loc_dsv4=getattr(forward_batch, "out_cache_loc_dsv4", None),
        spec_info=forward_batch.spec_info,
    )


class PPProxyTensors:
    # adapted from https://github.com/vllm-project/vllm/blob/d14e98d924724b284dc5eaf8070d935e214e50c0/vllm/sequence.py#L1103
    tensors: Dict[str, torch.Tensor]

    def __init__(self, tensors):
        # manually define this function, so that
        # Dynamo knows `IntermediateTensors()` comes from this file.
        # Otherwise, dataclass will generate this function by evaluating
        # a string, and we will lose the information about the source file.
        self.tensors = tensors

    def __getitem__(self, key: Union[str, slice]):
        if isinstance(key, str):
            return self.tensors[key]
        elif isinstance(key, slice):
            return self.__class__({k: v[key] for k, v in self.tensors.items()})

    def __setitem__(self, key: str, value: torch.Tensor):
        self.tensors[key] = value

    def __len__(self):
        return len(self.tensors)

    def __eq__(self, other: object):
        return isinstance(other, self.__class__) and self

    def __repr__(self) -> str:
        return f"PPProxyTensors(tensors={self.tensors})"


def compute_position(
    attn_backend: str,
    extend_prefix_lens: torch.Tensor,
    extend_seq_lens: torch.Tensor,
    extend_seq_lens_sum: int,
):
    if support_triton(attn_backend):
        positions, extend_start_loc = compute_position_triton(
            extend_prefix_lens,
            extend_seq_lens,
            extend_seq_lens_sum,
        )
    else:
        positions, extend_start_loc = compute_position_torch(
            extend_prefix_lens, extend_seq_lens
        )
    return positions, extend_start_loc


def compute_position_torch(
    extend_prefix_lens: torch.Tensor, extend_seq_lens: torch.Tensor
):
    positions = torch.cat(
        [
            torch.arange(
                prefix_len, prefix_len + extend_len, device=extend_prefix_lens.device
            )
            for prefix_len, extend_len in zip(extend_prefix_lens, extend_seq_lens)
        ],
        axis=0,
    )
    extend_start_loc = torch.zeros_like(extend_seq_lens)
    extend_start_loc[1:] = torch.cumsum(extend_seq_lens[:-1], dim=0)
    return positions.to(torch.int64), extend_start_loc


def _hash_rids_to_tensor(*, rids: List[str], device: torch.device) -> torch.Tensor:
    values: List[int] = [_stable_hash_str_to_i64(rid) for rid in rids]
    return torch.tensor(values, dtype=torch.int64, device=device)


def _bootstrap_rooms_to_tensor(
    *, bootstrap_rooms: List[Optional[int]], device: torch.device
) -> torch.Tensor:
    values: List[int] = [room if room is not None else -1 for room in bootstrap_rooms]
    return torch.tensor(values, dtype=torch.int64, device=device)


def _stable_hash_str_to_i64(rid: str) -> int:
    digest = hashlib.blake2b(rid.encode("utf-8"), digest_size=8).digest()
    return int.from_bytes(digest, "little", signed=True)

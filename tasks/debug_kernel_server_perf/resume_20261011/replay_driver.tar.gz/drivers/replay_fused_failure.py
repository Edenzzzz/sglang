"""Compare captured serving attention with fp32 and replay the fused kernel."""

import argparse
import json
import math

import torch


def causal_reference(query, key, value, query_offsets, page_offsets, lengths, page_size, scale):
    torch.backends.cuda.matmul.allow_tf32 = False
    query_heads = query.shape[1]
    kv_heads = key.shape[-2]
    group = query_heads // kv_heads
    key = key.flatten(0, 1)
    value = value.flatten(0, 1)
    result = torch.empty_like(query, dtype=torch.float32)
    for request, kv_length in enumerate(lengths):
        query_begin, query_end = query_offsets[request : request + 2]
        query_length = query_end - query_begin
        key_begin = page_offsets[request] * page_size
        keys = key[key_begin : key_begin + kv_length].float()
        values = value[key_begin : key_begin + kv_length].float()
        positions = torch.arange(kv_length, device=query.device)
        for query_start in range(0, query_length, 32):
            query_stop = min(query_start + 32, query_length)
            allowed = positions[None, :] <= (
                kv_length - query_length
                + torch.arange(query_start, query_stop, device=query.device)[:, None]
            )
            for kv_head in range(kv_heads):
                head_begin = kv_head * group
                head_end = head_begin + group
                queries = query[
                    query_begin + query_start : query_begin + query_stop,
                    head_begin:head_end,
                ].float().transpose(0, 1)
                scores = torch.matmul(queries, keys[:, kv_head].T) * scale
                probabilities = scores.masked_fill(~allowed, float("-inf")).softmax(-1)
                result[
                    query_begin + query_start : query_begin + query_stop,
                    head_begin:head_end,
                ] = torch.matmul(probabilities, values[:, kv_head]).transpose(0, 1)
    return result


def error_report(output, reference):
    difference = (output.float() - reference).flatten(1).norm(dim=1)
    relative = difference / reference.flatten(1).norm(dim=1).clamp_min(1e-6)
    finite = torch.isfinite(output).flatten(1).all(dim=1)
    bad = (~finite) | (relative > 0.02)
    return {
        "bad_rows": int(bad.sum()),
        "worst_relative_error": float(relative.max()),
        "worst_row": int(relative.argmax()),
        "nonfinite_rows": int((~finite).sum()),
    }


def report_partials(capture):
    if not capture.get("partial_rows"):
        return
    previous_threads = torch.get_num_threads()
    torch.set_num_threads(1)
    try:
        query_row = capture["worst_query_row"]
        offsets = capture["q_indptr"].tolist()
        request = next(index for index in range(len(offsets) - 1)
                       if offsets[index] <= query_row < offsets[index + 1])
        query_length = offsets[request + 1] - offsets[request]
        context_length = int(capture["kv_lens"][request])
        causal_end = context_length - query_length + query_row - offsets[request] + 1
        page_begin = int(capture["kv_indptr"][request]) * capture["page_size"]
        keys = capture["k"].flatten(0, 1)[page_begin : page_begin + context_length].float()
        values = capture["v"].flatten(0, 1)[page_begin : page_begin + context_length].float()
        query = capture["q"][query_row].float()
        group_size = query.shape[0] // keys.shape[1]
        merged = torch.empty_like(query)
        failures = []
        for partial in capture["partial_rows"]:
            head_in_group = partial["head_in_group"]
            partial_output = partial["output"].float()
            partial_lse = partial["lse"].float()
            weights = (partial_lse * math.log(2)).softmax(0)
            combined = (partial_output * weights[:, :, None]).sum(0)
            for kv_head in range(keys.shape[1]):
                query_head = kv_head * group_size + head_in_group
                merged[query_head] = combined[kv_head]
                for chunk in range(partial_output.shape[0]):
                    begin = chunk * capture["kv_chunk_size"]
                    end = min(begin + capture["kv_chunk_size"], causal_end)
                    if begin >= end:
                        expected = torch.zeros_like(query[query_head])
                        expected_lse = float("-inf")
                    else:
                        scores = keys[begin:end, kv_head] @ query[query_head] * capture["sm_scale"]
                        expected = scores.softmax(0) @ values[begin:end, kv_head]
                        expected_lse = float(scores.logsumexp(0) / math.log(2))
                    relative_error = float((partial_output[chunk, kv_head] - expected).norm()
                                           / expected.norm().clamp_min(1e-6))
                    actual_lse = float(partial_lse[chunk, kv_head])
                    lse_error = 0 if actual_lse == expected_lse else abs(actual_lse - expected_lse)
                    if relative_error > 0.02 or lse_error > 0.05 or not math.isfinite(relative_error):
                        failures.append({"head": query_head, "chunk": chunk,
                                         "relative_error": relative_error,
                                         "lse": actual_lse, "expected_lse": expected_lse})
        print(json.dumps({
            "partial_report_query": query_row, "causal_end": causal_end,
            "chunk_size": capture["kv_chunk_size"], "bad_partial_count": len(failures),
            "bad_partials": failures[:20],
            "captured_output_vs_partial_merge": error_report(
                capture["output"][query_row:query_row + 1], merged[None],
            ),
        }), flush=True)
    finally:
        torch.set_num_threads(previous_threads)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture")
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--original-strides", action="store_true")
    parser.add_argument("--physical-pages", action="store_true")
    parser.add_argument("--cold-cache", action="store_true")
    parser.add_argument("--poison-workspace", action="store_true")
    parser.add_argument("--saved-plan", action="store_true")
    parser.add_argument("--workspace-byte", type=int)
    arguments = parser.parse_args()
    if arguments.workspace_byte is not None and not 0 <= arguments.workspace_byte <= 255:
        parser.error("--workspace-byte must be between 0 and 255")
    capture = torch.load(arguments.capture, map_location="cpu", weights_only=True)
    report_partials(capture)
    query = capture["q"].cuda()
    key, value = capture["k"].cuda(), capture["v"].cuda()
    if arguments.original_strides:
        strided_key = torch.empty_strided(
            key.shape, capture["k_stride"], device="cuda", dtype=key.dtype,
        )
        strided_value = torch.empty_strided(
            value.shape, capture["v_stride"], device="cuda", dtype=value.dtype,
        )
        strided_key.copy_(key)
        strided_value.copy_(value)
        key, value = strided_key, strided_value
    query_offsets = capture["q_indptr"].tolist()
    page_offsets = capture["kv_indptr"].tolist()
    lengths = capture["kv_lens"].tolist()
    reference = causal_reference(
        query, key, value, query_offsets, page_offsets, lengths,
        capture["page_size"], capture["sm_scale"],
    )
    print(json.dumps({
        "layer_id": capture["layer_id"], "query_shape": list(query.shape),
        "query_lengths": torch.diff(capture["q_indptr"]).tolist(),
        "kv_lengths": lengths,
        "fa3_rows": capture["num_fa3_rows"],
        "replay_key_stride": list(key.stride()),
        "original_key_stride": list(capture["k_stride"]),
        "captured_fused": error_report(capture["output"].cuda(), reference),
        "captured_stock": error_report(capture["reference"].cuda(), reference),
    }), flush=True)

    from sglang.srt.layers.attention.fused_fa3_loader import load_fused_fa3
    import flashinfer

    load_fused_fa3()
    query_heads, head_dim = query.shape[1:]
    kv_heads = key.shape[-2]
    page_size = capture["page_size"]
    num_fa3 = capture["num_fa3_rows"]
    num_sm = torch.cuda.get_device_properties(query.device).multi_processor_count
    integer_workspace = torch.empty(64 << 20, device="cuda", dtype=torch.uint8)
    pinned_workspace = torch.empty_like(integer_workspace, device="cpu", pin_memory=True)
    float_workspace = torch.empty(16, device="cuda", dtype=torch.uint8)
    mask = torch.arange(len(lengths)) < num_fa3
    plan = torch.ops.fused_fa3.build_fused_plan(
        integer_workspace, pinned_workspace, float_workspace,
        capture["q_indptr"], capture["kv_indptr"], capture["kv_lens"], mask,
        query_heads, kv_heads, head_dim, head_dim, page_size,
        capture["sm_split"], num_sm, True,
    )
    if "pers_plan" in capture:
        saved_plan = capture["pers_plan"]
        saved_bytes = capture["pers_int"].numel()
        rebuilt = integer_workspace[:saved_bytes].cpu()
        saved = capture["pers_int"].clone()
        cursor = saved_plan[52]
        rebuilt[cursor:cursor + 4] = 0
        saved[cursor:cursor + 4] = 0
        differences = torch.nonzero(rebuilt != saved).flatten()
        print(json.dumps({
            "plan_vectors_match": list(plan) == saved_plan,
            "workspace_byte_differences": differences.numel(),
            "first_different_bytes": differences[:16].tolist(),
            "kernel_metadata": capture["kernel_metadata"],
            "kernel_heads": capture["kernel_heads"],
            "kernel_environment": capture["kernel_environment"],
            "q_stride": capture["q_stride"], "o_stride": capture["o_stride"],
        }), flush=True)
        if arguments.saved_plan:
            if list(plan) != saved_plan:
                raise RuntimeError("Saved plan has different scratch geometry; inspect differences first")
            integer_workspace[:saved_bytes].copy_(capture["pers_int"])
            plan = saved_plan
    page_ids = torch.arange(key.shape[0], dtype=torch.int32, device="cuda")
    fa3_wrapper = flashinfer.BatchPrefillWithPagedKVCacheWrapper(
        torch.empty(128 << 20, device="cuda", dtype=torch.uint8), backend="fa3",
    )
    last_pages = (capture["kv_lens"][:num_fa3] - 1) % page_size + 1
    fa3_wrapper.plan(
        capture["q_indptr"][:num_fa3 + 1], capture["kv_indptr"][:num_fa3 + 1],
        page_ids[:page_offsets[num_fa3]], last_pages,
        query_heads, kv_heads, head_dim, page_size, causal=True,
        q_data_type=query.dtype, kv_data_type=key.dtype,
    )
    fa3_integer_workspace = fa3_wrapper._int_workspace_buffer
    fa3_plan = list(fa3_wrapper._plan_info)
    if arguments.saved_plan:
        fa3_integer_workspace = capture["fa3_int"].cuda()
        fa3_plan = capture["fa3_plan"]
    device_lengths = capture["kv_lens"].cuda()
    device_queries = capture["q_indptr"].cuda()
    device_pages = capture["kv_indptr"].cuda()
    if arguments.physical_pages:
        physical_ids = capture["page_ids"].cuda()
        num_pages = int(physical_ids.max()) + 1
        physical_key = torch.zeros(
            (num_pages, *key.shape[1:]), device="cuda", dtype=key.dtype,
        )
        physical_value = torch.zeros_like(physical_key)
        physical_key.index_copy_(0, physical_ids, key)
        physical_value.index_copy_(0, physical_ids, value)
        key, value = physical_key, physical_value
        page_ids = physical_ids.int()
        print(json.dumps({"physical_pages": num_pages, "used_pages": page_ids.numel()}), flush=True)
    replay_failed = False
    cache_flush = (
        torch.empty(128 << 20, device="cuda", dtype=torch.uint8)
        if arguments.cold_cache else None
    )
    for repeat in range(arguments.repeats):
        output = torch.full_like(query, float("nan"))
        if arguments.poison_workspace:
            float_workspace.fill_(255)
        if arguments.workspace_byte is not None:
            float_workspace.fill_(arguments.workspace_byte)
        if cache_flush is not None:
            cache_flush.zero_()
        torch.ops.fused_fa3.fused_run(
            query, key, value, page_ids, output,
            fa3_integer_workspace, fa3_plan,
            integer_workspace, float_workspace, list(plan),
            query_heads, kv_heads, page_size, capture["sm_scale"],
            capture["sm_split"], query_offsets[num_fa3], capture["sm_split"],
            page_offsets[num_fa3], page_ids, output, len(lengths),
            max(torch.diff(capture["kv_indptr"]).tolist()),
            max(torch.diff(capture["q_indptr"]).tolist()),
            device_lengths, device_queries, device_pages,
        )
        torch.cuda.synchronize()
        report = error_report(output, reference)
        replay_failed |= report["bad_rows"] > 0
        print(json.dumps({"repeat": repeat, **report}), flush=True)
    return int(replay_failed)


if __name__ == "__main__":
    raise SystemExit(main())

import torch,json
from sglang.srt.layers.attention.fused_fa3_validation import verify_disputed_heads
torch.set_num_threads(1)
capture=torch.load('/dev/shm/w/mixed_trace_integration/failure.pt',map_location='cpu',weights_only=True)
row=capture['worst_query_row']; head=capture['worst_query_head']
result=verify_disputed_heads(capture['q'],capture['k'],capture['v'],capture['output'],capture['reference'],capture['q_indptr'],capture['kv_indptr'],capture['kv_lens'],torch.arange(capture['k'].shape[0]),torch.tensor([[row,head]]),capture['sm_scale'],0.02)
end=int(capture['kv_lens'][0])-int(capture['q_indptr'][1])+row+1
kv_head=head//(capture['q'].shape[1]//capture['k'].shape[-2])
keys=capture['k'].flatten(0,1)[:end,kv_head].double(); values=capture['v'].flatten(0,1)[:end,kv_head].double()
scores=keys@capture['q'][row,head].double()*capture['sm_scale']; expected=scores.softmax(0)@values
errors={name:float((capture[name][row,head].double()-expected).norm()/expected.norm()) for name in ('output','reference')}
print(json.dumps({'fp32_adjudication':result,'independent_cpu_fp64_errors':errors}))

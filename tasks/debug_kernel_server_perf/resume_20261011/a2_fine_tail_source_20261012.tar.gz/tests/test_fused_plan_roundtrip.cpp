#include "flashinfer/attention/fused_plan.cuh"
#include <cassert>
#include <cstdio>
#include <vector>
int main() {
  flashinfer::FusedPlanInfo<4> p{};
  // round-trip: every field must survive ToVector -> FromVector, which is exactly the property
  // the fuzzy-patched scheduler.cuh silently violated (11 pushes vs 10 reads).
  p.num_blks_x = 7; p.num_blks_y = 9;
  for (int i = 0; i < 4; ++i) {
    p.tasks[i].q_indptr_offset = 100 + i;
    p.tasks[i].batch_idx_offset = 200 + i;
    p.tasks[i].work_indptr_offset = 300 + i;
    p.tasks[i].kv_head_idx_offset = 400 + i;
  }
  p.num_fa3_clusters = 42; p.max_splits_fa3 = 5; p.num_fa3_requests = 3;
  p.cluster_cursor_offset = 11; p.num_pers_clusters = 13; p.fa3_batch_list_offset = 17;
  auto v = p.ToVector();
  printf("plan length: %zu (expected %u)\n", v.size(),
         flashinfer::FusedPlanInfo<4>::NUM_SHARED_ARGS + 4u * flashinfer::FusedPlanInfo<4>::NUM_TASK_ARGS);
  flashinfer::FusedPlanInfo<4> q{};
  q.FromVector(v);
  bool ok = q.num_blks_x == 7 && q.num_blks_y == 9 && q.num_fa3_clusters == 42 &&
            q.max_splits_fa3 == 5 && q.num_fa3_requests == 3 && q.cluster_cursor_offset == 11 &&
            q.num_pers_clusters == 13 && q.fa3_batch_list_offset == 17;
  for (int i = 0; i < 4; ++i)
    ok = ok && q.tasks[i].q_indptr_offset == 100 + i && q.tasks[i].batch_idx_offset == 200 + i &&
         q.tasks[i].work_indptr_offset == 300 + i && q.tasks[i].kv_head_idx_offset == 400 + i;
  printf("round-trip: %s\n", ok ? "PASS" : "FAIL");
  // plan_info[-1] must be the chosen split; the harness depends on it.
  printf("plan_info[-1] == num_fa3_clusters: %s\n", v.back() == 42 ? "PASS" : "FAIL");

  // --- work-item enumeration: the scheduling decision, checked on the host ---
  // A merged 4-mode batch: one 2048-token prefill chunk (FA3) + 7 verify rows of 4 tokens
  // (FA2). GQA 4, so packed_qo is 8192 and 16 -- the chunk lands on task 3 and the verify rows
  // on task 2 (tile16), which is what the measured tile-waste accounting assumed.
  {
    const int32_t qo[8] = {2048, 4, 4, 4, 4, 4, 4, 4};
    const int32_t kv[8] = {2048, 1000, 1007, 1014, 1021, 1028, 1035, 1042};
    const bool m[8] = {true, false, false, false, false, false, false, false};
    std::vector<flashinfer::FusedWorkItem> items[4];
    int32_t max_splits = 0;
    std::vector<int32_t> fa3_list;
    flashinfer::EnumerateFusedWorkItems(qo, kv, m, 8, /*gqa=*/4, /*num_kv_heads=*/1,
                                        /*fa3_tile_q=*/128, /*kv_chunk=*/512, items,
                                        &max_splits, &fa3_list);
    const size_t n0 = items[0].size(), n1 = items[1].size(), n2 = items[2].size(),
                 n3 = items[3].size();
    printf("work items: task0=%zu task1=%zu task2=%zu task3=%zu max_splits_fa3=%d fa3_reqs=%zu\n",
           n0, n1, n2, n3, max_splits, fa3_list.size());
    // task 3: packed 8192 / tile 128 = 64 q tiles, kv 2048 / 512 = 4 chunks -> 256 items.
    bool w = (n3 == 256) && (max_splits == 4) && (fa3_list.size() == 1) && (fa3_list[0] == 0);
    // verify rows: packed 16 -> tile16 -> 1 item each, no split -> 7 items on task 2.
    w = w && (n2 == 7) && (n0 == 0) && (n1 == 0);
    // every item must stay inside its request's ranges
    for (int t = 0; t < 4 && w; ++t)
      for (auto& it : items[t]) {
        const int64_t packed = (int64_t)qo[it.batch_idx] * 4;
        w = w && it.q_start >= 0 && it.q_start + it.q_len <= packed && it.kv_start >= 0 &&
            it.kv_end <= kv[it.batch_idx] && it.kv_start < it.kv_end && it.q_len > 0;
      }
    printf("enumeration: %s\n", w ? "PASS" : "FAIL");
    ok = ok && w;
  }
  // --- merge layout: only SPLIT groups get partials, and the CSR must be well formed ---
  {
    const int32_t qo[8] = {2048, 4, 4, 4, 4, 4, 4, 4};
    const int32_t kv[8] = {2048, 1000, 1007, 1014, 1021, 1028, 1035, 1042};
    const bool m[8] = {true, false, false, false, false, false, false, false};
    std::vector<flashinfer::FusedWorkItem> items[4];
    int32_t ms = 0; std::vector<int32_t> fl;
    flashinfer::EnumerateFusedWorkItems(qo, kv, m, 8, 4, 1, 128, 512, items, &ms, &fl);
    flashinfer::FusedMergeLayout lay;
    const int32_t token_indptr[9] = {0, 2048, 2052, 2056, 2060, 2064, 2068, 2072, 2076};
    flashinfer::BuildFusedMergeLayout(items, kv, 8, 1, token_indptr, 4, &lay);
    bool w = lay.num_merge_tiles == 64 && lay.total_partial_rows == 64L * 4 * 128 &&
             lay.merge_indptr.size() == 8193 && lay.merge_o_indices.size() == 8192;
    for (size_t row = 0; row < lay.merge_o_indices.size(); ++row) {
      w = w && lay.merge_o_indices[row] == int32_t(row);
      w = w && lay.merge_indptr[row + 1] - lay.merge_indptr[row] == 4;
    }
    // CSR well formed: starts at 0, monotonic, ends at total
    w = w && lay.merge_indptr.front() == 0 &&
        lay.merge_indptr.back() == (int32_t)lay.total_partial_rows;
    for (size_t i = 1; i < lay.merge_indptr.size() && w; ++i)
      w = w && lay.merge_indptr[i] > lay.merge_indptr[i - 1];
    // unsplit items (task 2, the verify rows) must have no partial assigned
    for (auto x : lay.partial_indptr[2]) w = w && x == -1;
    // split items (task 3) must all have one
    for (auto x : lay.partial_indptr[3]) w = w && x >= 0;
    printf("merge layout: tiles=%d partial_rows=%lld %s\n", lay.num_merge_tiles,
           (long long)lay.total_partial_rows, w ? "PASS" : "FAIL");
    ok = ok && w;
  }
  {
    const int32_t query_lengths[2] = {48, 4};
    const int32_t kv_lengths[2] = {256, 256};
    const int32_t token_offsets[3] = {0, 48, 52};
    const bool fa3_rows[2] = {true, false};
    std::vector<flashinfer::FusedWorkItem> work[4];
    flashinfer::EnumerateFusedWorkItems(query_lengths, kv_lengths, fa3_rows, 2, 7, 4,
                                      128, 128, work, nullptr, nullptr);
    flashinfer::FusedMergeLayout layout;
    flashinfer::BuildFusedMergeLayout(work, kv_lengths, 2, 4, token_offsets, 7, &layout);
    bool layout_ok = layout.total_partial_rows == 672 && layout.merge_o_indices.size() == 336;
    for (size_t packed_row = 0; packed_row < layout.merge_o_indices.size(); ++packed_row) {
      const int32_t expected = int32_t(packed_row / 7) * 28 + int32_t(packed_row % 7);
      layout_ok = layout_ok && layout.merge_o_indices[packed_row] == expected;
      layout_ok = layout_ok && layout.merge_indptr[packed_row + 1] -
                                      layout.merge_indptr[packed_row] == 2;
    }
    printf("GQA7 four-head merge coordinates: %s\n", layout_ok ? "PASS" : "FAIL");
    ok = ok && layout_ok;
  }
  {
    setenv("FUSED_FA2_TILES", "48,32,16", 1);
    const int32_t query_lengths[5] = {4, 8, 12, 16, 24};
    const int32_t kv_lengths[5] = {2048, 2048, 2048, 2048, 2048};
    const bool fa3_rows[5] = {false, false, false, false, false};
    std::vector<flashinfer::FusedWorkItem> work[4];
    flashinfer::EnumerateFusedWorkItems(query_lengths, kv_lengths, fa3_rows, 5, 4, 1,
                                        128, 1024, work, nullptr, nullptr);
    bool class_ok = work[2].size() == 1 && work[1].size() == 1 && work[0].size() == 5;
    class_ok = class_ok && work[0][0].q_len == 48 && work[0][1].q_len == 48 &&
               work[0][2].q_len == 16;
    printf("FA2 classes 48/32/16 routing: %s\n", class_ok ? "PASS" : "FAIL");
    ok = ok && class_ok;
    unsetenv("FUSED_FA2_TILES");
  }
  {
    setenv("FUSED_FA2_TILES", "48,32,16", 1);
    bool tails_ok = true;
    for (const char* group_major : {"0", "1"}) {
      setenv("FUSED_GROUP_MAJOR", group_major, 1);
      for (const char* split : {"0", "1"}) {
        setenv("FUSED_FA2_SPLIT", split, 1);
        for (int32_t group : {4, 7}) {
          for (int32_t query_length = 1; query_length <= 65; ++query_length) {
            const int32_t query_lengths[2] = {32, query_length};
            const int32_t kv_lengths[2] = {256, 513};
            const int32_t token_offsets[3] = {0, 32, 32 + query_length};
            const bool fa3_mask[2] = {true, false};
            std::vector<flashinfer::FusedWorkItem> original[4], fine[4];
            setenv("FUSED_FA2_FINE_TAIL", "0", 1);
            flashinfer::EnumerateFusedWorkItems(query_lengths, kv_lengths, fa3_mask, 2,
                                              group, 2, 128, 128, original, nullptr, nullptr);
            setenv("FUSED_FA2_FINE_TAIL", "1", 1);
            flashinfer::EnumerateFusedWorkItems(query_lengths, kv_lengths, fa3_mask, 2,
                                              group, 2, 128, 128, fine, nullptr, nullptr);
            std::vector<int32_t> coverage(query_length * group, 0);
            int32_t original_capacity = 0, fine_capacity = 0;
            const int32_t widths[3] = {48, 32, 16};
            for (int task = 0; task < 3; ++task) {
              original_capacity += int32_t(original[task].size()) * widths[task];
              fine_capacity += int32_t(fine[task].size()) * widths[task];
              for (const auto& item : fine[task]) {
                tails_ok = tails_ok && item.q_len <= widths[task] && item.batch_idx == 1;
                for (int32_t row = item.q_start; row < item.q_start + item.q_len; ++row) {
                  if (row < 0 || row >= int32_t(coverage.size())) {
                    tails_ok = false;
                  } else {
                    ++coverage[row];
                  }
                }
              }
            }
            const int32_t chunks = split[0] == '1' ? 5 : 1;
            for (int32_t covered : coverage) tails_ok = tails_ok && covered == 2 * chunks;
            tails_ok = tails_ok && fine_capacity <= original_capacity &&
                       fine[3].size() == original[3].size();
            if (group == 7 && query_length == 8) {
              tails_ok = tails_ok && fine_capacity * 3 == original_capacity * 2;
            }
            flashinfer::FusedMergeLayout before, after;
            flashinfer::BuildFusedMergeLayout(original, kv_lengths, 2, 2, token_offsets,
                                             group, &before);
            flashinfer::BuildFusedMergeLayout(fine, kv_lengths, 2, 2, token_offsets,
                                             group, &after);
            std::map<int32_t, int32_t> before_rows, after_rows;
            for (size_t row = 0; row < before.merge_o_indices.size(); ++row) {
              before_rows[before.merge_o_indices[row]] +=
                  before.merge_indptr[row + 1] - before.merge_indptr[row];
            }
            for (size_t row = 0; row < after.merge_o_indices.size(); ++row) {
              after_rows[after.merge_o_indices[row]] +=
                  after.merge_indptr[row + 1] - after.merge_indptr[row];
            }
            tails_ok = tails_ok && before_rows == after_rows &&
                       before.total_partial_rows == after.total_partial_rows;
          }
        }
      }
    }
    unsetenv("FUSED_FA2_FINE_TAIL");
    unsetenv("FUSED_GROUP_MAJOR");
    unsetenv("FUSED_FA2_SPLIT");
    unsetenv("FUSED_FA2_TILES");
    printf("FA2 per-item tail coverage and split merge: %s\n", tails_ok ? "PASS" : "FAIL");
    ok = ok && tails_ok;
  }
  {
    const int32_t query_lengths[2] = {512, 4};
    const int32_t kv_lengths[2] = {2048, 8192};
    const bool fa3_mask[2] = {true, false};
    const int32_t sparse_query[1] = {1};
    const int32_t long_context[1] = {65536};
    const bool sparse_mask[1] = {true};
    bool budget_ok = flashinfer::FusedWorkBudgetKvChunk(
        query_lengths, kv_lengths, fa3_mask, 2, 7, 4, 128, 64) == 2048;
    budget_ok = budget_ok && flashinfer::FusedWorkBudgetKvChunk(
        sparse_query, long_context, sparse_mask, 1, 7, 4, 128, 64) == 4096;
    budget_ok = budget_ok && flashinfer::FusedWorkBudgetKvChunk(
        query_lengths, kv_lengths, nullptr, 2, 7, 4, 128, 64) == 0;
    printf("query/head-aware KV split budget: %s\n", budget_ok ? "PASS" : "FAIL");
    ok = ok && budget_ok;
  }
  {
    unsetenv("FUSED_FA2_SPLIT");
    unsetenv("FUSED_FA2_KV_CHUNK");
    bool split_ok = flashinfer::FusedFa2KvChunk(512) == 0;
    setenv("FUSED_FA2_SPLIT", "1", 1);
    split_ok = split_ok && flashinfer::FusedFa2KvChunk(512) == 512;
    setenv("FUSED_FA2_KV_CHUNK", "256", 1);
    split_ok = split_ok && flashinfer::FusedFa2KvChunk(0) == 256;
    const int32_t query_lengths[2] = {4, 1};
    const int32_t kv_lengths[2] = {1024, 513};
    const int32_t token_offsets[3] = {0, 4, 5};
    const bool fa3_mask[2] = {false, false};
    std::vector<flashinfer::FusedWorkItem> work[4];
    flashinfer::EnumerateFusedWorkItems(query_lengths, kv_lengths, fa3_mask, 2, 7, 4,
                                      128, 0, work, nullptr, nullptr);
    split_ok = split_ok && work[1].size() == 16 && work[2].size() == 12 && work[3].empty();
    flashinfer::FusedMergeLayout layout;
    flashinfer::BuildFusedMergeLayout(work, kv_lengths, 2, 4, token_offsets, 7, &layout);
    split_ok = split_ok && layout.merge_o_indices.size() == 35 &&
               layout.total_partial_rows == 133;
    for (size_t packed_row = 0; packed_row < 35 && split_ok; ++packed_row) {
      split_ok = layout.merge_o_indices[packed_row] ==
                     int32_t(packed_row / 7) * 28 + int32_t(packed_row % 7) &&
                 layout.merge_indptr[packed_row + 1] - layout.merge_indptr[packed_row] ==
                     (packed_row < 28 ? 4 : 3);
    }
    for (const char* invalid : {"0", "-128", "129", "256x"}) {
      setenv("FUSED_FA2_KV_CHUNK", invalid, 1);
      bool rejected = false;
      try {
        flashinfer::FusedFa2KvChunk(0);
      } catch (const std::exception&) {
        rejected = true;
      }
      split_ok = split_ok && rejected;
    }
    unsetenv("FUSED_FA2_SPLIT");
    unsetenv("FUSED_FA2_KV_CHUNK");
    printf("independent FA2 split and merge coordinates: %s\n", split_ok ? "PASS" : "FAIL");
    ok = ok && split_ok;
  }
  return ok && v.back() == 42 ? 0 : 1;
}

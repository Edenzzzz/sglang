set -e
export SGLANG_FUSED_FA3_CONSUMER_REGS=240
bash /dev/shm/w/fa3_single_wg_r240/measure.sh

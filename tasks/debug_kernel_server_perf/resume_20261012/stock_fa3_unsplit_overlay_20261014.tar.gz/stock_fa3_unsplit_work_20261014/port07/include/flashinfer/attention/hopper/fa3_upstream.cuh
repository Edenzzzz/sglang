#ifndef FLASHINFER_ATTENTION_HOPPER_FA3_UPSTREAM_CUH_
#define FLASHINFER_ATTENTION_HOPPER_FA3_UPSTREAM_CUH_

// Upstream flash-attention's FA3 mainloop and epilogue, instantiated for the
// fused kernel's wgmma role.
//
// Why this exists. flashinfer's prefill_sm90 is a SIMPLIFIED FA3 port, and the
// difference is the bulk of the wgmma role's deficit: measured 772 us against
// 421 us for the FA2 persistent kernel on a long-prefix fixture, of which the
// K/V stage count accounts for only ~15% and the packed-Q gather for nothing at
// all (767.8 us against 769.5 us with the gather skipped). The remaining ~1.6x is
// the mainloop itself, so the fix is to use the real one rather than keep
// optimising the simplified one a flag at a time.
//
// What it replaces rather than supplements. CollectiveMainloopFwdSm90 is
// templated on exactly the features this effort hand-rolled, and in better form:
//   PagedKVNonTMA_  -> our sparse/paged KV gather (block_sparse_gather.cuh)
//   PackGQA_        -> our element-wise packed-Q load (sparse_mainloop.cuh)
//   Split_          -> our partial-O/LSE write and MergeGroupJIT path
//   Varlen_         -> our ragged qo_indptr handling
// plus IntraWGOverlap (S/P ping-pong), which we never had.
//
// Smem budget, which is what decides feasibility. Upstream TensorStorage is
// 132096 B at Stages=1, 197632 at 2, 263168 at 3. The FA2 role's slot is 69632
// and the opt-in limit 232448, so Stages=1 fits DISJOINTLY at 201728 with 30720
// spare -- no aliasing, and therefore none of the unexplained aliasing fault.
// Stages=2 would require aliasing; Stages=3 cannot fit at all.

#include "../../utils.cuh"
#include "../unified_wgmma_scheduler.cuh"
#include "../../../../../flash-attention/hopper/utils.h"
#include "../../../../../flash-attention/hopper/tile_scheduler.hpp"
#include "../../../../../flash-attention/hopper/mainloop_fwd_sm90_tma_gmma_ws.hpp"
#include "../../../../../flash-attention/hopper/epilogue_fwd.hpp"
#include "cutlass/cluster_launch.hpp"
#include "../../../../../flash-attention/hopper/flash_fwd_kernel_sm90.h"
#include "../../../../../flash-attention/hopper/flash_fwd_combine_kernel.h"

namespace flashinfer {

// Two K/V stages, which is what upstream uses unconditionally on Sm90
// (flash_fwd_launch_template.h:47, kStages = Arch >= 90 ? 2 : ...). The old default
// here was 1, to fit beside the FA2 slot in the fused kernel; that dispatch is closed
// and the FA3 executor now owns its SM's smem outright, so there is nothing to fit
// beside and no reason to run shallower than upstream.
#ifndef FLASHINFER_FA3_UPSTREAM_STAGES
#define FLASHINFER_FA3_UPSTREAM_STAGES 2
#endif

// bf16 in, fp32 accumulate, 128x128x128 tiles, head dim 128, no cluster. Local is off;
// AppendKV and rotary are off because sglang applies rope before attention.
//
// CAUSAL, bottom-right aligned (query i of a row sits at kv_len - q_len + i). This was
// hardcoded false on the premise that "the fused path serves non-causal chunked prefill",
// which is wrong: an extend row's queries must not see the later tokens of their own
// chunk. With no prefix the error is total; the in-server check measured rel err 0.12-0.80
// on append rows (qo 3809 onto kv 12000), and the serving gate diverged after ~6 tokens.
// The kernel harness never saw it because its reference was non-causal as well.
#ifndef FLASHINFER_FA3_CAUSAL
#define FLASHINFER_FA3_CAUSAL 1
#endif
// Cluster size along M. >1 is the prerequisite for DSMEM: peer smem
// (mapa.shared::cluster) only exists inside a cluster, so KV multicast cannot be built
// until the kernel is actually launched as one. Upstream carries the same knob as
// ClusterM and launches through cutlass::launch_kernel_on_cluster when it exceeds 1
// (flash_fwd_launch_template.h:187-189); our launcher used a plain <<<>>> and therefore
// never formed a cluster at all. Default 1 keeps today's behaviour exactly.
#ifndef FLASHINFER_FA3_CLUSTER_M
#define FLASHINFER_FA3_CLUSTER_M 1
#endif
using UpstreamFA3ClusterShape =
    cute::Shape<cute::Int<FLASHINFER_FA3_CLUSTER_M>, cute::_1, cute::_1>;

template <int HeadDim = 128, bool SplitKV = true>
using UpstreamFA3Mainloop = flash::CollectiveMainloopFwdSm90<
    FLASHINFER_FA3_UPSTREAM_STAGES, UpstreamFA3ClusterShape,
    cute::Shape<cute::_128, cute::_128, cute::Int<HeadDim>>, HeadDim, cutlass::bfloat16_t, float,
    cutlass::arch::Sm90,
    /*Is_causal=*/bool(FLASHINFER_FA3_CAUSAL), /*Is_local=*/false, /*Has_softcap=*/false,
    /*Varlen=*/true,
    // PagedKVNonTMA=true gathers KV with cp.async through the page table.
    // PagedKVNonTMA=false takes upstream's TMA paged path, which flips Use_TMA_KV true
    // and is the prerequisite for TMA multicast; it requires page_size % kBlockN == 0
    // (mainloop_fwd_sm90:537), so only with 128-token pages. Measured at page 128, TMA
    // is slightly SLOWER than cp.async here (496 ms vs 480 ms), so it is kept off by
    // default and enabled only for the multicast work.
#ifndef FLASHINFER_FA3_PAGED_TMA
#define FLASHINFER_FA3_PAGED_TMA 0
#endif
    /*PagedKVNonTMA=*/!bool(FLASHINFER_FA3_PAGED_TMA), /*AppendKV=*/false, /*HasQv=*/false,
    // MmaPV_is_RS=true is what upstream's own tuner returns for head_dim 128 bf16:
    // tile_size_fwd_sm90 gives {kBlockM=128, kBlockN=128, MmaPV_is_RS=true,
    // IntraWGOverlap=true} (tile_size.h:33, with use_blockN_128 true because
    // paged_kv_non_TMA is set). This was false from the first port commit -- a guess,
    // never measured. With RS off, the softmax result P round-trips through smem with a
    // barrier per KV block instead of staying in registers for the PV mma, which
    // serialises softmax against the mma and leaves the mainloop latency-bound: 80 GB/s
    // and 10.3 TFLOP/s against FA2's 2518 GB/s and 322 TFLOP/s on identical work, with
    // throughput perfectly linear in SM count to 132.
#ifndef FLASHINFER_FA3_MMA_PV_RS
#define FLASHINFER_FA3_MMA_PV_RS 1
#endif
    /*MmaPV_is_RS=*/bool(FLASHINFER_FA3_MMA_PV_RS), /*IntraWGOverlap=*/true, /*PackGQA=*/true,
    SplitKV, /*V_colmajor=*/false>;

template <int HeadDim = 128, bool SplitKV = true>
using UpstreamFA3Epilogue = flash::CollectiveEpilogueFwd<
    cute::Shape<cute::_128, cute::Int<HeadDim>, cute::_128>,
    UpstreamFA3ClusterShape, cutlass::bfloat16_t, cutlass::arch::Sm90,
    /*NumEpilogueThreads=*/256, /*Varlen=*/true, /*PackGQA=*/true, SplitKV,
    /*FP8PermuteCol=*/false>;

// Upstream's Arguments conventions, read off flash_fwd_launch_template.h:85-120
// so they are matched rather than guessed:
//
//   shape_Q           = {total_q, d, h, 1}           (varlen: batch folds into 1)
//   stride_Q          = {q_row_stride, 1, q_head_stride, 0}
//   shape_K (paged)   = {page_size, d, h_k, num_pages}
//   stride_K          = {k_row_stride, 1, k_head_stride, 0}
//   shape_page_table  = {batch, seqlen_k / page_size}
//   stride_page_table = {page_table_batch_stride, 1}
//
// THE ONE THING THAT DOES NOT MAP FOR FREE. Upstream indexes the page table as
// page_table[bidb * batch_stride + block], i.e. a dense 2-D [batch, max_pages]
// array with a uniform per-request stride. sglang supplies a RAGGED page list --
// kv_indices packed back to back, addressed through kv_indptr -- which has no
// uniform stride. So the port needs a per-step conversion into a padded
// [batch, max_pages] table.
//
// Cost, so the decision is informed rather than assumed: at 64 concurrent
// requests and 8192 tokens with page_size 1 that is 64 * 8192 * 4 B = 2 MiB and a
// scatter over 524k entries per step. Cheap in bytes, but it is per-step work on
// the critical path and it is the kind of thing that must be CUDA-graph safe --
// a device-side scatter into a preallocated buffer, not a host loop. Larger page
// sizes shrink it proportionally.
//
// The plan arrays the fused dispatch already has, in the shape upstream wants.
// Deliberately a flat POD: the point is that no translation layer is needed --
// qo_indptr IS cu_seqlens_q, kv_indices IS the page table, kv_lens IS seqused_k.
struct UpstreamFA3Plan {
  cutlass::bfloat16_t const* q_ptr;
  cutlass::bfloat16_t* k_ptr;
  cutlass::bfloat16_t* v_ptr;
  int const* page_table;     // our kv_indices
  int const* cu_seqlens_q;   // our qo_indptr
  int const* seqused_k;      // our kv_lens
  // total_q is the varlen Q extent (shape_Q[0]); num_pages/page_size describe the
  // KV cache. Conflating them mis-shapes the Q tensor and would read out of range.
  int total_q;
  // Token count of the FA3 SUBSET only. The combine scheduler must be told a token extent
  // that matches the batch count it is given (num_fa3_requests), because both
  // choose_scheduling_algo and the LINEARIZE_M_AND_BATCH tile mapping are derived from the
  // pair (flash_fwd_combine_kernel.h:294-298, 326). Addressing is unaffected: the combine
  // resolves rows through varlen_batch_idx_ptr -> cu_seqlens[actual_bidb], i.e. absolute
  // offsets, so this value only sizes the grid and picks the algorithm. Passing the whole
  // batch's total_q here while passing only the FA3 request count as `b` made the
  // linearized walk run past the FA3 rows and overwrite the FA2 executor's output.
  int fa3_total_q;
  int num_pages, page_size, num_qo_heads, num_kv_heads, head_dim;
  int64_t q_stride_tok, q_stride_head, kv_stride_page, kv_stride_tok, kv_stride_head;
  // O's OWN strides. The epilogue was being handed q_stride_tok/q_stride_head for
  // the output tensor, which is right only when O and Q happen to share a layout.
  int64_t o_stride_tok, o_stride_head;
  // Batch count, for the combine pass's scheduler (it walks cu_seqlens per request).
  int num_requests_for_combine;
  // MAX q length over requests. The combine scheduler sizes its grid as
  // ceil_div(seqlen_q * num_heads, kBlockM) and, per its own comment, expects the
  // varlen maximum here -- passing 0 made grid.x zero and the launch failed with
  // "invalid argument".
  int max_seqlen_q;
  // Per-request split counts, device-side; see FillNumSplitsDynamic.
  int const* num_splits_dynamic;
  // The requests the wgmma queue owns, and how many. The combine pass must run over
  // only these: over the whole batch it reduces never-written partials onto the FA2
  // executor's rows.
  int const* fa3_batch_list;
  int num_fa3_requests;
  float softmax_scale;
  int num_splits;
};

// Scheduler adapter: upstream's interface, our plan's work items.
//
// Upstream's own schedulers claim the whole grid, which the fused kernel cannot
// allow -- the role branch on blockIdx.x decides who runs FA3, and the FA2 roles
// own the rest. So the mainloop is driven from our plan instead, through the
// interface upstream's kernel body expects (get_initial_work / get_next_work /
// is_valid / get_block_coord).
//
// This is far smaller than the equivalent adapter for flashinfer's FA3, because
// upstream's WorkTileInfo is just {block_idx, bidh, bidb, split_idx}: the
// mainloop derives seqlens and page-table offsets itself from params + bidb via
// cu_seqlens_q / seqused_k, rather than having an 8-field tuple pushed into it.
// Our plan already stores every one of those four fields per task-3 item.
template <typename IdType>
struct UpstreamFA3SchedulerAdapter {
  // Upstream's kernel body constructs the scheduler from a SharedStorage* and
  // reserves room for it in its own SharedStorage. Ours needs none: the work
  // items live in the plan buffer in global memory, so an empty struct keeps the
  // interface without costing smem -- which matters, because the whole port
  // depends on fitting beside the FA2 role's 69632-byte slot.
  struct SharedStorage {};

  struct Params {
    // Task-3 slices of the 4-task plan, exactly as the ext already reads them.
    IdType const* work_indptr;   // per-CTA [begin, end) into the item arrays
    IdType const* q_start;       // PACKED row offset -> block_idx = q_start / 128
    IdType const* kv_head_idx;   // -> bidh (PackGQA packs the group of this kv head)
    IdType const* batch_idx;     // -> bidb; upstream indexes cu_seqlens with it
    // split_idx is DERIVED, not stored: the plan has no kv_chunk_idx array, and
    // persistent.cuh:372 computes the same quantity as kv_start / len_kv_chunk.
    // Keeping that derivation in one place avoids a second source of truth.
    IdType const* kv_start;
    // Per-item row KV length, for the per-item num_splits above.
    IdType const* kv_len;
    IdType const* len_kv_chunk;  // task 3's element, read as [0]
    // Per-request Q prefix sum in TOKENS, and the GQA group size, so the packed-row
    // base of a request can be subtracted from the plan's global q_start.
    IdType const* q_indptr_per_req;
    uint32_t gqa_group_size;
    uint32_t cta_tile_q;
  };

  struct WorkTileInfo {
    int block_idx = 0, bidh = 0, bidb = -1, split_idx = 0;
    int cursor = 0, ptr_begin = 0, ptr_end = 0;

    CUTLASS_DEVICE bool is_valid(Params const&) const { return bidb >= 0; }

    CUTLASS_DEVICE cute::tuple<int32_t, int32_t, int32_t, int32_t> get_block_coord(
        Params const&) const {
      return {block_idx, bidh, bidb, split_idx};
    }
  };

  CUTLASS_DEVICE UpstreamFA3SchedulerAdapter(SharedStorage* const) {}

  CUTLASS_DEVICE static WorkTileInfo at(Params const& p, int idx, int cursor, int begin,
                                        int end) {
    if (cursor + begin >= end) return {0, 0, -1, 0, cursor, begin, end};
    // split_idx is NOT a bare chunk index on this path. Under Split && Varlen the
    // epilogue reads a per-work-item num_splits out of the TOP 16 BITS of split_idx
    // and masks the index to the low 16 (epilogue_fwd.hpp:226-231). Leaving the high
    // bits zero makes it fall back to the plan-wide maximum, which is wrong for
    // every row that did NOT split: that row writes one partial, the epilogue still
    // takes the is_split branch, and the combine pass then averages it with
    // uninitialised memory. So the row's own chunk count is encoded here, which is
    // exactly what upstream designed the field for.
    const int chunk_len = (p.len_kv_chunk != nullptr) ? int(p.len_kv_chunk[0]) : 0;
    int chunk = 0, nsplits = 1;
    if (chunk_len > 0) {
      chunk = int(p.kv_start[idx]) / chunk_len;
      // Non-causal: the planner chunks the row's full KV length. Causal would need
      // packed_causal_kv_end here, the same basis scheduler.cuh uses.
      const int kv_len = int(p.kv_len[idx]);
      nsplits = (kv_len + chunk_len - 1) / chunk_len;
      if (nsplits < 1) nsplits = 1;
    }
    const int split_field = (nsplits << 16) | (chunk & 0x0000FFFF);
    // q_start is ALREADY request-local: the planner pushes
    // qo_tile_idx * cluster_tile_q (scheduler.cuh:1655), i.e. the tile's offset within
    // its request, not a global packed-row offset. So q_start / cta_tile_q is the
    // m_block upstream wants, and subtracting the request's packed base -- which I did
    // on the theory that the offset was global -- drives it negative for every request
    // after the first and faults with an illegal access.
    return {int(p.q_start[idx]) / int(p.cta_tile_q), int(p.kv_head_idx[idx]),
            int(p.batch_idx[idx]), split_field, cursor, begin, end};
  }

  template <bool IsProducerWarp = false>
  CUTLASS_DEVICE WorkTileInfo get_initial_work(Params const& p) const {
    const int begin = int(p.work_indptr[blockIdx.x]);
    const int end = int(p.work_indptr[blockIdx.x + 1]);
    return at(p, begin, 0, begin, end);
  }

  template <bool IsProducerWarp = false>
  CUTLASS_DEVICE WorkTileInfo get_next_work(Params const& p, WorkTileInfo const& cur) const {
    const int next = cur.cursor + 1;
    return at(p, cur.ptr_begin + next, next, cur.ptr_begin, cur.ptr_end);
  }

  // Upstream's body calls these; the plan is static per launch so they are no-ops.
  CUTLASS_DEVICE void init_consumer() const {}
  CUTLASS_DEVICE void prefetch_next_work(Params const&, WorkTileInfo&) const {}
  CUTLASS_DEVICE void broadcast_next_work(WorkTileInfo&) const {}
};

// Build upstream's mainloop and epilogue Arguments from our plan.
//
// Everything here follows flash_fwd_launch_template.h:85-120 so the conventions
// match upstream exactly; the only transformation is the dense page table, which
// ScatterRaggedPageTable below produces.
//
// Varlen is on, so batch folds to 1 in shape_Q and the batch strides are 0 --
// per-request addressing comes from cu_seqlens_q / seqused_k, which are our
// qo_indptr / kv_lens unchanged.
template <int HeadDim = 128, bool SplitKV = true>
inline typename UpstreamFA3Mainloop<HeadDim, SplitKV>::Arguments MakeUpstreamMainloopArgs(
    UpstreamFA3Plan const& p, int const* dense_page_table, int max_pages_per_seq, int batch) {
  using ML = UpstreamFA3Mainloop<HeadDim, SplitKV>;
  using cute::_1;
  return typename ML::Arguments{
      p.q_ptr,
      {p.total_q, p.head_dim, p.num_qo_heads, 1},
      {p.q_stride_tok, _1{}, p.q_stride_head, 0},
      p.k_ptr,
      {p.page_size, p.head_dim, p.num_kv_heads, p.num_pages},
      // The FOURTH element is the stride over PAGES, matching shape_K's fourth
      // dimension (num_pages). It was 0, which aliased every page onto page 0: upstream
      // indexes K[page_token, d, kv_head, page] and a zero page stride makes every
      // lookup read the first page's data. That corrupts every wgmma row equally while
      // leaving the FA2 role untouched, which is exactly the symptom -- both wgmma rows
      // wrong by ~10x with the FA2 decode row exact to 5e-4, at one split, with the
      // split path, the combine, the partial layouts and the Q tile index all
      // independently ruled out. kv_stride_page was computed in the dispatch and then
      // never used.
      {p.kv_stride_tok, _1{}, p.kv_stride_head, p.kv_stride_page},
      p.v_ptr,
      p.head_dim,
      {p.kv_stride_tok, _1{}, p.kv_stride_head, p.kv_stride_page},  // V, same layout
      nullptr, {0, 0, 0, 0}, {0, _1{}, 0, 0},   // K_new: AppendKV is off
      nullptr, {0, _1{}, 0, 0},                  // V_new
      nullptr, {0, _1{}, 0, 0},                  // Qv: HasQv is off
      nullptr, {0, 0}, {0, _1{}},                // rotary cos: applied before attention
      nullptr, {0, _1{}}, false,
      dense_page_table,
      {batch, max_pages_per_seq},
      {max_pages_per_seq, _1{}},
      p.softmax_scale,
      // StrideDescale is a 2-tuple, so {0} does not construct it; unused for bf16
      nullptr, nullptr, nullptr, {0, 0}, {0, 0}, {0, 0},
      -1, -1, 0,                                 // window_left/right, attention_chunk
      0.f,                                       // softcap
      p.num_splits,
      nullptr,                                   // kv_batch_idx
      p.cu_seqlens_q, nullptr, nullptr,          // cu_seqlens q / k / k_new
      nullptr, p.seqused_k, nullptr, nullptr};   // seqused q / k, leftpad_k, seqlens_rotary
}

// Epilogue Arguments. Split is on, so the partial-O/LSE pointers are required:
// upstream writes a split's output there and its own combine kernel reduces them,
// which is the path that replaces our store_partial + MergeGroupJIT. Passing
// nullptr for them while Split=true would fault on the first split tile.
//
// nheads_kv is passed explicitly because PackGQA needs the group size to unpack
// rows; cu_seqlens / seqused are the same qo_indptr / kv_lens the mainloop gets.
// The split partials use UPSTREAM'S OWN varlen layout, not a layout of our
// choosing, so the epilogue that writes them and the combine pass that reads them
// cannot disagree about anything. flash_api.cpp:1102 allocates
//
//   out_accum        [num_splits, num_heads, total_q, head_dim]   contiguous
//   softmax_lse_accum[num_splits, num_heads, total_q]             contiguous
//
// i.e. split is the OUTERMOST axis. An earlier version of this put d innermost and
// split third, which is an equally dense layout but not the one the combine kernel
// is written against, so it would have produced plausible wrong numbers.
inline int64_t UpstreamPartialORowStride(UpstreamFA3Plan const& p) {
  return int64_t(p.head_dim);
}
inline int64_t UpstreamPartialOHeadStride(UpstreamFA3Plan const& p) {
  return int64_t(p.total_q) * p.head_dim;
}
inline int64_t UpstreamPartialOSplitStride(UpstreamFA3Plan const& p) {
  return UpstreamPartialOHeadStride(p) * p.num_qo_heads;
}
inline int64_t UpstreamPartialLSEHeadStride(UpstreamFA3Plan const& p) {
  return int64_t(p.total_q);
}
inline int64_t UpstreamPartialLSESplitStride(UpstreamFA3Plan const& p) {
  return UpstreamPartialLSEHeadStride(p) * p.num_qo_heads;
}
// Element counts for the two buffers, so the allocation and the strides come from
// one place.
inline int64_t UpstreamPartialOElems(UpstreamFA3Plan const& p) {
  return UpstreamPartialOSplitStride(p) * (p.num_splits > 0 ? p.num_splits : 1);
}
inline int64_t UpstreamPartialLSEElems(UpstreamFA3Plan const& p) {
  return UpstreamPartialLSESplitStride(p) * (p.num_splits > 0 ? p.num_splits : 1);
}

// Per-REQUEST split counts for the combine pass. It takes num_splits_dynamic_ptr as
// a per-batch array; passing nullptr makes it use the plan-wide maximum for every
// request, which would have it reduce uninitialised partials for any request that
// did not split. Derived from the same two quantities the epilogue uses, so the
// writer and the reader cannot disagree: the request's KV length in tokens
// (kv_indptr is in PAGES) divided by the chunk length.
// Takes PER-REQUEST KV lengths in tokens. It must not be derived from the plan's
// kv_indptr: that array is pushed once per WORK ITEM
// (scheduler.cuh:1583, inside the cluster loop), so differencing kv_indptr[b+1] and
// kv_indptr[b] subtracts two unrelated work items rather than bounding a request's
// pages. Reading it that way is what left 439/512 rows unwritten with the combine
// pass otherwise correctly wired.
//
// The division matches the epilogue's per-item ceil_div(kv_len, chunk_len) exactly, so
// the count the combine reduces is the count the epilogue wrote.
template <typename IdType>
__global__ void FillNumSplitsDynamic(IdType const* kv_lens_per_req, IdType const* len_kv_chunk,
                                     int* out, int num_requests) {
  const int b = blockIdx.x * blockDim.x + threadIdx.x;
  if (b >= num_requests) return;
  const int chunk_len = (len_kv_chunk != nullptr) ? int(len_kv_chunk[0]) : 0;
  const int kv_tokens = int(kv_lens_per_req[b]);
  int n = 1;
  if (chunk_len > 0 && kv_tokens > 0) n = (kv_tokens + chunk_len - 1) / chunk_len;
  out[b] = n < 1 ? 1 : n;
}

template <typename IdType>
inline cudaError_t LaunchFillNumSplitsDynamic(IdType const* kv_lens_per_req,
                                              IdType const* len_kv_chunk, int* out,
                                              int num_requests, cudaStream_t stream) {
  if (num_requests <= 0) return cudaSuccess;
  const int threads = 128;
  const int blocks = (num_requests + threads - 1) / threads;
  FillNumSplitsDynamic<IdType>
      <<<blocks, threads, 0, stream>>>(kv_lens_per_req, len_kv_chunk, out, num_requests);
  return cudaGetLastError();
}

// ---------------------------------------------------------------------------
// Split-KV reduction, upstream's own.
//
// flash-attention reduces split partials in a SEPARATE kernel
// (flash_fwd_combine_kernel.h, run_mha_fwd_combine), so its split path is two
// launches. Our port instantiates the mainloop with Split=true, which means the
// epilogue writes partials and final O stays untouched -- measured on fixture 2 as
// 511/512 unwritten rows with max_splits_fa3=2, the one correct row being the FA2
// decode row. So this pass is required for the port to be correct at all on a
// split plan, and it is also the fair parity reference: flash-attention pays the
// same second launch.
//
// Tile choice follows upstream's own dispatcher (flash_fwd_combine_launch_template.h:68):
// at head_dim 128, kBlockK = 128 so kBlockM = 8, and kBlockM == 8 forbids the
// kLogMaxSplits=4 branch, giving 5 (up to 32 splits).
template <int HeadDim>
using UpstreamCombineKernel =
    flash::FlashAttnFwdCombine<cute::Shape<cute::Int<8>, cute::Int<HeadDim>>,
                               /*kLogMaxSplits=*/5, /*kNThreads=*/256, /*AlignmentLSE=*/1,
                               /*IsEvenK=*/false, /*Varlen=*/true, cutlass::bfloat16_t, float,
                               cutlass::arch::Sm90>;

template <int HeadDim>
inline cudaError_t LaunchUpstreamCombine(UpstreamFA3Plan const& p, cutlass::bfloat16_t* ptr_O,
                                         float* ptr_LSE, float const* ptr_O_partial,
                                         float const* ptr_LSE_partial, cudaStream_t stream) {
  using CK = UpstreamCombineKernel<HeadDim>;
  using cute::_1;
  if (p.num_fa3_requests <= 0) return cudaSuccess;
  // Same layout as the epilogue wrote, expressed in this kernel's axis order:
  // O_partial is (tok, dv, split, head, batch) and LSE_partial is
  // (tok, split, head, batch). Both come from the shared stride helpers.
  typename CK::Arguments args{
      /*b=*/p.num_fa3_requests,
      ptr_O_partial,
      {p.total_q, p.head_dim, p.num_splits, p.num_qo_heads, 1},
      {UpstreamPartialORowStride(p), _1{}, UpstreamPartialOSplitStride(p),
       UpstreamPartialOHeadStride(p), 0},
      ptr_LSE_partial,
      {p.total_q, p.num_splits, p.num_qo_heads, 1},
      {_1{}, UpstreamPartialLSESplitStride(p), UpstreamPartialLSEHeadStride(p), 0},
      ptr_O,
      {p.o_stride_tok, _1{}, p.o_stride_head, 0},
      ptr_LSE,
      {_1{}, int64_t(p.total_q), 0},
      p.cu_seqlens_q,
      /*seqused=*/nullptr,
      p.num_splits_dynamic,
      p.fa3_batch_list,
      /*semaphore_to_reset=*/nullptr};

  typename CK::SchedulerArguments sched_args{p.num_fa3_requests,
                                             p.max_seqlen_q,
                                             // the FA3 subset, matching num_fa3_requests
                                             p.fa3_total_q > 0 ? p.fa3_total_q : p.total_q,
                                             p.num_qo_heads,
                                             p.num_kv_heads,
                                             p.head_dim,
                                             /*pack_gqa=*/true,
                                             p.cu_seqlens_q,
                                             /*seqused_q=*/nullptr,
                                             /*prepare_seqlen_q_ptr=*/nullptr,
                                             p.fa3_batch_list};

  typename CK::Params params{CK::to_underlying_arguments(args),
                             CK::TileScheduler::to_underlying_arguments(sched_args)};
  auto kernel = cutlass::device_kernel<CK>;
  int smem_size = CK::SharedStorageSize;
  if (smem_size >= 48 * 1024) {
    FLASHINFER_CUDA_CALL(
        cudaFuncSetAttribute(kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, smem_size));
  }
  dim3 grid = CK::TileScheduler::get_grid_shape(sched_args);
  kernel<<<grid, CK::MaxThreadsPerBlock, smem_size, stream>>>(params);
  return cudaGetLastError();
}

template <int HeadDim = 128, bool SplitKV = true>
inline typename UpstreamFA3Epilogue<HeadDim, SplitKV>::Arguments MakeUpstreamEpilogueArgs(
    UpstreamFA3Plan const& p, cutlass::bfloat16_t* ptr_O, float* ptr_O_partial, float* ptr_LSE,
    float* ptr_LSE_partial) {
  using EP = UpstreamFA3Epilogue<HeadDim, SplitKV>;
  using cute::_1;
  return typename EP::Arguments{
      // ShapeO and StrideO carry a FIFTH num_splits dimension under Split, and
      // StrideLSE is four-element (seqlen_q, head, batch, num_splits) -- see
      // epilogue_fwd.hpp:82-84. Writing the 4-/3-element forms compiles while the
      // header is merely included and only fails on instantiation.
      ptr_O,
      {p.total_q, p.head_dim, p.num_qo_heads, 1, p.num_splits},
      {p.o_stride_tok, _1{}, p.o_stride_head, 0, 0},
      ptr_O_partial,
      // Ordered (seq, d, head, batch, split) here; the combine pass wants the same
      // layout as (tok, dv, split, head, batch), which is why both are built from
      // the shared stride helpers above rather than written out twice.
      {UpstreamPartialORowStride(p), _1{}, UpstreamPartialOHeadStride(p), 0,
       UpstreamPartialOSplitStride(p)},
      ptr_LSE,
      {_1{}, int64_t(p.total_q), 0, 0},
      ptr_LSE_partial,
      // (seq, head, batch, split) with seq contiguous: stride_head = total_q,
      // stride_split = total_q*H. The previous split stride was total_q, which
      // collided with head 1.
      {_1{}, UpstreamPartialLSEHeadStride(p), 0, UpstreamPartialLSESplitStride(p)},
      p.num_kv_heads,
      p.cu_seqlens_q,
      nullptr};
}

// Ragged -> dense page table, device side.
//
// Upstream indexes page_table[bidb * stride + block]; sglang stores kv_indices
// packed back to back behind kv_indptr. This scatters the former from the latter
// into a caller-preallocated buffer, which is what keeps it CUDA-graph safe: no
// allocation, no host round trip, and a launch geometry that depends only on
// (batch, max_pages) rather than on the batch's contents.
//
// Rows are padded with -1 rather than 0. Zero is a VALID page id, so padding with
// it would make a short request silently read page 0 for its tail blocks instead
// of reading nothing -- a wrong answer rather than a fault. Upstream never
// addresses past seqused_k, so the padding should never be dereferenced; -1 means
// that if it ever is, the fault is immediate and attributable.
template <typename IdType>
__global__ void ScatterRaggedPageTable(IdType const* __restrict__ kv_indptr,
                                       IdType const* __restrict__ kv_indices,
                                       IdType* __restrict__ dense, int batch, int max_pages) {
  const int b = blockIdx.x;
  if (b >= batch) return;
  const int begin = int(kv_indptr[b]);
  const int n = int(kv_indptr[b + 1]) - begin;
  IdType* row = dense + size_t(b) * size_t(max_pages);
  for (int i = threadIdx.x; i < max_pages; i += blockDim.x) {
    row[i] = (i < n) ? kv_indices[begin + i] : IdType(-1);
  }
}

template <typename IdType>
inline cudaError_t LaunchScatterRaggedPageTable(IdType const* kv_indptr,
                                                IdType const* kv_indices, IdType* dense,
                                                int batch, int max_pages, cudaStream_t stream) {
  if (batch <= 0 || max_pages <= 0) return cudaSuccess;
  ScatterRaggedPageTable<IdType><<<batch, 256, 0, stream>>>(kv_indptr, kv_indices, dense, batch,
                                                            max_pages);
  return cudaGetLastError();
}

// The whole point of conforming to upstream's scheduler interface: its kernel is
// templated on the scheduler, so plugging ours in yields upstream's ENTIRE body --
// warp specialisation, pipelines, producer/consumer loops, IntraWGOverlap -- with
// no rewrite, while our plan still decides which CTA does which work.
template <int HeadDim = 128, typename IdType = int32_t>
using UpstreamFA3Kernel = flash::FlashAttnFwdSm90<UpstreamFA3Mainloop<HeadDim>,
                                                  UpstreamFA3Epilogue<HeadDim>,
                                                  UpstreamFA3SchedulerAdapter<IdType>>;

// The same kernel driven by UPSTREAM'S scheduler instead of our adapter. This is
// flash-attention unmodified end to end, so it is the known-good baseline the adapter
// should have been measured against before being trusted. Defined after
// UpstreamOwnScheduler, below.


// WORKSPACE the port needs, which the existing buffers cannot supply.
//
// Upstream's ElementPartial is **float** (epilogue_fwd.hpp:30) while our
// partial_o is DTypeO, i.e. bf16. They cannot share a buffer: handing upstream
// our bf16 partials would have it write floats over half as many elements as it
// thinks it owns, corrupting whatever follows -- silently, since nothing checks.
// So the port allocates its own, and the sizes are:
//
//   partial O   : total_q * head_dim * num_splits * sizeof(float)
//   partial LSE : total_q * num_qo_heads * num_splits * sizeof(float)
//   page table  : batch * max_pages_per_seq * sizeof(int32_t)
//
// At 8192 tokens, head_dim 128, 28 qo heads, num_splits 1 and 64 requests at
// page_size 1 that is 4 MiB + 0.9 MiB + 2 MiB. Modest, but it is additional
// workspace that the ext and the sglang backend must both size, and it has to be
// preallocated rather than grown per step to stay CUDA-graph safe.
//
// Build the kernel Params DIRECTLY rather than through
// FlashAttnFwdSm90::to_underlying_arguments.
//
// That path cannot be used: upstream's kernel Arguments hardcodes
// flash::TileSchedulerArguments for its scheduler field and feeds it to
// TileScheduler::to_underlying_arguments, so a scheduler with its own argument
// type does not fit through it. The alternatives were to fork upstream's headers
// or to smuggle our plan pointers through fields meant for something else; both
// are worse than assembling Params here, since Params is a plain aggregate of
// {mainloop, epilogue, hw_info, scheduler} and the two collectives expose their
// own to_underlying_arguments.
template <int HeadDim = 128, typename IdType = int32_t>
inline typename UpstreamFA3Kernel<HeadDim, IdType>::Params MakeUpstreamFA3Params(
    typename UpstreamFA3Mainloop<HeadDim>::Arguments const& ml,
    typename UpstreamFA3Epilogue<HeadDim>::Arguments const& ep,
    typename UpstreamFA3SchedulerAdapter<IdType>::Params const& sched, int sm_count) {
  // Aggregate-initialise: the collectives' Params hold const members, so their
  // copy-assignment is deleted and field-by-field assignment will not compile.
  cutlass::KernelHardwareInfo hw{};
  hw.sm_count = sm_count;
  return typename UpstreamFA3Kernel<HeadDim, IdType>::Params{
      UpstreamFA3Mainloop<HeadDim>::to_underlying_arguments(ml),
      UpstreamFA3Epilogue<HeadDim>::to_underlying_arguments(ep), hw, sched};
}

// Our scheduler's Params from the plan pointers the ext fills. Separate from
// make_unified_wgmma_args because the upstream adapter needs a different subset:
// block_idx/bidh/bidb/split_idx rather than the 8-field tuple flashinfer's body
// destructures.
// UPSTREAM'S OWN SCHEDULER, as an alternative to the adapter above.
//
// Reason this exists: every numerical fault in this port has been in the adapter or in
// the descriptors handed to it -- the zero KV page stride, per-work-item arrays where
// per-request was wanted, the combine pass's batch list. The mainloop and epilogue are
// upstream's and have never been implicated. Replacing a working scheduler with our own
// and debugging forward was the wrong order; running upstream's configuration first gives
// a known-good baseline to change ONE thing against.
//
// TileSchedulerArguments already accepts everything the plan now carries:
//   varlen_batch_idx_ptr  <- the requests the planner routed to the wgmma queue
//   cu_seqlens            <- per-request q_indptr
//   seqused               <- per-request KV lengths
//   num_splits_dynamic_ptr<- per-request split counts
// and it takes seqlen_k / headdim / element_size so upstream applies its OWN L2
// swizzling, which is the behaviour we wanted to keep anyway.
//
// What our plan still decides is which REQUESTS each executor serves -- the 4-mode
// assignment -- while upstream schedules tiles within its own queue. That is the split
// the two-executor design needs; it does not need us to own FA3's tile order.
// Template order is <kBlockM, kBlockN, NumMmaThreads, NumProducerThreads, Split, PackGQA,
// WarpSpecialized, LPT, Sort, Prepared>. 256 mma + 128 producer threads is FA3's own
// 384-thread warp specialisation.
//
// LPT=true is upstream's own longest-processing-time ordering, which is what we wanted to
// keep -- it comes with the L2 swizzling the scheduler derives from seqlen_k / headdim /
// element_size, so using upstream's scheduler does not give up either property.
//
// Prepared=false because that path expects num_m_blocks_ptr precomputed on device, which
// we do not supply.
template <int HeadDim = 128, bool SplitKV = true>
// Derived from the mainloop rather than hardcoded, because hardcoding these is how the
// port drifted from upstream before. Upstream computes each of them
// (flash_fwd_launch_template.h:60-66):
//
//   NumMmaThreads       = CollectiveMainloop::NumMmaThreads
//   NumProducerThreads  = CollectiveMainloop::NumProducerThreads, which is
//                         (!Transpose_V && Use_TMA_KV && Use_TMA_Q) ? 32 : 128
//                         (mainloop_fwd_sm90:121). This resolves to 128 for us on BOTH the
//                         cp.async and the TMA paged path, because Use_TMA_Q = !PackGQA
//                         (mainloop_fwd_sm90:56) and we run PackGQA=true -- packed GQA
//                         cannot load Q through TMA, so the single-producer-warp form is
//                         unreachable here and the old hardcoded 128 was correct. Derived
//                         anyway: it stops being correct the moment PackGQA is turned off.
//   LPT                 = Is_causal || Is_local  -> false for us. Despite the name this is
//                         an L2-locality choice, not longest-processing-time: the LPT branch
//                         (tile_scheduler.hpp:686) groups heads that share KV in L2, and
//                         under Prepared=false with PackGQA its nheads_in_l2 degenerates to
//                         1, so it orders all m_blocks of one head before the next head.
//                         LPT=false orders heads first instead. Which wins is an L2 question
//                         and is measured, not assumed; upstream's choice here is false.
//   Sort                = !Is_local              -> true for us, but INERT: the scheduler
//                         only consults it under `Prepared && Sort`
//                         (tile_scheduler.hpp:566), and we run Prepared=false. Set to
//                         upstream's value so the two cannot disagree if Prepared changes.
//
// Overridable only so the previous values can be A/B'd; the defaults are upstream's.
#ifndef FLASHINFER_FA3_SCHED_LPT
#define FLASHINFER_FA3_SCHED_LPT FLASHINFER_FA3_CAUSAL  // upstream: LPT = Is_causal || Is_local
#endif
#ifndef FLASHINFER_FA3_SCHED_SORT
#define FLASHINFER_FA3_SCHED_SORT 1
#endif
using UpstreamOwnScheduler = flash::VarlenDynamicPersistentTileScheduler<
    /*kBlockM=*/128, /*kBlockN=*/128,
    /*NumMmaThreads=*/UpstreamFA3Mainloop<128>::NumMmaThreads,
    /*NumProducerThreads=*/UpstreamFA3Mainloop<128>::NumProducerThreads, SplitKV,
    /*PackGQA=*/true, /*WarpSpecialized=*/true,
    /*LPT=*/bool(FLASHINFER_FA3_SCHED_LPT), /*Sort=*/bool(FLASHINFER_FA3_SCHED_SORT),
    /*Prepared=*/false>;

// The port's own expectations about the mainloop, asserted rather than assumed. If a trait
// change moves either count, the kernel's thread layout and the scheduler's barrier arrival
// counts must move together, and a mismatch there is silent.
static_assert(UpstreamFA3Mainloop<128>::NumMmaThreads == 256,
              "the FA3 executor's launch geometry assumes 2 MMA warpgroups");
// 128 because Use_TMA_Q = !PackGQA is false under packed GQA, which makes the
// single-producer-warp form unreachable regardless of the KV path. If PackGQA is ever
// turned off this drops to 32 on the TMA path and the launch geometry must follow.
static_assert(UpstreamFA3Mainloop<128>::NumProducerThreads == 128,
              "packed GQA forces the 128-thread producer form, per mainloop_fwd_sm90:56,121");

template <int HeadDim = 128, bool SplitKV = true>
using UpstreamFA3KernelOwnSched =
    flash::FlashAttnFwdSm90<UpstreamFA3Mainloop<HeadDim, SplitKV>, UpstreamFA3Epilogue<HeadDim, SplitKV>,
                            UpstreamOwnScheduler<HeadDim, SplitKV>>;

inline flash::TileSchedulerArguments MakeUpstreamOwnSchedArgs(UpstreamFA3Plan const& p,
                                                              int* tile_count_semaphore) {
  const int qhead_per_khead = p.num_kv_heads > 0 ? p.num_qo_heads / p.num_kv_heads : 1;
  return flash::TileSchedulerArguments{
      /*num_blocks=*/cute::ceil_div(p.max_seqlen_q * qhead_per_khead, 128),
      // PackGQA is on, so num_head is num_head_K per the struct's own comment.
      /*num_head=*/p.num_kv_heads,
      /*num_batch=*/p.num_fa3_requests,
      /*num_splits=*/p.num_splits,
      /*qhead_per_khead=*/qhead_per_khead,
      /*seqlen=*/p.max_seqlen_q,
      /*seqlen_k=*/p.max_seqlen_q,
      /*headdim=*/p.head_dim,
      /*headdim_v=*/p.head_dim,
      /*element_size=*/int(sizeof(cutlass::bfloat16_t)),
      tile_count_semaphore,
      p.cu_seqlens_q,
      // `seqused` is the QUERY length per request -- the scheduler feeds it straight into
      // num_m_blocks = ceil_div(seqused[b] * qhead_per_khead, kBlockM)
      // (tile_scheduler.hpp:599-621, the Prepared=false branch). This passed `seqused_k`,
      // so m-blocks were sized from the KV length: at q=2048 the correct count is 112, and
      // kv=100352 gave ceil_div(100352*7,128) = 5488, a 49x bloat. Multiplied by the
      // n-block count (itself proportional to KV) that made total work Theta(kv^2) instead
      // of Theta(kv) -- measured as us/kv^2 constant to 2.1% over a 9.8x KV range, and as a
      // 39x gap on the TraceLab batch against a predicted 41x.
      //
      // The surplus m-blocks address q rows past the request's end, which the epilogue
      // masks, so the output stayed CORRECT and only the time was wrong. That is why every
      // numerics gate passed while the kernel ran 31x slow.
      //
      // nullptr is the right value rather than a seqused_q array: with `seqused == nullptr`
      // the scheduler differences `cu_seqlens` (tile_scheduler.hpp:610-613), and
      // cu_seqlens_q is already supplied and already per-request, so it yields the exact
      // query length. The mainloop keeps getting seqused_k through its own arguments; this
      // was only the scheduler's copy.
      /*seqused=*/nullptr,
      p.num_splits_dynamic,
      /*num_m_blocks_ptr=*/nullptr,
      p.fa3_batch_list,
      /*num_nheads_in_l2_ptr=*/nullptr};
}

template <typename IdType>
inline typename UpstreamFA3SchedulerAdapter<IdType>::Params make_unified_wgmma_upstream_sched(
    UnifiedWgmmaPlanPtrs<IdType> const& p) {
  return typename UpstreamFA3SchedulerAdapter<IdType>::Params{
      p.work_indptr, p.q_start,          p.kv_head_idx,      p.batch_idx,
      p.kv_start,    p.kv_len,           p.len_kv_chunk,     p.q_indptr_per_req,
      p.num_qo_heads / (p.num_kv_heads > 0 ? p.num_kv_heads : 1u), p.cta_tile_q};
}

// Launch upstream FA3 with upstream's own scheduler. Mirrors run_flash_fwd in
// flash_fwd_launch_template.h: Params is assembled from the three collectives'
// to_underlying_arguments, the grid comes from the scheduler, and the kernel entry is
// cutlass::device_kernel<K> -- so no kernel of ours sits between flash-attention and the
// hardware.
//
// tile_count_semaphore must be a device int, zeroed per launch: the dynamic persistent
// scheduler hands out tiles through it.
template <int HeadDim = 128, bool SplitKV = true>
inline cudaError_t LaunchUpstreamFA3OwnSched(
    typename UpstreamFA3Mainloop<HeadDim, SplitKV>::Arguments const& mainloop_args,
    typename UpstreamFA3Epilogue<HeadDim, SplitKV>::Arguments const& epilogue_args,
    flash::TileSchedulerArguments const& sched_args, int sm_count, cudaStream_t stream) {
  using K = UpstreamFA3KernelOwnSched<HeadDim, SplitKV>;
  cutlass::KernelHardwareInfo hw_info{};
  hw_info.sm_count = sm_count;
  typename K::Params params{
      UpstreamFA3Mainloop<HeadDim, SplitKV>::to_underlying_arguments(mainloop_args),
      UpstreamFA3Epilogue<HeadDim, SplitKV>::to_underlying_arguments(epilogue_args), hw_info,
      K::TileScheduler::to_underlying_arguments(sched_args)};

  auto kernel = cutlass::device_kernel<K>;
  int smem_size = K::SharedStorageSize;
  if (smem_size >= 48 * 1024) {
    FLASHINFER_CUDA_CALL(
        cudaFuncSetAttribute(kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, smem_size));
  }
  dim3 grid = K::get_grid_shape(params);
  dim3 block = K::get_block_shape();
  if constexpr (FLASHINFER_FA3_CLUSTER_M > 1) {
    // Clusters must be launched, not merely declared: a plain <<<>>> ignores the
    // ClusterShape and the kernel runs with no cluster, which is what left DSMEM
    // unreachable. Mirrors flash_fwd_launch_template.h:187-189.
    dim3 cluster_dims(cute::size<0>(UpstreamFA3ClusterShape{}),
                      cute::size<1>(UpstreamFA3ClusterShape{}),
                      cute::size<2>(UpstreamFA3ClusterShape{}));
    cutlass::ClusterLaunchParams launch_params{grid, block, cluster_dims, smem_size, stream};
    cutlass::Status st =
        cutlass::launch_kernel_on_cluster(launch_params, (void const*)kernel, params);
    if (st != cutlass::Status::kSuccess) return cudaErrorLaunchFailure;
  } else {
    kernel<<<grid, block, smem_size, stream>>>(params);
  }
  return cudaGetLastError();
}

}  // namespace flashinfer

#endif  // FLASHINFER_ATTENTION_HOPPER_FA3_UPSTREAM_CUH_

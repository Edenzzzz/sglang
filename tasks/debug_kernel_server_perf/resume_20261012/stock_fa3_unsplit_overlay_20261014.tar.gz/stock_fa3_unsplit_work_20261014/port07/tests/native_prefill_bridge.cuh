#pragma once

#include <flashinfer/attention/prefill.cuh>
#include <flashinfer/attention/scheduler.cuh>
#include <flashinfer/attention/variants.cuh>

struct NativePagedParams {
  using DTypeQ = __nv_bfloat16;
  using DTypeKV = __nv_bfloat16;
  using DTypeO = __nv_bfloat16;
  using IdType = int32_t;

  DTypeQ* q = nullptr;
  flashinfer::paged_kv_t<DTypeKV, IdType> paged_kv;
  IdType* q_indptr = nullptr;
  DTypeO* o = nullptr;
  float* lse = nullptr;
  flashinfer::uint_fastdiv group_size;
  double sm_scale = 0;
  double logits_soft_cap = 0;
  double rope_rcp_scale = 1;
  double rope_rcp_theta = 0.0001;
  uint32_t num_qo_heads = 0;
  IdType q_stride_n = 0;
  IdType q_stride_h = 0;
  uint32_t k_sf_stride_page = 0, k_sf_stride_n = 0, k_sf_stride_h = 0;
  uint32_t v_sf_stride_page = 0, v_sf_stride_n = 0, v_sf_stride_h = 0;
  int32_t window_left = -1;
  IdType* request_indices = nullptr;
  IdType* qo_tile_indices = nullptr;
  IdType* kv_tile_indices = nullptr;
  IdType* merge_indptr = nullptr;
  IdType* o_indptr = nullptr;
  bool* block_valid_mask = nullptr;
  IdType* kv_chunk_size_ptr = nullptr;
  uint32_t max_total_num_rows = 0;
  uint32_t* total_num_rows = nullptr;
  uint32_t padded_batch_size = 0;
  bool partition_kv = false;
  bool independent_pdl = false;
  unsigned long long* pdl_timeline = nullptr;

  __host__ __device__ __forceinline__ uint32_t get_qo_len(uint32_t batch_idx) const {
    return q_indptr[batch_idx + 1] - q_indptr[batch_idx];
  }

  __host__ __device__ __forceinline__ uint32_t get_kv_len(uint32_t batch_idx) const {
    return paged_kv.get_length(batch_idx);
  }
};

void native_fa2_run(at::Tensor q, at::Tensor k_cache, at::Tensor v_cache,
                    at::Tensor qo_indptr, at::Tensor kv_indptr, at::Tensor kv_indices,
                    at::Tensor last_page_len, at::Tensor output, at::Tensor lse,
                    at::Tensor float_workspace, at::Tensor int_workspace,
                    std::vector<int64_t> plan_values, double sm_scale,
                    bool enable_pdl, bool independent_pdl, at::Tensor timeline) {
  TORCH_CHECK(q.is_cuda() && q.dim() == 3 && q.size(2) == 128,
              "native FA2 bridge requires CUDA Q with head dimension 128");
  TORCH_CHECK(q.scalar_type() == at::kBFloat16 && k_cache.scalar_type() == at::kBFloat16 &&
              v_cache.scalar_type() == at::kBFloat16 && output.scalar_type() == at::kBFloat16,
              "native FA2 bridge supports bf16 only");
  TORCH_CHECK(output.sizes() == q.sizes() && output.is_contiguous(),
              "native FA2 output must be contiguous and match Q");
  TORCH_CHECK(!independent_pdl || enable_pdl, "independent work requires a PDL launch");
  for (const auto& tensor : {k_cache, v_cache, qo_indptr, kv_indptr, kv_indices,
                            last_page_len, output, lse, float_workspace, int_workspace, timeline}) {
    TORCH_CHECK(tensor.is_cuda() && tensor.device() == q.device(), "CUDA device mismatch");
  }
  for (const auto& tensor : {qo_indptr, kv_indptr, kv_indices, last_page_len}) {
    TORCH_CHECK(tensor.scalar_type() == at::kInt && tensor.is_contiguous(),
                "native FA2 index tensors must be contiguous int32");
  }
  TORCH_CHECK(float_workspace.scalar_type() == at::kByte &&
              int_workspace.scalar_type() == at::kByte &&
              float_workspace.is_contiguous() && int_workspace.is_contiguous(),
              "native FA2 workspaces must be contiguous byte buffers");
  TORCH_CHECK(timeline.numel() == 0 ||
              (timeline.scalar_type() == at::kLong && timeline.numel() == 4 && timeline.is_contiguous()),
              "PDL timeline must be empty or four int64 values");
  if (k_cache.dim() == 3) k_cache = k_cache.unsqueeze(1);
  if (v_cache.dim() == 3) v_cache = v_cache.unsqueeze(1);
  TORCH_CHECK(k_cache.dim() == 4 && v_cache.sizes() == k_cache.sizes() &&
              k_cache.size(3) == 128 && k_cache.stride(3) == 1 && v_cache.stride(3) == 1,
              "native FA2 bridge requires NHD paged caches with head dimension 128");
  const int64_t batch = kv_indptr.numel() - 1;
  const int64_t heads = q.size(1), kv_heads = k_cache.size(2);
  TORCH_CHECK(batch > 0 && qo_indptr.numel() == batch + 1 && last_page_len.numel() == batch,
              "native FA2 batch metadata mismatch");
  TORCH_CHECK(kv_heads > 0 && heads % kv_heads == 0, "invalid GQA head counts");
  TORCH_CHECK(lse.numel() == 0 ||
              (lse.scalar_type() == at::kFloat && lse.numel() == q.size(0) * heads && lse.is_contiguous()),
              "invalid native FA2 LSE buffer");
  const c10::cuda::OptionalCUDAGuard device_guard(q.device());
  const cudaStream_t stream = c10::cuda::getCurrentCUDAStream();
  flashinfer::PrefillPlanInfo plan;
  plan.FromVector(plan_values);
  TORCH_CHECK(plan.total_num_rows >= q.size(0), "native FA2 plan has too few output rows");
  void* integer_buffer = int_workspace.data_ptr();
  void* float_buffer = float_workspace.data_ptr();
  NativePagedParams params{};
  params.q = static_cast<__nv_bfloat16*>(q.data_ptr());
  params.paged_kv = flashinfer::paged_kv_t<__nv_bfloat16, int32_t>(
      kv_heads, k_cache.size(1), 128, batch, flashinfer::QKVLayout::kNHD,
      static_cast<__nv_bfloat16*>(k_cache.data_ptr()),
      static_cast<__nv_bfloat16*>(v_cache.data_ptr()),
      k_cache.strides().data(), v_cache.strides().data(), kv_indices.data_ptr<int32_t>(),
      kv_indptr.data_ptr<int32_t>(), last_page_len.data_ptr<int32_t>());
  params.q_indptr = qo_indptr.data_ptr<int32_t>();
  params.o = static_cast<__nv_bfloat16*>(output.data_ptr());
  params.lse = lse.numel() == 0 ? nullptr : lse.data_ptr<float>();
  params.num_qo_heads = heads;
  params.group_size = flashinfer::uint_fastdiv(heads / kv_heads);
  params.q_stride_n = q.stride(0);
  params.q_stride_h = q.stride(1);
  params.sm_scale = sm_scale;
  params.request_indices = flashinfer::GetPtrFromBaseOffset<int32_t>(integer_buffer, plan.request_indices_offset);
  params.qo_tile_indices = flashinfer::GetPtrFromBaseOffset<int32_t>(integer_buffer, plan.qo_tile_indices_offset);
  params.kv_tile_indices = flashinfer::GetPtrFromBaseOffset<int32_t>(integer_buffer, plan.kv_tile_indices_offset);
  params.o_indptr = flashinfer::GetPtrFromBaseOffset<int32_t>(integer_buffer, plan.o_indptr_offset);
  params.kv_chunk_size_ptr = flashinfer::GetPtrFromBaseOffset<int32_t>(integer_buffer, plan.kv_chunk_size_ptr_offset);
  params.padded_batch_size = plan.padded_batch_size;
  params.max_total_num_rows = plan.total_num_rows;
  params.independent_pdl = independent_pdl;
  params.pdl_timeline = timeline.numel() == 0 ? nullptr :
      reinterpret_cast<unsigned long long*>(timeline.data_ptr<int64_t>());
  __nv_bfloat16* temporary_output = nullptr;
  float* temporary_lse = nullptr;
  if (plan.split_kv) {
    params.merge_indptr = flashinfer::GetPtrFromBaseOffset<int32_t>(integer_buffer, plan.merge_indptr_offset);
    temporary_output = flashinfer::GetPtrFromBaseOffset<__nv_bfloat16>(float_buffer, plan.v_offset);
    temporary_lse = flashinfer::GetPtrFromBaseOffset<float>(float_buffer, plan.s_offset);
    if (plan.enable_cuda_graph) {
      params.block_valid_mask = flashinfer::GetPtrFromBaseOffset<bool>(integer_buffer, plan.block_valid_mask_offset);
    }
  }
  if (plan.enable_cuda_graph) {
    params.total_num_rows = flashinfer::GetPtrFromBaseOffset<uint32_t>(integer_buffer, plan.total_num_rows_offset);
  }
  bool equal_strides = k_cache.strides() == v_cache.strides();
  using NativeAttention = flashinfer::DefaultAttention<false, false, false, false>;
  cudaError_t status = cudaSuccess;
  auto launch = [&](auto stride_tag) {
    constexpr bool SAME_KV_STRIDES = decltype(stride_tag)::value;
    DISPATCH_CTA_TILE_Q(plan.cta_tile_q, CTA_TILE_Q, {
      status = flashinfer::BatchPrefillWithPagedKVCacheDispatched<
          SAME_KV_STRIDES, CTA_TILE_Q, 128, 128, flashinfer::PosEncodingMode::kNone,
          false, flashinfer::MaskMode::kCausal, NativeAttention, NativePagedParams>(
          params, temporary_output, temporary_lse, enable_pdl, stream);
    });
  };
  if (equal_strides) launch(std::true_type{});
  else launch(std::false_type{});
  TORCH_CHECK(status == cudaSuccess, "native FA2 launch failed: ", cudaGetErrorString(status));
}
